# Vikalink Enterprise PostgreSQL Database Architecture

## 1. Architecture Overview

This database architecture decouples the frontend application code from all customer, domain, hosting, invoice, and payment state. When application updates are deployed via GitHub → Netlify, **no customer records are reset or modified**.

```
                         GITHUB
                           │
                     Application Code
                           │
                           ▼
                        NETLIFY
              ┌────────────┼────────────┐
              │            │            │
           Frontend     Functions     AI/Agents
              │            │
              │            ▼
              │       PostgreSQL (Netlify / Neon / Cloud SQL)
              │            │
              │     ┌──────┴───────┐
              │     │              │
              │ Customers       Billing
              │ Domains         Orders
              │ Hosting         Payments
              │ Carts           Services
              │ Invoices        Settings
              │
              ▼
         CUSTOMER WEBSITE
              │
              ▼
       SECURE SERVER APIs
              │
       ┌──────┼──────────────┐
       ▼      ▼              ▼
    cPanel   WHM        Domain Registrar
                         APIs
```

---

## 2. Directory Structure

```text
/database
├── schema.sql                     # Full PostgreSQL DDL (Tables, Indexes, Foreign Keys, Constraints)
├── seed.sql                       # Default TLD pricing, hosting packages, server nodes, email templates
├── migrations/
│   └── 001_initial_schema.sql     # Idempotent migration wrapper
└── README.md                      # Deployment & setup documentation
```

---

## 3. Database Tables Breakdown

### Core Modules:
1. **Users & Customers (`users`, `customers`, `user_sessions`)**:
   - Stores authentication credentials, hashed passwords, 2FA settings, contact addresses, and customer wallet balances.
2. **Multi-Tenant Carts (`carts`, `cart_items`)**:
   - Resolves cross-customer cart leakage. Every cart item is bound to the customer's `customer_id` or isolated session token.
3. **TLDs & Registered Domains (`tld_pricing`, `registered_domains`, `domain_contacts`, `domain_dns_records`, `domain_activities`)**:
   - Tracks domain ownership, nameservers, DNS zone records, WHOIS contact handles, and real-time registrar sync status.
4. **Hosting Infrastructure (`hosting_servers`, `hosting_packages`, `hosting_subscriptions`, `hosting_provisioning_queue`)**:
   - Manages cPanel/WHM server nodes, allocated NVMe/Bandwidth quotas, active subscriptions, and background provisioning queues.
5. **Orders, Invoices & Payments (`orders`, `order_items`, `invoices`, `invoice_items`, `payments`, `wallet_transactions`)**:
   - Records every transaction, Mobile Money reference, Paystack authorization, and staff manual approval audit.
6. **Support & System (`support_tickets`, `ticket_replies`, `system_settings`, `email_templates`, `audit_logs`)**:
   - Full support ticketing system, dynamic email layouts, and tamper-proof privileged audit logs.

---

## 4. How to Deploy to Netlify Database / PostgreSQL

### Step 1: Provision your PostgreSQL Database
- In **Netlify**, go to your site dashboard → **Data & Storage** → **Netlify DB (Postgres)**.
- Or use any managed PostgreSQL instance (**Neon**, **Supabase**, **Cloud SQL**, **RDS**).

### Step 2: Configure Environment Variables in Netlify
In Netlify Site Settings → **Environment Variables**, set:

```env
DATABASE_URL=postgresql://vikalink_user:your_password@ep-host.region.aws.neon.tech/vikalink_db?sslmode=require
JWT_SECRET=your_super_secret_jwt_encryption_key
WHM_HOST=srv1.celoxaghana.online
WHM_API_TOKEN=your_whm_remote_access_token
PAYSTACK_SECRET_KEY=sk_live_...
```

### Step 3: Run the Initial Schema
Using `psql` or the Netlify DB console:

```bash
# Execute the complete schema
psql "$DATABASE_URL" -f database/schema.sql

# Seed initial TLDs and Hosting Packages
psql "$DATABASE_URL" -f database/seed.sql
```

---

## 5. Migration Safety Rules

1. **Never Drop Production Tables**: Always use `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` for future schema expansions.
2. **Atomic Transactions**: Wrap migrations in `BEGIN; ... COMMIT;`.
3. **Version Tracking**: The `schema_migrations` table records executed migration versions to prevent duplicate execution.
