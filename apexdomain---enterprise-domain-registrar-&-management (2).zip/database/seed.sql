-- =====================================================================
-- VIKALINK ENTERPRISE SEED DATA
-- Default TLD Catalogs, Hosting Packages, Email Templates & Settings
-- =====================================================================

-- 1. SEED TLD PRICING (Ghana & Global TLDs)
INSERT INTO tld_pricing (tld, register_price, renew_price, transfer_price, currency, is_popular, is_ghana_special, grace_period_days, redemption_period_days)
VALUES
    ('.com.gh', 120.00, 120.00, 95.00, 'GHS', TRUE, TRUE, 30, 30),
    ('.gh', 350.00, 350.00, 300.00, 'GHS', TRUE, TRUE, 30, 30),
    ('.org.gh', 120.00, 120.00, 95.00, 'GHS', FALSE, TRUE, 30, 30),
    ('.edu.gh', 150.00, 150.00, 120.00, 'GHS', FALSE, TRUE, 30, 30),
    ('.gov.gh', 200.00, 200.00, 180.00, 'GHS', FALSE, TRUE, 30, 30),
    ('.com', 215.00, 245.00, 210.00, 'GHS', TRUE, FALSE, 30, 30),
    ('.net', 240.00, 260.00, 230.00, 'GHS', TRUE, FALSE, 30, 30),
    ('.org', 225.00, 250.00, 220.00, 'GHS', TRUE, FALSE, 30, 30),
    ('.online', 45.00, 310.00, 190.00, 'GHS', TRUE, FALSE, 30, 30),
    ('.store', 55.00, 350.00, 210.00, 'GHS', FALSE, FALSE, 30, 30),
    ('.tech', 65.00, 360.00, 220.00, 'GHS', FALSE, FALSE, 30, 30),
    ('.io', 550.00, 580.00, 520.00, 'GHS', TRUE, FALSE, 30, 30),
    ('.ai', 1100.00, 1100.00, 990.00, 'GHS', TRUE, FALSE, 30, 30),
    ('.africa', 190.00, 220.00, 180.00, 'GHS', TRUE, FALSE, 30, 30)
ON CONFLICT (tld) DO UPDATE SET
    register_price = EXCLUDED.register_price,
    renew_price = EXCLUDED.renew_price,
    transfer_price = EXCLUDED.transfer_price;

-- 2. SEED HOSTING PACKAGES
INSERT INTO hosting_packages (id, name, slug, category, disk_limit_mb, bandwidth_limit_gb, max_ftp_accounts, max_email_accounts, max_databases, max_subdomains, price_monthly, price_annually, currency, features)
VALUES
    (
        'pkg-starter', 
        'Starter cPanel Cloud', 
        'starter-cpanel-cloud', 
        'cPanel Hosting', 
        5120, 
        50, 
        2, 
        5, 
        2, 
        5, 
        45.00, 
        450.00, 
        'GHS', 
        '["5 GB NVMe SSD Storage", "50 GB Monthly Bandwidth", "Free Let''s Encrypt SSL", "1-Click WordPress Installer", "Daily Automated Backups", "5 Business Email Accounts"]'::jsonb
    ),
    (
        'pkg-business', 
        'Business Pro NVMe', 
        'business-pro-nvme', 
        'cPanel Hosting', 
        20480, 
        250, 
        10, 
        25, 
        10, 
        20, 
        95.00, 
        950.00, 
        'GHS', 
        '["20 GB High-Speed NVMe Storage", "250 GB Monthly Bandwidth", "Free Wildcard SSL", "LiteSpeed Web Server Cache", "Staging Environment", "25 Business Email Accounts", "Malware Scanner & Cleanup"]'::jsonb
    ),
    (
        'pkg-enterprise', 
        'Enterprise Cloud Fleet', 
        'enterprise-cloud-fleet', 
        'cPanel Hosting', 
        51200, 
        1000, 
        50, 
        100, 
        50, 
        50, 
        185.00, 
        1850.00, 
        'GHS', 
        '["50 GB Dedicated NVMe Storage", "1 TB High-Speed Bandwidth", "Free Premium EV SSL", "Dedicated Cloud IP Address", "Unlimited Databases", "Priority 24/7 Phone & WhatsApp Support", "Automated Hourly Snapshots"]'::jsonb
    )
ON CONFLICT (id) DO UPDATE SET
    price_monthly = EXCLUDED.price_monthly,
    price_annually = EXCLUDED.price_annually,
    features = EXCLUDED.features;

-- 3. SEED DEFAULT HOSTING SERVER NODE
INSERT INTO hosting_servers (name, hostname, ip_address, provider, api_port, is_ssl, nameserver1, nameserver2, max_accounts, active_accounts)
VALUES
    (
        'Accra Premium Node #1', 
        'srv1.celoxaghana.online', 
        '102.130.112.55', 
        'cpanel', 
        2087, 
        TRUE, 
        'ns1.celoxaghana.online', 
        'ns2.celoxaghana.online', 
        300, 
        12
    )
ON CONFLICT (hostname) DO NOTHING;

-- 4. SEED EMAIL TEMPLATES
INSERT INTO email_templates (id, name, subject, body_html, variables)
VALUES
    (
        'order_confirmed',
        'Order Confirmation',
        'Your Order #{{order_number}} on Vikalink is Confirmed',
        '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #1e293b;"><h2 style="color: #4f46e5;">Order Confirmed</h2><p>Dear {{customer_name}},</p><p>Thank you for choosing Vikalink. We have received your order <strong>#{{order_number}}</strong> for <strong>GHS {{total_amount}}</strong>.</p><p>Please find your invoice attached or view it directly in your Client Portal.</p></div>',
        '["customer_name", "order_number", "total_amount", "invoice_url"]'::jsonb
    ),
    (
        'cpanel_provisioned',
        'cPanel Account Details',
        'Your Web Hosting Account for {{domain_name}} is Ready',
        '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #1e293b;"><h2 style="color: #059669;">Your Hosting is Active</h2><p>Dear {{customer_name}},</p><p>Your hosting account for <strong>{{domain_name}}</strong> has been provisioned successfully on server <strong>{{server_node}}</strong>.</p><p><strong>cPanel Username:</strong> {{cpanel_user}}<br><strong>Control Panel URL:</strong> <a href="{{cpanel_url}}">{{cpanel_url}}</a></p></div>',
        '["customer_name", "domain_name", "server_node", "cpanel_user", "cpanel_url"]'::jsonb
    )
ON CONFLICT (id) DO NOTHING;

-- 5. SEED SYSTEM SETTINGS
INSERT INTO system_settings (key, value, category, description)
VALUES
    (
        'general_site_config',
        '{"siteName": "Vikalink Networks", "supportEmail": "support@celoxaghana.online", "currency": "GHS", "phone": "+233 24 000 0000"}'::jsonb,
        'general',
        'Platform branding and contact information'
    ),
    (
        'payment_momo_config',
        '{"mtnNumber": "0241234567", "mtnAccountName": "Vikalink Solutions Ltd", "telecelNumber": "0209876543", "telecelAccountName": "Vikalink Solutions Ltd", "instructions": "Send exact amount and enter Transaction ID in receipt submission."}'::jsonb,
        'payment',
        'Manual Mobile Money billing instructions and merchant account credentials'
    )
ON CONFLICT (key) DO NOTHING;
