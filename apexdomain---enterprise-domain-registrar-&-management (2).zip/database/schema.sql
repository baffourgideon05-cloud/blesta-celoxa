-- =====================================================================
-- VIKALINK ENTERPRISE DOMAIN REGISTRAR & CLOUD HOSTING
-- PostgreSQL Production Database Schema
-- Compatible with: Netlify Postgres, Neon, Supabase, Cloud SQL, Aurora
-- =====================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================================
-- 1. USERS, AUTHENTICATION & ACCESS CONTROL (IAM / RBAC)
-- =====================================================================

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'customer', -- 'customer', 'staff', 'support', 'billing', 'admin', 'super_admin'
    is_email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    is_two_factor_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    two_factor_secret VARCHAR(255),
    status VARCHAR(30) NOT NULL DEFAULT 'active', -- 'active', 'suspended', 'pending_verification'
    last_login_at TIMESTAMP WITH TIME ZONE,
    last_login_ip VARCHAR(45),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    full_name VARCHAR(255) GENERATED ALWAYS AS (first_name || ' ' || last_name) STORED,
    company_name VARCHAR(255),
    phone VARCHAR(50) NOT NULL,
    address_line1 VARCHAR(255) NOT NULL,
    address_line2 VARCHAR(255),
    city VARCHAR(100) NOT NULL,
    state_region VARCHAR(100) NOT NULL,
    postal_code VARCHAR(30) DEFAULT '00233',
    country_code VARCHAR(2) NOT NULL DEFAULT 'GH',
    tax_id VARCHAR(50),
    wallet_balance_ghs NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    is_vip BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_token_hash VARCHAR(255) UNIQUE NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    is_revoked BOOLEAN NOT NULL DEFAULT FALSE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 2. MULTI-TENANT ISOLATED SHOPPING CARTS
-- =====================================================================

CREATE TABLE IF NOT EXISTS carts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES customers(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE, -- For guest sessions prior to sign-in
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cart_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cart_id UUID NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
    item_type VARCHAR(50) NOT NULL, -- 'domain_register', 'domain_transfer', 'domain_renew', 'hosting_plan'
    product_name VARCHAR(255) NOT NULL,
    domain_name VARCHAR(255),
    tld VARCHAR(30),
    billing_period_months INT NOT NULL DEFAULT 12,
    unit_price NUMERIC(12, 2) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    configuration JSONB NOT NULL DEFAULT '{}'::jsonb, -- Custom nameservers, whois privacy, auto-renew, package ID
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 3. TLD CATALOG, PRICING & REGISTRATION MATRIX
-- =====================================================================

CREATE TABLE IF NOT EXISTS tld_pricing (
    tld VARCHAR(30) PRIMARY KEY, -- e.g. '.com.gh', '.gh', '.com', '.org'
    register_price NUMERIC(10, 2) NOT NULL,
    renew_price NUMERIC(10, 2) NOT NULL,
    transfer_price NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    is_popular BOOLEAN NOT NULL DEFAULT FALSE,
    is_ghana_special BOOLEAN NOT NULL DEFAULT FALSE,
    grace_period_days INT NOT NULL DEFAULT 30,
    redemption_period_days INT NOT NULL DEFAULT 30,
    min_registration_years INT NOT NULL DEFAULT 1,
    max_registration_years INT NOT NULL DEFAULT 10,
    supported_registrars JSONB NOT NULL DEFAULT '["GHNIC", "ResellerClub", "Enom"]'::jsonb,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 4. REGISTERED DOMAINS, WHOIS CONTACTS & DNS
-- =====================================================================

CREATE TABLE IF NOT EXISTS registered_domains (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    domain_name VARCHAR(255) UNIQUE NOT NULL,
    tld VARCHAR(30) NOT NULL REFERENCES tld_pricing(tld),
    registrar_name VARCHAR(50) NOT NULL DEFAULT 'GHNIC', -- 'GHNIC', 'ResellerClub', 'Namecheap', 'Enom'
    registrar_domain_id VARCHAR(100),
    auth_code VARCHAR(100),
    nameservers JSONB NOT NULL DEFAULT '["ns1.celoxaghana.online", "ns2.celoxaghana.online"]'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'active', -- 'active', 'pending_registration', 'pending_transfer', 'expired', 'suspended', 'redemption'
    auto_renew BOOLEAN NOT NULL DEFAULT TRUE,
    is_locked BOOLEAN NOT NULL DEFAULT TRUE,
    privacy_protection BOOLEAN NOT NULL DEFAULT FALSE,
    dnssec_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    registration_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    last_synced_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS domain_contacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id UUID NOT NULL REFERENCES registered_domains(id) ON DELETE CASCADE,
    contact_type VARCHAR(20) NOT NULL, -- 'registrant', 'admin', 'tech', 'billing'
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    organization VARCHAR(255),
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    address_line1 VARCHAR(255) NOT NULL,
    address_line2 VARCHAR(255),
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    postal_code VARCHAR(30) NOT NULL,
    country_code VARCHAR(2) NOT NULL DEFAULT 'GH',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    UNIQUE(domain_id, contact_type)
);

CREATE TABLE IF NOT EXISTS domain_dns_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id UUID NOT NULL REFERENCES registered_domains(id) ON DELETE CASCADE,
    record_type VARCHAR(10) NOT NULL, -- 'A', 'AAAA', 'CNAME', 'MX', 'TXT', 'SRV', 'NS', 'CAA'
    host_name VARCHAR(255) NOT NULL, -- '@', 'www', 'mail', etc.
    record_value TEXT NOT NULL,
    ttl INT NOT NULL DEFAULT 3600,
    priority INT, -- For MX or SRV records
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS domain_activities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id UUID NOT NULL REFERENCES registered_domains(id) ON DELETE CASCADE,
    activity_type VARCHAR(50) NOT NULL, -- 'REGISTERED', 'NAMESERVERS_UPDATED', 'DNS_UPDATED', 'LOCKED', 'UNLOCKED', 'RENEWED'
    description TEXT NOT NULL,
    actor_email VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 5. WEB HOSTING INFRASTRUCTURE & SUBSCRIPTIONS (cPanel / WHM)
-- =====================================================================

CREATE TABLE IF NOT EXISTS hosting_servers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL, -- e.g. 'Accra Node #1 (cPanel)', 'London VPS Cluster'
    hostname VARCHAR(255) UNIQUE NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    provider VARCHAR(50) NOT NULL DEFAULT 'cpanel', -- 'cpanel', 'plesk', 'directadmin', 'custom'
    api_port INT NOT NULL DEFAULT 2087,
    is_ssl BOOLEAN NOT NULL DEFAULT TRUE,
    nameserver1 VARCHAR(255) NOT NULL DEFAULT 'ns1.celoxaghana.online',
    nameserver2 VARCHAR(255) NOT NULL DEFAULT 'ns2.celoxaghana.online',
    max_accounts INT NOT NULL DEFAULT 500,
    active_accounts INT NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hosting_packages (
    id VARCHAR(50) PRIMARY KEY, -- e.g. 'pkg-starter', 'pkg-business', 'pkg-enterprise'
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL DEFAULT 'cPanel Hosting', -- 'cPanel Hosting', 'WordPress Pro', 'Cloud VPS'
    disk_limit_mb INT NOT NULL, -- Quota in Megabytes (e.g. 5120 = 5GB)
    bandwidth_limit_gb INT NOT NULL, -- Bandwidth in Gigabytes
    max_ftp_accounts INT NOT NULL DEFAULT 5,
    max_email_accounts INT NOT NULL DEFAULT 10,
    max_databases INT NOT NULL DEFAULT 5,
    max_subdomains INT NOT NULL DEFAULT 10,
    price_monthly NUMERIC(10, 2) NOT NULL,
    price_annually NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    features JSONB NOT NULL DEFAULT '[]'::jsonb,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hosting_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    server_id UUID REFERENCES hosting_servers(id) ON DELETE SET NULL,
    package_id VARCHAR(50) REFERENCES hosting_packages(id),
    domain_name VARCHAR(255) NOT NULL,
    plan_name VARCHAR(100) NOT NULL,
    cpanel_user VARCHAR(32) NOT NULL,
    server_node_name VARCHAR(100) NOT NULL DEFAULT 'Node #gh1-accra',
    ip_address VARCHAR(45) NOT NULL DEFAULT '102.130.112.55',
    billing_cycle VARCHAR(30) NOT NULL DEFAULT 'monthly', -- 'monthly', 'annually', 'biennially'
    price NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    disk_limit_mb INT NOT NULL DEFAULT 10240,
    bandwidth_limit_gb INT NOT NULL DEFAULT 100,
    status VARCHAR(30) NOT NULL DEFAULT 'active', -- 'active', 'pending_setup', 'suspended', 'terminated'
    auto_renew BOOLEAN NOT NULL DEFAULT TRUE,
    setup_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hosting_provisioning_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subscription_id UUID REFERENCES hosting_subscriptions(id) ON DELETE SET NULL,
    customer_id UUID NOT NULL REFERENCES customers(id),
    server_id UUID REFERENCES hosting_servers(id),
    action VARCHAR(50) NOT NULL, -- 'create_account', 'suspend_account', 'unsuspend_account', 'terminate_account', 'change_package', 'reset_password'
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(30) NOT NULL DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed', 'retrying'
    attempts INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 5,
    last_error TEXT,
    scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 6. ORDERS, INVOICES, PAYMENTS & WALLET TRANSACTIONS
-- =====================================================================

CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number VARCHAR(50) UNIQUE NOT NULL, -- e.g. 'ORD-2026-8841'
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    total_amount NUMERIC(12, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    status VARCHAR(30) NOT NULL DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'cancelled', 'refunded'
    payment_method VARCHAR(50) NOT NULL, -- 'momo', 'bank_transfer', 'paystack', 'wallet', 'crypto'
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    item_type VARCHAR(50) NOT NULL, -- 'domain_register', 'domain_renew', 'hosting_plan'
    description VARCHAR(255) NOT NULL,
    domain_name VARCHAR(255),
    quantity INT NOT NULL DEFAULT 1,
    unit_price NUMERIC(12, 2) NOT NULL,
    total_price NUMERIC(12, 2) NOT NULL,
    configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS invoices (
    id VARCHAR(50) PRIMARY KEY, -- e.g. 'INV-1049', 'INV-1050'
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
    order_type VARCHAR(50) NOT NULL DEFAULT 'Domain & Hosting Purchase',
    subtotal NUMERIC(12, 2) NOT NULL,
    tax_amount NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    total_amount NUMERIC(12, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    status VARCHAR(30) NOT NULL DEFAULT 'unpaid', -- 'unpaid', 'verifying', 'paid', 'cancelled', 'refunded'
    payment_method VARCHAR(50) NOT NULL DEFAULT 'momo',
    issue_date DATE NOT NULL DEFAULT CURRENT_DATE,
    due_date DATE NOT NULL,
    paid_date DATE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS invoice_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id VARCHAR(50) NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    description VARCHAR(255) NOT NULL,
    item_type VARCHAR(50) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price NUMERIC(12, 2) NOT NULL,
    total_amount NUMERIC(12, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id VARCHAR(50) NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    transaction_reference VARCHAR(100) UNIQUE NOT NULL,
    gateway VARCHAR(50) NOT NULL, -- 'momo_gh', 'bank_transfer', 'paystack', 'wallet', 'crypto_usdt'
    payment_method VARCHAR(50) NOT NULL, -- 'MTN MoMo', 'Telecel Cash', 'Bank Wire', 'Paystack Card'
    amount NUMERIC(12, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    status VARCHAR(30) NOT NULL DEFAULT 'pending', -- 'pending', 'verifying', 'approved', 'declined', 'refunded'
    
    -- Custom Payment / MoMo Verification Details
    payer_name VARCHAR(255),
    payer_phone VARCHAR(50),
    momo_transaction_id VARCHAR(100),
    proof_attachment_url TEXT,
    staff_notes TEXT,
    verified_by_user_id UUID REFERENCES users(id),
    verified_at TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallet_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    type VARCHAR(30) NOT NULL, -- 'deposit', 'purchase_debit', 'refund_credit', 'manual_adjustment'
    amount NUMERIC(12, 2) NOT NULL,
    balance_after NUMERIC(12, 2) NOT NULL,
    reference VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 7. SUPPORT TICKETS & CLIENT HELP DESK
-- =====================================================================

CREATE TABLE IF NOT EXISTS support_tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_number VARCHAR(50) UNIQUE NOT NULL, -- e.g. 'TCK-9402'
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    department VARCHAR(50) NOT NULL DEFAULT 'Technical Support', -- 'Technical Support', 'Billing', 'Domain Operations', 'Hosting Provisioning'
    subject VARCHAR(255) NOT NULL,
    priority VARCHAR(20) NOT NULL DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
    status VARCHAR(30) NOT NULL DEFAULT 'open', -- 'open', 'customer_reply', 'staff_replied', 'in_progress', 'resolved', 'closed'
    last_reply_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ticket_replies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_id UUID NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
    author_type VARCHAR(20) NOT NULL, -- 'customer', 'staff', 'system'
    author_id UUID REFERENCES users(id),
    author_name VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    attachments JSONB NOT NULL DEFAULT '[]'::jsonb,
    is_internal_note BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 8. SYSTEM CONFIGURATION, EMAIL TEMPLATES & AUDIT LOGS
-- =====================================================================

CREATE TABLE IF NOT EXISTS system_settings (
    key VARCHAR(100) PRIMARY KEY,
    value JSONB NOT NULL,
    category VARCHAR(50) NOT NULL DEFAULT 'general', -- 'general', 'payment', 'registrar', 'hosting', 'security'
    is_secret BOOLEAN NOT NULL DEFAULT FALSE,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS email_templates (
    id VARCHAR(50) PRIMARY KEY, -- e.g. 'welcome_user', 'invoice_created', 'domain_registered', 'payment_verified'
    name VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    body_html TEXT NOT NULL,
    variables JSONB NOT NULL DEFAULT '[]'::jsonb,
    is_system BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_email VARCHAR(255) NOT NULL,
    actor_role VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL, -- 'PRIVILEGED_LOGIN', 'PAYMENT_APPROVED', 'CPANEL_ACCOUNT_CREATED', 'DNS_CHANGED'
    target_type VARCHAR(50), -- 'customer', 'invoice', 'domain', 'hosting', 'system_setting'
    target_id VARCHAR(100),
    details TEXT NOT NULL,
    ip_address VARCHAR(45) NOT NULL DEFAULT '127.0.0.1',
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 9. PERFORMANCE INDEXES
-- =====================================================================

-- Customers & Users
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_customers_user_id ON customers(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(session_token_hash);

-- Carts
CREATE INDEX IF NOT EXISTS idx_carts_customer_id ON carts(customer_id);
CREATE INDEX IF NOT EXISTS idx_carts_session_token ON carts(session_token);
CREATE INDEX IF NOT EXISTS idx_cart_items_cart_id ON cart_items(cart_id);

-- Domains
CREATE INDEX IF NOT EXISTS idx_domains_customer_id ON registered_domains(customer_id);
CREATE INDEX IF NOT EXISTS idx_domains_domain_name ON registered_domains(domain_name);
CREATE INDEX IF NOT EXISTS idx_domains_status ON registered_domains(status);
CREATE INDEX IF NOT EXISTS idx_domains_expiry ON registered_domains(expiry_date);
CREATE INDEX IF NOT EXISTS idx_dns_records_domain_id ON domain_dns_records(domain_id);

-- Hosting
CREATE INDEX IF NOT EXISTS idx_hosting_customer_id ON hosting_subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_hosting_domain_name ON hosting_subscriptions(domain_name);
CREATE INDEX IF NOT EXISTS idx_hosting_cpanel_user ON hosting_subscriptions(cpanel_user);
CREATE INDEX IF NOT EXISTS idx_hosting_status ON hosting_subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_provisioning_queue_status ON hosting_provisioning_queue(status);

-- Invoices & Payments
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_customer_id ON invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_payments_invoice_id ON payments(invoice_id);
CREATE INDEX IF NOT EXISTS idx_payments_customer_id ON payments(customer_id);
CREATE INDEX IF NOT EXISTS idx_payments_reference ON payments(transaction_reference);
CREATE INDEX IF NOT EXISTS idx_wallet_customer_id ON wallet_transactions(customer_id);

-- Support & Audits
CREATE INDEX IF NOT EXISTS idx_tickets_customer_id ON support_tickets(customer_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_actor ON audit_logs(actor_email);
