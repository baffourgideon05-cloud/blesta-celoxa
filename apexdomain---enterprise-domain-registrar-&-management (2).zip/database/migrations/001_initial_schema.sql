-- =====================================================================
-- VIKALINK ENTERPRISE MIGRATION 001: Initial Core Schema
-- Safe, Idempotent, Non-destructive Migration
-- =====================================================================

BEGIN;

-- 1. Create Migration History Table if not exists
CREATE TABLE IF NOT EXISTS schema_migrations (
    id SERIAL PRIMARY KEY,
    version VARCHAR(50) UNIQUE NOT NULL,
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    checksum VARCHAR(64)
);

-- Check if already applied
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM schema_migrations WHERE version = '001_initial_schema') THEN
        -- Run extensions
        CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
        CREATE EXTENSION IF NOT EXISTS "pgcrypto";

        -- Record migration
        INSERT INTO schema_migrations (version, checksum) VALUES ('001_initial_schema', 'vikalink-prod-v1.0');
    END IF;
END $$;

COMMIT;
