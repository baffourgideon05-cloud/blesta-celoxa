import { DomainResult } from '../types';
import { TLD_CATALOG } from '../data/tlds';
import { systemDatabase } from '../services/systemDatabase';

// Currency exchange rates relative to USD
export const CURRENCY_RATES: Record<string, { symbol: string; rate: number; name: string; flag?: string }> = {
  USD: { symbol: '$', rate: 1.0, name: 'USD - United States Dollar' },
  GHS: { symbol: 'GH₵', rate: 15.5, name: 'GHS - Ghanaian Cedi' },
  EUR: { symbol: '€', rate: 0.92, name: 'EUR - Euro' },
  GBP: { symbol: '£', rate: 0.79, name: 'GBP - British Pound' },
  JPY: { symbol: '¥', rate: 154.5, name: 'JPY - Japanese Yen' },
  INR: { symbol: '₹', rate: 83.2, name: 'INR - Indian Rupee' },
  CAD: { symbol: 'CA$', rate: 1.36, name: 'CAD - Canadian Dollar' },
  AUD: { symbol: 'AU$', rate: 1.52, name: 'AUD - Australian Dollar' },
  NGN: { symbol: '₦', rate: 1450.0, name: 'NGN - Nigerian Naira' },
  ZAR: { symbol: 'R', rate: 18.2, name: 'ZAR - South African Rand' },
};

export function convertPrice(priceInUsd: number, currency: string = 'USD'): number {
  const curr = CURRENCY_RATES[currency] || CURRENCY_RATES.USD;
  return Number((priceInUsd * curr.rate).toFixed(2));
}

export function formatCurrencyAmount(amountInTargetCurrency: number, currency: string = 'USD'): string {
  const curr = CURRENCY_RATES[currency] || CURRENCY_RATES.USD;
  if (currency === 'JPY') {
    return `${curr.symbol}${Math.round(amountInTargetCurrency).toLocaleString()}`;
  }
  if (currency === 'GHS') {
    return `${curr.symbol} ${amountInTargetCurrency.toFixed(2)}`;
  }
  return `${curr.symbol}${amountInTargetCurrency.toFixed(2)}`;
}

export function formatPrice(priceInUsd: number, currency: string = 'USD'): string {
  const curr = CURRENCY_RATES[currency] || CURRENCY_RATES.USD;
  const converted = priceInUsd * curr.rate;
  if (currency === 'JPY') {
    return `${curr.symbol}${Math.round(converted).toLocaleString()}`;
  }
  if (currency === 'GHS') {
    return `${curr.symbol} ${converted.toFixed(2)}`;
  }
  return `${curr.symbol}${converted.toFixed(2)}`;
}

export interface TaxBreakdown {
  subtotalUsd: number;
  subtotalFormatted: string;
  discountUsd: number;
  discountFormatted: string;
  taxableAmountUsd: number;
  taxRatePercent: number;
  taxAmountUsd: number;
  taxAmountFormatted: string;
  icannFeeUsd: number;
  icannFeeFormatted: string;
  grandTotalUsd: number;
  grandTotalFormatted: string;
  grandTotalInTargetCurrency: number;
  currency: string;
  currencySymbol: string;
}

export function calculateTaxBreakdown(params: {
  subtotalUsd: number;
  currency?: string;
  taxRatePercent?: number;
  discountUsd?: number;
  icannFeeUsd?: number;
}): TaxBreakdown {
  const currency = params.currency || 'USD';
  const subtotalUsd = (typeof params.subtotalUsd === 'number' && !isNaN(params.subtotalUsd)) ? Math.max(0, params.subtotalUsd) : 0;
  const taxRate = (typeof params.taxRatePercent === 'number' && !isNaN(params.taxRatePercent)) ? params.taxRatePercent : 15;
  const discountUsd = (typeof params.discountUsd === 'number' && !isNaN(params.discountUsd)) ? Math.max(0, params.discountUsd) : 0;
  const icannFeeUsd = (typeof params.icannFeeUsd === 'number' && !isNaN(params.icannFeeUsd)) ? Math.max(0, params.icannFeeUsd) : 0;

  const taxableAmountUsd = Math.max(0, subtotalUsd - discountUsd);
  const taxAmountUsd = Number(((taxableAmountUsd * taxRate) / 100).toFixed(2));
  const grandTotalUsd = Number(Math.max(0, taxableAmountUsd + taxAmountUsd + icannFeeUsd).toFixed(2));
  const curr = CURRENCY_RATES[currency] || CURRENCY_RATES.USD;
  const rate = (curr && typeof curr.rate === 'number' && !isNaN(curr.rate)) ? curr.rate : 1;
  const grandTotalInTargetCurrency = Number((grandTotalUsd * rate).toFixed(2));

  return {
    subtotalUsd,
    subtotalFormatted: formatPrice(subtotalUsd, currency),
    discountUsd,
    discountFormatted: formatPrice(discountUsd, currency),
    taxableAmountUsd,
    taxRatePercent: taxRate,
    taxAmountUsd,
    taxAmountFormatted: formatPrice(taxAmountUsd, currency),
    icannFeeUsd,
    icannFeeFormatted: formatPrice(icannFeeUsd, currency),
    grandTotalUsd,
    grandTotalFormatted: formatPrice(grandTotalUsd, currency),
    grandTotalInTargetCurrency,
    currency,
    currencySymbol: curr?.symbol || '$',
  };
}

export function generateDomainResults(searchTerm: string): DomainResult[] {
  if (!searchTerm || typeof searchTerm !== 'string' || !searchTerm.trim()) return [];

  const rawClean = (searchTerm || '').toLowerCase().trim().replace(/https?:\/\//, '').replace(/^www\./, '');
  
  // Extract name and explicit TLD if typed e.g. "nexus.io" -> name: "nexus", explicitTld: ".io"
  let name = rawClean;
  let explicitTld = '';
  
  const dotIndex = rawClean.indexOf('.');
  if (dotIndex > 0) {
    name = rawClean.slice(0, dotIndex).replace(/[^a-z0-9-]/g, '');
    explicitTld = rawClean.slice(dotIndex);
  } else {
    name = rawClean.replace(/[^a-z0-9-]/g, '');
  }

  if (!name) return [];

  const results: DomainResult[] = [];

  // In-house registered brand domains
  const inHouseBrandDomains = [
    'celoxaghana.online',
    'celoxaghana.com',
    'apexcloud.io',
    'nexusapp.com',
    'venturelabs.ai',
  ];

  // Known reserved or popular domains
  const reservedTaken = [
    'google', 'apple', 'amazon', 'microsoft', 'meta', 'twitter', 'facebook', 'openai', 
    'stripe', 'github', 'tesla', 'uber', 'airbnb', 'netflix', 'spotify', 'zoom', 'paystack'
  ];
  const premiumKeywords = ['ai', 'cloud', 'nexus', 'app', 'dev', 'meta', 'pay', 'coin', 'trade', 'shop', 'tech', 'smart', 'data', 'block', 'hub', 'bot', 'flow'];

  const prefixes = ['', 'get', 'try', 'the', 'use', 'my', 'go'];
  const suffixes = ['', 'hq', 'labs', 'app', 'hub', 'stack', 'flow', 'io', 'ai', 'cloud', 'craft', 'pro', 'zone', 'box'];

  let idCounter = 1;

  // 1. Direct TLD variations for exact clean name
  TLD_CATALOG.forEach((tldInfo) => {
    const fullDomain = `${name}${tldInfo.tld}`.toLowerCase();
    const isExplicit = explicitTld && explicitTld === tldInfo.tld;
    
    // Evaluate authoritative internal status & ownership
    const evalStatus = systemDatabase.evaluateDomainStatus(fullDomain);
    const isBrand = evalStatus.isOwnedByPlatformCustomer || inHouseBrandDomains.includes(fullDomain);
    const isReserved = evalStatus.detailedStatus === 'reserved' || reservedTaken.includes(name) || (name.length <= 3 && tldInfo.tld === '.com');
    const isPremium = !isBrand && !isReserved && premiumKeywords.includes(name) && (tldInfo.tld === '.com' || tldInfo.tld === '.ai' || tldInfo.tld === '.io');

    let initialDetailedStatus = evalStatus.detailedStatus;
    if (isPremium && initialDetailedStatus === 'available') {
      initialDetailedStatus = 'premium';
    } else if (isReserved && initialDetailedStatus === 'available') {
      initialDetailedStatus = 'reserved';
    }

    let regPrice = tldInfo.registrationPrice;
    if (isPremium) {
      regPrice = regPrice * 25 + 499;
    }

    const isAvail = initialDetailedStatus === 'available' || initialDetailedStatus === 'premium';

    results.push({
      id: `search-dom-${fullDomain.replace(/[^a-z0-9]/g, '-')}`,
      domain: fullDomain,
      name: name,
      tld: tldInfo.tld,
      isAvailable: isAvail,
      isPremium: isPremium,
      detailedStatus: initialDetailedStatus,
      statusMessage: evalStatus.statusMessage,
      isOwnedByCurrentUser: evalStatus.isOwnedByYou,
      ownershipRecordId: evalStatus.ownership?.id,
      expiryDate: evalStatus.expiryDate,
      creationDate: evalStatus.creationDate,
      timelineStep: evalStatus.timelineStep,
      isBrandRegistered: isBrand,
      brandRegistrar: isBrand ? 'ApexDomain Enterprise / Celoxa Technology Group Ltd' : undefined,
      registrationPrice: Number(regPrice.toFixed(2)),
      renewalPrice: tldInfo.renewalPrice,
      transferPrice: tldInfo.transferPrice,
      restorePrice: tldInfo.restorePrice,
      icannFee: tldInfo.icannFee,
      category: tldInfo.category,
      description: isBrand 
        ? (evalStatus.isOwnedByYou ? 'Managed in your ApexDomain Account' : 'Registered in-house with ApexDomain / Celoxa Group') 
        : tldInfo.description,
      timeEstimate: tldInfo.tld === '.com' || tldInfo.tld === '.net' ? 'Instant' : '1-3 minutes',
      popularityScore: isExplicit ? 99 : (tldInfo.tld === '.com' ? 98 : tldInfo.tld === '.ai' ? 95 : 85),
      characterLength: fullDomain.length,
      brandScore: Math.min(99, Math.max(65, 100 - name.length * 2 + (tldInfo.tld === '.com' ? 10 : 5))),
      hasPrivacyIncluded: true,
      isCheckingLive: true,
    });
  });

  // 2. Add high-value variations if primary is taken or to enrich choices
  const featuredTlds = ['.com', '.io', '.ai', '.app', '.tech', '.co', '.store', '.cloud'];

  prefixes.forEach((pre) => {
    if (!pre) return;
    const varName = `${pre}${name}`;
    featuredTlds.slice(0, 3).forEach((tld) => {
      const full = `${varName}${tld}`.toLowerCase();
      const evalStatus = systemDatabase.evaluateDomainStatus(full);
      const isBrand = evalStatus.isOwnedByPlatformCustomer || inHouseBrandDomains.includes(full);
      const tldInfo = TLD_CATALOG.find((t) => t.tld === tld) || TLD_CATALOG[0];
      const isAvail = evalStatus.detailedStatus === 'available';

      results.push({
        id: `search-dom-${full.replace(/[^a-z0-9]/g, '-')}`,
        domain: full,
        name: varName,
        tld: tld,
        isAvailable: isAvail,
        isPremium: false,
        detailedStatus: evalStatus.detailedStatus,
        statusMessage: evalStatus.statusMessage,
        isOwnedByCurrentUser: evalStatus.isOwnedByYou,
        ownershipRecordId: evalStatus.ownership?.id,
        expiryDate: evalStatus.expiryDate,
        creationDate: evalStatus.creationDate,
        timelineStep: evalStatus.timelineStep,
        isBrandRegistered: isBrand,
        brandRegistrar: isBrand ? 'ApexDomain Enterprise / Celoxa Technology Group Ltd' : undefined,
        registrationPrice: tldInfo.registrationPrice,
        renewalPrice: tldInfo.renewalPrice,
        transferPrice: tldInfo.transferPrice,
        restorePrice: tldInfo.restorePrice,
        icannFee: tldInfo.icannFee,
        category: tldInfo.category,
        description: `Brandable prefix variation: ${pre.toUpperCase()} + ${name}`,
        timeEstimate: 'Instant',
        popularityScore: 82,
        characterLength: full.length,
        brandScore: 88,
        hasPrivacyIncluded: true,
      });
    });
  });

  suffixes.forEach((suf) => {
    if (!suf) return;
    const varName = `${name}${suf}`;
    featuredTlds.slice(0, 3).forEach((tld) => {
      const full = `${varName}${tld}`.toLowerCase();
      const evalStatus = systemDatabase.evaluateDomainStatus(full);
      const isBrand = evalStatus.isOwnedByPlatformCustomer || inHouseBrandDomains.includes(full);
      const tldInfo = TLD_CATALOG.find((t) => t.tld === tld) || TLD_CATALOG[0];
      const isAvail = evalStatus.detailedStatus === 'available';

      results.push({
        id: `search-dom-${full.replace(/[^a-z0-9]/g, '-')}`,
        domain: full,
        name: varName,
        tld: tld,
        isAvailable: isAvail,
        isPremium: false,
        detailedStatus: evalStatus.detailedStatus,
        statusMessage: evalStatus.statusMessage,
        isOwnedByCurrentUser: evalStatus.isOwnedByYou,
        ownershipRecordId: evalStatus.ownership?.id,
        expiryDate: evalStatus.expiryDate,
        creationDate: evalStatus.creationDate,
        timelineStep: evalStatus.timelineStep,
        isBrandRegistered: isBrand,
        brandRegistrar: isBrand ? 'ApexDomain Enterprise / Celoxa Technology Group Ltd' : undefined,
        registrationPrice: tldInfo.registrationPrice,
        renewalPrice: tldInfo.renewalPrice,
        transferPrice: tldInfo.transferPrice,
        restorePrice: tldInfo.restorePrice,
        icannFee: tldInfo.icannFee,
        category: tldInfo.category,
        description: `Memorable modifier suffix: ${name} + ${suf.toUpperCase()}`,
        timeEstimate: 'Instant',
        popularityScore: 80,
        characterLength: full.length,
        brandScore: 86,
        hasPrivacyIncluded: true,
      });
    });
  });

  // Ensure strict uniqueness by domain name
  const seen = new Set<string>();
  return results.filter((item) => {
    if (seen.has(item.domain)) return false;
    seen.add(item.domain);
    return true;
  });
}

// Real-Time Live Server Batch Verification Helper
export async function enrichResultsWithLiveAvailability(
  results: DomainResult[]
): Promise<DomainResult[]> {
  if (!results || results.length === 0) return [];

  const domainsToQuery = results.slice(0, 15).map((r) => r.domain);

  try {
    const res = await fetch('/api/domains/batch-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domains: domainsToQuery }),
    });

    if (!res.ok) {
      return results.map((r) => {
        const evalStatus = systemDatabase.evaluateDomainStatus(r.domain, undefined, { unableToVerify: true });
        return {
          ...r,
          detailedStatus: evalStatus.detailedStatus,
          statusMessage: evalStatus.statusMessage,
          isAvailable: evalStatus.detailedStatus === 'available' || evalStatus.detailedStatus === 'premium',
          isCheckingLive: false,
        };
      });
    }

    const data = await res.json();
    if (!data.success || !Array.isArray(data.results)) {
      return results.map((r) => ({ ...r, isCheckingLive: false }));
    }

    const statusMap = new Map<string, any>();
    data.results.forEach((item: any) => {
      statusMap.set(item.domain.toLowerCase(), item);
    });

    return results.map((r) => {
      const match = statusMap.get(r.domain.toLowerCase());
      if (match) {
        const evalStatus = systemDatabase.evaluateDomainStatus(r.domain, undefined, {
          isAvailable: match.isAvailable,
          isBrandRegistered: match.isBrandRegistered,
          registrar: match.registrar,
          creationDate: match.creationDate,
          expirationDate: match.expirationDate,
          unableToVerify: match.unableToVerify,
        });

        const isAvail = evalStatus.detailedStatus === 'available' || evalStatus.detailedStatus === 'premium';

        return {
          ...r,
          isAvailable: isAvail,
          detailedStatus: evalStatus.detailedStatus,
          statusMessage: evalStatus.statusMessage,
          isOwnedByCurrentUser: evalStatus.isOwnedByYou,
          ownershipRecordId: evalStatus.ownership?.id,
          expiryDate: evalStatus.expiryDate,
          creationDate: evalStatus.creationDate,
          timelineStep: evalStatus.timelineStep,
          isBrandRegistered: evalStatus.isOwnedByPlatformCustomer,
          brandRegistrar: match.brandRegistrar || r.brandRegistrar,
          registeredOwnerEmail: evalStatus.isOwnedByYou ? evalStatus.ownership?.ownerEmail : undefined, // Privacy protected!
          realRegistrarName: match.registrar,
          isCheckingLive: false,
        };
      }
      return { ...r, isCheckingLive: false };
    });
  } catch (err) {
    console.error('Failed to verify live domain availability batch:', err);
    return results.map((r) => {
      const evalStatus = systemDatabase.evaluateDomainStatus(r.domain, undefined, { unableToVerify: true });
      return {
        ...r,
        detailedStatus: evalStatus.detailedStatus,
        statusMessage: evalStatus.statusMessage,
        isAvailable: evalStatus.detailedStatus === 'available' || evalStatus.detailedStatus === 'premium',
        isCheckingLive: false,
      };
    });
  }
}

export function getLiveSearchSuggestions(query: string): DomainResult[] {
  if (!query || query.length < 2) return [];
  const all = generateDomainResults(query);
  return all.slice(0, 5);
}

export interface FilterOptions {
  category?: string;
  tld?: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy?: 'price_asc' | 'price_desc' | 'popular' | 'alpha' | 'score';
  availabilityOnly?: boolean;
}

export function filterAndSortResults(
  results: DomainResult[],
  filters: FilterOptions
): DomainResult[] {
  let filtered = [...results];

  if (filters.availabilityOnly) {
    filtered = filtered.filter((r) => r.isAvailable);
  }

  if (filters.category && filters.category !== 'All') {
    filtered = filtered.filter((r) => r.category === filters.category);
  }

  if (filters.tld && filters.tld !== 'All') {
    filtered = filtered.filter((r) => (r.tld || '').toLowerCase() === (filters.tld || '').toLowerCase());
  }

  if (filters.minPrice !== undefined && filters.maxPrice !== undefined) {
    filtered = filtered.filter(
      (r) => r.registrationPrice >= filters.minPrice! && r.registrationPrice <= filters.maxPrice!
    );
  }

  if (filters.sortBy) {
    switch (filters.sortBy) {
      case 'price_asc':
        filtered.sort((a, b) => a.registrationPrice - b.registrationPrice);
        break;
      case 'price_desc':
        filtered.sort((a, b) => b.registrationPrice - a.registrationPrice);
        break;
      case 'alpha':
        filtered.sort((a, b) => a.domain.localeCompare(b.domain));
        break;
      case 'score':
        filtered.sort((a, b) => b.brandScore - a.brandScore);
        break;
      case 'popular':
      default:
        filtered.sort((a, b) => b.popularityScore - a.popularityScore);
        break;
    }
  }

  return filtered;
}

