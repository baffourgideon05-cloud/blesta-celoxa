import dns from 'dns';
import https from 'https';
import http from 'http';

export interface AuthoritativeWhoisResult {
  domainName: string;
  status: string;
  isAvailable: boolean;
  isBrandRegistered: boolean;
  brandRegistrar?: string;
  brandAccountEmail?: string;
  registrar: string;
  registrarIanaId?: string;
  creationDate: string;
  updatedDate: string;
  expirationDate: string;
  registrantOrganization: string;
  registrantCountry: string;
  nameServers: string[];
  dnssec: string;
  rawWhoisText: string;
  dnsRecords?: { type: string; name: string; value: string; ttl?: number; priority?: number }[];
  httpStatus?: {
    isOnline: boolean;
    statusCode?: number;
    serverHeader?: string;
    ipAddress?: string;
    protocol?: string;
  };
  authoritativeSource: 'IN_HOUSE_BRAND_DATABASE' | 'LIVE_RDAP_DNS' | 'AUTHORITATIVE_DNS';
}

export interface BrandDomainRecord {
  id: string;
  domain: string;
  registeredDate: string;
  expiryDate: string;
  ownerEmail: string;
  ownerName: string;
  registrar: string;
  autoRenew: boolean;
  locked: boolean;
  whoisPrivacy: boolean;
  authCode: string;
  nameservers: string[];
  dnsRecords: { id: string; type: string; name: string; value: string; ttl: number; priority?: number }[];
}

// In-House Registered Brand Domains Database
const IN_HOUSE_BRAND_DOMAINS: Map<string, BrandDomainRecord> = new Map([
  [
    'celoxaghana.online',
    {
      id: 'reg-brand-celoxa-01',
      domain: 'celoxaghana.online',
      registeredDate: '2025-01-01T00:00:00Z',
      expiryDate: '2028-01-01T00:00:00Z',
      ownerEmail: 'admin@celoxaghana.online',
      ownerName: 'Celoxa Technologies Ltd / Gideon Baffour',
      registrar: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
      autoRenew: true,
      locked: true,
      whoisPrivacy: true,
      authCode: 'EPP-CELOXA-772910-GH',
      nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
      dnsRecords: [
        { id: 'dns-c-1', type: 'A', name: '@', value: '198.51.100.42', ttl: 3600 },
        { id: 'dns-c-2', type: 'CNAME', name: 'www', value: 'celoxaghana.online', ttl: 3600 },
        { id: 'dns-c-3', type: 'MX', name: '@', value: 'mail.celoxaghana.online', ttl: 3600, priority: 10 },
        { id: 'dns-c-4', type: 'TXT', name: '@', value: 'v=spf1 include:_spf.apexdomain.com ~all', ttl: 3600 },
        { id: 'dns-c-5', type: 'TXT', name: '_ghana-verification', value: 'celoxa-ghana-verified-active-2026', ttl: 3600 },
      ],
    },
  ],
  [
    'celoxaghana.com',
    {
      id: 'reg-brand-celoxa-02',
      domain: 'celoxaghana.com',
      registeredDate: '2024-11-15T10:00:00Z',
      expiryDate: '2027-11-15T10:00:00Z',
      ownerEmail: 'baffourgideon05@gmail.com',
      ownerName: 'Gideon Baffour (Celoxa Group)',
      registrar: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
      autoRenew: true,
      locked: true,
      whoisPrivacy: true,
      authCode: 'EPP-CELOXA-COM-883910',
      nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
      dnsRecords: [
        { id: 'dns-cc-1', type: 'A', name: '@', value: '198.51.100.42', ttl: 3600 },
        { id: 'dns-cc-2', type: 'CNAME', name: 'www', value: 'celoxaghana.online', ttl: 3600 },
      ],
    },
  ],
  [
    'apexcloud.io',
    {
      id: 'reg-brand-apexcloud',
      domain: 'apexcloud.io',
      registeredDate: '2025-01-15T08:30:00Z',
      expiryDate: '2027-01-15T08:30:00Z',
      ownerEmail: 'contact@apexcloud.io',
      ownerName: 'Apex Cloud Solutions',
      registrar: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
      autoRenew: true,
      locked: true,
      whoisPrivacy: true,
      authCode: 'EPP-APEX-992384-IO',
      nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
      dnsRecords: [
        { id: 'dns-a-1', type: 'A', name: '@', value: '76.76.21.21', ttl: 3600 },
        { id: 'dns-a-2', type: 'CNAME', name: 'www', value: 'cname.vercel-dns.com', ttl: 3600 },
        { id: 'dns-a-3', type: 'MX', name: '@', value: 'ASPMX.L.GOOGLE.COM', ttl: 3600, priority: 1 },
      ],
    },
  ],
  [
    'nexusapp.com',
    {
      id: 'reg-brand-nexus',
      domain: 'nexusapp.com',
      registeredDate: '2024-09-10T12:00:00Z',
      expiryDate: '2026-09-10T12:00:00Z',
      ownerEmail: 'kwame@enterpriseghana.com',
      ownerName: 'Akwaaba Digital Hub',
      registrar: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
      autoRenew: true,
      locked: true,
      whoisPrivacy: true,
      authCode: 'EPP-NEXUS-881923-COM',
      nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
      dnsRecords: [
        { id: 'dns-n-1', type: 'A', name: '@', value: '185.199.108.153', ttl: 300 },
        { id: 'dns-n-2', type: 'A', name: '@', value: '185.199.109.153', ttl: 300 },
      ],
    },
  ],
  [
    'venturelabs.ai',
    {
      id: 'reg-brand-venture',
      domain: 'venturelabs.ai',
      registeredDate: '2025-05-20T14:15:00Z',
      expiryDate: '2027-05-20T14:15:00Z',
      ownerEmail: 'founder@venturelabs.ai',
      ownerName: 'VentureLabs AI Ltd',
      registrar: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
      autoRenew: false,
      locked: false,
      whoisPrivacy: true,
      authCode: 'EPP-VENTURE-331002-AI',
      nameservers: ['ns1.cloudflare.com', 'ns2.cloudflare.com'],
      dnsRecords: [
        { id: 'dns-v-1', type: 'NS', name: '@', value: 'ns1.cloudflare.com', ttl: 86400 },
        { id: 'dns-v-2', type: 'NS', name: '@', value: 'ns2.cloudflare.com', ttl: 86400 },
      ],
    },
  ],
]);

// Helper: Run async task with timeout
function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(fallback), ms);
    promise
      .then((val) => {
        clearTimeout(timer);
        resolve(val);
      })
      .catch(() => {
        clearTimeout(timer);
        resolve(fallback);
      });
  });
}

// 1. Live Authoritative DNS Query Engine
export async function queryLiveDns(domain: string): Promise<{
  hasDns: boolean;
  nameservers: string[];
  ipv4: string[];
  ipv6: string[];
  mxRecords: { exchange: string; priority: number }[];
  txtRecords: string[];
  soaRecord: any | null;
}> {
  const cleanDomain = domain.toLowerCase().trim();

  const nsPromise = withTimeout(dns.promises.resolveNs(cleanDomain), 2000, [] as string[]);
  const aPromise = withTimeout(dns.promises.resolve4(cleanDomain), 2000, [] as string[]);
  const aaaaPromise = withTimeout(dns.promises.resolve6(cleanDomain), 2000, [] as string[]);
  const mxPromise = withTimeout(dns.promises.resolveMx(cleanDomain), 2000, [] as dns.MxRecord[]);
  const txtPromise = withTimeout(dns.promises.resolveTxt(cleanDomain), 2000, [] as string[][]);
  const soaPromise = withTimeout(dns.promises.resolveSoa(cleanDomain), 2000, null as dns.SoaRecord | null);

  const [ns, a, aaaa, mx, txtGroup, soa] = await Promise.all([
    nsPromise,
    aPromise,
    aaaaPromise,
    mxPromise,
    txtPromise,
    soaPromise,
  ]);

  const flatTxt = txtGroup.map((t) => (Array.isArray(t) ? t.join('') : t));
  const hasDns = (ns && ns.length > 0) || (a && a.length > 0) || (mx && mx.length > 0) || !!soa;

  return {
    hasDns,
    nameservers: ns || [],
    ipv4: a || [],
    ipv6: aaaa || [],
    mxRecords: mx || [],
    txtRecords: flatTxt,
    soaRecord: soa,
  };
}

// 2. Real-Time RDAP (Registration Data Access Protocol) Query Engine
export async function queryLiveRdap(domain: string): Promise<{
  found: boolean;
  data: any | null;
  rawJsonString: string;
}> {
  const cleanDomain = domain.toLowerCase().trim();
  const url = `https://rdap.org/domain/${encodeURIComponent(cleanDomain)}`;

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3500);

    const resp = await fetch(url, {
      signal: controller.signal,
      headers: {
        Accept: 'application/rdap+json, application/json',
        'User-Agent': 'ApexDomain-Enterprise-RDAP-Client/2.5',
      },
    });

    clearTimeout(timer);

    if (resp.status === 404) {
      return { found: false, data: null, rawJsonString: `Domain ${cleanDomain} returned HTTP 404 (Not Found in Global RDAP Registry).` };
    }

    if (!resp.ok) {
      return { found: false, data: null, rawJsonString: `RDAP registry server responded with HTTP status ${resp.status}.` };
    }

    const json = await resp.json();
    return {
      found: true,
      data: json,
      rawJsonString: JSON.stringify(json, null, 2),
    };
  } catch (err: any) {
    return {
      found: false,
      data: null,
      rawJsonString: `RDAP lookup timed out or network unreachable: ${err?.message || 'Error'}`,
    };
  }
}

// 3. Live HTTP Web Server & SSL Probe
export async function probeLiveWebServer(domain: string, ipFallback?: string): Promise<{
  isOnline: boolean;
  statusCode?: number;
  serverHeader?: string;
  ipAddress?: string;
  protocol?: string;
}> {
  const cleanDomain = domain.toLowerCase().trim();

  const checkHttp = async (protocol: 'https' | 'http') => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2500);
    try {
      const res = await fetch(`${protocol}://${cleanDomain}`, {
        method: 'HEAD',
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; ApexDomainStatusBot/1.0)',
        },
      });
      clearTimeout(timer);
      return {
        isOnline: true,
        statusCode: res.status,
        serverHeader: res.headers.get('server') || 'Active Web Server',
        protocol: protocol.toUpperCase(),
        ipAddress: ipFallback || 'Resolved',
      };
    } catch {
      clearTimeout(timer);
      return null;
    }
  };

  const httpsResult = await checkHttp('https');
  if (httpsResult) return httpsResult;

  const httpResult = await checkHttp('http');
  if (httpResult) return httpResult;

  return { isOnline: false, ipAddress: ipFallback };
}

// 4. Master Authoritative Domain Lookup Service
export async function lookupDomainAuthoritative(domainInput: string): Promise<AuthoritativeWhoisResult> {
  const domain = (domainInput || '').toLowerCase().trim().replace(/https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');

  // 1. Check in-house brand database FIRST
  if (IN_HOUSE_BRAND_DOMAINS.has(domain)) {
    const brandRecord = IN_HOUSE_BRAND_DOMAINS.get(domain)!;
    const dnsInfo = await queryLiveDns(domain);
    const httpInfo = await probeLiveWebServer(domain, brandRecord.dnsRecords.find((r) => r.type === 'A')?.value);

    const rawWhoisText = `Domain Name: ${domain.toUpperCase()}
Registry Domain ID: APX_${brandRecord.id.toUpperCase()}
Registrar WHOIS Server: whois.apexdomain.com
Registrar URL: https://apexdomain.com
Updated Date: ${new Date().toISOString().split('T')[0]}T00:00:00Z
Creation Date: ${brandRecord.registeredDate}
Registry Expiry Date: ${brandRecord.expiryDate}
Registrar: ${brandRecord.registrar}
Registrar IANA ID: 9942
Registrar Abuse Contact Email: abuse@apexdomain.com
Registrar Abuse Contact Phone: +233.302918840
Domain Status: ${brandRecord.locked ? 'clientTransferProhibited https://icann.org/epp#clientTransferProhibited' : 'ok'}
Domain In-House Registration: REGISTERED WITH APEXDOMAIN / CELOXA TECHNOLOGY GROUP
Owner Account: ${brandRecord.ownerName} (${brandRecord.ownerEmail})
${brandRecord.nameservers.map((ns, idx) => `Name Server: ${ns.toUpperCase()}`).join('\n')}
DNSSEC: ${brandRecord.locked ? 'signedDelegation' : 'unsigned'}
Authoritative DNS Zone: Host Cluster Anycast (Tier-3 Cloud DC Accra)`;

    return {
      domainName: domain.toUpperCase(),
      status: 'REGISTERED (In-House Brand Domain / Active)',
      isAvailable: false,
      isBrandRegistered: true,
      brandRegistrar: 'ApexDomain Enterprise / Celoxa Technology Group Ltd',
      brandAccountEmail: brandRecord.ownerEmail,
      registrar: brandRecord.registrar,
      registrarIanaId: '9942',
      creationDate: brandRecord.registeredDate,
      updatedDate: new Date().toISOString(),
      expirationDate: brandRecord.expiryDate,
      registrantOrganization: brandRecord.ownerName,
      registrantCountry: 'GH',
      nameServers: brandRecord.nameservers,
      dnssec: 'active',
      rawWhoisText,
      dnsRecords: brandRecord.dnsRecords,
      httpStatus: httpInfo,
      authoritativeSource: 'IN_HOUSE_BRAND_DATABASE',
    };
  }

  // 2. Parallel Live DNS & RDAP querying
  const [dnsResult, rdapResult] = await Promise.all([
    queryLiveDns(domain),
    queryLiveRdap(domain),
  ]);

  // Construct structured DNS records
  const dnsRecordsList: { type: string; name: string; value: string; ttl?: number; priority?: number }[] = [];
  dnsResult.ipv4.forEach((ip) => dnsRecordsList.push({ type: 'A', name: '@', value: ip, ttl: 300 }));
  dnsResult.ipv6.forEach((ip6) => dnsRecordsList.push({ type: 'AAAA', name: '@', value: ip6, ttl: 300 }));
  dnsResult.nameservers.forEach((ns) => dnsRecordsList.push({ type: 'NS', name: '@', value: ns, ttl: 86400 }));
  dnsResult.mxRecords.forEach((mx) => dnsRecordsList.push({ type: 'MX', name: '@', value: mx.exchange, ttl: 3600, priority: mx.priority }));
  dnsResult.txtRecords.forEach((txt) => dnsRecordsList.push({ type: 'TXT', name: '@', value: txt, ttl: 3600 }));

  // Probe web server if DNS resolved
  let httpStatusResult: any = { isOnline: false };
  if (dnsResult.ipv4.length > 0 || dnsResult.hasDns) {
    httpStatusResult = await probeLiveWebServer(domain, dnsResult.ipv4[0]);
  }

  // Extract metadata from RDAP
  if (rdapResult.found && rdapResult.data) {
    const data = rdapResult.data;

    // Find registrar name from entities
    let registrarName = 'ICANN Accredited Registrar';
    let registrarIanaId = '';
    let registrantOrg = 'Redacted for Privacy';
    let registrantCountry = 'Global / Hidden';

    if (Array.isArray(data.entities)) {
      for (const ent of data.entities) {
        if (ent.roles?.includes('registrar')) {
          registrarName = ent.vcardArray?.[1]?.find((f: any) => f[0] === 'fn')?.[3] || ent.handle || registrarName;
          const ianaEntry = ent.publicIds?.find((p: any) => p.type?.toLowerCase().includes('iana'));
          if (ianaEntry) registrarIanaId = String(ianaEntry.identifier);
        }
        if (ent.roles?.includes('registrant')) {
          const fn = ent.vcardArray?.[1]?.find((f: any) => f[0] === 'fn')?.[3];
          const org = ent.vcardArray?.[1]?.find((f: any) => f[0] === 'org')?.[3];
          registrantOrg = org || fn || registrantOrg;
        }
      }
    }

    // Find creation, update, and expiration events
    let creationDate = 'Historical Record';
    let updatedDate = 'Recent';
    let expirationDate = 'Active Registration';

    if (Array.isArray(data.events)) {
      data.events.forEach((ev: any) => {
        if (ev.eventAction === 'registration') creationDate = ev.eventDate;
        if (ev.eventAction === 'last changed' || ev.eventAction === 'last update') updatedDate = ev.eventDate;
        if (ev.eventAction === 'expiration') expirationDate = ev.eventDate;
      });
    }

    // Extract status codes
    const statusCodes = Array.isArray(data.status) ? data.status.join(', ') : 'clientTransferProhibited, active';
    const nsFromRdap = Array.isArray(data.nameservers)
      ? data.nameservers.map((n: any) => (typeof n === 'string' ? n : n.ldhName || n.handle || ''))
      : [];

    const finalNameservers = nsFromRdap.length > 0 ? nsFromRdap : dnsResult.nameservers;

    const rawWhois = `Domain Name: ${domain.toUpperCase()}
Registry Domain ID: ${data.handle || 'N/A'}
Registrar: ${registrarName}
Registrar IANA ID: ${registrarIanaId || 'N/A'}
Domain Status: ${statusCodes}
Creation Date: ${creationDate}
Updated Date: ${updatedDate}
Registry Expiry Date: ${expirationDate}
Registrant Organization: ${registrantOrg}
${finalNameservers.map((ns: string) => `Name Server: ${ns.toUpperCase()}`).join('\n')}
DNSSEC: ${data.secureDNS?.delegationSigned ? 'signedDelegation' : 'unsigned'}
Authoritative RDAP URL: ${data.links?.[0]?.href || 'https://rdap.org/domain/' + domain}

--- RAW RDAP REGISTRY PAYLOAD ---
${rdapResult.rawJsonString}`;

    return {
      domainName: domain.toUpperCase(),
      status: `REGISTERED (${statusCodes.slice(0, 50)})`,
      isAvailable: false,
      isBrandRegistered: false,
      registrar: registrarName,
      registrarIanaId,
      creationDate,
      updatedDate,
      expirationDate,
      registrantOrganization: registrantOrg,
      registrantCountry,
      nameServers: finalNameservers,
      dnssec: data.secureDNS?.delegationSigned ? 'signedDelegation' : 'unsigned',
      rawWhoisText: rawWhois,
      dnsRecords: dnsRecordsList,
      httpStatus: httpStatusResult,
      authoritativeSource: 'LIVE_RDAP_DNS',
    };
  }

  // 3. If RDAP was not found but Authoritative DNS records exist:
  if (dnsResult.hasDns) {
    const rawWhois = `Domain Name: ${domain.toUpperCase()}
Registry Status: REGISTERED (Authoritative DNS Records Active Worldwide)
Nameservers:
${dnsResult.nameservers.map((ns) => `  - ${ns}`).join('\n')}
IP Addresses (A Records):
${dnsResult.ipv4.map((ip) => `  - ${ip}`).join('\n')}
Mail Exchangers (MX):
${dnsResult.mxRecords.map((m) => `  - ${m.exchange} (Priority ${m.priority})`).join('\n')}
SOA Record Primary Master: ${dnsResult.soaRecord?.nsname || 'Active'}
DNSSEC: unsigned
Note: Global root nameservers confirm active domain delegation.`;

    return {
      domainName: domain.toUpperCase(),
      status: 'REGISTERED (Active DNS Zone Delegated)',
      isAvailable: false,
      isBrandRegistered: false,
      registrar: 'Global Registry / External Registrar',
      creationDate: 'Active Record',
      updatedDate: new Date().toISOString().split('T')[0],
      expirationDate: 'Active Delegated Zone',
      registrantOrganization: 'Protected by Privacy Guard',
      registrantCountry: 'Unknown',
      nameServers: dnsResult.nameservers,
      dnssec: 'unsigned',
      rawWhoisText: rawWhois,
      dnsRecords: dnsRecordsList,
      httpStatus: httpStatusResult,
      authoritativeSource: 'AUTHORITATIVE_DNS',
    };
  }

  // 4. If No RDAP and No DNS -> Truly AVAILABLE!
  const availableText = `========================================================================
DOMAINS REGISTRY SEARCH RESULT
========================================================================
Domain Name: ${domain.toUpperCase()}
Status: AVAILABLE FOR IMMEDIATE REGISTRATION
Registry Operator: ApexDomain Global Registrar Gateway
Estimated Setup Time: Instant (under 60 seconds)
Whois Privacy Protection: Included Free of Charge
DNS Management: Apex Anycast DNS Included

This domain is currently unregistered and available for first-come, first-served purchase.
You can register this domain now with direct checkout or add it to your shopping cart.
========================================================================`;

  return {
    domainName: domain.toUpperCase(),
    status: 'AVAILABLE FOR REGISTRATION',
    isAvailable: true,
    isBrandRegistered: false,
    registrar: 'ApexDomain Enterprise (Ready to Register)',
    creationDate: 'N/A (Unregistered)',
    updatedDate: 'N/A',
    expirationDate: 'N/A',
    registrantOrganization: 'N/A (Available)',
    registrantCountry: 'N/A',
    nameServers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
    dnssec: 'Supported',
    rawWhoisText: availableText,
    dnsRecords: [],
    httpStatus: { isOnline: false },
    authoritativeSource: 'LIVE_RDAP_DNS',
  };
}

// 5. Batch Availability Checker with parallel processing
export async function batchCheckAvailability(domains: string[]): Promise<
  {
    domain: string;
    isAvailable: boolean;
    isBrandRegistered: boolean;
    brandRegistrar?: string;
    ownerEmail?: string;
    registrar?: string;
    status: string;
  }[]
> {
  const results = await Promise.all(
    domains.slice(0, 20).map(async (dom) => {
      const clean = dom.toLowerCase().trim();
      
      // Fast check in-house first
      if (IN_HOUSE_BRAND_DOMAINS.has(clean)) {
        const brand = IN_HOUSE_BRAND_DOMAINS.get(clean)!;
        return {
          domain: clean,
          isAvailable: false,
          isBrandRegistered: true,
          brandRegistrar: brand.registrar,
          ownerEmail: brand.ownerEmail,
          registrar: brand.registrar,
          status: 'REGISTERED (In-House with ApexDomain / Celoxa)',
        };
      }

      // Live check
      try {
        const whois = await lookupDomainAuthoritative(clean);
        return {
          domain: clean,
          isAvailable: whois.isAvailable,
          isBrandRegistered: whois.isBrandRegistered,
          brandRegistrar: whois.brandRegistrar,
          ownerEmail: whois.brandAccountEmail,
          registrar: whois.registrar,
          status: whois.status,
        };
      } catch {
        return {
          domain: clean,
          isAvailable: true,
          isBrandRegistered: false,
          status: 'AVAILABLE',
        };
      }
    })
  );

  return results;
}

// 6. In-house Registration Mutator
export function registerDomainInHouse(record: BrandDomainRecord) {
  IN_HOUSE_BRAND_DOMAINS.set(record.domain.toLowerCase().trim(), record);
}

export function getAllBrandRegisteredDomains(): BrandDomainRecord[] {
  return Array.from(IN_HOUSE_BRAND_DOMAINS.values());
}
