import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

// Encryption configuration
const ENCRYPTION_ALGORITHM = 'aes-256-gcm';
const SERVER_SECRET_KEY = process.env.PAYMENT_CONFIG_SECRET || process.env.SESSION_SECRET || 'celoxa-paystack-master-encryption-key-2026';
const CONFIG_FILE_PATH = path.join(process.cwd(), '.server_paystack_config.json');
const AUDIT_FILE_PATH = path.join(process.cwd(), '.server_payment_audit.json');
const WEBHOOK_LOGS_FILE_PATH = path.join(process.cwd(), '.server_webhook_logs.json');

// Interface for Paystack Stored Configuration
export interface PaystackStoredConfig {
  enabled: boolean;
  environment: 'test' | 'live';
  publicKey: string;
  encryptedSecretKey: string;
  secretKeyIv: string;
  secretKeyAuthTag: string;
  merchantName: string;
  currencyPreference: string;
  allowedChannels: string[];
  callbackUrl?: string;
  webhookUrl?: string;
  lastUpdated: string;
  lastUpdatedBy?: string;
}

// Interface for Public Sanitized Config returned to Admin UI
export interface PaystackSanitizedConfig {
  enabled: boolean;
  environment: 'test' | 'live';
  publicKey: string;
  isSecretKeyConfigured: boolean;
  maskedSecretKey: string;
  merchantName: string;
  currencyPreference: string;
  allowedChannels: string[];
  callbackUrl: string;
  webhookUrl: string;
  lastUpdated: string;
  healthStatus: 'healthy' | 'warning' | 'error' | 'unconfigured';
}

export interface PaymentAuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  environment: 'test' | 'live';
  details: string;
  status: 'success' | 'failed' | 'warning';
  ipAddress?: string;
}

export interface WebhookLogEntry {
  id: string;
  timestamp: string;
  event: string;
  reference: string;
  amount?: number;
  currency?: string;
  channel?: string;
  signatureValid: boolean;
  status: 'processed' | 'ignored_duplicate' | 'failed' | 'signature_mismatch';
  processingTimeMs: number;
  error?: string;
}

// Encryption Helpers
function getDerivedKey(): Buffer {
  return crypto.scryptSync(SERVER_SECRET_KEY, 'celoxa_salt_ghana_paystack_v1', 32);
}

function encryptSecretKey(plainText: string): { encrypted: string; iv: string; authTag: string } {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, getDerivedKey(), iv);
  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return {
    encrypted,
    iv: iv.toString('hex'),
    authTag,
  };
}

function decryptSecretKey(encryptedHex: string, ivHex: string, authTagHex: string): string {
  if (!encryptedHex || !ivHex || !authTagHex) return '';
  try {
    const decipher = crypto.createDecipheriv(
      ENCRYPTION_ALGORITHM,
      getDerivedKey(),
      Buffer.from(ivHex, 'hex')
    );
    decipher.setAuthTag(Buffer.from(authTagHex, 'hex'));
    let decrypted = decipher.update(encryptedHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    console.error('[PaystackService] Failed to decrypt secret key:', err);
    return '';
  }
}

class PaystackService {
  private configCache: PaystackStoredConfig | null = null;
  private processedReferences: Set<string> = new Set();
  private auditLogs: PaymentAuditLog[] = [];
  private webhookLogs: WebhookLogEntry[] = [];

  constructor() {
    this.loadConfig();
    this.loadAuditLogs();
    this.loadWebhookLogs();
  }

  private loadConfig() {
    try {
      if (fs.existsSync(CONFIG_FILE_PATH)) {
        const raw = fs.readFileSync(CONFIG_FILE_PATH, 'utf-8');
        this.configCache = JSON.parse(raw);
      }
    } catch (err) {
      console.warn('[PaystackService] Could not read config file, initializing defaults:', err);
    }

    // If no file config exists or fallback, bootstrap with the configured Live Paystack credentials
    const DEFAULT_LIVE_PUBLIC_KEY = 'pk_live_93621f2292fc2f1396ddc18fea182881a6f55e1b';
    const DEFAULT_LIVE_SECRET_KEY = 'sk_live_1a5c6f59c88c52262c2a1e2b38935c5c859edfbd';

    if (!this.configCache) {
      const envSecret = process.env.PAYSTACK_SECRET_KEY || DEFAULT_LIVE_SECRET_KEY;
      const envPublic = process.env.PAYSTACK_PUBLIC_KEY || DEFAULT_LIVE_PUBLIC_KEY;
      const isTest = envSecret.startsWith('sk_test_') || envPublic.startsWith('pk_test_');

      const encrypted = encryptSecretKey(envSecret);
      this.configCache = {
        enabled: true,
        environment: isTest ? 'test' : 'live',
        publicKey: envPublic,
        encryptedSecretKey: encrypted.encrypted,
        secretKeyIv: encrypted.iv,
        secretKeyAuthTag: encrypted.authTag,
        merchantName: 'Celoxa Ghana / ApexDomain Enterprise (Live Paystack)',
        currencyPreference: 'GHS',
        allowedChannels: ['card', 'mobile_money', 'bank_transfer', 'ussd'],
        lastUpdated: new Date().toISOString(),
        lastUpdatedBy: 'Live Paystack Bootstrap Key Injector',
      };
      this.persistConfig();
    } else if (
      this.configCache.publicKey.startsWith('pk_test_') ||
      !this.configCache.publicKey ||
      this.configCache.publicKey.includes('apexdomain_ghana')
    ) {
      // Upgrade from placeholder/test key to user's provided live keys
      const encrypted = encryptSecretKey(DEFAULT_LIVE_SECRET_KEY);
      this.configCache = {
        ...this.configCache,
        enabled: true,
        environment: 'live',
        publicKey: DEFAULT_LIVE_PUBLIC_KEY,
        encryptedSecretKey: encrypted.encrypted,
        secretKeyIv: encrypted.iv,
        secretKeyAuthTag: encrypted.authTag,
        lastUpdated: new Date().toISOString(),
        lastUpdatedBy: 'Live Paystack Key Upgrade',
      };
      this.persistConfig();
    }
  }

  private persistConfig() {
    if (!this.configCache) return;
    try {
      fs.writeFileSync(CONFIG_FILE_PATH, JSON.stringify(this.configCache, null, 2), 'utf-8');
    } catch (err) {
      console.error('[PaystackService] Failed to persist config to disk:', err);
    }
  }

  private loadAuditLogs() {
    try {
      if (fs.existsSync(AUDIT_FILE_PATH)) {
        const raw = fs.readFileSync(AUDIT_FILE_PATH, 'utf-8');
        this.auditLogs = JSON.parse(raw);
      }
    } catch (err) {
      this.auditLogs = [];
    }
  }

  private persistAuditLogs() {
    try {
      fs.writeFileSync(AUDIT_FILE_PATH, JSON.stringify(this.auditLogs.slice(0, 500), null, 2), 'utf-8');
    } catch (err) {
      console.error('[PaystackService] Failed to persist audit logs:', err);
    }
  }

  private loadWebhookLogs() {
    try {
      if (fs.existsSync(WEBHOOK_LOGS_FILE_PATH)) {
        const raw = fs.readFileSync(WEBHOOK_LOGS_FILE_PATH, 'utf-8');
        this.webhookLogs = JSON.parse(raw);
      }
    } catch (err) {
      this.webhookLogs = [];
    }
  }

  private persistWebhookLogs() {
    try {
      fs.writeFileSync(WEBHOOK_LOGS_FILE_PATH, JSON.stringify(this.webhookLogs.slice(0, 500), null, 2), 'utf-8');
    } catch (err) {
      console.error('[PaystackService] Failed to persist webhook logs:', err);
    }
  }

  public logAudit(actor: string, action: string, details: string, status: 'success' | 'failed' | 'warning', ipAddress?: string) {
    const entry: PaymentAuditLog = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actor: actor || 'System Admin',
      action,
      environment: this.configCache?.environment || 'test',
      details,
      status,
      ipAddress: ipAddress || '127.0.0.1',
    };
    this.auditLogs.unshift(entry);
    this.persistAuditLogs();
  }

  public logWebhook(entry: Omit<WebhookLogEntry, 'id' | 'timestamp'>) {
    const fullEntry: WebhookLogEntry = {
      id: `whlog-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      ...entry,
    };
    this.webhookLogs.unshift(fullEntry);
    this.persistWebhookLogs();
  }

  public getAuditLogs(): PaymentAuditLog[] {
    return [...this.auditLogs];
  }

  public getWebhookLogs(): WebhookLogEntry[] {
    return [...this.webhookLogs];
  }

  // Get raw active secret key for server-side API execution only
  public getActiveSecretKey(): string {
    if (!this.configCache) {
      return process.env.PAYSTACK_SECRET_KEY || '';
    }
    const decrypted = decryptSecretKey(
      this.configCache.encryptedSecretKey,
      this.configCache.secretKeyIv,
      this.configCache.secretKeyAuthTag
    );
    if (!decrypted && process.env.PAYSTACK_SECRET_KEY) {
      return process.env.PAYSTACK_SECRET_KEY;
    }
    return decrypted;
  }

  // Get sanitized config for frontend UI
  public getSanitizedConfig(originUrl?: string): PaystackSanitizedConfig {
    const secretKey = this.getActiveSecretKey();
    const hasSecretKey = Boolean(secretKey && secretKey.length > 8);
    const origin = originUrl || (typeof process !== 'undefined' && process.env.APP_URL) || 'https://celoxaghana.online';

    if (!this.configCache) {
      return {
        enabled: false,
        environment: 'test',
        publicKey: process.env.PAYSTACK_PUBLIC_KEY || '',
        isSecretKeyConfigured: hasSecretKey,
        maskedSecretKey: hasSecretKey ? '••••••••••••••••••••••••••••••••' : '',
        merchantName: 'ApexDomain Enterprise',
        currencyPreference: 'GHS',
        allowedChannels: ['card', 'mobile_money', 'bank_transfer', 'ussd'],
        callbackUrl: `${origin}/`,
        webhookUrl: `${origin}/api/payments/paystack/webhook`,
        lastUpdated: new Date().toISOString(),
        healthStatus: hasSecretKey ? 'healthy' : 'unconfigured',
      };
    }

    const isHealthy = this.configCache.enabled && hasSecretKey && Boolean(this.configCache.publicKey);

    return {
      enabled: this.configCache.enabled,
      environment: this.configCache.environment,
      publicKey: this.configCache.publicKey || '',
      isSecretKeyConfigured: hasSecretKey,
      maskedSecretKey: hasSecretKey ? '••••••••••••••••••••••••••••••••' : '',
      merchantName: this.configCache.merchantName || 'ApexDomain Enterprise',
      currencyPreference: this.configCache.currencyPreference || 'GHS',
      allowedChannels: this.configCache.allowedChannels || ['card', 'mobile_money', 'bank_transfer', 'ussd'],
      callbackUrl: this.configCache.callbackUrl || `${origin}/`,
      webhookUrl: this.configCache.webhookUrl || `${origin}/api/payments/paystack/webhook`,
      lastUpdated: this.configCache.lastUpdated,
      healthStatus: isHealthy ? 'healthy' : hasSecretKey ? 'warning' : 'unconfigured',
    };
  }

  // Update configuration with encryption, verification, and cache reload
  public async saveConfig(payload: {
    enabled: boolean;
    environment: 'test' | 'live';
    publicKey: string;
    secretKey?: string; // If omitted, keep existing secret key
    merchantName?: string;
    currencyPreference?: string;
    allowedChannels?: string[];
    callbackUrl?: string;
    webhookUrl?: string;
    updatedBy?: string;
    ipAddress?: string;
  }): Promise<{ success: boolean; message: string; config: PaystackSanitizedConfig; verifiedTest?: any }> {
    const { enabled, environment, publicKey, secretKey, merchantName, currencyPreference, allowedChannels, callbackUrl, webhookUrl, updatedBy, ipAddress } = payload;

    // 1. Validate Public Key format
    const cleanPublicKey = (publicKey || '').trim();
    if (enabled && !cleanPublicKey) {
      throw new Error('Public Key is required when Paystack gateway is enabled.');
    }

    if (cleanPublicKey) {
      if (environment === 'test' && !cleanPublicKey.startsWith('pk_test_')) {
        throw new Error('In Test Mode, Public Key must begin with "pk_test_"');
      }
      if (environment === 'live' && !cleanPublicKey.startsWith('pk_live_')) {
        throw new Error('In Live Mode, Public Key must begin with "pk_live_"');
      }
    }

    // 2. Handle Secret Key
    let finalEncrypted = this.configCache?.encryptedSecretKey || '';
    let finalIv = this.configCache?.secretKeyIv || '';
    let finalAuthTag = this.configCache?.secretKeyAuthTag || '';
    let secretKeyToTest = '';

    if (secretKey && secretKey.trim().length > 0) {
      const cleanSecretKey = secretKey.trim();

      // Check format
      if (environment === 'test' && !cleanSecretKey.startsWith('sk_test_')) {
        throw new Error('In Test Mode, Secret Key must begin with "sk_test_"');
      }
      if (environment === 'live' && !cleanSecretKey.startsWith('sk_live_')) {
        throw new Error('In Live Mode, Secret Key must begin with "sk_live_"');
      }

      const encrypted = encryptSecretKey(cleanSecretKey);
      finalEncrypted = encrypted.encrypted;
      finalIv = encrypted.iv;
      finalAuthTag = encrypted.authTag;
      secretKeyToTest = cleanSecretKey;
    } else {
      // Kept existing key
      secretKeyToTest = this.getActiveSecretKey();
    }

    if (enabled && !finalEncrypted && !process.env.PAYSTACK_SECRET_KEY) {
      throw new Error('Secret Key is required when Paystack gateway is enabled.');
    }

    // 3. Update in-memory configuration object
    const newConfig: PaystackStoredConfig = {
      enabled,
      environment,
      publicKey: cleanPublicKey,
      encryptedSecretKey: finalEncrypted,
      secretKeyIv: finalIv,
      secretKeyAuthTag: finalAuthTag,
      merchantName: merchantName || 'ApexDomain Enterprise (Paystack Gateway)',
      currencyPreference: currencyPreference || 'GHS',
      allowedChannels: allowedChannels && allowedChannels.length > 0 ? allowedChannels : ['card', 'mobile_money', 'bank_transfer', 'ussd'],
      callbackUrl,
      webhookUrl,
      lastUpdated: new Date().toISOString(),
      lastUpdatedBy: updatedBy || 'Administrator',
    };

    this.configCache = newConfig;

    // 4. Persist to secure disk storage
    this.persistConfig();

    // 5. Read back and verify decryption integrity
    const decryptedBack = this.getActiveSecretKey();
    if (finalEncrypted && !decryptedBack) {
      this.logAudit(updatedBy || 'Admin', 'Config Save Failed', 'Encryption/Decryption verification failed on save', 'failed', ipAddress);
      throw new Error('Cryptographic verification failed: Secret key could not be decrypted after saving.');
    }

    this.logAudit(
      updatedBy || 'Admin',
      'Update Paystack Configuration',
      `Updated Paystack settings. Environment: ${environment.toUpperCase()}, Gateway: ${enabled ? 'ENABLED' : 'DISABLED'}, Channels: ${newConfig.allowedChannels.join(', ')}`,
      'success',
      ipAddress
    );

    return {
      success: true,
      message: 'Paystack gateway settings securely encrypted and saved to server storage.',
      config: this.getSanitizedConfig(),
    };
  }

  // Live test connection with Paystack servers
  public async testConnection(overrideSecretKey?: string): Promise<{
    success: boolean;
    environment: 'test' | 'live';
    latencyMs: number;
    message: string;
    banksCount?: number;
    merchantInfo?: any;
    error?: string;
  }> {
    const keyToUse = overrideSecretKey ? overrideSecretKey.trim() : this.getActiveSecretKey();

    if (!keyToUse || keyToUse.length < 5) {
      return {
        success: false,
        environment: this.configCache?.environment || 'test',
        latencyMs: 0,
        message: 'Paystack Secret Key is missing or not configured.',
        error: 'No secret key available for testing.',
      };
    }

    const env: 'test' | 'live' = keyToUse.startsWith('sk_live_') ? 'live' : 'test';
    const startTime = Date.now();

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      const response = await fetch('https://api.paystack.co/bank?country=ghana', {
        headers: {
          Authorization: `Bearer ${keyToUse}`,
          'Content-Type': 'application/json',
        },
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;
      const data = await response.json();

      if (response.ok && data.status) {
        this.logAudit('Admin / System', 'Test Paystack Connection', `Connection test succeeded (${env.toUpperCase()} mode, ${latencyMs}ms latency).`, 'success');
        return {
          success: true,
          environment: env,
          latencyMs,
          message: `Paystack API connection verified successfully! Environment: ${env.toUpperCase()}, Response latency: ${latencyMs}ms. ${data.data?.length || 0} settlement banks retrieved.`,
          banksCount: data.data?.length || 0,
        };
      } else {
        const errorMsg = data.message || 'Paystack server rejected the secret key.';
        this.logAudit('Admin / System', 'Test Paystack Connection', `Connection test failed: ${errorMsg}`, 'failed');
        return {
          success: false,
          environment: env,
          latencyMs,
          message: `Paystack connection test failed: ${errorMsg}`,
          error: errorMsg,
        };
      }
    } catch (err: any) {
      const latencyMs = Date.now() - startTime;
      const errMsg = err.name === 'AbortError' ? 'Connection timed out after 10 seconds' : err.message || 'Network error reaching Paystack';
      this.logAudit('Admin / System', 'Test Paystack Connection', `Network connection failure: ${errMsg}`, 'failed');
      return {
        success: false,
        environment: env,
        latencyMs,
        message: `Failed to connect to Paystack API: ${errMsg}`,
        error: errMsg,
      };
    }
  }

  // Health check diagnostic
  public async getHealthReport(): Promise<{
    environment: 'test' | 'live';
    publicKeyStatus: { configured: boolean; keyPrefix: string };
    secretKeyStatus: { configured: boolean; decryptable: boolean };
    storageStatus: { persistent: boolean; fileExists: boolean };
    apiConnectivity: { connected: boolean; latencyMs: number; error?: string };
    webhookStatus: { configured: boolean; url: string };
    overallStatus: 'READY' | 'WARNING' | 'NOT_CONFIGURED';
    summary: string;
  }> {
    const secretKey = this.getActiveSecretKey();
    const isSecretConfigured = Boolean(secretKey && secretKey.length > 5);
    const pubKey = this.configCache?.publicKey || process.env.PAYSTACK_PUBLIC_KEY || '';
    const isPubConfigured = Boolean(pubKey && pubKey.length > 5);
    const fileExists = fs.existsSync(CONFIG_FILE_PATH);
    const env = this.configCache?.environment || (secretKey.startsWith('sk_live_') ? 'live' : 'test');

    let apiConnected = false;
    let latency = 0;
    let apiError: string | undefined;

    if (isSecretConfigured) {
      const testRes = await this.testConnection();
      apiConnected = testRes.success;
      latency = testRes.latencyMs;
      apiError = testRes.error;
    }

    const origin = (typeof process !== 'undefined' && process.env.APP_URL) || 'https://celoxaghana.online';
    const webhookUrl = `${origin}/api/payments/paystack/webhook`;

    let overall: 'READY' | 'WARNING' | 'NOT_CONFIGURED' = 'NOT_CONFIGURED';
    if (isSecretConfigured && isPubConfigured && apiConnected) {
      overall = 'READY';
    } else if (isSecretConfigured || isPubConfigured) {
      overall = 'WARNING';
    }

    return {
      environment: env,
      publicKeyStatus: {
        configured: isPubConfigured,
        keyPrefix: pubKey ? pubKey.slice(0, 8) + '...' : 'none',
      },
      secretKeyStatus: {
        configured: isSecretConfigured,
        decryptable: isSecretConfigured,
      },
      storageStatus: {
        persistent: true,
        fileExists,
      },
      apiConnectivity: {
        connected: apiConnected,
        latencyMs: latency,
        error: apiError,
      },
      webhookStatus: {
        configured: true,
        url: webhookUrl,
      },
      overallStatus: overall,
      summary:
        overall === 'READY'
          ? `Paystack Gateway is 100% operational in ${env.toUpperCase()} mode.`
          : overall === 'WARNING'
          ? 'Paystack credentials configured but live connectivity test encountered an issue.'
          : 'Paystack Gateway is not configured. Please enter Public and Secret Keys in Admin Settings.',
    };
  }

  // Real Server-Side Payment Initialization
  public async initializeTransaction(params: {
    email: string;
    amount: number; // In main currency unit, e.g. 150.00 GHS
    currency?: string;
    reference?: string;
    metadata?: Record<string, any>;
    callbackUrl?: string;
    channels?: string[];
  }): Promise<{
    success: boolean;
    authorization_url?: string;
    access_code?: string;
    reference: string;
    publicKey: string;
    amountSubunits: number;
    currency: string;
    error?: string;
  }> {
    const { email, amount, currency = 'GHS', reference, metadata = {}, callbackUrl, channels } = params;

    const secretKey = this.getActiveSecretKey();
    if (!secretKey) {
      throw new Error('Paystack secret key is not configured on the server.');
    }

    const cleanCurrency = currency.toUpperCase();
    const amountSubunits = Math.round(amount * 100);
    const uniqueRef = reference || `PAY-APX-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100000 + Math.random() * 900000)}`;

    const paystackPayload: any = {
      email,
      amount: amountSubunits,
      currency: cleanCurrency,
      reference: uniqueRef,
      metadata: {
        ...metadata,
        initialized_at: new Date().toISOString(),
      },
    };

    if (callbackUrl) {
      paystackPayload.callback_url = callbackUrl;
    }

    if (channels && channels.length > 0) {
      paystackPayload.channels = channels;
    } else if (this.configCache?.allowedChannels && this.configCache.allowedChannels.length > 0) {
      paystackPayload.channels = this.configCache.allowedChannels;
    }

    const response = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(paystackPayload),
    });

    const data = await response.json();

    if (response.ok && data.status) {
      this.logAudit(
        email,
        'Initialize Paystack Transaction',
        `Transaction initialized: ${uniqueRef} for ${cleanCurrency} ${amount.toFixed(2)}`,
        'success'
      );

      return {
        success: true,
        authorization_url: data.data.authorization_url,
        access_code: data.data.access_code,
        reference: data.data.reference || uniqueRef,
        publicKey: this.configCache?.publicKey || process.env.PAYSTACK_PUBLIC_KEY || '',
        amountSubunits,
        currency: cleanCurrency,
      };
    } else {
      const errMsg = data.message || 'Failed to initialize Paystack transaction.';
      this.logAudit(
        email,
        'Initialize Paystack Transaction Failed',
        `Failed to initialize transaction ${uniqueRef}: ${errMsg}`,
        'failed'
      );
      throw new Error(errMsg);
    }
  }

  // Real Server-Side Payment Verification
  public async verifyTransaction(reference: string): Promise<{
    success: boolean;
    verified: boolean;
    status: string;
    amount: number;
    currency: string;
    reference: string;
    channel?: string;
    paidAt?: string;
    customer?: any;
    gatewayResponse?: string;
    metadata?: any;
    error?: string;
  }> {
    if (!reference) {
      throw new Error('Transaction reference is required for verification.');
    }

    const secretKey = this.getActiveSecretKey();
    if (!secretKey) {
      throw new Error('Paystack secret key is not configured on the server.');
    }

    const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: {
        Authorization: `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
      },
    });

    const data = await response.json();

    if (response.ok && data.status) {
      const isSuccess = data.data.status === 'success';
      const paidAmount = (data.data.amount || 0) / 100;

      this.logAudit(
        data.data.customer?.email || 'Customer',
        'Verify Paystack Payment',
        `Transaction ${reference} verified. Status: ${data.data.status.toUpperCase()}, Amount: ${data.data.currency} ${paidAmount.toFixed(2)}`,
        isSuccess ? 'success' : 'warning'
      );

      return {
        success: true,
        verified: isSuccess,
        status: data.data.status,
        amount: paidAmount,
        currency: data.data.currency,
        reference: data.data.reference,
        channel: data.data.channel,
        paidAt: data.data.paid_at,
        customer: data.data.customer,
        gatewayResponse: data.data.gateway_response,
        metadata: data.data.metadata,
      };
    } else {
      const errMsg = data.message || 'Unable to verify transaction with Paystack.';
      this.logAudit('System', 'Verify Paystack Payment Failed', `Verification failed for reference ${reference}: ${errMsg}`, 'failed');
      return {
        success: false,
        verified: false,
        status: 'failed',
        amount: 0,
        currency: 'GHS',
        reference,
        error: errMsg,
      };
    }
  }

  // Verify Webhook Signature using HMAC SHA-512
  public verifyWebhookSignature(rawBody: string, signature: string): boolean {
    const secretKey = this.getActiveSecretKey();
    if (!secretKey || !signature) return false;

    const hash = crypto.createHmac('sha512', secretKey).update(rawBody).digest('hex');
    return hash === signature;
  }

  // Idempotent webhook event processor
  public isEventAlreadyProcessed(reference: string): boolean {
    if (!reference) return false;
    if (this.processedReferences.has(reference)) return true;
    this.processedReferences.add(reference);
    if (this.processedReferences.size > 2000) {
      const first = this.processedReferences.values().next().value;
      if (first) this.processedReferences.delete(first);
    }
    return false;
  }
}

export const paystackService = new PaystackService();
