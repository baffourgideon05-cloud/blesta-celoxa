import { RegisteredDomain } from '../types';

export const INITIAL_REGISTERED_DOMAINS: RegisteredDomain[] = [
  {
    id: 'reg-celoxa',
    domain: 'celoxaghana.online',
    registeredDate: '2025-01-01',
    expiryDate: '2028-01-01',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-CELOXA-772910-GH',
    status: 'active',
    registrationPrice: 120,
    renewalPrice: 120,
    currency: 'GHS',
    billingCycle: '1 Year',
    orderId: 'ORD-10482',
    invoiceId: 'INV-10482',
    paymentStatus: 'Paid',
    serviceId: 'DOM-10482',
    customerName: 'Gideon Baffour',
    customerEmail: 'baffourgideon05@gmail.com',
    nameserverMode: 'system_default',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
    customNameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', '', ''],
    nameserverUpdatedDate: '2025-01-01',
    nameserverUpdatedBy: 'System',
    registrarProvider: 'resellerclub',
    registrarAccount: 'Reseller Account #01',
    providerDomainId: 'RC-DOM-772910',
    lastSyncDate: '2026-08-19 14:20 UTC',
    syncStatus: 'synced',
    provisioningState: 'completed',
    contactInfo: {
      registrantName: 'Gideon Baffour',
      registrantEmail: 'baffourgideon05@gmail.com',
      registrantPhone: '+233 24 000 0000',
      organization: 'Celoxa Ghana',
      country: 'Ghana (GH)'
    },
    activityTimeline: [
      { id: 'act-1', title: 'Domain Registered', description: 'Domain successfully registered for 3-year term.', date: '01 Jan 2025', type: 'registration' },
      { id: 'act-2', title: 'Payment Completed', description: 'Order #ORD-10482 paid in full via Paystack.', date: '01 Jan 2025', type: 'payment' },
      { id: 'act-3', title: 'System Default Nameservers Configured', description: 'Delegated to ns1.apexdomain.com, ns2.apexdomain.com.', date: '01 Jan 2025', type: 'nameserver' },
      { id: 'act-4', title: 'Auto-Renewal Configured', description: 'Auto-renewal enabled with active payment method.', date: '15 Jan 2025', type: 'renewal' }
    ],
    dnsRecords: [
      { id: 'dns-celoxa-1', type: 'A', name: '@', value: '198.51.100.42', ttl: 3600 },
      { id: 'dns-celoxa-2', type: 'CNAME', name: 'www', value: 'celoxaghana.online', ttl: 3600 },
      { id: 'dns-celoxa-3', type: 'MX', name: '@', value: 'mail.celoxaghana.online', ttl: 3600, priority: 10 },
      { id: 'dns-celoxa-4', type: 'TXT', name: '@', value: 'v=spf1 include:_spf.apexdomain.com ~all', ttl: 3600 },
      { id: 'dns-celoxa-5', type: 'TXT', name: '_ghana-verification', value: 'celoxa-ghana-verified-active-2026', ttl: 3600 }
    ],
    emailForwarding: [
      { id: 'ef-celoxa-1', source: 'info@celoxaghana.online', destination: 'admin@celoxaghana.online', active: true },
      { id: 'ef-celoxa-2', source: 'support@celoxaghana.online', destination: 'help@celoxaghana.online', active: true }
    ]
  },
  {
    id: 'reg-1',
    domain: 'apexcloud.io',
    registeredDate: '2025-01-15',
    expiryDate: '2027-01-15',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-APEX-992384-IO',
    status: 'active',
    registrationPrice: 480,
    renewalPrice: 480,
    currency: 'GHS',
    billingCycle: '1 Year',
    orderId: 'ORD-10319',
    invoiceId: 'INV-10319',
    paymentStatus: 'Paid',
    serviceId: 'DOM-10319',
    customerName: 'Gideon Baffour',
    customerEmail: 'baffourgideon05@gmail.com',
    nameserverMode: 'system_default',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
    customNameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', '', ''],
    nameserverUpdatedDate: '2025-01-15',
    nameserverUpdatedBy: 'System',
    registrarProvider: 'enom',
    registrarAccount: 'Enom Master Partner #04',
    providerDomainId: 'ENOM-DOM-992384',
    lastSyncDate: '2026-08-19 12:10 UTC',
    syncStatus: 'synced',
    provisioningState: 'completed',
    contactInfo: {
      registrantName: 'Gideon Baffour',
      registrantEmail: 'baffourgideon05@gmail.com',
      registrantPhone: '+233 24 000 0000',
      organization: 'ApexCloud Corp',
      country: 'Ghana (GH)'
    },
    activityTimeline: [
      { id: 'act-10', title: 'Domain Registered', description: 'Registered under .io registry policy.', date: '15 Jan 2025', type: 'registration' },
      { id: 'act-11', title: 'Invoice #INV-10319 Settled', description: 'Paid via Mobile Money wallet deduction.', date: '15 Jan 2025', type: 'payment' },
      { id: 'act-12', title: 'DNS Zone Configured', description: 'Zone published to Apex Anycast DNS.', date: '15 Jan 2025', type: 'system' }
    ],
    dnsRecords: [
      { id: 'dns-1', type: 'A', name: '@', value: '76.76.21.21', ttl: 3600 },
      { id: 'dns-2', type: 'CNAME', name: 'www', value: 'cname.vercel-dns.com', ttl: 3600 },
      { id: 'dns-3', type: 'MX', name: '@', value: 'ASPMX.L.GOOGLE.COM', ttl: 3600, priority: 1 },
      { id: 'dns-4', type: 'TXT', name: '@', value: 'v=spf1 include:_spf.google.com ~all', ttl: 3600 }
    ],
    emailForwarding: [
      { id: 'ef-1', source: 'contact@apexcloud.io', destination: 'admin@mycompany.com', active: true },
      { id: 'ef-2', source: 'support@apexcloud.io', destination: 'support-team@mycompany.com', active: true }
    ]
  },
  {
    id: 'reg-2',
    domain: 'nexusapp.com',
    registeredDate: '2024-09-10',
    expiryDate: '2026-09-10',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-NEXUS-881923-COM',
    status: 'expiring_soon',
    registrationPrice: 180,
    renewalPrice: 180,
    currency: 'GHS',
    billingCycle: '1 Year',
    orderId: 'ORD-09881',
    invoiceId: 'INV-09881',
    paymentStatus: 'Paid',
    serviceId: 'DOM-09881',
    customerName: 'Gideon Baffour',
    customerEmail: 'baffourgideon05@gmail.com',
    nameserverMode: 'system_default',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
    customNameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', '', ''],
    nameserverUpdatedDate: '2024-09-10',
    nameserverUpdatedBy: 'System',
    registrarProvider: 'resellerclub',
    registrarAccount: 'Reseller Account #01',
    providerDomainId: 'RC-DOM-881923',
    lastSyncDate: '2026-08-19 09:30 UTC',
    syncStatus: 'synced',
    provisioningState: 'completed',
    contactInfo: {
      registrantName: 'Gideon Baffour',
      registrantEmail: 'baffourgideon05@gmail.com',
      registrantPhone: '+233 24 000 0000',
      organization: 'Nexus App Labs',
      country: 'Ghana (GH)'
    },
    activityTimeline: [
      { id: 'act-20', title: 'Domain Registered', description: 'Registered for 2 years.', date: '10 Sep 2024', type: 'registration' },
      { id: 'act-21', title: 'Renewal Reminder Sent', description: 'Expiring in less than 30 days. Auto-renew scheduled.', date: '10 Aug 2026', type: 'renewal' }
    ],
    dnsRecords: [
      { id: 'dns-5', type: 'A', name: '@', value: '185.199.108.153', ttl: 300 },
      { id: 'dns-6', type: 'A', name: '@', value: '185.199.109.153', ttl: 300 },
      { id: 'dns-7', type: 'TXT', name: '_github-pages-challenge-nexus', value: '9a8b7c6d5e', ttl: 3600 }
    ],
    emailForwarding: [
      { id: 'ef-3', source: 'hello@nexusapp.com', destination: 'founder@gmail.com', active: true }
    ]
  },
  {
    id: 'reg-3',
    domain: 'venturelabs.ai',
    registeredDate: '2025-05-20',
    expiryDate: '2027-05-20',
    autoRenew: false,
    locked: false,
    whoisPrivacy: true,
    authCode: 'EPP-VENTURE-331002-AI',
    status: 'active',
    registrationPrice: 950,
    renewalPrice: 950,
    currency: 'GHS',
    billingCycle: '1 Year',
    orderId: 'ORD-10772',
    invoiceId: 'INV-10772',
    paymentStatus: 'Paid',
    serviceId: 'DOM-10772',
    customerName: 'Gideon Baffour',
    customerEmail: 'baffourgideon05@gmail.com',
    nameserverMode: 'custom',
    nameservers: ['ns1.cloudflare.com', 'ns2.cloudflare.com'],
    customNameservers: ['ns1.cloudflare.com', 'ns2.cloudflare.com', '', ''],
    nameserverUpdatedDate: '2025-05-20',
    nameserverUpdatedBy: 'Customer',
    registrarProvider: 'godaddy',
    registrarAccount: 'GoDaddy Reseller #02',
    providerDomainId: 'GD-DOM-331002',
    lastSyncDate: '2026-08-19 11:00 UTC',
    syncStatus: 'synced',
    provisioningState: 'completed',
    contactInfo: {
      registrantName: 'Gideon Baffour',
      registrantEmail: 'baffourgideon05@gmail.com',
      registrantPhone: '+233 24 000 0000',
      organization: 'Venture Labs Africa',
      country: 'Ghana (GH)'
    },
    activityTimeline: [
      { id: 'act-30', title: 'Domain Registered', description: 'New 2-year AI domain registration.', date: '20 May 2025', type: 'registration' },
      { id: 'act-31', title: 'Custom Cloudflare Nameservers Delegated', description: 'Updated nameservers to ns1.cloudflare.com, ns2.cloudflare.com by customer.', date: '20 May 2025', type: 'nameserver' }
    ],
    dnsRecords: [
      { id: 'dns-8', type: 'NS', name: '@', value: 'ns1.cloudflare.com', ttl: 86400 },
      { id: 'dns-9', type: 'NS', name: '@', value: 'ns2.cloudflare.com', ttl: 86400 }
    ],
    emailForwarding: []
  }
];
