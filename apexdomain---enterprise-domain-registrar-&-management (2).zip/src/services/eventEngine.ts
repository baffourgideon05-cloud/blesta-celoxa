import { notificationEngine } from './notificationEngine';
import { systemDatabase } from './systemDatabase';
import { SystemSettingsConfig } from '../types';

export type SystemEventType = 
  | 'order.created'
  | 'payment.success'
  | 'payment.failed'
  | 'hosting.activated'
  | 'hosting.suspended'
  | 'domain.registered'
  | 'domain.renewed'
  | 'ticket.created'
  | 'ticket.replied'
  | 'staff.action'
  | 'security.alert';

export interface SystemEventPayload {
  eventType: SystemEventType;
  userId?: string;
  customerName?: string;
  customerEmail?: string;
  orderNumber?: string;
  orderId?: string;
  invoiceNumber?: string;
  invoiceId?: string;
  paymentReference?: string;
  amount?: number | string;
  currency?: string;
  domain?: string;
  hostingPlan?: string;
  serviceStatus?: string;
  renewalDate?: string;
  serverNode?: string;
  cpanelUsername?: string;
  staffActor?: string;
  staffAction?: string;
  targetResource?: string;
  details?: string;
  ipAddress?: string;
  metadata?: Record<string, any>;
}

export interface EmailTemplateDefinition {
  id: string;
  name: string;
  subjectTemplate: string;
  bodyTemplate: string;
  category: 'account' | 'order' | 'payment' | 'domain' | 'hosting' | 'support' | 'security';
}

export const STANDARD_EMAIL_TEMPLATES: Record<string, EmailTemplateDefinition> = {
  ORDER_CREATED: {
    id: 'ORDER_CREATED',
    name: 'Order Confirmation & Invoice Generated',
    subjectTemplate: 'Order Received #{{order_number}} - {{company_name}}',
    bodyTemplate: 'Dear {{customer_name}},\n\nThank you for your order #{{order_number}}. Your invoice #{{invoice_number}} totaling {{currency}} {{amount}} has been generated and is awaiting payment.\n\nYou can complete payment via Paystack (Mobile Money / Cards) or Bank Transfer.\n\nDashboard: {{client_dashboard_url}}',
    category: 'order'
  },
  PAYMENT_RECEIPT: {
    id: 'PAYMENT_RECEIPT',
    name: 'Official Payment Receipt & Confirmation',
    subjectTemplate: 'Payment Confirmation: Invoice #{{invoice_number}} - {{company_name}}',
    bodyTemplate: 'Dear {{customer_name}},\n\nWe have successfully received and verified your payment of {{currency}} {{amount}} via reference {{payment_reference}} for invoice #{{invoice_number}}.\n\nYour services are being automatically provisioned now.',
    category: 'payment'
  },
  PAYMENT_FAILED: {
    id: 'PAYMENT_FAILED',
    name: 'Payment Attempt Failed',
    subjectTemplate: 'Action Required: Payment Failed for Order #{{order_number}}',
    bodyTemplate: 'Dear {{customer_name}},\n\nYour recent payment attempt for order #{{order_number}} could not be completed. Please retry your payment using Mobile Money or Card at {{client_dashboard_url}}.',
    category: 'payment'
  },
  HOSTING_ACTIVATED: {
    id: 'HOSTING_ACTIVATED',
    name: 'Hosting Account Instant Activation',
    subjectTemplate: 'Hosting Account Activated: {{domain}} ({{hosting_plan}})',
    bodyTemplate: 'Dear {{customer_name}},\n\nYour hosting plan "{{hosting_plan}}" for {{domain}} is now ACTIVE on server {{server_node}}.\n\nControl Panel Username: {{cpanel_username}}\nManage in Client Portal: {{client_dashboard_url}}',
    category: 'hosting'
  },
  DOMAIN_REGISTERED: {
    id: 'DOMAIN_REGISTERED',
    name: 'Domain Registration Completed',
    subjectTemplate: 'Domain Registration Completed: {{domain}}',
    bodyTemplate: 'Dear {{customer_name}},\n\nCongratulations! Your domain {{domain}} has been successfully registered and secured with WHOIS Privacy & Anycast DNS.\n\nExpiration / Renewal Date: {{renewal_date}}\n\nManage DNS & Nameservers: {{client_dashboard_url}}',
    category: 'domain'
  },
  SECURITY_ALERT: {
    id: 'SECURITY_ALERT',
    name: 'Security Notification',
    subjectTemplate: 'Security Alert: {{details}} - {{company_name}}',
    bodyTemplate: 'Hello {{customer_name}},\n\nA security event was detected on your account: {{details}} from IP {{ip_address}}.\n\nIf this was not you, please lock your session immediately.',
    category: 'security'
  }
};

class CentralEventEngine {
  private listeners: Map<SystemEventType, Array<(payload: SystemEventPayload) => void>> = new Map();

  constructor() {
    this.registerInternalHandlers();
  }

  // --- Variable Interpolation Helper ---
  public interpolate(template: string, vars: Record<string, any>): string {
    const settings = systemDatabase.getSettings();
    const allVars: Record<string, any> = {
      company_name: settings.general?.companyName || 'Celoxa Technologies Ltd',
      site_name: settings.general?.siteName || 'Celoxa Ghana Cloud Systems',
      support_email: settings.general?.contactEmail || 'support@celoxaghana.online',
      client_dashboard_url: typeof window !== 'undefined' ? window.location.origin : 'https://celoxaghana.online',
      ...vars,
    };

    return template.replace(/\{\{([a-zA-Z0-9_]+)\}\}/g, (_, key) => {
      return allVars[key] !== undefined && allVars[key] !== null ? String(allVars[key]) : '';
    });
  }

  // --- Register Internal Core Handlers ---
  private registerInternalHandlers() {
    // 1. Payment Success Pipeline
    this.on('payment.success', (payload) => {
      const settings = systemDatabase.getSettings();
      const companyName = settings.general?.companyName || 'Celoxa Technologies';
      const custName = payload.customerName || 'Valued Customer';
      const custEmail = payload.customerEmail || 'client@celoxaghana.online';
      const invNum = payload.invoiceNumber || 'INV-1001';
      const amtStr = payload.amount ? String(payload.amount) : '0.00';
      const curr = payload.currency || 'GHS';

      // 1a. In-App & Email Dispatch
      const subject = this.interpolate(STANDARD_EMAIL_TEMPLATES.PAYMENT_RECEIPT.subjectTemplate, {
        invoice_number: invNum,
        company_name: companyName
      });
      const body = this.interpolate(STANDARD_EMAIL_TEMPLATES.PAYMENT_RECEIPT.bodyTemplate, {
        customer_name: custName,
        invoice_number: invNum,
        amount: amtStr,
        currency: curr === 'GHS' ? 'GH₵' : '$',
        payment_reference: payload.paymentReference || 'PSTK-REF-AUTO',
      });

      notificationEngine.dispatchEvent({
        userId: payload.userId || 'all',
        recipientEmail: custEmail,
        recipientName: custName,
        category: 'payment',
        title: `Payment Received: Invoice #${invNum}`,
        message: `We verified payment of ${curr === 'GHS' ? 'GH₵' : '$'} ${amtStr} via ${payload.paymentReference || 'Paystack'}.`,
        template: 'PAYMENT_RECEIPT',
        emailSubject: subject,
        actionUrl: 'client_portal',
        actionLabel: 'View Invoices',
        metadata: payload.metadata
      });

      // 1b. Write Audit Log
      systemDatabase.addAuditLog({
        actor: custEmail,
        action: 'PAYMENT_VERIFIED',
        target: `Invoice #${invNum}`,
        details: `Verified payment ${curr} ${amtStr} via Paystack Ref: ${payload.paymentReference || 'N/A'}`,
        ipAddress: payload.ipAddress || '127.0.0.1',
        status: 'success'
      });
    });

    // 2. Hosting Activated Pipeline
    this.on('hosting.activated', (payload) => {
      const custName = payload.customerName || 'Valued Customer';
      const custEmail = payload.customerEmail || 'client@celoxaghana.online';
      const domain = payload.domain || 'mysite.com';
      const plan = payload.hostingPlan || 'NVMe cPanel Cloud';

      const subject = this.interpolate(STANDARD_EMAIL_TEMPLATES.HOSTING_ACTIVATED.subjectTemplate, {
        domain,
        hosting_plan: plan
      });

      notificationEngine.dispatchEvent({
        userId: payload.userId || 'all',
        recipientEmail: custEmail,
        recipientName: custName,
        category: 'hosting',
        title: `Hosting Activated: ${domain}`,
        message: `Your ${plan} hosting account for ${domain} has been automatically provisioned and is active.`,
        template: 'HOSTING_ACTIVATED',
        emailSubject: subject,
        actionUrl: 'command_center',
        actionLabel: 'Open cPanel Hub',
        metadata: payload.metadata
      });

      systemDatabase.addAuditLog({
        actor: 'SYSTEM_AUTOPROVISION',
        action: 'HOSTING_SERVICE_ACTIVATED',
        target: domain,
        details: `Provisioned ${plan} on server node ${payload.serverNode || 'US-EAST-GH1'}`,
        ipAddress: payload.ipAddress || '127.0.0.1',
        status: 'success'
      });
    });

    // 3. Domain Registered Pipeline
    this.on('domain.registered', (payload) => {
      const custName = payload.customerName || 'Valued Customer';
      const custEmail = payload.customerEmail || 'client@celoxaghana.online';
      const domain = payload.domain || 'example.gh';

      const subject = this.interpolate(STANDARD_EMAIL_TEMPLATES.DOMAIN_REGISTERED.subjectTemplate, { domain });

      notificationEngine.dispatchEvent({
        userId: payload.userId || 'all',
        recipientEmail: custEmail,
        recipientName: custName,
        category: 'domain',
        title: `Domain Active: ${domain}`,
        message: `Your domain ${domain} is registered with WHOIS privacy and Anycast DNS.`,
        template: 'DOMAIN_REGISTERED',
        emailSubject: subject,
        actionUrl: 'management',
        actionLabel: 'Manage DNS',
        metadata: payload.metadata
      });

      systemDatabase.addAuditLog({
        actor: 'REGISTRAR_ENGINE',
        action: 'DOMAIN_REGISTRATION_COMPLETED',
        target: domain,
        details: `ICANN & Registry registration verified for 1 year. Auth code generated.`,
        ipAddress: payload.ipAddress || '127.0.0.1',
        status: 'success'
      });
    });

    // 4. Staff Activity Pipeline
    this.on('staff.action', (payload) => {
      systemDatabase.addAuditLog({
        actor: payload.staffActor || 'Staff Member',
        action: payload.staffAction || 'STAFF_OPERATION',
        target: payload.targetResource || 'System',
        details: payload.details || 'Staff administrative operation performed',
        ipAddress: payload.ipAddress || '127.0.0.1',
        status: 'info'
      });
    });
  }

  // --- Subscribe to Events ---
  public on(eventType: SystemEventType, handler: (payload: SystemEventPayload) => void): () => void {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    this.listeners.get(eventType)!.push(handler);

    return () => {
      const arr = this.listeners.get(eventType);
      if (arr) {
        this.listeners.set(eventType, arr.filter(h => h !== handler));
      }
    };
  }

  // --- Dispatch Central Event ---
  public emit(eventType: SystemEventType, payload: Omit<SystemEventPayload, 'eventType'>) {
    const fullPayload: SystemEventPayload = { ...payload, eventType };
    const handlers = this.listeners.get(eventType) || [];
    handlers.forEach(fn => {
      try {
        fn(fullPayload);
      } catch (err) {
        console.error(`[EventEngine] Error handling event ${eventType}:`, err);
      }
    });
  }
}

export const eventEngine = new CentralEventEngine();
