import { EmailTemplate, EmailBrandingConfig, EmailOutboxRecord, EmailTemplateId } from '../types';
import { notificationEngine } from './notificationEngine';
import { systemDatabase } from './systemDatabase';

const STORAGE_BRANDING_KEY = 'CELOXA_EMAIL_BRANDING_V1';
const STORAGE_TEMPLATES_KEY = 'CELOXA_EMAIL_TEMPLATES_V1';
const STORAGE_OUTBOX_KEY = 'CELOXA_EMAIL_OUTBOX_V1';

export const DEFAULT_EMAIL_BRANDING: EmailBrandingConfig = {
  companyName: 'Celoxa Ghana Cloud Systems',
  logoUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=200&auto=format&fit=crop&q=80',
  senderName: 'Celoxa Automated Provisioning & Billing',
  senderEmail: 'billing@celoxaghana.online',
  supportEmail: 'support@celoxaghana.online',
  supportPhone: '+233 (0) 24 123 4567',
  websiteUrl: 'https://celoxaghana.online',
  primaryColor: '#4f46e5', // Indigo 600
  accentColor: '#10b981', // Emerald 500
  footerText: 'Celoxa Ghana Cloud Infrastructure & Domain Registry Services • Enterprise Tier 3 Cloud Datacenter, Accra, Ghana',
};

export const DEFAULT_TEMPLATES: EmailTemplate[] = [
  {
    id: 'INVOICE_MARKED_PAID',
    name: 'Invoice Marked as Paid (Manual & Custom Payment Approval)',
    category: 'billing',
    description: 'Sent when an administrator verifies a custom bank/MoMo transaction and marks the invoice as Paid.',
    variables: ['customerName', 'invoiceNumber', 'orderId', 'amount', 'currency', 'paymentMethod', 'approvedBy', 'date', 'viewInvoiceUrl'],
    subjectTemplate: 'Payment Received & Verified: Invoice #{invoiceNumber} - {companyName}',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Payment Verified Successfully</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>,
        </p>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          We have successfully received and verified your payment of <strong>{currency} {amount}</strong> for Invoice <strong>#{invoiceNumber}</strong> (Order #{orderId}).
        </p>
        <div style="margin: 20px 0; padding: 16px; background: #f8fafc; border-left: 4px solid #10b981; border-radius: 6px;">
          <p style="margin: 4px 0; color: #334155; font-size: 14px;"><strong>Payment Method:</strong> {paymentMethod}</p>
          <p style="margin: 4px 0; color: #334155; font-size: 14px;"><strong>Verified By:</strong> {approvedBy}</p>
          <p style="margin: 4px 0; color: #334155; font-size: 14px;"><strong>Timestamp:</strong> {date}</p>
          <p style="margin: 4px 0; color: #334155; font-size: 14px;"><strong>Status:</strong> <span style="color: #10b981; font-weight: bold;">PAID & PROVISIONING INITIATED</span></p>
        </div>
        <p style="color: #475569; font-size: 14px;">
          All associated hosting and domain services are being provisioned immediately. You will receive your access credentials shortly.
        </p>
        <div style="margin-top: 24px;">
          <a href="{viewInvoiceUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">View Official Paid Invoice</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'HOSTING_ACCOUNT_CREATED',
    name: 'Hosting Account Welcome & Control Panel Access',
    category: 'hosting',
    description: 'Dispatched immediately when cPanel/DirectAdmin/Plesk account creation succeeds.',
    variables: ['customerName', 'domain', 'packageName', 'cpanelUser', 'cpanelPassword', 'cpanelUrl', 'serverIp', 'serverHostname', 'nameserver1', 'nameserver2', 'phpVersion'],
    subjectTemplate: 'Your Web Hosting Account is Ready: {domain} ({packageName})',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Welcome to Your New Hosting Account!</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>,
        </p>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Your web hosting plan for <strong>{domain}</strong> has been provisioned on our high-speed cloud infrastructure.
        </p>
        
        <div style="margin: 20px 0; padding: 18px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px;">
          <h3 style="color: #166534; margin-top: 0; font-size: 16px;">Control Panel Login Details</h3>
          <p style="margin: 6px 0; font-size: 14px; color: #1e293b;"><strong>Control Panel URL:</strong> <a href="{cpanelUrl}" style="color: #4f46e5;">{cpanelUrl}</a></p>
          <p style="margin: 6px 0; font-size: 14px; color: #1e293b;"><strong>Username:</strong> <code style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px;">{cpanelUser}</code></p>
          <p style="margin: 6px 0; font-size: 14px; color: #1e293b;"><strong>Temporary Password:</strong> <code style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px;">{cpanelPassword}</code></p>
          <p style="margin: 6px 0; font-size: 14px; color: #1e293b;"><strong>Dedicated IP:</strong> {serverIp}</p>
          <p style="margin: 6px 0; font-size: 14px; color: #1e293b;"><strong>PHP Version:</strong> {phpVersion}</p>
        </div>

        <div style="margin: 20px 0; padding: 18px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;">
          <h3 style="color: #334155; margin-top: 0; font-size: 16px;">Assigned Nameservers (DNS)</h3>
          <p style="margin: 4px 0; font-size: 14px; color: #475569;">1. {nameserver1}</p>
          <p style="margin: 4px 0; font-size: 14px; color: #475569;">2. {nameserver2}</p>
        </div>

        <div style="margin-top: 24px;">
          <a href="{cpanelUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Log in to Control Panel</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'DOMAIN_REGISTERED',
    name: 'Domain Registration Confirmation',
    category: 'domain',
    description: 'Dispatched when a domain registration is completed via registrar adapter.',
    variables: ['customerName', 'domain', 'years', 'registeredDate', 'expiryDate', 'registrarName', 'nameservers', 'manageDnsUrl'],
    subjectTemplate: 'Domain Active: {domain} Registered Successfully',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Domain Name Registration Active</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>,
        </p>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Congratulations! Your domain name <strong>{domain}</strong> has been registered for <strong>{years} year(s)</strong> with <strong>{registrarName}</strong>.
        </p>

        <div style="margin: 20px 0; padding: 16px; background: #f8fafc; border-left: 4px solid #4f46e5; border-radius: 6px;">
          <p style="margin: 4px 0; font-size: 14px;"><strong>Domain:</strong> {domain}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>Registered On:</strong> {registeredDate}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>Expiration Date:</strong> {expiryDate}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>Active Nameservers:</strong> {nameservers}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>WHOIS Privacy:</strong> <span style="color: #10b981;">Enabled</span></p>
        </div>

        <div style="margin-top: 24px;">
          <a href="{manageDnsUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Manage DNS & Nameservers</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'PAYMENT_RECEIVED',
    name: 'Online Payment Receipt (Paystack Gateway)',
    category: 'billing',
    description: 'Instant receipt sent when customer pays online via Paystack Mobile Money or Card.',
    variables: ['customerName', 'invoiceNumber', 'orderId', 'amount', 'currency', 'paystackReference', 'date', 'viewInvoiceUrl'],
    subjectTemplate: 'Official Receipt for Payment #{paystackReference} ({currency} {amount})',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Payment Receipt Confirmation</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>, thank you for your payment!
        </p>
        <div style="margin: 20px 0; padding: 16px; background: #f8fafc; border-left: 4px solid #10b981; border-radius: 6px;">
          <p style="margin: 4px 0; font-size: 14px;"><strong>Invoice Number:</strong> #{invoiceNumber}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>Amount Paid:</strong> {currency} {amount}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>Paystack Ref:</strong> {paystackReference}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>Date:</strong> {date}</p>
        </div>
        <div style="margin-top: 24px;">
          <a href="{viewInvoiceUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Download Official Receipt</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'INVOICE_CREATED',
    name: 'New Invoice Issued (Pending Custom / Manual Payment)',
    category: 'billing',
    description: 'Sent when an order is placed with Custom Payment and is awaiting customer deposit.',
    variables: ['customerName', 'invoiceNumber', 'orderId', 'amount', 'currency', 'paymentInstructions', 'dueDate', 'viewInvoiceUrl'],
    subjectTemplate: 'New Invoice #{invoiceNumber} Issued - Action Required ({currency} {amount})',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Invoice #{invoiceNumber} Issued</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>, your invoice has been generated and is ready for payment.
        </p>
        <div style="margin: 20px 0; padding: 16px; background: #fffbeb; border-left: 4px solid #f59e0b; border-radius: 6px;">
          <p style="margin: 4px 0; font-size: 14px;"><strong>Amount Due:</strong> {currency} {amount}</p>
          <p style="margin: 4px 0; font-size: 14px;"><strong>Due Date:</strong> {dueDate}</p>
          <div style="margin-top: 10px; font-size: 13px; color: #92400e;">
            <strong>Custom Payment Instructions:</strong><br/>
            {paymentInstructions}
          </div>
        </div>
        <div style="margin-top: 24px;">
          <a href="{viewInvoiceUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">View & Pay Invoice</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'PROVISIONING_FAILED',
    name: 'Provisioning Alert & Support Escalation',
    category: 'hosting',
    description: 'Triggered if a registrar or control panel API returns an error during automated provisioning.',
    variables: ['customerName', 'orderId', 'serviceName', 'errorDetails', 'supportTicketId', 'supportUrl'],
    subjectTemplate: 'Action Required: Service Provisioning Notice for Order #{orderId}',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #991b1b; margin-top: 0; font-size: 20px;">Service Activation Pending Manual Review</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>,
        </p>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          We received your payment for <strong>{serviceName}</strong> (Order #{orderId}). However, automated registrar or server provisioning required manual administrative verification.
        </p>
        <div style="margin: 20px 0; padding: 16px; background: #fef2f2; border-left: 4px solid #ef4444; border-radius: 6px;">
          <p style="margin: 4px 0; font-size: 14px; color: #991b1b;"><strong>Status:</strong> Queued for Tier 2 Engineer Dispatch</p>
          <p style="margin: 4px 0; font-size: 13px; color: #7f1d1d;"><strong>Diagnostic Note:</strong> {errorDetails}</p>
        </div>
        <p style="color: #475569; font-size: 14px;">
          Our 24/7 technical operations desk has automatically been alerted. No further action is required from you.
        </p>
        <div style="margin-top: 24px;">
          <a href="{supportUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Track Support Ticket #{supportTicketId}</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SERVICE_SUSPENDED',
    name: 'Service Suspension Notice',
    category: 'hosting',
    description: 'Sent when an account is suspended due to overdue invoice or administrative action.',
    variables: ['customerName', 'serviceName', 'domain', 'reason', 'invoiceId', 'paymentUrl'],
    subjectTemplate: 'Service Suspension Notice: {domain} ({serviceName})',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #991b1b; margin-top: 0; font-size: 20px;">Hosting Service Suspended</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>, your service <strong>{domain}</strong> has been suspended.
        </p>
        <p style="color: #475569; font-size: 14px;"><strong>Reason:</strong> {reason}</p>
        <div style="margin-top: 24px;">
          <a href="{paymentUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Reactivate Service (Pay Invoice)</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'SERVICE_TERMINATED',
    name: 'Service Termination Notice',
    category: 'hosting',
    description: 'Sent when a hosting service is permanently removed from the server.',
    variables: ['customerName', 'serviceName', 'domain', 'reason', 'date'],
    subjectTemplate: 'Service Terminated: {domain}',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Service Termination Confirmation</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>, the service for <strong>{domain}</strong> has been terminated as of {date}.
        </p>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'DOMAIN_RENEWAL',
    name: 'Domain Renewal Reminder',
    category: 'domain',
    description: 'Sent 30/15/7 days before a domain expires.',
    variables: ['customerName', 'domain', 'expiryDate', 'daysRemaining', 'renewalPrice', 'renewUrl'],
    subjectTemplate: 'Domain Renewal Notice: {domain} expires in {daysRemaining} days',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Domain Expiration Reminder</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>, your domain <strong>{domain}</strong> will expire on <strong>{expiryDate}</strong> ({daysRemaining} days remaining).
        </p>
        <div style="margin-top: 24px;">
          <a href="{renewUrl}" style="background: #10b981; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Renew Domain Now</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 'PASSWORD_RESET',
    name: 'Password Reset & Account Security',
    category: 'system',
    description: 'Sent when customer requests a password recovery link.',
    variables: ['customerName', 'resetUrl', 'expiryHours', 'ipAddress'],
    subjectTemplate: 'Reset Your Account Password - {companyName}',
    bodyTemplate: `
      <div style="padding: 24px; background: #ffffff; border-radius: 12px;">
        <h2 style="color: #1e293b; margin-top: 0; font-size: 20px;">Password Reset Request</h2>
        <p style="color: #475569; font-size: 15px; line-height: 1.6;">
          Hello <strong>{customerName}</strong>, we received a request to reset your account password.
        </p>
        <div style="margin-top: 24px;">
          <a href="{resetUrl}" style="background: #4f46e5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Reset Password</a>
        </div>
      </div>
    `,
    enabled: true,
    lastUpdated: new Date().toISOString(),
  },
];

class EmailTemplateEngine {
  private branding: EmailBrandingConfig = DEFAULT_EMAIL_BRANDING;
  private templates: EmailTemplate[] = [];
  private outbox: EmailOutboxRecord[] = [];
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      const rawBranding = localStorage.getItem(STORAGE_BRANDING_KEY);
      if (rawBranding) {
        this.branding = JSON.parse(rawBranding);
      } else {
        this.branding = DEFAULT_EMAIL_BRANDING;
        this.saveBranding();
      }

      const rawTemplates = localStorage.getItem(STORAGE_TEMPLATES_KEY);
      if (rawTemplates) {
        this.templates = JSON.parse(rawTemplates);
      } else {
        this.templates = DEFAULT_TEMPLATES;
        this.saveTemplates();
      }

      const rawOutbox = localStorage.getItem(STORAGE_OUTBOX_KEY);
      if (rawOutbox) {
        this.outbox = JSON.parse(rawOutbox);
      } else {
        this.outbox = this.getInitialOutbox();
        this.saveOutbox();
      }
    } catch (e) {
      console.error('[EmailTemplateEngine] Storage load error:', e);
      this.branding = DEFAULT_EMAIL_BRANDING;
      this.templates = DEFAULT_TEMPLATES;
      this.outbox = this.getInitialOutbox();
    }
  }

  private saveBranding() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_BRANDING_KEY, JSON.stringify(this.branding));
    } catch (e) {
      console.error('[EmailTemplateEngine] Failed to save branding:', e);
    }
  }

  private saveTemplates() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_TEMPLATES_KEY, JSON.stringify(this.templates));
    } catch (e) {
      console.error('[EmailTemplateEngine] Failed to save templates:', e);
    }
  }

  private saveOutbox() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_OUTBOX_KEY, JSON.stringify(this.outbox.slice(0, 300)));
    } catch (e) {
      console.error('[EmailTemplateEngine] Failed to save outbox:', e);
    }
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  public subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private getInitialOutbox(): EmailOutboxRecord[] {
    return [
      {
        id: 'outbox-1',
        recipientEmail: 'baffourgideon05@gmail.com',
        recipientName: 'Gideon Baffour',
        subject: 'Payment Received & Verified: Invoice #INV-100239 - Celoxa Ghana Cloud Systems',
        templateId: 'INVOICE_MARKED_PAID',
        category: 'billing',
        status: 'sent',
        renderedHtml: '<p>Invoice #INV-100239 marked paid.</p>',
        sentAt: new Date(Date.now() - 3600000 * 2).toISOString(),
        relatedOrderId: 'ORD-100239',
      },
      {
        id: 'outbox-2',
        recipientEmail: 'kwame@enterpriseghana.com',
        recipientName: 'Kwame Mensah',
        subject: 'Your Web Hosting Account is Ready: enterpriseghana.com',
        templateId: 'HOSTING_ACCOUNT_CREATED',
        category: 'hosting',
        status: 'sent',
        renderedHtml: '<p>cPanel account provisioned successfully.</p>',
        sentAt: new Date(Date.now() - 3600000 * 24).toISOString(),
        relatedOrderId: 'ORD-100230',
      },
    ];
  }

  public getBranding(): EmailBrandingConfig {
    return { ...this.branding };
  }

  public saveBrandingConfig(config: EmailBrandingConfig) {
    this.branding = config;
    this.saveBranding();
    this.notify();
    systemDatabase.logAuditEvent(
      'UPDATE_EMAIL_BRANDING',
      config.companyName,
      `Updated email template header/footer branding & colors`
    );
  }

  public getTemplates(): EmailTemplate[] {
    return [...this.templates];
  }

  public getTemplateById(id: EmailTemplateId): EmailTemplate | undefined {
    return this.templates.find((t) => t.id === id);
  }

  public saveTemplate(template: EmailTemplate) {
    this.templates = this.templates.map((t) => (t.id === template.id ? { ...template, lastUpdated: new Date().toISOString() } : t));
    this.saveTemplates();
    this.notify();
    systemDatabase.logAuditEvent(
      'UPDATE_EMAIL_TEMPLATE',
      template.name,
      `Modified template markup for ${template.id}`
    );
  }

  public renderEmail(templateId: EmailTemplateId, variables: Record<string, any>): { subject: string; html: string } {
    const template = this.getTemplateById(templateId);
    const branding = this.branding;

    const mergedVars: Record<string, any> = {
      companyName: branding.companyName,
      senderEmail: branding.senderEmail,
      supportEmail: branding.supportEmail,
      supportPhone: branding.supportPhone || '',
      websiteUrl: branding.websiteUrl,
      year: new Date().getFullYear().toString(),
      ...variables,
    };

    let subject = template?.subjectTemplate || 'Notification from {companyName}';
    let body = template?.bodyTemplate || '<p>{message}</p>';

    // Replace variables
    Object.entries(mergedVars).forEach(([key, val]) => {
      const regex = new RegExp(`\\{${key}\\}`, 'g');
      subject = subject.replace(regex, String(val ?? ''));
      body = body.replace(regex, String(val ?? ''));
    });

    // Wrap in responsive HTML email envelope
    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
  <style>
    body { margin: 0; padding: 0; background-color: #0f172a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; }
    .header { background: #0f172a; padding: 28px 24px; text-align: center; border-bottom: 2px solid #334155; }
    .logo { height: 42px; width: auto; max-width: 180px; object-fit: contain; }
    .title { color: #ffffff; font-size: 18px; font-weight: 800; margin-top: 10px; margin-bottom: 0; letter-spacing: -0.02em; }
    .content { padding: 32px 28px; color: #334155; }
    .footer { background: #0f172a; padding: 24px; text-align: center; color: #94a3b8; font-size: 12px; line-height: 1.6; border-top: 1px solid #1e293b; }
    .footer a { color: #818cf8; text-decoration: none; }
  </style>
</head>
<body style="margin: 0; padding: 20px 10px; background-color: #0f172a;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center">
        <div class="container" style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);">
          <!-- Header -->
          <div class="header" style="background: #0f172a; padding: 24px; text-align: center;">
            <h1 style="color: #ffffff; font-size: 20px; font-weight: 900; margin: 0; letter-spacing: -0.02em;">
              ${branding.companyName}
            </h1>
            <p style="color: #818cf8; font-size: 12px; margin: 4px 0 0 0; font-weight: 600;">
              Cloud & Domain Automation Infrastructure
            </p>
          </div>

          <!-- Body Content -->
          <div class="content" style="padding: 28px 24px;">
            ${body}
          </div>

          <!-- Footer -->
          <div class="footer" style="background: #0f172a; padding: 24px; text-align: center; color: #94a3b8; font-size: 11px; line-height: 1.6;">
            <p style="margin: 0 0 6px 0; color: #cbd5e1; font-weight: 600;">${branding.footerText}</p>
            <p style="margin: 0;">Need support? Email <a href="mailto:${branding.supportEmail}" style="color: #818cf8;">${branding.supportEmail}</a> or call ${branding.supportPhone || '+233 (0) 24 123 4567'}</p>
            <p style="margin: 6px 0 0 0; color: #64748b;">© ${new Date().getFullYear()} ${branding.companyName}. All rights reserved.</p>
          </div>
        </div>
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    return { subject, html };
  }

  public dispatchEmail(params: {
    templateId: EmailTemplateId;
    recipientEmail: string;
    recipientName: string;
    variables: Record<string, any>;
    relatedOrderId?: string;
    relatedServiceId?: string;
  }): EmailOutboxRecord {
    const { subject, html } = this.renderEmail(params.templateId, params.variables);

    const record: EmailOutboxRecord = {
      id: `outbox-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      recipientEmail: params.recipientEmail,
      recipientName: params.recipientName,
      subject,
      templateId: params.templateId,
      category: this.getTemplateById(params.templateId)?.category || 'system',
      status: 'sent',
      renderedHtml: html,
      sentAt: new Date().toISOString(),
      relatedOrderId: params.relatedOrderId,
      relatedServiceId: params.relatedServiceId,
    };

    this.outbox = [record, ...this.outbox.slice(0, 299)];
    this.saveOutbox();

    // Also dispatch to system in-app notifications
    notificationEngine.dispatchEvent({
      userId: params.variables.userId || 'user-admin-google-001',
      recipientEmail: params.recipientEmail,
      recipientName: params.recipientName,
      category: record.category as any,
      title: subject,
      message: `Email dispatched: ${subject}`,
      template: params.templateId,
      emailSubject: subject,
      metadata: params.variables,
    });

    this.notify();
    return record;
  }

  public getOutbox(): EmailOutboxRecord[] {
    return [...this.outbox];
  }

  public clearOutbox() {
    this.outbox = [];
    this.saveOutbox();
    this.notify();
  }
}

export const emailTemplateEngine = new EmailTemplateEngine();
