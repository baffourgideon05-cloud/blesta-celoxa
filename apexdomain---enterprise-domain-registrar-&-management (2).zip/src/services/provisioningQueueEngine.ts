import { ProvisioningJob, ProvisioningJobStep, RegistrarProviderType, ControlPanelProviderType, NameserverConfig } from '../types';
import { registrarManager } from './registrarManager';
import { hostingControlPanelManager } from './hostingControlPanelManager';
import { emailTemplateEngine } from './emailTemplateEngine';
import { systemDatabase } from './systemDatabase';
import { commerceEngine } from './commerceEngine';

const STORAGE_QUEUE_KEY = 'CELOXA_PROVISIONING_QUEUE_V1';

export const INITIAL_JOBS: ProvisioningJob[] = [
  {
    id: 'job-100239',
    orderId: 'ORD-100239',
    invoiceId: 'INV-100239',
    customerId: 'user-cust-102',
    customerName: 'Kwame Mensah',
    customerEmail: 'kwame@enterpriseghana.com',
    domain: 'enterpriseghana.com',
    packageName: 'NVMe Starter Hosting',
    serviceType: 'bundle',
    registrarProvider: 'internal',
    hostingProvider: 'cpanel',
    nameserverMode: 'system_default',
    nameservers: ['ns1.celoxaghana.online', 'ns2.celoxaghana.online', 'ns3.celoxaghana.online', 'ns4.celoxaghana.online'],
    status: 'completed',
    currentStep: 'Completed Successfully',
    steps: [
      { name: 'Payment Verification', status: 'completed', timestamp: new Date(Date.now() - 3600000 * 24).toISOString(), details: 'Paystack Ref PSTK-ORD-100239 verified' },
      { name: 'Hosting Account Creation (WHM)', status: 'completed', timestamp: new Date(Date.now() - 3600000 * 24 + 1000).toISOString(), details: 'cPanel user enterpris created on Ghana Cloud Cluster' },
      { name: 'Domain Registration (Registrar API)', status: 'completed', timestamp: new Date(Date.now() - 3600000 * 24 + 2000).toISOString(), details: 'Registered with Celoxa Ghana Internal Registry for 1 year' },
      { name: 'Push DNS & Nameservers', status: 'completed', timestamp: new Date(Date.now() - 3600000 * 24 + 2500).toISOString(), details: 'Default nameservers assigned' },
      { name: 'Dispatch Welcome Credentials Email', status: 'completed', timestamp: new Date(Date.now() - 3600000 * 24 + 3000).toISOString(), details: 'Branded email dispatched to kwame@enterpriseghana.com' },
    ],
    retryCount: 0,
    maxRetries: 3,
    cpanelUsername: 'enterpris',
    cpanelUrl: 'https://whm01.accra.celoxaghana.online:2083',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 24 + 3000).toISOString(),
    completedAt: new Date(Date.now() - 3600000 * 24 + 3000).toISOString(),
  },
];

class ProvisioningQueueEngine {
  private jobs: ProvisioningJob[] = [];
  private listeners: Set<() => void> = new Set();
  private isProcessing = false;

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      const raw = localStorage.getItem(STORAGE_QUEUE_KEY);
      if (raw) {
        this.jobs = JSON.parse(raw);
      } else {
        this.jobs = INITIAL_JOBS;
        this.saveJobs();
      }
    } catch (e) {
      console.error('[ProvisioningQueueEngine] Storage load error:', e);
      this.jobs = INITIAL_JOBS;
    }
  }

  private saveJobs() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(this.jobs.slice(0, 100)));
    } catch (e) {
      console.error('[ProvisioningQueueEngine] Failed to save jobs:', e);
    }
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  public subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  public getJobs(): ProvisioningJob[] {
    return [...this.jobs];
  }

  public getJobById(id: string): ProvisioningJob | undefined {
    return this.jobs.find((j) => j.id === id);
  }

  public enqueueJob(params: {
    orderId: string;
    invoiceId: string;
    customerId: string;
    customerName: string;
    customerEmail: string;
    domain?: string;
    packageName?: string;
    planId?: string;
    serviceType: 'domain' | 'hosting' | 'bundle';
    registrarProvider?: RegistrarProviderType;
    hostingProvider?: ControlPanelProviderType;
    hostingServerId?: string;
    nameserverMode?: 'system_default' | 'custom';
    nameservers?: string[];
  }): ProvisioningJob {
    const defaultReg = registrarManager.getDefaultRegistrar();
    const defaultSrv = hostingControlPanelManager.getDefaultServer();

    const actualNs = params.nameservers && params.nameservers.length > 0 && params.nameservers[0]
      ? params.nameservers
      : defaultSrv.defaultNameservers;

    const initialSteps: ProvisioningJobStep[] = [
      { name: 'Payment Verification', status: 'completed', timestamp: new Date().toISOString(), details: `Verified for Order #${params.orderId}` },
      ...(params.serviceType === 'hosting' || params.serviceType === 'bundle'
        ? [{ name: 'Hosting Account Creation (WHM/cPanel)', status: 'pending' as const }]
        : []),
      ...(params.serviceType === 'domain' || params.serviceType === 'bundle'
        ? [
            { name: 'Domain Registration (Registrar API)', status: 'pending' as const },
            { name: 'Push DNS & Nameservers', status: 'pending' as const },
          ]
        : []),
      { name: 'Dispatch Welcome Credentials Email', status: 'pending' as const },
    ];

    const job: ProvisioningJob = {
      id: `job-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      orderId: params.orderId,
      invoiceId: params.invoiceId,
      customerId: params.customerId,
      customerName: params.customerName,
      customerEmail: params.customerEmail,
      domain: params.domain || 'mysite.online',
      packageName: params.packageName || 'Cloud Hosting Starter',
      planId: params.planId,
      serviceType: params.serviceType,
      registrarProvider: params.registrarProvider || defaultReg.provider,
      hostingProvider: params.hostingProvider || defaultSrv.provider,
      hostingServerId: params.hostingServerId || defaultSrv.id,
      nameserverMode: params.nameserverMode || 'system_default',
      nameservers: actualNs,
      status: 'queued',
      currentStep: 'Queued for immediate provisioning',
      steps: initialSteps,
      retryCount: 0,
      maxRetries: 3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.jobs = [job, ...this.jobs];
    this.saveJobs();
    this.notify();

    // Trigger asynchronous execution pipeline immediately
    setTimeout(() => this.processJob(job.id), 100);

    return job;
  }

  public async processJob(jobId: string) {
    const job = this.getJobById(jobId);
    if (!job) return;

    this.updateJobStatus(jobId, { status: 'provisioning', currentStep: 'Starting automated pipeline...' });

    try {
      let cpanelUsername = '';
      let cpanelUrl = '';
      let tempPassword = '';
      let serverIp = '154.160.10.45';
      let serverHostname = 'whm01.accra.celoxaghana.online';

      // 1. Hosting Provisioning Step
      if (job.serviceType === 'hosting' || job.serviceType === 'bundle') {
        this.updateStep(jobId, 'Hosting Account Creation (WHM/cPanel)', 'in_progress');
        
        const hostResult = await hostingControlPanelManager.provisionAccount({
          domain: job.domain || 'mysite.online',
          packageName: job.packageName || 'Standard Cloud',
          customerName: job.customerName,
          customerEmail: job.customerEmail,
          serverId: job.hostingServerId,
        });

        if (!hostResult.success) {
          throw new Error(`Control panel account creation failed: ${hostResult.errorMessage || 'Server response error'}`);
        }

        cpanelUsername = hostResult.username;
        cpanelUrl = hostResult.cpanelUrl;
        tempPassword = hostResult.tempPassword || 'Pass#Security2026!';
        serverIp = hostResult.serverIp;
        serverHostname = hostResult.serverHostname;

        this.updateStep(jobId, 'Hosting Account Creation (WHM/cPanel)', 'completed', `Account ${cpanelUsername} created on ${hostResult.serverName}`);
      }

      // 2. Domain Registration Step
      if (job.serviceType === 'domain' || job.serviceType === 'bundle') {
        this.updateStep(jobId, 'Domain Registration (Registrar API)', 'in_progress');

        const domainResult = await registrarManager.registerDomain({
          domain: job.domain || 'mysite.online',
          years: 1,
          customerName: job.customerName,
          customerEmail: job.customerEmail,
          nameservers: job.nameservers,
          provider: job.registrarProvider,
        });

        if (!domainResult.success) {
          throw new Error(`Registrar registration failed: ${domainResult.errorMessage || 'API error'}`);
        }

        this.updateStep(jobId, 'Domain Registration (Registrar API)', 'completed', `Registered with ${domainResult.registrar} (Auth: ${domainResult.authCode})`);

        // 3. Push Nameservers Step
        this.updateStep(jobId, 'Push DNS & Nameservers', 'in_progress');
        await registrarManager.updateNameservers(job.domain || 'mysite.online', job.nameservers, job.registrarProvider);
        this.updateStep(jobId, 'Push DNS & Nameservers', 'completed', `Nameservers active: ${job.nameservers.slice(0, 2).join(', ')}`);
      }

      // 4. Save to System Database Records
      const now = new Date().toISOString();
      const expiry = new Date(Date.now() + 365 * 24 * 3600 * 1000).toISOString();

      if (job.serviceType === 'domain' || job.serviceType === 'bundle') {
        const nsConfig: NameserverConfig = {
          mode: job.nameserverMode,
          ns1: job.nameservers[0] || 'ns1.celoxaghana.online',
          ns2: job.nameservers[1] || 'ns2.celoxaghana.online',
          ns3: job.nameservers[2],
          ns4: job.nameservers[3],
          lastUpdated: now,
          syncStatus: 'synced',
          syncedRegistrar: job.registrarProvider,
        };

        systemDatabase.registerNewDomain({
          domain: job.domain || 'mysite.online',
          ownerUserId: job.customerId,
          ownerEmail: job.customerEmail,
          ownerName: job.customerName,
          status: 'active',
          registeredDate: now,
          expiryDate: expiry,
          autoRenew: true,
          locked: true,
          whoisPrivacy: true,
          authCode: `EPP-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
          nameservers: job.nameservers,
          nameserverConfig: nsConfig,
          registrarProvider: job.registrarProvider,
          registrarName: registrarManager.getRegistrarByProvider(job.registrarProvider)?.name || 'Celoxa Registry',
          orderId: job.orderId,
        });
      }

      if (job.serviceType === 'hosting' || job.serviceType === 'bundle') {
        const nsConfig: NameserverConfig = {
          mode: job.nameserverMode,
          ns1: job.nameservers[0] || 'ns1.celoxaghana.online',
          ns2: job.nameservers[1] || 'ns2.celoxaghana.online',
          ns3: job.nameservers[2],
          ns4: job.nameservers[3],
          lastUpdated: now,
          syncStatus: 'synced',
        };

        systemDatabase.provisionHostingAccountDirectly({
          id: `srv-${Date.now()}`,
          name: `${job.domain} (${job.packageName})`,
          domain: job.domain || 'mysite.online',
          planName: job.packageName || 'Cloud Hosting',
          diskUsageMb: 24,
          diskLimitMb: 10000,
          bandwidthUsageGb: 0.1,
          bandwidthLimitGb: 250,
          ipAddress: serverIp,
          phpVersion: 'PHP 8.3 (ea-php83)',
          cpanelUser: cpanelUsername,
          cpanelUrl: cpanelUrl,
          controlPanelType: job.hostingProvider,
          hostingServerId: job.hostingServerId,
          nameservers: job.nameservers,
          nameserverConfig: nsConfig,
          price: 18.5,
          billingCycle: 'annually',
          startDate: now,
          expiryDate: expiry,
          autoRenew: true,
          status: 'active',
          timeline: [
            {
              id: `evt-${Date.now()}`,
              timestamp: now,
              type: 'created',
              title: 'Account Provisioned & Live',
              description: `cPanel account initialized on cluster. Automated SSL configured.`,
              actor: 'Automated Provisioning Engine',
            },
          ],
        });
      }

      // 5. Dispatch Branded Email Template Step
      this.updateStep(jobId, 'Dispatch Welcome Credentials Email', 'in_progress');

      if (job.serviceType === 'hosting' || job.serviceType === 'bundle') {
        emailTemplateEngine.dispatchEmail({
          templateId: 'HOSTING_ACCOUNT_CREATED',
          recipientEmail: job.customerEmail,
          recipientName: job.customerName,
          variables: {
            customerName: job.customerName,
            domain: job.domain,
            packageName: job.packageName,
            cpanelUser: cpanelUsername,
            cpanelPassword: tempPassword,
            cpanelUrl: cpanelUrl,
            serverIp,
            serverHostname,
            nameserver1: job.nameservers[0] || 'ns1.celoxaghana.online',
            nameserver2: job.nameservers[1] || 'ns2.celoxaghana.online',
            phpVersion: 'PHP 8.3',
            userId: job.customerId,
          },
          relatedOrderId: job.orderId,
        });
      } else {
        emailTemplateEngine.dispatchEmail({
          templateId: 'DOMAIN_REGISTERED',
          recipientEmail: job.customerEmail,
          recipientName: job.customerName,
          variables: {
            customerName: job.customerName,
            domain: job.domain,
            years: 1,
            registeredDate: new Date().toLocaleDateString(),
            expiryDate: new Date(Date.now() + 365 * 24 * 3600 * 1000).toLocaleDateString(),
            registrarName: registrarManager.getRegistrarByProvider(job.registrarProvider)?.name || 'Celoxa Registry',
            nameservers: job.nameservers.join(', '),
            manageDnsUrl: '#',
            userId: job.customerId,
          },
          relatedOrderId: job.orderId,
        });
      }

      this.updateStep(jobId, 'Dispatch Welcome Credentials Email', 'completed', `Dispatched credentials to ${job.customerEmail}`);

      // Finalize Job
      this.updateJobStatus(jobId, {
        status: 'completed',
        currentStep: 'Service Provisioned & Live',
        cpanelUsername,
        cpanelUrl,
        completedAt: new Date().toISOString(),
      });

      systemDatabase.logAuditEvent(
        'PROVISION_SERVICE_SUCCESS',
        job.domain || job.orderId,
        `Automated provisioning completed for ${job.domain} (${job.customerName})`
      );
    } catch (err: any) {
      console.error('[ProvisioningQueueEngine] Provisioning Error:', err);

      const errorMessage = err?.message || 'Unknown network or API error';
      this.updateJobStatus(jobId, {
        status: 'failed',
        currentStep: `Failed: ${errorMessage}`,
        errorDetails: errorMessage,
      });

      // Dispatch Provisioning Failed Alert
      emailTemplateEngine.dispatchEmail({
        templateId: 'PROVISIONING_FAILED',
        recipientEmail: job.customerEmail,
        recipientName: job.customerName,
        variables: {
          customerName: job.customerName,
          orderId: job.orderId,
          serviceName: `${job.domain} (${job.packageName || 'Domain'})`,
          errorDetails: errorMessage,
          supportTicketId: `TICK-${Math.floor(1000 + Math.random() * 9000)}`,
          supportUrl: '#',
          userId: job.customerId,
        },
        relatedOrderId: job.orderId,
      });

      systemDatabase.logAuditEvent(
        'PROVISION_SERVICE_FAILED',
        job.domain || job.orderId,
        `Provisioning error for ${job.domain}: ${errorMessage}`
      );
    }
  }

  public retryJob(jobId: string, overrides?: { registrarProvider?: RegistrarProviderType; hostingServerId?: string }) {
    const job = this.getJobById(jobId);
    if (!job) return;

    const updatedJob: ProvisioningJob = {
      ...job,
      status: 'queued',
      retryCount: job.retryCount + 1,
      errorDetails: undefined,
      registrarProvider: overrides?.registrarProvider || job.registrarProvider,
      hostingServerId: overrides?.hostingServerId || job.hostingServerId,
      steps: job.steps.map((s) => ({ ...s, status: s.name === 'Payment Verification' ? 'completed' : 'pending' })),
      updatedAt: new Date().toISOString(),
    };

    this.jobs = this.jobs.map((j) => (j.id === jobId ? updatedJob : j));
    this.saveJobs();
    this.notify();

    setTimeout(() => this.processJob(jobId), 100);
  }

  private updateJobStatus(jobId: string, updates: Partial<ProvisioningJob>) {
    this.jobs = this.jobs.map((j) =>
      j.id === jobId ? { ...j, ...updates, updatedAt: new Date().toISOString() } : j
    );
    this.saveJobs();
    this.notify();
  }

  private updateStep(jobId: string, stepName: string, status: ProvisioningJobStep['status'], details?: string) {
    this.jobs = this.jobs.map((j) => {
      if (j.id !== jobId) return j;
      const updatedSteps = j.steps.map((s) =>
        s.name === stepName
          ? { ...s, status, timestamp: new Date().toISOString(), details: details || s.details }
          : s
      );
      return {
        ...j,
        currentStep: stepName,
        steps: updatedSteps,
        updatedAt: new Date().toISOString(),
      };
    });
    this.saveJobs();
    this.notify();
  }

  public clearJobs() {
    this.jobs = [];
    this.saveJobs();
    this.notify();
  }
}

export const provisioningQueueEngine = new ProvisioningQueueEngine();
