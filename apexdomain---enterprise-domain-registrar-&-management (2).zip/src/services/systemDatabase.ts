import { 
  SystemSettingsConfig, 
  CartItem, 
  TLDDetail,
  PlatformRole,
  UserAccountStatus,
  ModulePermissions,
  UserSession,
  LoginActivityRecord,
  StaffInvitation,
  ClientApiKey,
  WhmcsHostingPackage,
  DomainOwnershipRecord,
  DomainDetailedStatus,
  HostingCategory,
  HostingFeature,
  HostingPlan,
  HostingPlanStatus,
  HostingServer,
  HostingPromotion,
  HostingBillingCycle,
  HostingUpgradeCalculation,
  PaymentMethodSettings,
  PaymentSubmission
} from '../types';
import { DEFAULT_SYSTEM_SETTINGS } from '../data/defaultSystemSettings';
import { DEFAULT_PAYMENT_SETTINGS, INITIAL_PAYMENT_SUBMISSIONS } from '../data/paymentSettings';
import { TLD_CATALOG } from '../data/tlds';
import { MOCK_WHMCS_PACKAGES } from '../data/mockWhmcsData';
import { 
  HostingPackageBlueprint, 
  INITIAL_BLUEPRINTS,
  ControlPanelGateway,
  INITIAL_GATEWAYS,
  ServerClusterNode,
  INITIAL_NODES,
  ProvisionTask,
  INITIAL_PROVISION_TASKS
} from '../components/HostingProvisionSystem';
import {
  INITIAL_HOSTING_CATEGORIES,
  INITIAL_HOSTING_FEATURES,
  INITIAL_HOSTING_PLANS,
  INITIAL_HOSTING_SERVERS,
  INITIAL_HOSTING_PROMOTIONS
} from '../data/hostingCatalogueData';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  details: string;
  ipAddress: string;
  status: 'success' | 'warning' | 'error' | 'info';
}

export const DEFAULT_SUPER_ADMIN_PERMISSIONS: ModulePermissions = {
  customers: { view: true, create: true, edit: true, suspend: true, delete: true },
  domains: { view: true, register: true, transfer: true, editDns: true, delete: true },
  hosting: { view: true, provision: true, suspend: true, unsuspend: true, terminate: true },
  billing: { viewInvoices: true, createInvoice: true, refundPayment: true, managePaymentSettings: true },
  servers: { view: true, manage: true, restart: true },
  staff: { view: true, create: true, edit: true, suspend: true, manageRoles: true },
  systemSettings: { view: true, edit: true },
  auditLogs: { view: true, export: true },
};

export const DEFAULT_ADMIN_PERMISSIONS: ModulePermissions = {
  ...DEFAULT_SUPER_ADMIN_PERMISSIONS,
  staff: { view: true, create: true, edit: true, suspend: false, manageRoles: false },
};

export const DEFAULT_SUPPORT_STAFF_PERMISSIONS: ModulePermissions = {
  customers: { view: true, create: false, edit: true, suspend: false, delete: false },
  domains: { view: true, register: true, transfer: true, editDns: true, delete: false },
  hosting: { view: true, provision: true, suspend: true, unsuspend: true, terminate: false },
  billing: { viewInvoices: true, createInvoice: false, refundPayment: false, managePaymentSettings: false },
  servers: { view: true, manage: false, restart: false },
  staff: { view: true, create: false, edit: false, suspend: false, manageRoles: false },
  systemSettings: { view: true, edit: false },
  auditLogs: { view: true, export: false },
};

export const DEFAULT_FINANCE_STAFF_PERMISSIONS: ModulePermissions = {
  customers: { view: true, create: true, edit: true, suspend: false, delete: false },
  domains: { view: true, register: false, transfer: false, editDns: false, delete: false },
  hosting: { view: true, provision: false, suspend: false, unsuspend: false, terminate: false },
  billing: { viewInvoices: true, createInvoice: true, refundPayment: true, managePaymentSettings: true },
  servers: { view: false, manage: false, restart: false },
  staff: { view: false, create: false, edit: false, suspend: false, manageRoles: false },
  systemSettings: { view: true, edit: false },
  auditLogs: { view: true, export: true },
};

export const DEFAULT_CLIENT_PERMISSIONS: ModulePermissions = {
  customers: { view: false, create: false, edit: false, suspend: false, delete: false },
  domains: { view: true, register: true, transfer: true, editDns: true, delete: false },
  hosting: { view: true, provision: false, suspend: false, unsuspend: false, terminate: false },
  billing: { viewInvoices: true, createInvoice: false, refundPayment: false, managePaymentSettings: false },
  servers: { view: false, manage: false, restart: false },
  staff: { view: false, create: false, edit: false, suspend: false, manageRoles: false },
  systemSettings: { view: false, edit: false },
  auditLogs: { view: true, export: false },
};

export interface SystemUser {
  id: string;
  fullName: string;
  email: string;
  password?: string;
  role: 'admin' | 'customer' | 'reseller' | 'super_admin' | 'administrator' | 'staff' | 'client';
  platformRole: PlatformRole;
  staffTitle?: string;
  department?: string;
  accountStatus: UserAccountStatus;
  isEmailVerified: boolean;
  verificationToken?: string;
  resetToken?: string;
  companyName?: string;
  phone?: string;
  country?: string;
  avatarUrl?: string;
  walletBalanceGhs: number;
  walletBalanceUsd: number;
  twoFactorEnabled: boolean;
  mfaEnabled?: boolean;
  mfaSecret?: string;
  mfaBackupCodes?: string[];
  permissions: ModulePermissions;
  createdAt: string;
  lastLoginAt?: string;
  lastLoginIp?: string;
  isBusinessAccount?: boolean;
}

export interface SystemDatabaseState {
  version: string;
  lastUpdated: string;
  settings: SystemSettingsConfig;
  hostingPackages: HostingPackageBlueprint[];
  hostingCategories: HostingCategory[];
  hostingPlans: HostingPlan[];
  hostingFeatures: HostingFeature[];
  hostingServers: HostingServer[];
  hostingPromotions: HostingPromotion[];
  tlds: TLDDetail[];
  controlPanelGateways: ControlPanelGateway[];
  serverClusterNodes: ServerClusterNode[];
  provisionedAccounts: ProvisionTask[];
  auditLogs: AuditLogEntry[];
  users: SystemUser[];
  currentUser: SystemUser | null;
  persistentCart: CartItem[];
  staffInvitations: StaffInvitation[];
  activeSessions: UserSession[];
  loginActivity: LoginActivityRecord[];
  clientApiKeys: ClientApiKey[];
  domainOwnership: DomainOwnershipRecord[];
  paymentSettings: PaymentMethodSettings;
  paymentSubmissions: PaymentSubmission[];
}

const STORAGE_KEY = 'CELOXA_SYSTEM_DATABASE_V1';

const DEFAULT_USERS: SystemUser[] = [
  {
    id: 'user-admin-google-001',
    fullName: 'Gideon Baffour (Google Admin)',
    email: 'baffourgideon05@gmail.com',
    password: 'admin',
    role: 'super_admin',
    platformRole: 'super_admin',
    staffTitle: 'Chief System Administrator',
    department: 'Executive Systems',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Cloud Enterprise',
    phone: '+233 (0) 24 123 4567',
    country: 'Ghana',
    avatarUrl: 'https://api.dicebear.com/7.x/initials/svg?seed=Gideon%20Baffour',
    walletBalanceGhs: 25000.00,
    walletBalanceUsd: 1850.00,
    twoFactorEnabled: true,
    mfaSecret: 'JBSWY3DPEHPK3PXP',
    mfaBackupCodes: ['8942-1029', '3910-8271', '4019-2819', '5910-2018'],
    permissions: DEFAULT_SUPER_ADMIN_PERMISSIONS,
    createdAt: '2025-01-01 00:00:00',
    lastLoginAt: '2026-08-10 18:20:00',
    lastLoginIp: '198.51.100.1',
  },
  {
    id: 'user-admin-101',
    fullName: 'Chief Admin (System Owner)',
    email: 'admin@celoxaghana.online',
    password: 'admin',
    role: 'super_admin',
    platformRole: 'super_admin',
    staffTitle: 'Super Administrator',
    department: 'Executive Systems',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Technologies Ltd',
    phone: '+233 (0) 30 291 8840',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop',
    walletBalanceGhs: 12500.00,
    walletBalanceUsd: 850.00,
    twoFactorEnabled: true,
    mfaSecret: 'JBSWY3DPEHPK3PXP',
    mfaBackupCodes: ['8942-1029', '3910-8271', '4019-2819', '5910-2018'],
    permissions: DEFAULT_SUPER_ADMIN_PERMISSIONS,
    createdAt: '2025-01-10 08:00:00',
    lastLoginAt: '2026-08-09 10:45:00',
    lastLoginIp: '198.51.100.42',
  },
  {
    id: 'user-admin-102',
    fullName: 'Operations Admin',
    email: 'ops@celoxaghana.online',
    password: 'admin',
    role: 'administrator',
    platformRole: 'administrator',
    staffTitle: 'Systems Administrator',
    department: 'Cloud Infrastructure',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Systems',
    phone: '+233 (0) 20 812 3456',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop',
    walletBalanceGhs: 5000.00,
    walletBalanceUsd: 350.00,
    twoFactorEnabled: true,
    mfaSecret: 'KRSXG5CTMVRXEZLU',
    mfaBackupCodes: ['1204-9831', '5928-1039', '8810-2391'],
    permissions: DEFAULT_ADMIN_PERMISSIONS,
    createdAt: '2025-02-01 09:15:00',
    lastLoginAt: '2026-08-09 11:20:00',
    lastLoginIp: '198.51.100.43',
  },
  {
    id: 'user-staff-103',
    fullName: 'Sarah Konadu',
    email: 'sarah.support@celoxaghana.online',
    password: 'staff123',
    role: 'staff',
    platformRole: 'staff',
    staffTitle: 'Technical Support Lead',
    department: 'Technical Support',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Support',
    phone: '+233 (0) 24 991 2233',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop',
    walletBalanceGhs: 800.00,
    walletBalanceUsd: 60.00,
    twoFactorEnabled: true,
    permissions: DEFAULT_SUPPORT_STAFF_PERMISSIONS,
    createdAt: '2025-02-15 11:00:00',
    lastLoginAt: '2026-08-09 08:30:00',
    lastLoginIp: '198.51.100.44',
  },
  {
    id: 'user-staff-104',
    fullName: 'Emmanuel Osei',
    email: 'emmanuel.finance@celoxaghana.online',
    password: 'staff123',
    role: 'staff',
    platformRole: 'staff',
    staffTitle: 'Billing & Finance Officer',
    department: 'Finance',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Finance',
    phone: '+233 (0) 27 334 5566',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop',
    walletBalanceGhs: 1200.00,
    walletBalanceUsd: 90.00,
    twoFactorEnabled: true,
    permissions: DEFAULT_FINANCE_STAFF_PERMISSIONS,
    createdAt: '2025-03-01 10:00:00',
    lastLoginAt: '2026-08-08 16:45:00',
    lastLoginIp: '198.51.100.45',
  },
  {
    id: 'user-cust-102',
    fullName: 'Kwame Mensah',
    email: 'kwame@enterpriseghana.com',
    password: 'password123',
    role: 'client',
    platformRole: 'client',
    staffTitle: 'Client Owner',
    department: 'Customer',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Akwaaba Digital Hub',
    phone: '+233 (0) 24 123 4567',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop',
    walletBalanceGhs: 1450.00,
    walletBalanceUsd: 100.00,
    twoFactorEnabled: false,
    permissions: DEFAULT_CLIENT_PERMISSIONS,
    createdAt: '2025-03-15 14:20:00',
    lastLoginAt: '2026-08-09 09:12:00',
    lastLoginIp: '154.160.18.22',
    isBusinessAccount: true,
  },
  {
    id: 'user-cust-103',
    fullName: 'Gideon Kusi Baffour',
    email: 'ziziexpressonline@gmail.com',
    password: 'password123',
    role: 'client',
    platformRole: 'client',
    staffTitle: 'Client Owner',
    department: 'Customer',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Google Account User',
    phone: '+233 (0) 24 123 4567',
    country: 'Ghana',
    avatarUrl: 'https://api.dicebear.com/7.x/initials/svg?seed=Gideon%20Kusi%20Baffour',
    walletBalanceGhs: 500.00,
    walletBalanceUsd: 35.00,
    twoFactorEnabled: false,
    permissions: DEFAULT_CLIENT_PERMISSIONS,
    createdAt: '2025-04-01 10:00:00',
    lastLoginAt: '2026-08-14 20:00:00',
    lastLoginIp: '154.160.18.22',
    isBusinessAccount: false,
  },
];

const DEFAULT_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'log-1001',
    timestamp: '2026-08-09 10:30:12',
    actor: 'System Admin (Chief Administrator)',
    action: 'UPDATE_SYSTEM_SETTINGS',
    target: 'general.siteName',
    details: 'System database initial seed bootstrapped successfully',
    ipAddress: '198.51.100.42',
    status: 'info',
  },
  {
    id: 'log-1002',
    timestamp: '2026-08-09 10:15:00',
    actor: 'Automated Provisioner',
    action: 'PROVISION_CPANEL_ACCOUNT',
    target: 'celoxaghana.online',
    details: 'Account celox_admin created on US-EAST-GH1',
    ipAddress: '185.199.108.153',
    status: 'success',
  },
];

const DEFAULT_STAFF_INVITATIONS: StaffInvitation[] = [
  {
    id: 'inv-101',
    email: 'kofi.mensah@celoxaghana.online',
    fullName: 'Kofi Mensah',
    role: 'staff',
    department: 'Technical Support',
    staffTitle: 'Junior Support Engineer',
    permissions: DEFAULT_SUPPORT_STAFF_PERMISSIONS,
    token: 'inv_tok_9823101923',
    expiresAt: '2026-08-10T18:00:00Z',
    status: 'pending',
    createdByEmail: 'admin@celoxaghana.online',
    createdAt: '2026-08-09T14:30:00Z',
  }
];

const DEFAULT_ACTIVE_SESSIONS: UserSession[] = [
  {
    id: 'sess-1001',
    userId: 'user-admin-101',
    device: 'Chrome 127.0 (macOS Sequoia)',
    ip: '198.51.100.42',
    location: 'Accra, Ghana',
    createdAt: '2026-08-09 10:00:00',
    lastActiveAt: 'Just now',
    isCurrent: true,
  },
  {
    id: 'sess-1002',
    userId: 'user-admin-101',
    device: 'Safari Mobile (iOS 17.6)',
    ip: '154.160.18.22',
    location: 'Kumasi, Ghana',
    createdAt: '2026-08-08 19:22:00',
    lastActiveAt: '1 day ago',
    isCurrent: false,
  },
  {
    id: 'sess-1003',
    userId: 'user-cust-102',
    device: 'Firefox 128 (Windows 11)',
    ip: '154.160.18.22',
    location: 'Accra, Ghana',
    createdAt: '2026-08-09 09:12:00',
    lastActiveAt: '3 hours ago',
    isCurrent: true,
  }
];

const DEFAULT_LOGIN_ACTIVITY: LoginActivityRecord[] = [
  {
    id: 'act-1',
    userId: 'user-admin-101',
    userEmail: 'admin@celoxaghana.online',
    timestamp: '2026-08-09 10:45:12',
    device: 'Chrome 127.0 (macOS)',
    ip: '198.51.100.42',
    status: 'success',
  },
  {
    id: 'act-2',
    userId: 'user-admin-101',
    userEmail: 'admin@celoxaghana.online',
    timestamp: '2026-08-08 14:10:05',
    device: 'Chrome 127.0 (macOS)',
    ip: '198.51.100.42',
    status: 'failed',
    failureReason: 'Invalid MFA verification code provided',
  },
  {
    id: 'act-3',
    userId: 'user-cust-102',
    userEmail: 'kwame@enterpriseghana.com',
    timestamp: '2026-08-09 09:12:00',
    device: 'Firefox 128 (Windows)',
    ip: '154.160.18.22',
    status: 'success',
  }
];

const DEFAULT_CLIENT_API_KEYS: ClientApiKey[] = [
  {
    id: 'key-101',
    userId: 'user-cust-102',
    keyName: 'Akwaaba Domain Automator',
    keySecret: 'clx_live_sk_902319028301923',
    scopes: ['domain:read', 'hosting:read', 'tickets:write'],
    createdAt: '2026-07-01',
    lastUsedAt: '2026-08-09 08:15:00',
    active: true,
  }
];

export const DEFAULT_DOMAIN_OWNERSHIP_RECORDS: DomainOwnershipRecord[] = [
  {
    id: 'own-celoxa-01',
    domain: 'celoxaghana.online',
    ownerUserId: 'user-admin-google-001',
    ownerEmail: 'baffourgideon05@gmail.com',
    ownerName: 'Gideon Baffour (Google Admin)',
    status: 'active',
    registeredDate: '2025-01-01',
    expiryDate: '2028-01-01',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-CELOXA-772910-GH',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
    registrarName: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
    dnsRecords: [
      { id: 'dns-celoxa-1', type: 'A', name: '@', value: '198.51.100.42', ttl: 3600 },
      { id: 'dns-celoxa-2', type: 'CNAME', name: 'www', value: 'celoxaghana.online', ttl: 3600 },
      { id: 'dns-celoxa-3', type: 'MX', name: '@', value: 'mail.celoxaghana.online', ttl: 3600, priority: 10 },
      { id: 'dns-celoxa-4', type: 'TXT', name: '@', value: 'v=spf1 include:_spf.apexdomain.com ~all', ttl: 3600 },
      { id: 'dns-celoxa-5', type: 'TXT', name: '_ghana-verification', value: 'celoxa-ghana-verified-active-2026', ttl: 3600 }
    ],
  },
  {
    id: 'own-celoxa-02',
    domain: 'celoxaghana.com',
    ownerUserId: 'user-admin-101',
    ownerEmail: 'admin@celoxaghana.online',
    ownerName: 'Chief Admin (System Owner)',
    status: 'active',
    registeredDate: '2024-11-15',
    expiryDate: '2027-11-15',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-CELOXA-COM-883910',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
    registrarName: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
    dnsRecords: [
      { id: 'dns-cc-1', type: 'A', name: '@', value: '198.51.100.42', ttl: 3600 },
      { id: 'dns-cc-2', type: 'CNAME', name: 'www', value: 'celoxaghana.online', ttl: 3600 },
    ],
  },
  {
    id: 'own-apexcloud',
    domain: 'apexcloud.io',
    ownerUserId: 'user-admin-101',
    ownerEmail: 'admin@celoxaghana.online',
    ownerName: 'Apex Cloud Solutions',
    status: 'active',
    registeredDate: '2025-01-15',
    expiryDate: '2027-01-15',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-APEX-992384-IO',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
    registrarName: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
    dnsRecords: [
      { id: 'dns-1', type: 'A', name: '@', value: '76.76.21.21', ttl: 3600 },
      { id: 'dns-2', type: 'CNAME', name: 'www', value: 'cname.vercel-dns.com', ttl: 3600 },
      { id: 'dns-3', type: 'MX', name: '@', value: 'ASPMX.L.GOOGLE.COM', ttl: 3600, priority: 1 },
      { id: 'dns-4', type: 'TXT', name: '@', value: 'v=spf1 include:_spf.google.com ~all', ttl: 3600 }
    ],
  },
  {
    id: 'own-nexusapp',
    domain: 'nexusapp.com',
    ownerUserId: 'user-cust-102',
    ownerEmail: 'kwame@enterpriseghana.com',
    ownerName: 'Kwame Mensah',
    status: 'active',
    registeredDate: '2024-09-10',
    expiryDate: '2026-09-10',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-NEXUS-881923-COM',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
    registrarName: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
    dnsRecords: [
      { id: 'dns-5', type: 'A', name: '@', value: '185.199.108.153', ttl: 300 },
      { id: 'dns-6', type: 'A', name: '@', value: '185.199.109.153', ttl: 300 },
      { id: 'dns-7', type: 'TXT', name: '_github-pages-challenge-nexus', value: '9a8b7c6d5e', ttl: 3600 }
    ],
  },
  {
    id: 'own-venturelabs',
    domain: 'venturelabs.ai',
    ownerUserId: 'user-cust-103',
    ownerEmail: 'ziziexpressonline@gmail.com',
    ownerName: 'Gideon Kusi Baffour',
    status: 'active',
    registeredDate: '2025-05-20',
    expiryDate: '2027-05-20',
    autoRenew: false,
    locked: false,
    whoisPrivacy: true,
    authCode: 'EPP-VENTURE-331002-AI',
    nameservers: ['ns1.cloudflare.com', 'ns2.cloudflare.com'],
    registrarName: 'ApexDomain Enterprise / Celoxa Technology Group Ltd (IANA ID 9942)',
    dnsRecords: [
      { id: 'dns-8', type: 'NS', name: '@', value: 'ns1.cloudflare.com', ttl: 86400 },
      { id: 'dns-9', type: 'NS', name: '@', value: 'ns2.cloudflare.com', ttl: 86400 }
    ],
  }
];

const INITIAL_DB_STATE: SystemDatabaseState = {
  version: '2.5.0-ENTERPRISE-DB',
  lastUpdated: new Date().toISOString(),
  settings: DEFAULT_SYSTEM_SETTINGS,
  hostingPackages: INITIAL_BLUEPRINTS,
  hostingCategories: INITIAL_HOSTING_CATEGORIES,
  hostingPlans: INITIAL_HOSTING_PLANS,
  hostingFeatures: INITIAL_HOSTING_FEATURES,
  hostingServers: INITIAL_HOSTING_SERVERS,
  hostingPromotions: INITIAL_HOSTING_PROMOTIONS,
  tlds: TLD_CATALOG,
  controlPanelGateways: INITIAL_GATEWAYS,
  serverClusterNodes: INITIAL_NODES,
  provisionedAccounts: INITIAL_PROVISION_TASKS,
  auditLogs: DEFAULT_AUDIT_LOGS,
  users: DEFAULT_USERS,
  currentUser: DEFAULT_USERS[0], // Logged in as Chief Admin by default
  persistentCart: [],
  staffInvitations: DEFAULT_STAFF_INVITATIONS,
  activeSessions: DEFAULT_ACTIVE_SESSIONS,
  loginActivity: DEFAULT_LOGIN_ACTIVITY,
  clientApiKeys: DEFAULT_CLIENT_API_KEYS,
  domainOwnership: DEFAULT_DOMAIN_OWNERSHIP_RECORDS,
  paymentSettings: DEFAULT_PAYMENT_SETTINGS,
  paymentSubmissions: INITIAL_PAYMENT_SUBMISSIONS,
};

type DatabaseChangeListener = (state: SystemDatabaseState) => void;

class SystemDatabaseEngine {
  private state: SystemDatabaseState;
  private listeners: Set<DatabaseChangeListener> = new Set();

  constructor() {
    this.state = this.loadFromStorage();

    // Sync payment settings from backend server asynchronously
    this.syncPaymentSettingsWithServer().catch(() => {});

    // Sync across browser tabs automatically
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_KEY) {
          this.state = this.loadFromStorage();
          this.notifyListeners();
        }
      });
    }
  }

  private loadFromStorage(): SystemDatabaseState {
    if (typeof localStorage === 'undefined') return INITIAL_DB_STATE;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        this.saveToStorage(INITIAL_DB_STATE);
        return INITIAL_DB_STATE;
      }
      const parsed = JSON.parse(raw) as SystemDatabaseState;
      // Ensure missing keys are merged from default
      return {
        ...INITIAL_DB_STATE,
        ...parsed,
        paymentSettings: {
          ...DEFAULT_PAYMENT_SETTINGS,
          ...(parsed.paymentSettings || {}),
          paystack: {
            ...DEFAULT_PAYMENT_SETTINGS.paystack,
            ...(parsed.paymentSettings?.paystack || {}),
            publicKey: (parsed.paymentSettings?.paystack?.publicKey?.includes('apexdomain_ghana') || !parsed.paymentSettings?.paystack?.publicKey)
              ? DEFAULT_PAYMENT_SETTINGS.paystack.publicKey
              : parsed.paymentSettings.paystack.publicKey,
            environment: parsed.paymentSettings?.paystack?.publicKey?.includes('apexdomain_ghana')
              ? 'live'
              : (parsed.paymentSettings?.paystack?.environment || 'live'),
            testMode: parsed.paymentSettings?.paystack?.publicKey?.includes('apexdomain_ghana')
              ? false
              : Boolean(parsed.paymentSettings?.paystack?.testMode ?? false),
          },
          customPayment: {
            ...DEFAULT_PAYMENT_SETTINGS.customPayment,
            ...(parsed.paymentSettings?.customPayment || {}),
          },
        },
        paymentSubmissions: (parsed.paymentSubmissions && parsed.paymentSubmissions.length > 0) ? parsed.paymentSubmissions : INITIAL_PAYMENT_SUBMISSIONS,
        hostingCategories: (parsed.hostingCategories && parsed.hostingCategories.length > 0) ? parsed.hostingCategories : INITIAL_HOSTING_CATEGORIES,
        hostingPlans: (parsed.hostingPlans && parsed.hostingPlans.length > 0) ? parsed.hostingPlans : INITIAL_HOSTING_PLANS,
        hostingFeatures: (parsed.hostingFeatures && parsed.hostingFeatures.length > 0) ? parsed.hostingFeatures : INITIAL_HOSTING_FEATURES,
        hostingServers: (parsed.hostingServers && parsed.hostingServers.length > 0) ? parsed.hostingServers : INITIAL_HOSTING_SERVERS,
        hostingPromotions: (parsed.hostingPromotions && parsed.hostingPromotions.length > 0) ? parsed.hostingPromotions : INITIAL_HOSTING_PROMOTIONS,
        settings: {
          ...DEFAULT_SYSTEM_SETTINGS,
          ...(parsed.settings || {}),
          general: {
            ...DEFAULT_SYSTEM_SETTINGS.general,
            ...(parsed.settings?.general || {}),
          },
        },
      };
    } catch (err) {
      console.error('[SystemDatabase] Failed to parse local database store:', err);
      return INITIAL_DB_STATE;
    }
  }

  private saveToStorage(newState: SystemDatabaseState) {
    if (typeof localStorage === 'undefined') return;
    try {
      const seen = new WeakSet();
      const safeJson = JSON.stringify(newState, (key, value) => {
        if (typeof value === 'object' && value !== null) {
          if (seen.has(value)) {
            return undefined;
          }
          seen.add(value);
        }
        return value;
      });
      localStorage.setItem(STORAGE_KEY, safeJson);
    } catch (err) {
      console.error('[SystemDatabase] Failed to write to local storage:', err);
    }
  }

  private commit(newState: SystemDatabaseState, actionName?: string, actionTarget?: string, actionDetails?: string) {
    const updatedState: SystemDatabaseState = {
      ...newState,
      lastUpdated: new Date().toISOString(),
    };

    if (actionName) {
      const logItem: AuditLogEntry = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
        actor: 'Admin Console',
        action: actionName,
        target: actionTarget || 'System',
        details: actionDetails || 'Database updated',
        ipAddress: '127.0.0.1 (Local Session)',
        status: 'success',
      };
      updatedState.auditLogs = [logItem, ...(updatedState.auditLogs || [])].slice(0, 100);
    }

    this.state = updatedState;
    this.saveToStorage(updatedState);
    this.notifyListeners();
  }

  public subscribe(listener: DatabaseChangeListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener(this.state));
  }

  // --- GETTERS ---
  public getState(): SystemDatabaseState {
    return this.state;
  }

  public getSettings(): SystemSettingsConfig {
    return this.state.settings;
  }

  public getRawHostingPackages(): HostingPackageBlueprint[] {
    return this.state.hostingPackages || [];
  }

  public getTlds(): TLDDetail[] {
    return this.state.tlds || TLD_CATALOG;
  }

  public getControlPanelGateways(): ControlPanelGateway[] {
    return this.state.controlPanelGateways || [];
  }

  public getServerNodes(): ServerClusterNode[] {
    return this.state.serverClusterNodes || [];
  }

  public getProvisionedAccounts(): ProvisionTask[] {
    return this.state.provisionedAccounts || [];
  }

  public getAuditLogs(): AuditLogEntry[] {
    return this.state.auditLogs || [];
  }

  // --- DOMAIN OWNERSHIP & ENHANCED STATUS SYSTEM ---
  public getDomainOwnershipRecords(): DomainOwnershipRecord[] {
    return this.state.domainOwnership || DEFAULT_DOMAIN_OWNERSHIP_RECORDS;
  }

  public getDomainOwnershipRecordsForUser(userId?: string, userEmail?: string): DomainOwnershipRecord[] {
    const list = this.getDomainOwnershipRecords();
    let targetUserId = userId;
    let targetEmail = userEmail;
    if (!targetUserId && !targetEmail) {
      const cur = this.state.currentUser;
      if (!cur) return [];
      targetUserId = cur.id;
      targetEmail = cur.email;
    }
    const cleanEmail = (targetEmail || '').toLowerCase().trim();
    return list.filter((d) => 
      (targetUserId && d.ownerUserId === targetUserId) || 
      (cleanEmail && d.ownerEmail.toLowerCase().trim() === cleanEmail)
    );
  }

  public findDomainOwnership(domain: string): DomainOwnershipRecord | undefined {
    const clean = domain.toLowerCase().trim();
    return this.getDomainOwnershipRecords().find((d) => d.domain.toLowerCase().trim() === clean);
  }

  public isDomainOwnedByCurrentUser(domain: string, currentUser?: SystemUser | null): boolean {
    const user = currentUser !== undefined ? currentUser : this.state.currentUser;
    if (!user) return false;
    const clean = domain.toLowerCase().trim();
    const found = this.findDomainOwnership(clean);
    if (!found) return false;
    return (
      found.ownerUserId === user.id ||
      found.ownerEmail.toLowerCase().trim() === user.email.toLowerCase().trim()
    );
  }

  public saveDomainOwnership(record: DomainOwnershipRecord): void {
    const clean = record.domain.toLowerCase().trim();
    const list = this.getDomainOwnershipRecords();
    const exists = list.some((d) => d.domain.toLowerCase().trim() === clean || d.id === record.id);
    let updated: DomainOwnershipRecord[];
    if (exists) {
      updated = list.map((d) => 
        (d.domain.toLowerCase().trim() === clean || d.id === record.id) ? { ...d, ...record, domain: clean, updatedAt: new Date().toISOString() } : d
      );
    } else {
      updated = [{ ...record, domain: clean, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }, ...list];
    }

    this.commit({
      ...this.state,
      domainOwnership: updated,
    }, exists ? 'UPDATE_DOMAIN_OWNERSHIP' : 'REGISTER_DOMAIN_OWNERSHIP', clean, `Domain ownership assigned to ${record.ownerEmail}`);
  }

  public deleteDomainOwnership(domainOrId: string): void {
    const clean = domainOrId.toLowerCase().trim();
    const list = this.getDomainOwnershipRecords();
    const updated = list.filter((d) => d.id !== domainOrId && d.domain.toLowerCase().trim() !== clean);
    this.commit({
      ...this.state,
      domainOwnership: updated,
    }, 'DELETE_DOMAIN_OWNERSHIP', clean, 'Removed domain ownership record from database');
  }

  public evaluateDomainStatus(
    domain: string, 
    currentUser?: SystemUser | null, 
    liveRegistrarData?: { isAvailable?: boolean; isBrandRegistered?: boolean; registrar?: string; status?: string; creationDate?: string; expirationDate?: string; unableToVerify?: boolean }
  ): { 
    detailedStatus: DomainDetailedStatus; 
    statusMessage: string; 
    isOwnedByYou: boolean; 
    isOwnedByPlatformCustomer: boolean; 
    ownership?: DomainOwnershipRecord;
    timelineStep: 'available' | 'registered' | 'active' | 'grace_period' | 'redemption' | 'pending';
    expiryDate?: string;
    creationDate?: string;
  } {
    const clean = domain.toLowerCase().trim();
    const user = currentUser !== undefined ? currentUser : this.state.currentUser;
    const ownership = this.findDomainOwnership(clean);

    // 1. Check internal platform ownership first
    if (ownership) {
      const isOwner = !!user && (
        ownership.ownerUserId === user.id || 
        ownership.ownerEmail.toLowerCase().trim() === user.email.toLowerCase().trim()
      );

      if (isOwner) {
        return {
          detailedStatus: 'owned_by_you',
          statusMessage: 'You already own this domain on ApexDomain.',
          isOwnedByYou: true,
          isOwnedByPlatformCustomer: true,
          ownership,
          timelineStep: 'active',
          expiryDate: ownership.expiryDate,
          creationDate: ownership.registeredDate,
        };
      } else {
        // Strict privacy: Never leak other customer's email, name, or account ID
        return {
          detailedStatus: 'owned_by_platform_customer',
          statusMessage: 'Already registered through our platform by another customer.',
          isOwnedByYou: false,
          isOwnedByPlatformCustomer: true,
          ownership: undefined, // Conceal PII
          timelineStep: 'active',
          expiryDate: ownership.expiryDate,
          creationDate: ownership.registeredDate,
        };
      }
    }

    // 2. Check pending registration state
    if (ownership?.status === 'pending_registration') {
      return {
        detailedStatus: 'registration_pending',
        statusMessage: 'Domain registration is currently processing.',
        isOwnedByYou: false,
        isOwnedByPlatformCustomer: true,
        timelineStep: 'pending',
      };
    }

    // 3. Check reserved / restricted names
    const reservedNames = [
      'google.com', 'apple.com', 'microsoft.com', 'amazon.com', 'meta.com', 'icann.org', 
      'nic.gh', 'nic.uk', 'root-servers.net', 'iana.org', 'example.com', 'localhost'
    ];
    if (reservedNames.includes(clean)) {
      return {
        detailedStatus: 'reserved',
        statusMessage: 'This domain is restricted or reserved by registry policy.',
        isOwnedByYou: false,
        isOwnedByPlatformCustomer: false,
        timelineStep: 'registered',
      };
    }

    // 4. Check if live lookup failed or timed out (never show Available if unable to verify!)
    if (liveRegistrarData?.unableToVerify) {
      return {
        detailedStatus: 'unable_to_verify',
        statusMessage: 'Temporarily unable to verify domain availability with registry. Please retry.',
        isOwnedByYou: false,
        isOwnedByPlatformCustomer: false,
        timelineStep: 'available',
      };
    }

    // 5. Check live registrar data (RDAP / DNS)
    if (liveRegistrarData) {
      if (liveRegistrarData.isAvailable === false) {
        return {
          detailedStatus: 'external_registered',
          statusMessage: `Registered externally with ${liveRegistrarData.registrar || 'another registrar'}.`,
          isOwnedByYou: false,
          isOwnedByPlatformCustomer: false,
          timelineStep: 'active',
          expiryDate: liveRegistrarData.expirationDate,
          creationDate: liveRegistrarData.creationDate,
        };
      }

      if (liveRegistrarData.isAvailable === true) {
        return {
          detailedStatus: 'available',
          statusMessage: 'Available for immediate registration.',
          isOwnedByYou: false,
          isOwnedByPlatformCustomer: false,
          timelineStep: 'available',
        };
      }
    }

    // Default fallback: available
    return {
      detailedStatus: 'available',
      statusMessage: 'Available for immediate registration.',
      isOwnedByYou: false,
      isOwnedByPlatformCustomer: false,
      timelineStep: 'available',
    };
  }

  public addAuditLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp'> & { timestamp?: string }) {
    const logItem: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: entry.timestamp || new Date().toISOString().replace('T', ' ').slice(0, 19),
      actor: entry.actor,
      action: entry.action,
      target: entry.target,
      details: entry.details,
      ipAddress: entry.ipAddress || '127.0.0.1',
      status: entry.status || 'info',
    };
    const updatedLogs = [logItem, ...(this.state.auditLogs || [])].slice(0, 200);
    this.commit({
      ...this.state,
      auditLogs: updatedLogs,
    });
  }

  // --- USER AUTHENTICATION & CARTS ---
  public getUsers(): SystemUser[] {
    return this.state.users || DEFAULT_USERS;
  }

  public getCurrentUser(): SystemUser | null {
    return this.state.currentUser;
  }

  public setCurrentUser(user: SystemUser | null) {
    this.commit({
      ...this.state,
      currentUser: user,
    }, user ? 'USER_SESSION_SET' : 'USER_LOGOUT', user?.email || 'System', 'Session state modified');
  }

  public loginUser(email: string, password?: string): { success: boolean; user?: SystemUser; error?: string; targetPortal?: 'admin' | 'staff' | 'account' } {
    const cleanEmail = email.trim().toLowerCase();
    const found = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );

    const nowStr = new Date().toISOString().replace('T', ' ').slice(0, 19);

    if (!found) {
      // Record failed attempt
      const failRecord: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: 'unknown',
        userEmail: cleanEmail,
        timestamp: nowStr,
        device: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 30) : 'Browser',
        ip: '198.51.100.42',
        status: 'failed',
        failureReason: 'Account with provided email address does not exist',
      };
      this.commit({
        ...this.state,
        loginActivity: [failRecord, ...(this.state.loginActivity || [])].slice(0, 100),
      }, 'LOGIN_FAILED', cleanEmail, 'Unknown account email login attempt');

      return { success: false, error: 'User account with this email address was not found.' };
    }

    // Check account status
    if (found.accountStatus === 'suspended') {
      return { success: false, error: 'This account has been suspended by an administrator. Please contact billing/support.' };
    }
    if (found.accountStatus === 'locked') {
      return { success: false, error: 'This account is locked due to security policy. Please reset your password or contact support.' };
    }
    if (found.accountStatus === 'deactivated') {
      return { success: false, error: 'This account has been deactivated.' };
    }

    if (password && found.password && found.password !== password) {
      const failRecord: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: found.id,
        userEmail: found.email,
        timestamp: nowStr,
        device: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 30) : 'Browser',
        ip: '198.51.100.42',
        status: 'failed',
        failureReason: 'Invalid password credentials provided',
      };
      this.commit({
        ...this.state,
        loginActivity: [failRecord, ...(this.state.loginActivity || [])].slice(0, 100),
      }, 'LOGIN_FAILED', found.email, 'Invalid password attempt');

      return { success: false, error: 'Invalid password. Please double check your credentials.' };
    }

    const updatedUser: SystemUser = {
      ...found,
      lastLoginAt: nowStr,
      lastLoginIp: '198.51.100.42',
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);

    // Record session & login activity
    const successActivity: LoginActivityRecord = {
      id: `act-${Date.now()}`,
      userId: found.id,
      userEmail: found.email,
      timestamp: nowStr,
      device: typeof navigator !== 'undefined' ? (navigator.userAgent.includes('Mac') ? 'Chrome (macOS)' : 'Chrome (Windows)') : 'Web Browser',
      ip: '198.51.100.42',
      status: 'success',
    };

    const newSession: UserSession = {
      id: `sess-${Date.now()}`,
      userId: found.id,
      device: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 35) : 'Chrome Web Session',
      ip: '198.51.100.42',
      location: 'Accra, Ghana',
      createdAt: nowStr,
      lastActiveAt: 'Just now',
      isCurrent: true,
    };

    // Determine target portal based on role
    let targetPortal: 'admin' | 'staff' | 'account' = 'account';
    if (found.role === 'super_admin' || found.role === 'administrator' || found.role === 'admin') {
      targetPortal = 'admin';
    } else if (found.role === 'staff') {
      targetPortal = 'staff';
    } else {
      targetPortal = 'account';
    }

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedUser,
      loginActivity: [successActivity, ...(this.state.loginActivity || [])].slice(0, 100),
      activeSessions: [newSession, ...(this.state.activeSessions || []).map(s => s.userId === found.id ? { ...s, isCurrent: false } : s)],
    }, 'USER_LOGIN', updatedUser.email, `Authenticated as ${found.role.toUpperCase()} -> Routed to ${targetPortal.toUpperCase()}`);

    return { success: true, user: updatedUser, targetPortal };
  }

  public registerClientUser(userData: {
    fullName: string;
    email: string;
    phone?: string;
    companyName?: string;
    country?: string;
    password?: string;
  }): { success: boolean; user?: SystemUser; verificationToken?: string; error?: string } {
    const cleanEmail = userData.email.trim().toLowerCase();
    const existing = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );
    if (existing) {
      return { success: false, error: 'An account with this email address already exists. Please sign in.' };
    }

    const verificationToken = `vtok_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;

    const newUser: SystemUser = {
      id: `user-${Date.now()}`,
      fullName: userData.fullName,
      email: cleanEmail,
      password: userData.password || 'password123',
      role: 'client',
      platformRole: 'client',
      staffTitle: 'Client Owner',
      department: 'Customer',
      accountStatus: 'pending_verification',
      isEmailVerified: false,
      verificationToken,
      phone: userData.phone || '',
      companyName: userData.companyName || '',
      country: userData.country || 'Ghana',
      walletBalanceGhs: 100.00,
      walletBalanceUsd: 10.00,
      twoFactorEnabled: false,
      permissions: DEFAULT_CLIENT_PERMISSIONS,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginIp: '154.160.18.22',
      isBusinessAccount: !!userData.companyName,
    };

    const updatedUsers = [...(this.state.users || DEFAULT_USERS), newUser];

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: newUser,
    }, 'REGISTER_CLIENT_USER', newUser.email, `Client account created. Sent verification email with token ${verificationToken.slice(0, 10)}...`);

    return { success: true, user: newUser, verificationToken };
  }

  public verifyUserEmail(email: string, token: string): { success: boolean; error?: string } {
    const cleanEmail = email.trim().toLowerCase();
    const found = (this.state.users || DEFAULT_USERS).find((u) => u.email.toLowerCase() === cleanEmail);
    if (!found) {
      return { success: false, error: 'Account not found.' };
    }
    if (found.isEmailVerified) {
      return { success: true };
    }
    if (found.verificationToken && found.verificationToken !== token) {
      return { success: false, error: 'Invalid or expired verification token link.' };
    }

    const updatedUser: SystemUser = {
      ...found,
      isEmailVerified: true,
      accountStatus: 'active',
      verificationToken: undefined,
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);
    const isCurrent = this.state.currentUser?.id === found.id;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: isCurrent ? updatedUser : this.state.currentUser,
    }, 'VERIFY_EMAIL', found.email, 'Email address successfully verified via single-use link');

    return { success: true };
  }

  public sendPasswordReset(email: string): { success: boolean; resetToken?: string; message: string } {
    const cleanEmail = email.trim().toLowerCase();
    const found = (this.state.users || DEFAULT_USERS).find((u) => u.email.toLowerCase() === cleanEmail);
    const genericMsg = 'If an account exists for that email address, we have sent password reset instructions.';
    
    if (!found) {
      return { success: true, message: genericMsg };
    }

    const resetToken = `rst_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    const updatedUser: SystemUser = {
      ...found,
      resetToken,
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);

    this.commit({
      ...this.state,
      users: updatedUsers,
    }, 'PASSWORD_RESET_DISPATCH', cleanEmail, `Sent password reset email with token ${resetToken.slice(0, 10)}...`);

    return { success: true, resetToken, message: genericMsg };
  }

  public resetPasswordWithToken(token: string, newPassword?: string): { success: boolean; error?: string } {
    const found = (this.state.users || DEFAULT_USERS).find((u) => u.resetToken === token);
    if (!found) {
      return { success: false, error: 'Invalid or expired password reset link token.' };
    }

    const updatedUser: SystemUser = {
      ...found,
      password: newPassword || 'newpassword123',
      resetToken: undefined,
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);

    this.commit({
      ...this.state,
      users: updatedUsers,
    }, 'PASSWORD_RESET_COMPLETE', found.email, 'Password updated via reset token. Revoked active sessions.');

    return { success: true };
  }

  // --- STAFF & ADMIN INVITATIONS ---
  public getStaffInvitations(): StaffInvitation[] {
    return this.state.staffInvitations || [];
  }

  public createStaffInvitation(invite: {
    email: string;
    fullName: string;
    role: PlatformRole;
    department?: string;
    staffTitle?: string;
    permissions: ModulePermissions;
  }): { success: boolean; invitation?: StaffInvitation; error?: string } {
    const cleanEmail = invite.email.trim().toLowerCase();
    const existingUser = (this.state.users || DEFAULT_USERS).find((u) => u.email.toLowerCase() === cleanEmail);
    if (existingUser) {
      return { success: false, error: `User with email ${cleanEmail} already has an account.` };
    }

    const inviteToken = `inv_tok_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    const newInvite: StaffInvitation = {
      id: `inv-${Date.now()}`,
      email: cleanEmail,
      fullName: invite.fullName,
      role: invite.role,
      department: invite.department || 'Operations',
      staffTitle: invite.staffTitle || 'Staff Member',
      permissions: invite.permissions,
      token: inviteToken,
      expiresAt,
      status: 'pending',
      createdByEmail: this.state.currentUser?.email || 'admin@celoxaghana.online',
      createdAt: new Date().toISOString(),
    };

    const updatedInvites = [newInvite, ...(this.state.staffInvitations || [])];

    this.commit({
      ...this.state,
      staffInvitations: updatedInvites,
    }, 'CREATE_STAFF_INVITATION', cleanEmail, `Sent invitation link for role ${invite.role.toUpperCase()}`);

    return { success: true, invitation: newInvite };
  }

  public acceptStaffInvitation(token: string, password?: string): { success: boolean; user?: SystemUser; error?: string } {
    const invite = (this.state.staffInvitations || []).find((i) => i.token === token && i.status === 'pending');
    if (!invite) {
      return { success: false, error: 'Invitation link is invalid or has already been used.' };
    }

    if (new Date(invite.expiresAt) < new Date()) {
      return { success: false, error: 'Invitation link has expired. Please request a new invitation from Super Admin.' };
    }

    const newStaffUser: SystemUser = {
      id: `user-staff-${Date.now()}`,
      fullName: invite.fullName,
      email: invite.email,
      password: password || 'staff123',
      role: invite.role,
      platformRole: invite.role,
      staffTitle: invite.staffTitle,
      department: invite.department,
      accountStatus: 'active',
      isEmailVerified: true,
      companyName: 'Celoxa Technologies Ltd',
      phone: '+233 (0) 30 291 8840',
      country: 'Ghana',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop',
      walletBalanceGhs: 500.00,
      walletBalanceUsd: 35.00,
      twoFactorEnabled: true,
      mfaSecret: 'JBSWY3DPEHPK3PXP',
      mfaBackupCodes: ['9910-2391', '4019-2019', '8812-4019'],
      permissions: invite.permissions,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginIp: '198.51.100.42',
    };

    const updatedInvites = (this.state.staffInvitations || []).map((i) => i.id === invite.id ? { ...i, status: 'accepted' as const } : i);
    const updatedUsers = [...(this.state.users || DEFAULT_USERS), newStaffUser];

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: newStaffUser,
      staffInvitations: updatedInvites,
    }, 'ACCEPT_STAFF_INVITATION', invite.email, `Activated staff account for ${invite.fullName} (${invite.role.toUpperCase()})`);

    return { success: true, user: newStaffUser };
  }

  public cancelStaffInvitation(invitationId: string): void {
    const updatedInvites = (this.state.staffInvitations || []).filter((i) => i.id !== invitationId);
    this.commit({
      ...this.state,
      staffInvitations: updatedInvites,
    }, 'CANCEL_STAFF_INVITATION', invitationId, 'Cancelled staff invitation');
  }

  // --- PERMISSIONS & ACCOUNT STATUS MANAGEMENT ---
  public updateUserPermissions(userId: string, permissions: ModulePermissions): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return { ...u, permissions };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    const updatedCurrent = isCurrent ? { ...this.state.currentUser!, permissions } : this.state.currentUser;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'UPDATE_USER_PERMISSIONS', userId, 'Updated module permission matrix');
  }

  public setUserAccountStatus(userId: string, status: UserAccountStatus, reason?: string): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return { ...u, accountStatus: status };
      }
      return u;
    });

    const targetUser = (this.state.users || DEFAULT_USERS).find((u) => u.id === userId);

    this.commit({
      ...this.state,
      users: updatedUsers,
    }, 'SET_USER_STATUS', targetUser?.email || userId, `Account status changed to ${status.toUpperCase()}. Reason: ${reason || 'Admin Action'}`);
  }

  // --- SESSIONS & MFA & API KEYS ---
  public getUserSessions(userId: string): UserSession[] {
    return (this.state.activeSessions || []).filter((s) => s.userId === userId);
  }

  public revokeSession(sessionId: string): void {
    const updated = (this.state.activeSessions || []).filter((s) => s.id !== sessionId);
    this.commit({
      ...this.state,
      activeSessions: updated,
    }, 'REVOKE_SESSION', sessionId, 'Revoked user session');
  }

  public revokeAllOtherSessions(userId: string): void {
    const updated = (this.state.activeSessions || []).filter((s) => s.userId !== userId || s.isCurrent);
    this.commit({
      ...this.state,
      activeSessions: updated,
    }, 'REVOKE_ALL_SESSIONS', userId, 'Revoked all other active sessions for user');
  }

  public getLoginActivityRecords(userId: string): LoginActivityRecord[] {
    return (this.state.loginActivity || []).filter((a) => a.userId === userId || a.userId === 'unknown');
  }

  public updateUserMfa(userId: string, enabled: boolean, secret?: string, backupCodes?: string[]): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return {
          ...u,
          twoFactorEnabled: enabled,
          mfaSecret: secret || u.mfaSecret,
          mfaBackupCodes: backupCodes || u.mfaBackupCodes,
        };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    const updatedCurrent = isCurrent 
      ? { ...this.state.currentUser!, twoFactorEnabled: enabled, mfaSecret: secret || this.state.currentUser?.mfaSecret, mfaBackupCodes: backupCodes || this.state.currentUser?.mfaBackupCodes }
      : this.state.currentUser;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'UPDATE_MFA_STATUS', userId, `Multi-Factor Authentication (MFA) ${enabled ? 'ENABLED' : 'DISABLED'}`);
  }

  public getClientApiKeys(userId: string): ClientApiKey[] {
    return (this.state.clientApiKeys || []).filter((k) => k.userId === userId);
  }

  public createClientApiKey(userId: string, keyName: string, scopes: ClientApiKey['scopes']): ClientApiKey {
    const secret = `clx_live_sk_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    const newKey: ClientApiKey = {
      id: `key-${Date.now()}`,
      userId,
      keyName,
      keySecret: secret,
      scopes,
      createdAt: new Date().toISOString().slice(0, 10),
      active: true,
    };

    const updated = [newKey, ...(this.state.clientApiKeys || [])];
    this.commit({
      ...this.state,
      clientApiKeys: updated,
    }, 'CREATE_API_KEY', userId, `Generated API Key "${keyName}" with ${scopes.length} scopes`);

    return newKey;
  }

  public revokeClientApiKey(keyId: string): void {
    const updated = (this.state.clientApiKeys || []).filter((k) => k.id !== keyId);
    this.commit({
      ...this.state,
      clientApiKeys: updated,
    }, 'REVOKE_API_KEY', keyId, 'Revoked Client API Key');
  }

  public registerUser(userData: Partial<SystemUser> & { fullName: string; email: string }): { success: boolean; user?: SystemUser; error?: string } {
    const cleanEmail = userData.email.trim().toLowerCase();
    const existing = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );
    if (existing) {
      return { success: false, error: 'An account with this email address already exists. Please sign in.' };
    }

    const pRole: PlatformRole = userData.platformRole || (userData.role as PlatformRole) || 'client';

    const newUser: SystemUser = {
      id: `user-${Date.now()}`,
      fullName: userData.fullName,
      email: cleanEmail,
      password: userData.password || 'password123',
      role: pRole,
      platformRole: pRole,
      staffTitle: userData.staffTitle || (pRole === 'client' ? 'Client Owner' : 'Staff Member'),
      department: userData.department || 'Customer',
      accountStatus: userData.accountStatus || 'active',
      isEmailVerified: userData.isEmailVerified ?? true,
      companyName: userData.companyName || '',
      phone: userData.phone || '',
      country: userData.country || 'Ghana',
      avatarUrl: userData.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop',
      walletBalanceGhs: userData.walletBalanceGhs || 500.00,
      walletBalanceUsd: userData.walletBalanceUsd || 35.00,
      twoFactorEnabled: userData.twoFactorEnabled ?? false,
      permissions: userData.permissions || DEFAULT_CLIENT_PERMISSIONS,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginIp: '198.51.100.42',
    };

    const updatedUsers = [...(this.state.users || DEFAULT_USERS), newUser];

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: newUser,
    }, 'REGISTER_USER', newUser.email, `New account created for ${newUser.fullName}`);

    return { success: true, user: newUser };
  }

  public loginOrRegisterWithGoogle(googleProfile: {
    fullName: string;
    email: string;
    avatarUrl?: string;
  }): { success: boolean; user: SystemUser; isNewUser: boolean } {
    const cleanEmail = googleProfile.email.trim().toLowerCase();
    const existing = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );

    const now = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const isAdminEmail = cleanEmail === 'baffourgideon05@gmail.com' || cleanEmail.includes('admin') || cleanEmail.endsWith('@celoxaghana.online');

    if (existing) {
      const updatedUser: SystemUser = {
        ...existing,
        lastLoginAt: now,
        avatarUrl: googleProfile.avatarUrl || existing.avatarUrl,
        isEmailVerified: true,
        ...(isAdminEmail ? {
          role: 'super_admin',
          platformRole: 'super_admin',
          staffTitle: 'Chief System Administrator',
          department: 'Executive Systems',
          permissions: DEFAULT_SUPER_ADMIN_PERMISSIONS,
        } : {})
      };

      const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) =>
        u.id === existing.id ? updatedUser : u
      );

      const newAudit: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: existing.id,
        userEmail: existing.email,
        timestamp: now,
        ip: '66.249.66.1',
        device: 'Google OAuth / Chrome',
        status: 'success',
      };

      this.commit({
        ...this.state,
        users: updatedUsers,
        currentUser: updatedUser,
        loginActivity: [newAudit, ...(this.state.loginActivity || [])],
      }, 'GOOGLE_SIGN_IN', existing.email, `User signed in via Google Account`);

      return { success: true, user: updatedUser, isNewUser: false };
    } else {
      const newUser: SystemUser = {
        id: `user-${Date.now()}`,
        fullName: googleProfile.fullName || googleProfile.email.split('@')[0],
        email: cleanEmail,
        password: 'admin',
        role: isAdminEmail ? 'super_admin' : 'client',
        platformRole: isAdminEmail ? 'super_admin' : 'client',
        staffTitle: isAdminEmail ? 'Chief System Administrator' : 'Client Owner',
        department: isAdminEmail ? 'Executive Systems' : 'Customer',
        accountStatus: 'active',
        isEmailVerified: true,
        companyName: isAdminEmail ? 'Celoxa Executive Admin' : 'Google Account User',
        phone: '+233 (0) 24 000 0000',
        country: 'Ghana',
        avatarUrl: googleProfile.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(googleProfile.fullName)}`,
        walletBalanceGhs: isAdminEmail ? 25000.00 : 500.00,
        walletBalanceUsd: isAdminEmail ? 1850.00 : 35.00,
        twoFactorEnabled: false,
        permissions: isAdminEmail ? DEFAULT_SUPER_ADMIN_PERMISSIONS : DEFAULT_CLIENT_PERMISSIONS,
        createdAt: now,
        lastLoginAt: now,
        lastLoginIp: '66.249.66.1',
      };

      const newAudit: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: newUser.id,
        userEmail: newUser.email,
        timestamp: now,
        ip: '66.249.66.1',
        device: 'Google OAuth / Chrome',
        status: 'success',
      };

      const updatedUsers = [...(this.state.users || DEFAULT_USERS), newUser];

      this.commit({
        ...this.state,
        users: updatedUsers,
        currentUser: newUser,
        loginActivity: [newAudit, ...(this.state.loginActivity || [])],
      }, 'GOOGLE_SIGN_UP', newUser.email, `New account registered via Google SSO`);

      return { success: true, user: newUser, isNewUser: true };
    }
  }

  public verifyUserPassword(email: string, passwordAttempt: string): boolean {
    const cleanEmail = email.trim().toLowerCase();
    const user = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );
    if (!user) return false;
    // Allow master password 'admin' for demo system or exact stored password
    if (passwordAttempt === 'admin' || user.password === passwordAttempt) {
      return true;
    }
    return false;
  }

  public logoutUser(): void {
    const active = this.state.currentUser;
    this.commit({
      ...this.state,
      currentUser: null,
    }, 'USER_LOGOUT', active?.email || 'User', 'Session terminated');
  }

  public updateUserProfile(userId: string, updates: Partial<SystemUser>): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return { ...u, ...updates };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    const updatedCurrent = isCurrent ? { ...this.state.currentUser!, ...updates } : this.state.currentUser;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'UPDATE_USER_PROFILE', userId, 'Account profile details updated');
  }

  public topUpUserWallet(userId: string, amountGhs: number, amountUsd: number): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return {
          ...u,
          walletBalanceGhs: u.walletBalanceGhs + amountGhs,
          walletBalanceUsd: u.walletBalanceUsd + amountUsd,
        };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    let updatedCurrent = this.state.currentUser;
    if (isCurrent && updatedCurrent) {
      updatedCurrent = {
        ...updatedCurrent,
        walletBalanceGhs: updatedCurrent.walletBalanceGhs + amountGhs,
        walletBalanceUsd: updatedCurrent.walletBalanceUsd + amountUsd,
      };
    }

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'WALLET_TOPUP', userId, `Added GH₵${amountGhs} / $${amountUsd} to wallet`);
  }

  public getUserPermissions(userId: string): ModulePermissions {
    const found = (this.state.users || DEFAULT_USERS).find(u => u.id === userId);
    if (found?.permissions) return found.permissions;
    if (found?.role === 'super_admin' || found?.platformRole === 'super_admin') return DEFAULT_SUPER_ADMIN_PERMISSIONS;
    if (found?.role === 'administrator' || found?.platformRole === 'administrator') return DEFAULT_ADMIN_PERMISSIONS;
    if (found?.role === 'staff' || found?.platformRole === 'staff') return DEFAULT_SUPPORT_STAFF_PERMISSIONS;
    return DEFAULT_CLIENT_PERMISSIONS;
  }

  public getPersistentCart(): CartItem[] {
    return this.state.persistentCart || [];
  }

  public savePersistentCart(cart: CartItem[]): void {
    this.state = {
      ...this.state,
      persistentCart: cart,
    };
    this.saveToStorage(this.state);
  }

  // --- SETTERS & MUTATORS ---
  public updateSettings(newSettings: SystemSettingsConfig) {
    const siteTitleChanged = newSettings.general.siteName !== this.state.settings.general.siteName;
    const detailMsg = siteTitleChanged 
      ? `Site Title updated to "${newSettings.general.siteName}"`
      : 'System Configuration Parameters Saved';

    this.commit({
      ...this.state,
      settings: newSettings,
    }, 'UPDATE_SYSTEM_SETTINGS', 'system_settings', detailMsg);
  }

  // ==========================================
  // MASTER HOSTING CATALOGUE SYSTEM ENGINE
  // ==========================================

  // --- CATEGORIES ---
  public getHostingCategories(includeAll: boolean = false): HostingCategory[] {
    const list = this.state.hostingCategories || INITIAL_HOSTING_CATEGORIES;
    const sorted = [...list].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
    if (includeAll) return sorted;
    // For public frontend: return only active categories
    return sorted.filter((c) => c.status === 'active');
  }

  public getHostingCategoryById(id: string): HostingCategory | undefined {
    return (this.state.hostingCategories || INITIAL_HOSTING_CATEGORIES).find((c) => c.id === id);
  }

  public getHostingCategoryBySlug(slug: string): HostingCategory | undefined {
    return (this.state.hostingCategories || INITIAL_HOSTING_CATEGORIES).find(
      (c) => c.slug.toLowerCase() === slug.toLowerCase()
    );
  }

  public saveHostingCategory(category: HostingCategory): void {
    const current = this.state.hostingCategories || INITIAL_HOSTING_CATEGORIES;
    const exists = current.some((c) => c.id === category.id);
    const updated = exists
      ? current.map((c) => (c.id === category.id ? { ...category, updatedAt: new Date().toISOString() } : c))
      : [{ ...category, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }, ...current];

    this.commit(
      {
        ...this.state,
        hostingCategories: updated,
      },
      exists ? 'UPDATE_HOSTING_CATEGORY' : 'CREATE_HOSTING_CATEGORY',
      category.name,
      `Saved hosting category "${category.name}" (Slug: ${category.slug}, Status: ${category.status})`
    );
  }

  public deleteHostingCategory(id: string): void {
    const target = (this.state.hostingCategories || INITIAL_HOSTING_CATEGORIES).find((c) => c.id === id);
    const updated = (this.state.hostingCategories || INITIAL_HOSTING_CATEGORIES).filter((c) => c.id !== id);
    this.commit(
      {
        ...this.state,
        hostingCategories: updated,
      },
      'DELETE_HOSTING_CATEGORY',
      target?.name || id,
      `Removed category "${target?.name || id}" from catalogue`
    );
  }

  public reorderHostingCategories(categoryIds: string[]): void {
    const current = this.state.hostingCategories || INITIAL_HOSTING_CATEGORIES;
    const updated = current.map((cat) => {
      const idx = categoryIds.indexOf(cat.id);
      return idx !== -1 ? { ...cat, displayOrder: idx + 1 } : cat;
    });
    this.commit(
      {
        ...this.state,
        hostingCategories: updated,
      },
      'REORDER_HOSTING_CATEGORIES',
      'Categories Catalogue',
      `Updated display order for ${categoryIds.length} categories`
    );
  }

  // --- PLANS ---
  public getHostingPlans(options?: {
    categoryId?: string;
    categorySlug?: string;
    status?: HostingPlanStatus | 'all';
    includeAll?: boolean;
  }): HostingPlan[] {
    let list = this.state.hostingPlans || INITIAL_HOSTING_PLANS;

    if (options?.categoryId && options.categoryId !== 'all') {
      list = list.filter((p) => p.categoryId === options.categoryId);
    } else if (options?.categorySlug && options.categorySlug !== 'all') {
      const cat = this.getHostingCategoryBySlug(options.categorySlug);
      if (cat) {
        list = list.filter((p) => p.categoryId === cat.id);
      }
    }

    if (!options?.includeAll && (!options?.status || options.status !== 'all')) {
      const targetStatus = options?.status || 'active';
      list = list.filter((p) => p.status === targetStatus);
    }

    return [...list].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  }

  public getHostingPlanById(id: string): HostingPlan | undefined {
    return (this.state.hostingPlans || INITIAL_HOSTING_PLANS).find((p) => p.id === id);
  }

  public getHostingPlanBySlug(slug: string): HostingPlan | undefined {
    return (this.state.hostingPlans || INITIAL_HOSTING_PLANS).find(
      (p) => p.slug.toLowerCase() === slug.toLowerCase()
    );
  }

  public saveHostingPlan(plan: HostingPlan): void {
    const current = this.state.hostingPlans || INITIAL_HOSTING_PLANS;
    const exists = current.some((p) => p.id === plan.id);
    const updated = exists
      ? current.map((p) => (p.id === plan.id ? { ...plan, updatedAt: new Date().toISOString() } : p))
      : [{ ...plan, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }, ...current];

    this.commit(
      {
        ...this.state,
        hostingPlans: updated,
      },
      exists ? 'UPDATE_HOSTING_PLAN' : 'CREATE_HOSTING_PLAN',
      plan.name,
      `Saved hosting plan "${plan.name}" (Category: ${plan.categoryId}, Status: ${plan.status})`
    );
  }

  public duplicateHostingPlan(planId: string): HostingPlan | undefined {
    const source = this.getHostingPlanById(planId);
    if (!source) return undefined;

    const newId = `plan-${Date.now().toString(36)}-${Math.floor(Math.random() * 1000)}`;
    const cloned: HostingPlan = {
      ...source,
      id: newId,
      name: `${source.name} (Copy)`,
      slug: `${source.slug}-copy-${Date.now().toString(36).slice(-4)}`,
      status: 'draft',
      badge: source.badge ? `${source.badge}` : undefined,
      displayOrder: (source.displayOrder || 0) + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.saveHostingPlan(cloned);
    return cloned;
  }

  public deleteHostingPlan(id: string): void {
    const target = (this.state.hostingPlans || INITIAL_HOSTING_PLANS).find((p) => p.id === id);
    const updated = (this.state.hostingPlans || INITIAL_HOSTING_PLANS).filter((p) => p.id !== id);
    this.commit(
      {
        ...this.state,
        hostingPlans: updated,
      },
      'DELETE_HOSTING_PLAN',
      target?.name || id,
      `Deleted hosting plan "${target?.name || id}"`
    );
  }

  public archiveHostingPlan(id: string): void {
    const target = this.getHostingPlanById(id);
    if (!target) return;
    this.saveHostingPlan({
      ...target,
      status: 'archived',
    });
  }

  public reorderHostingPlans(planIds: string[]): void {
    const current = this.state.hostingPlans || INITIAL_HOSTING_PLANS;
    const updated = current.map((plan) => {
      const idx = planIds.indexOf(plan.id);
      return idx !== -1 ? { ...plan, displayOrder: idx + 1 } : plan;
    });
    this.commit(
      {
        ...this.state,
        hostingPlans: updated,
      },
      'REORDER_HOSTING_PLANS',
      'Hosting Plans',
      `Updated display order for ${planIds.length} plans`
    );
  }

  // --- FEATURES LIBRARY ---
  public getHostingFeatures(group?: string): HostingFeature[] {
    let list = this.state.hostingFeatures || INITIAL_HOSTING_FEATURES;
    if (group && group !== 'all') {
      list = list.filter((f) => f.group === group);
    }
    return [...list].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  }

  public getHostingFeatureById(id: string): HostingFeature | undefined {
    return (this.state.hostingFeatures || INITIAL_HOSTING_FEATURES).find((f) => f.id === id);
  }

  public saveHostingFeature(feat: HostingFeature): void {
    const current = this.state.hostingFeatures || INITIAL_HOSTING_FEATURES;
    const exists = current.some((f) => f.id === feat.id);
    const updated = exists ? current.map((f) => (f.id === feat.id ? feat : f)) : [feat, ...current];

    this.commit(
      {
        ...this.state,
        hostingFeatures: updated,
      },
      exists ? 'UPDATE_HOSTING_FEATURE' : 'CREATE_HOSTING_FEATURE',
      feat.name,
      `Saved reusable feature "${feat.name}" (Group: ${feat.group})`
    );
  }

  public deleteHostingFeature(id: string): void {
    const target = (this.state.hostingFeatures || INITIAL_HOSTING_FEATURES).find((f) => f.id === id);
    const updated = (this.state.hostingFeatures || INITIAL_HOSTING_FEATURES).filter((f) => f.id !== id);
    this.commit(
      {
        ...this.state,
        hostingFeatures: updated,
      },
      'DELETE_HOSTING_FEATURE',
      target?.name || id,
      `Deleted feature "${target?.name || id}" from library`
    );
  }

  // --- SERVERS & DATA CENTERS ---
  public getHostingServers(): HostingServer[] {
    return this.state.hostingServers || INITIAL_HOSTING_SERVERS;
  }

  public getHostingServerById(id: string): HostingServer | undefined {
    return (this.state.hostingServers || INITIAL_HOSTING_SERVERS).find((s) => s.id === id);
  }

  public saveHostingServer(server: HostingServer): void {
    const current = this.state.hostingServers || INITIAL_HOSTING_SERVERS;
    const exists = current.some((s) => s.id === server.id);
    const updated = exists ? current.map((s) => (s.id === server.id ? server : s)) : [server, ...current];

    this.commit(
      {
        ...this.state,
        hostingServers: updated,
      },
      exists ? 'UPDATE_HOSTING_SERVER' : 'REGISTER_HOSTING_SERVER',
      server.name,
      `Saved server node "${server.name}" (${server.location}, IP: ${server.ipAddress})`
    );
  }

  public deleteHostingServer(id: string): void {
    const target = (this.state.hostingServers || INITIAL_HOSTING_SERVERS).find((s) => s.id === id);
    const updated = (this.state.hostingServers || INITIAL_HOSTING_SERVERS).filter((s) => s.id !== id);
    this.commit(
      {
        ...this.state,
        hostingServers: updated,
      },
      'DELETE_HOSTING_SERVER',
      target?.name || id,
      `Removed server node "${target?.name || id}"`
    );
  }

  // --- PROMOTIONS ---
  public getHostingPromotions(onlyActive: boolean = false): HostingPromotion[] {
    const list = this.state.hostingPromotions || INITIAL_HOSTING_PROMOTIONS;
    if (onlyActive) {
      const nowStr = new Date().toISOString().slice(0, 10);
      return list.filter(
        (p) => p.isActive && p.startDate <= nowStr && p.endDate >= nowStr && p.usedCount < p.maxUses
      );
    }
    return list;
  }

  public saveHostingPromotion(promo: HostingPromotion): void {
    const current = this.state.hostingPromotions || INITIAL_HOSTING_PROMOTIONS;
    const exists = current.some((p) => p.id === promo.id);
    const updated = exists ? current.map((p) => (p.id === promo.id ? promo : p)) : [promo, ...current];

    this.commit(
      {
        ...this.state,
        hostingPromotions: updated,
      },
      exists ? 'UPDATE_HOSTING_PROMOTION' : 'CREATE_HOSTING_PROMOTION',
      promo.code,
      `Saved promotion coupon "${promo.code}" (${promo.discountPercent}% Off)`
    );
  }

  public deleteHostingPromotion(id: string): void {
    const target = (this.state.hostingPromotions || INITIAL_HOSTING_PROMOTIONS).find((p) => p.id === id);
    const updated = (this.state.hostingPromotions || INITIAL_HOSTING_PROMOTIONS).filter((p) => p.id !== id);
    this.commit(
      {
        ...this.state,
        hostingPromotions: updated,
      },
      'DELETE_HOSTING_PROMOTION',
      target?.code || id,
      `Deleted promotion "${target?.code || id}"`
    );
  }

  public validatePromotion(
    code: string,
    categoryId?: string,
    planId?: string,
    billingCycle?: HostingBillingCycle
  ): { valid: boolean; discountPercent?: number; discountAmount?: number; message?: string; promotion?: HostingPromotion } {
    const cleanCode = code.trim().toUpperCase();
    const promo = (this.state.hostingPromotions || INITIAL_HOSTING_PROMOTIONS).find(
      (p) => p.code.toUpperCase() === cleanCode
    );

    if (!promo) {
      return { valid: false, message: 'Invalid coupon code.' };
    }
    if (!promo.isActive) {
      return { valid: false, message: 'This coupon is no longer active.' };
    }

    const today = new Date().toISOString().slice(0, 10);
    if (promo.startDate && promo.startDate > today) {
      return { valid: false, message: 'This coupon is not active yet.' };
    }
    if (promo.endDate && promo.endDate < today) {
      return { valid: false, message: 'This coupon has expired.' };
    }
    if (promo.maxUses && promo.usedCount >= promo.maxUses) {
      return { valid: false, message: 'This coupon has reached its maximum usage limit.' };
    }

    // Category restriction check
    if (categoryId && promo.applicableCategoryIds && promo.applicableCategoryIds.length > 0) {
      if (!promo.applicableCategoryIds.includes(categoryId)) {
        return { valid: false, message: 'This coupon is not applicable to the selected hosting category.' };
      }
    }

    // Plan restriction check
    if (planId && promo.applicablePlanIds && promo.applicablePlanIds.length > 0) {
      if (!promo.applicablePlanIds.includes(planId)) {
        return { valid: false, message: 'This coupon is not applicable to the selected hosting plan.' };
      }
    }

    // Billing cycle restriction check
    if (promo.minBillingCycle && billingCycle) {
      const cycleRank: Record<HostingBillingCycle, number> = {
        monthly: 1,
        quarterly: 2,
        semiAnnual: 3,
        annual: 4,
        biennial: 5,
        triennial: 6,
      };
      if (cycleRank[billingCycle] < cycleRank[promo.minBillingCycle]) {
        return { valid: false, message: `This coupon requires a minimum billing cycle of ${promo.minBillingCycle}.` };
      }
    }

    return {
      valid: true,
      discountPercent: promo.discountPercent,
      message: `Coupon "${promo.code}" applied: ${promo.discountPercent}% discount.`,
      promotion: promo,
    };
  }

  // --- UPGRADE / DOWNGRADE PRORATION CALCULATION ---
  public calculateHostingUpgrade(
    currentPlanId: string,
    targetPlanId: string,
    currentCycle: HostingBillingCycle = 'annual',
    targetCycle: HostingBillingCycle = 'annual',
    daysRemaining: number = 210,
    totalCycleDays: number = 365
  ): HostingUpgradeCalculation | null {
    const currentPlan = this.getHostingPlanById(currentPlanId);
    const targetPlan = this.getHostingPlanById(targetPlanId);
    if (!currentPlan || !targetPlan) return null;

    const getCyclePrice = (plan: HostingPlan, cycle: HostingBillingCycle): number => {
      switch (cycle) {
        case 'monthly':
          return plan.pricing.monthly || (plan.pricing.annual ? plan.pricing.annual / 12 : 9.99);
        case 'quarterly':
          return plan.pricing.quarterly || (plan.pricing.monthly ? plan.pricing.monthly * 3 : 29.99);
        case 'semiAnnual':
          return plan.pricing.semiAnnual || (plan.pricing.monthly ? plan.pricing.monthly * 6 : 54.99);
        case 'annual':
          return plan.pricing.annual || (plan.pricing.monthly ? plan.pricing.monthly * 10 : 99.99);
        case 'biennial':
          return plan.pricing.biennial || (plan.pricing.annual ? plan.pricing.annual * 1.8 : 179.99);
        case 'triennial':
          return plan.pricing.triennial || (plan.pricing.annual ? plan.pricing.annual * 2.5 : 239.99);
        default:
          return plan.pricing.annual || 99.99;
      }
    };

    const currentCost = getCyclePrice(currentPlan, currentCycle);
    const targetCost = getCyclePrice(targetPlan, targetCycle);

    const safeTotalDays = totalCycleDays > 0 ? totalCycleDays : 365;
    const fractionRemaining = Math.max(0, Math.min(1, daysRemaining / safeTotalDays));

    const proratedCreditCurrentPlan = Number((currentCost * fractionRemaining).toFixed(2));
    const proratedCostTargetPlan = Number((targetCost * fractionRemaining).toFixed(2));
    const payableDifference = Number(Math.max(0, proratedCostTargetPlan - proratedCreditCurrentPlan).toFixed(2));

    return {
      currentPlan,
      targetPlan,
      currentBillingCycle: currentCycle,
      targetBillingCycle: targetCycle,
      daysRemaining,
      totalCycleDays: safeTotalDays,
      proratedCreditCurrentPlan,
      proratedCostTargetPlan,
      payableDifference,
      currency: targetPlan.pricing.currency || 'USD',
    };
  }

  // Legacy sync adapter: map hostingPlans to WhmcsHostingPackage for backward-compatibility
  public getHostingPackages(): WhmcsHostingPackage[] {
    const plans = this.getHostingPlans({ includeAll: true });
    if (plans.length > 0) {
      return plans.map((p) => {
        const cat = this.getHostingCategoryById(p.categoryId);
        return {
          id: p.id,
          name: p.name,
          category: (cat?.name || 'Shared Web Hosting') as any,
          module: (p.controlPanels[0] || 'cpanel') as any,
          description: p.shortDescription || p.fullDescription,
          diskLimitMb: p.resources.storageGb === 'unlimited' ? 0 : Number(p.resources.storageGb) * 1024,
          bandwidthLimitGb: p.resources.bandwidthGb === 'unlimited' ? 0 : Number(p.resources.bandwidthGb),
          maxDatabases: p.resources.databases === 'unlimited' ? 0 : Number(p.resources.databases),
          maxSubdomains: p.resources.subdomains === 'unlimited' ? 0 : Number(p.resources.subdomains),
          maxMailboxes: p.resources.emailAccounts === 'unlimited' ? 0 : Number(p.resources.emailAccounts),
          priceMonthly: p.pricing.monthly || (p.pricing.annual ? p.pricing.annual / 12 : 7.99),
          priceAnnually: p.pricing.annual || 79.9,
          freeDomainEligible: p.freeDomainEligible,
          features: Object.values(p.customFeatureValues || {}).length > 0 
            ? Object.values(p.customFeatureValues!) 
            : p.featureIds.map((fid) => this.getHostingFeatureById(fid)?.name || fid),
        };
      });
    }

    const list = this.state.hostingPackages || [];
    if (!list || list.length === 0) return MOCK_WHMCS_PACKAGES;
    return list.map((pkg: any) => ({
      id: pkg.id || `pkg-${Math.random().toString(36).substring(2, 7)}`,
      name: pkg.name || 'Hosting Package',
      category: pkg.category || 'Shared Web Hosting',
      module: pkg.module || pkg.controlPanelType || 'cpanel',
      description: pkg.description || 'High performance web hosting plan.',
      diskLimitMb: pkg.diskLimitMb ?? pkg.diskQuotaMb ?? 10000,
      bandwidthLimitGb: pkg.bandwidthLimitGb ?? pkg.bandwidthQuotaGb ?? 250,
      maxDatabases: pkg.maxDatabases ?? 5,
      maxSubdomains: pkg.maxSubdomains ?? 10,
      maxMailboxes: pkg.maxMailboxes ?? pkg.maxEmails ?? 10,
      priceMonthly: pkg.priceMonthly ?? 4.99,
      priceAnnually: pkg.priceAnnually ?? 49.90,
      freeDomainEligible: pkg.freeDomainEligible ?? true,
      features: pkg.features || ['Free SSL Certificate', 'cPanel Control Panel', 'Daily Backups', '1-Click WordPress Installer'],
    }));
  }

  public saveHostingPackage(pkg: any) {
    const packagesList = this.state.hostingPackages || [];
    const exists = packagesList.some((p: any) => p.id === pkg.id);
    let updated: any[];
    if (exists) {
      updated = packagesList.map((p: any) => (p.id === pkg.id ? pkg : p));
    } else {
      updated = [pkg, ...packagesList];
    }
    this.commit({
      ...this.state,
      hostingPackages: updated,
    }, exists ? 'UPDATE_PACKAGE' : 'CREATE_PACKAGE', pkg.name || 'Hosting Plan', `Saved hosting plan: ${pkg.name}`);
  }

  public deleteHostingPackage(id: string) {
    const pkg = this.state.hostingPackages.find((p) => p.id === id);
    this.commit({
      ...this.state,
      hostingPackages: this.state.hostingPackages.filter((p) => p.id !== id),
    }, 'DELETE_PACKAGE', pkg?.name || id, 'Removed hosting package from database');
  }

  public saveTld(tldItem: TLDDetail) {
    const currentTlds = this.state.tlds || TLD_CATALOG;
    const exists = currentTlds.some((t) => t.tld.toLowerCase() === tldItem.tld.toLowerCase());
    let updated: TLDDetail[];
    if (exists) {
      updated = currentTlds.map((t) => (t.tld.toLowerCase() === tldItem.tld.toLowerCase() ? tldItem : t));
    } else {
      updated = [...currentTlds, tldItem];
    }
    this.commit({
      ...this.state,
      tlds: updated,
    }, exists ? 'UPDATE_TLD' : 'CREATE_TLD', tldItem.tld, `Saved pricing for TLD ${tldItem.tld}`);
  }

  public deleteTld(tldName: string) {
    const currentTlds = this.state.tlds || TLD_CATALOG;
    this.commit({
      ...this.state,
      tlds: currentTlds.filter((t) => t.tld.toLowerCase() !== tldName.toLowerCase()),
    }, 'DELETE_TLD', tldName, 'Removed domain extension from database');
  }

  public saveControlPanelGateway(gw: ControlPanelGateway) {
    const exists = this.state.controlPanelGateways.some((g) => g.id === gw.id);
    let updated: ControlPanelGateway[];
    if (exists) {
      updated = this.state.controlPanelGateways.map((g) => (g.id === gw.id ? gw : g));
    } else {
      updated = [...this.state.controlPanelGateways, gw];
    }
    this.commit({
      ...this.state,
      controlPanelGateways: updated,
    }, exists ? 'UPDATE_GATEWAY' : 'CONNECT_GATEWAY', gw.name, `Control Panel API Gateway ${gw.type.toUpperCase()}`);
  }

  public deleteControlPanelGateway(id: string) {
    const gw = this.state.controlPanelGateways.find((g) => g.id === id);
    this.commit({
      ...this.state,
      controlPanelGateways: this.state.controlPanelGateways.filter((g) => g.id !== id),
    }, 'DISCONNECT_GATEWAY', gw?.name || id, 'Disconnected Control Panel API');
  }

  public saveServerNode(node: ServerClusterNode) {
    const exists = this.state.serverClusterNodes.some((n) => n.id === node.id);
    let updated: ServerClusterNode[];
    if (exists) {
      updated = this.state.serverClusterNodes.map((n) => (n.id === node.id ? node : n));
    } else {
      updated = [...this.state.serverClusterNodes, node];
    }
    this.commit({
      ...this.state,
      serverClusterNodes: updated,
    }, exists ? 'UPDATE_NODE' : 'REGISTER_NODE', node.name, `Server node registered IP ${node.ip}`);
  }

  public saveProvisionedAccount(account: ProvisionTask) {
    const exists = this.state.provisionedAccounts.some((a) => a.id === account.id);
    let updated: ProvisionTask[];
    if (exists) {
      updated = this.state.provisionedAccounts.map((a) => (a.id === account.id ? account : a));
    } else {
      updated = [account, ...this.state.provisionedAccounts];
    }
    this.commit({
      ...this.state,
      provisionedAccounts: updated,
    }, exists ? 'UPDATE_HOSTING_ACCOUNT' : 'PROVISION_ACCOUNT', account.domain, `User: ${account.username}`);
  }

  public deleteProvisionedAccount(id: string) {
    const acc = this.state.provisionedAccounts.find((a) => a.id === id);
    this.commit({
      ...this.state,
      provisionedAccounts: this.state.provisionedAccounts.filter((a) => a.id !== id),
    }, 'TERMINATE_ACCOUNT', acc?.domain || id, 'Hosting account terminated');
  }

  // --- PAYMENT SETTINGS & GATEWAY CONFIGURATION ---
  public getPaymentSettings(): PaymentMethodSettings {
    return this.state.paymentSettings || DEFAULT_PAYMENT_SETTINGS;
  }

  public savePaymentSettings(newSettings: PaymentMethodSettings) {
    this.commit(
      {
        ...this.state,
        paymentSettings: newSettings,
      },
      'UPDATE_PAYMENT_SETTINGS',
      'PaymentGateway',
      `Paystack: ${newSettings.paystack.enabled ? 'ENABLED' : 'DISABLED'} (${newSettings.paystack.environment?.toUpperCase() || 'TEST'})`
    );

    // Also push to backend server securely
    if (typeof fetch !== 'undefined') {
      fetch('/api/payments/paystack/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: newSettings.paystack.enabled,
          environment: newSettings.paystack.environment || (newSettings.paystack.testMode ? 'test' : 'live'),
          publicKey: newSettings.paystack.publicKey,
          secretKey: newSettings.paystack.secretKey, // only populated if user entered a new replacement key
          merchantName: newSettings.paystack.merchantName,
          currencyPreference: newSettings.paystack.currencyPreference,
          allowedChannels: newSettings.paystack.allowedChannels,
          callbackUrl: newSettings.paystack.callbackUrl,
          webhookUrl: newSettings.paystack.webhookUrl,
          updatedBy: this.state.currentUser?.fullName || 'Administrator',
        }),
      }).catch((err) => {
        console.warn('[SystemDatabase] Failed to sync payment settings to backend:', err);
      });
    }
  }

  public async syncPaymentSettingsWithServer(): Promise<PaymentMethodSettings> {
    if (typeof fetch === 'undefined') return this.getPaymentSettings();
    try {
      const res = await fetch('/api/payments/paystack/config');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.config) {
          const s = data.config;
          const merged: PaymentMethodSettings = {
            ...this.getPaymentSettings(),
            paystack: {
              enabled: s.enabled,
              testMode: s.environment === 'test',
              environment: s.environment,
              publicKey: s.publicKey || this.getPaymentSettings().paystack.publicKey,
              isSecretKeyConfigured: s.isSecretKeyConfigured,
              maskedSecretKey: s.maskedSecretKey,
              merchantName: s.merchantName,
              currencyPreference: s.currencyPreference as any,
              allowedChannels: s.allowedChannels,
              callbackUrl: s.callbackUrl,
              webhookUrl: s.webhookUrl,
              lastUpdated: s.lastUpdated,
              healthStatus: s.healthStatus,
            },
          };
          this.state = {
            ...this.state,
            paymentSettings: merged,
          };
          this.saveToStorage(this.state);
          this.notifyListeners();
          return merged;
        }
      }
    } catch (err) {
      console.warn('[SystemDatabase] Server payment sync skipped (offline/local mode)');
    }
    return this.getPaymentSettings();
  }

  public getPaymentSubmissions(): PaymentSubmission[] {
    return this.state.paymentSubmissions || INITIAL_PAYMENT_SUBMISSIONS;
  }

  public addPaymentSubmission(sub: PaymentSubmission) {
    this.commit(
      {
        ...this.state,
        paymentSubmissions: [sub, ...(this.state.paymentSubmissions || [])],
      },
      'PAYMENT_SUBMISSION',
      sub.orderId,
      `Payment of ${sub.currency} ${sub.amount} via ${sub.paymentMethod}`
    );
  }

  public updatePaymentSubmission(id: string, updates: Partial<PaymentSubmission>) {
    const existing = this.state.paymentSubmissions || [];
    const updated = existing.map((s) => (s.id === id ? { ...s, ...updates } : s));
    this.commit(
      {
        ...this.state,
        paymentSubmissions: updated,
      },
      'UPDATE_PAYMENT_SUBMISSION',
      id,
      `Status updated to ${updates.status || 'modified'}`
    );
  }

  // --- DATABASE EXPORT / IMPORT / RESET ---
  public exportJsonDump(): string {
    return JSON.stringify(this.state, null, 2);
  }

  public importJsonDump(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString) as SystemDatabaseState;
      if (!parsed.settings || !parsed.settings.general || !parsed.version) {
        throw new Error('Invalid database dump schema structure.');
      }
      this.commit(parsed, 'RESTORE_DATABASE', 'SystemDatabase', 'Imported database dump from JSON file');
      return true;
    } catch (err) {
      console.error('[SystemDatabase] Failed to import DB dump:', err);
      return false;
    }
  }

  public resetToFactoryDefaults() {
    this.commit(INITIAL_DB_STATE, 'RESET_DATABASE', 'SystemDatabase', 'Factory default state restored');
  }

  // --- SQL QUERY EXECUTION UTILITY ---
  public executeQuery(query: string): { success: boolean; data?: any[]; message: string; rowsAffected?: number } {
    const q = query.trim();
    const lower = q.toLowerCase();

    try {
      if (lower.startsWith('select')) {
        if (lower.includes('from system_settings') || lower.includes('from settings')) {
          return { success: true, data: [this.state.settings.general], message: 'Selected 1 record from system_settings' };
        }
        if (lower.includes('from hosting_packages') || lower.includes('from packages')) {
          return { success: true, data: this.state.hostingPackages, message: `Selected ${this.state.hostingPackages.length} records from hosting_packages` };
        }
        if (lower.includes('from control_panel_gateways') || lower.includes('from gateways')) {
          return { success: true, data: this.state.controlPanelGateways, message: `Selected ${this.state.controlPanelGateways.length} records from control_panel_gateways` };
        }
        if (lower.includes('from server_cluster_nodes') || lower.includes('from nodes')) {
          return { success: true, data: this.state.serverClusterNodes, message: `Selected ${this.state.serverClusterNodes.length} records from server_cluster_nodes` };
        }
        if (lower.includes('from provisioned_accounts') || lower.includes('from accounts')) {
          return { success: true, data: this.state.provisionedAccounts, message: `Selected ${this.state.provisionedAccounts.length} records from provisioned_accounts` };
        }
        if (lower.includes('from users') || lower.includes('from user')) {
          return { success: true, data: this.state.users, message: `Selected ${this.state.users.length} records from users` };
        }
        if (lower.includes('from persistent_cart') || lower.includes('from cart')) {
          return { success: true, data: this.state.persistentCart, message: `Selected ${this.state.persistentCart.length} records from persistent_cart` };
        }
        if (lower.includes('from audit_logs') || lower.includes('from logs')) {
          return { success: true, data: this.state.auditLogs, message: `Selected ${this.state.auditLogs.length} records from audit_logs` };
        }
        return { success: true, data: [{ database: 'CELOXA_SYSTEM_DB', tables: ['system_settings', 'users', 'persistent_cart', 'hosting_packages', 'control_panel_gateways', 'server_cluster_nodes', 'provisioned_accounts', 'audit_logs'] }], message: 'Tables listing query executed' };
      }

      if (lower.startsWith('show tables')) {
        return {
          success: true,
          data: [
            { table_name: 'system_settings', records: 1 },
            { table_name: 'users', records: this.state.users.length },
            { table_name: 'persistent_cart', records: this.state.persistentCart.length },
            { table_name: 'hosting_packages', records: this.state.hostingPackages.length },
            { table_name: 'control_panel_gateways', records: this.state.controlPanelGateways.length },
            { table_name: 'server_cluster_nodes', records: this.state.serverClusterNodes.length },
            { table_name: 'provisioned_accounts', records: this.state.provisionedAccounts.length },
            { table_name: 'audit_logs', records: this.state.auditLogs.length },
          ],
          message: 'Retrieved 8 database tables'
        };
      }

      if (lower.startsWith('update system_settings')) {
        // e.g. UPDATE system_settings SET site_title = 'My Title'
        const match = q.match(/site_name\s*=\s*['"]([^'"]+)['"]/i) || q.match(/site_title\s*=\s*['"]([^'"]+)['"]/i);
        if (match && match[1]) {
          const newName = match[1];
          const newSettings = {
            ...this.state.settings,
            general: {
              ...this.state.settings.general,
              siteName: newName,
            },
          };
          this.updateSettings(newSettings);
          return { success: true, message: `UPDATE 1 row in system_settings. siteName set to "${newName}"`, rowsAffected: 1 };
        }
      }

      return { success: true, message: `Query executed successfully. Database state verified.`, data: [] };
    } catch (err: any) {
      return { success: false, message: `SQL Syntax or Execution Error: ${err?.message || 'Failed'}` };
    }
  }

  // --- COMPATIBILITY & HELPER METHODS ---
  public getAllUsers(): SystemUser[] {
    return this.getUsers();
  }

  public createCustomerUser(userData: Partial<SystemUser>): SystemUser {
    const newUser: SystemUser = {
      id: `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      fullName: userData.fullName || 'New Customer',
      email: userData.email || 'customer@celoxaghana.online',
      phone: userData.phone || '+233 24 000 0000',
      role: 'customer',
      platformRole: 'client',
      accountStatus: 'active',
      isEmailVerified: true,
      walletBalanceGhs: 0,
      walletBalanceUsd: 0,
      twoFactorEnabled: false,
      permissions: DEFAULT_CLIENT_PERMISSIONS,
      createdAt: new Date().toISOString(),
      ...userData,
    };

    const currentUsers = this.getUsers();
    this.commit(
      {
        ...this.state,
        users: [newUser, ...currentUsers],
      },
      'CREATE_CUSTOMER_USER',
      newUser.id,
      `Created customer user account for ${newUser.fullName} (${newUser.email})`
    );

    return newUser;
  }

  public logAuditEvent(
    action: string,
    target: string,
    details: string,
    actor: string = 'System Admin',
    ipAddress: string = '127.0.0.1',
    status: 'success' | 'warning' | 'error' | 'info' = 'success'
  ) {
    const newEntry: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toLocaleString(),
      actor,
      action,
      target,
      details,
      ipAddress,
      status,
    };

    const existingLogs = this.getAuditLogs();
    this.commit(
      {
        ...this.state,
        auditLogs: [newEntry, ...existingLogs].slice(0, 500),
      },
      action,
      target,
      details
    );
  }

  public registerNewDomain(domainData: any): any {
    this.logAuditEvent(
      'DOMAIN_REGISTERED',
      domainData.domain || 'Domain',
      `Registered domain with registrar ${domainData.registrar || 'internal'}`
    );
    return { success: true, domain: domainData.domain, status: 'active', registeredAt: new Date().toISOString() };
  }

  public provisionHostingAccountDirectly(hostingData: any): any {
    this.logAuditEvent(
      'HOSTING_PROVISIONED',
      hostingData.domain || 'Hosting',
      `Provisioned package ${hostingData.packageName} on server ${hostingData.serverId || 'default'}`
    );
    return { success: true, domain: hostingData.domain, status: 'active', provisionedAt: new Date().toISOString() };
  }
}

export const systemDatabase = new SystemDatabaseEngine();
