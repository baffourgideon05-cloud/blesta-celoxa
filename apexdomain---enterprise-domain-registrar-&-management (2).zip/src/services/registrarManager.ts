import { RegistrarConfig, RegistrarApiLog, RegistrarProviderType, NameserverConfig } from '../types';
import { systemDatabase } from './systemDatabase';

const STORAGE_REGISTRARS_KEY = 'CELOXA_REGISTRARS_CONFIG_V1';
const STORAGE_REGISTRAR_LOGS_KEY = 'CELOXA_REGISTRAR_LOGS_V1';

export const DEFAULT_REGISTRARS: RegistrarConfig[] = [
  {
    id: 'reg-internal',
    name: 'Celoxa Ghana Internal Registry (Authoritative)',
    provider: 'internal',
    isDefault: true,
    isEnabled: true,
    testMode: false,
    defaultNameservers: [
      'ns1.celoxaghana.online',
      'ns2.celoxaghana.online',
      'ns3.celoxaghana.online',
      'ns4.celoxaghana.online',
    ],
    autoRenewSupport: true,
    dnsManagementSupport: true,
    privacyProtectionSupport: true,
    lastSyncTime: new Date().toISOString(),
    status: 'connected',
    statusMessage: 'Authoritative Internal Registry Engine Online (0ms Latency)',
    accountBalance: { amount: 100000, currency: 'USD' },
  },
  {
    id: 'reg-resellerclub',
    name: 'ResellerClub HTTP API',
    provider: 'resellerclub',
    isDefault: false,
    isEnabled: true,
    testMode: true,
    resellerId: '849201',
    apiKey: 'rc_live_key_99381a82fbc',
    endpointUrl: 'https://httpapi.com/api/domains/',
    defaultNameservers: [
      'ns1.resellerclub.com',
      'ns2.resellerclub.com',
      'ns3.resellerclub.com',
      'ns4.resellerclub.com',
    ],
    autoRenewSupport: true,
    dnsManagementSupport: true,
    privacyProtectionSupport: true,
    lastSyncTime: new Date(Date.now() - 3600000 * 4).toISOString(),
    status: 'connected',
    statusMessage: 'Sandbox OTE API Active (Reseller ID: 849201)',
    accountBalance: { amount: 4850.25, currency: 'USD' },
  },
  {
    id: 'reg-godaddy',
    name: 'GoDaddy Domains REST API',
    provider: 'godaddy',
    isDefault: false,
    isEnabled: true,
    testMode: true,
    apiKey: 'gd_key_a8319f201',
    apiSecret: 'gd_sec_991823ab1',
    endpointUrl: 'https://api.ote-godaddy.com/v1/domains',
    defaultNameservers: [
      'ns1.domaincontrol.com',
      'ns2.domaincontrol.com',
      'ns3.domaincontrol.com',
      'ns4.domaincontrol.com',
    ],
    autoRenewSupport: true,
    dnsManagementSupport: true,
    privacyProtectionSupport: true,
    lastSyncTime: new Date(Date.now() - 3600000 * 8).toISOString(),
    status: 'connected',
    statusMessage: 'GoDaddy OTE Sandbox API Key Validated',
    accountBalance: { amount: 2420.00, currency: 'USD' },
  },
  {
    id: 'reg-enom',
    name: 'eNom Command Interface',
    provider: 'enom',
    isDefault: false,
    isEnabled: true,
    testMode: true,
    username: 'celoxagh_reseller',
    password: '••••••••••••',
    endpointUrl: 'https://resellertest.enom.com/interface.asp',
    defaultNameservers: [
      'dns1.name-services.com',
      'dns2.name-services.com',
      'dns3.name-services.com',
      'dns4.name-services.com',
    ],
    autoRenewSupport: true,
    dnsManagementSupport: true,
    privacyProtectionSupport: true,
    lastSyncTime: new Date(Date.now() - 3600000 * 12).toISOString(),
    status: 'connected',
    statusMessage: 'eNom Reseller Test Environment Ready',
    accountBalance: { amount: 1540.80, currency: 'USD' },
  },
  {
    id: 'reg-namecheap',
    name: 'Namecheap API Integration',
    provider: 'namecheap',
    isDefault: false,
    isEnabled: false,
    testMode: true,
    username: 'celoxa_api',
    apiKey: 'nc_api_8381920',
    endpointUrl: 'https://api.sandbox.namecheap.com/xml.response',
    defaultNameservers: [
      'dns1.registrar-servers.com',
      'dns2.registrar-servers.com',
      'dns3.registrar-servers.com',
      'dns4.registrar-servers.com',
    ],
    autoRenewSupport: true,
    dnsManagementSupport: true,
    privacyProtectionSupport: true,
    status: 'untested',
    statusMessage: 'Credentials saved. Test connection required.',
    accountBalance: { amount: 0, currency: 'USD' },
  },
];

class RegistrarManager {
  private registrars: RegistrarConfig[] = [];
  private logs: RegistrarApiLog[] = [];
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      const rawRegs = localStorage.getItem(STORAGE_REGISTRARS_KEY);
      if (rawRegs) {
        this.registrars = JSON.parse(rawRegs);
      } else {
        this.registrars = DEFAULT_REGISTRARS;
        this.saveRegistrars();
      }

      const rawLogs = localStorage.getItem(STORAGE_REGISTRAR_LOGS_KEY);
      if (rawLogs) {
        this.logs = JSON.parse(rawLogs);
      } else {
        this.logs = this.getInitialLogs();
        this.saveLogs();
      }
    } catch (e) {
      console.error('[RegistrarManager] Storage load error:', e);
      this.registrars = DEFAULT_REGISTRARS;
      this.logs = this.getInitialLogs();
    }
  }

  private saveRegistrars() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_REGISTRARS_KEY, JSON.stringify(this.registrars));
    } catch (e) {
      console.error('[RegistrarManager] Failed to save registrars:', e);
    }
  }

  private saveLogs() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_REGISTRAR_LOGS_KEY, JSON.stringify(this.logs.slice(0, 200)));
    } catch (e) {
      console.error('[RegistrarManager] Failed to save logs:', e);
    }
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  public subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private getInitialLogs(): RegistrarApiLog[] {
    return [
      {
        id: 'rlog-1',
        registrarId: 'reg-internal',
        registrarName: 'Celoxa Ghana Internal Registry',
        provider: 'internal',
        action: 'check_availability',
        domain: 'celoxaghana.online',
        status: 'success',
        requestPayload: JSON.stringify({ domain: 'celoxaghana.online' }),
        responsePayload: JSON.stringify({ available: false, status: 'active', registrant: 'Celoxa Cloud' }),
        executionTimeMs: 12,
        timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
      },
      {
        id: 'rlog-2',
        registrarId: 'reg-resellerclub',
        registrarName: 'ResellerClub HTTP API',
        provider: 'resellerclub',
        action: 'test_connection',
        status: 'success',
        requestPayload: JSON.stringify({ command: 'ping', resellerId: '849201' }),
        responsePayload: JSON.stringify({ status: 'Success', balance: 4850.25, currency: 'USD' }),
        executionTimeMs: 184,
        timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
      },
      {
        id: 'rlog-3',
        registrarId: 'reg-godaddy',
        registrarName: 'GoDaddy Domains REST API',
        provider: 'godaddy',
        action: 'update_nameservers',
        domain: 'enterpriseghana.com',
        status: 'success',
        requestPayload: JSON.stringify({ domain: 'enterpriseghana.com', nameServers: ['ns1.celoxaghana.online', 'ns2.celoxaghana.online'] }),
        responsePayload: JSON.stringify({ code: 'OK', status: 'UPDATED' }),
        executionTimeMs: 240,
        timestamp: new Date(Date.now() - 3600000 * 18).toISOString(),
      },
    ];
  }

  public getRegistrars(): RegistrarConfig[] {
    return [...this.registrars];
  }

  public getRegistrarById(id: string): RegistrarConfig | undefined {
    return this.registrars.find((r) => r.id === id);
  }

  public getRegistrarByProvider(provider: RegistrarProviderType): RegistrarConfig | undefined {
    return this.registrars.find((r) => r.provider === provider) || this.getDefaultRegistrar();
  }

  public getDefaultRegistrar(): RegistrarConfig {
    return this.registrars.find((r) => r.isDefault) || this.registrars[0] || DEFAULT_REGISTRARS[0];
  }

  public saveRegistrar(config: RegistrarConfig) {
    const exists = this.registrars.some((r) => r.id === config.id);
    let updated: RegistrarConfig[];

    if (config.isDefault) {
      // Unset other defaults
      this.registrars = this.registrars.map((r) => ({ ...r, isDefault: r.id === config.id }));
    }

    if (exists) {
      updated = this.registrars.map((r) => (r.id === config.id ? config : r));
    } else {
      updated = [...this.registrars, config];
    }

    this.registrars = updated;
    this.saveRegistrars();
    this.notify();

    systemDatabase.logAuditEvent(
      'UPDATE_REGISTRAR',
      config.name,
      `Configured registrar ${config.name} (${config.provider})`
    );
  }

  public setDefaultRegistrar(id: string) {
    this.registrars = this.registrars.map((r) => ({
      ...r,
      isDefault: r.id === id,
    }));
    this.saveRegistrars();
    this.notify();
  }

  public async testConnection(id: string): Promise<{ success: boolean; message: string; latencyMs: number; balance?: string }> {
    const reg = this.getRegistrarById(id);
    if (!reg) return { success: false, message: 'Registrar not found', latencyMs: 0 };

    const startTime = performance.now();
    await new Promise((resolve) => setTimeout(resolve, Math.floor(Math.random() * 200) + 150));
    const latencyMs = Math.round(performance.now() - startTime);

    let success = true;
    let message = `Successfully connected to ${reg.name} (${reg.testMode ? 'Sandbox' : 'Production'}). API handshake validated.`;
    let balanceStr = reg.accountBalance ? `$${reg.accountBalance.amount.toFixed(2)} ${reg.accountBalance.currency}` : '$2,500.00 USD';

    if (reg.provider === 'namecheap' && !reg.apiKey) {
      success = false;
      message = 'Authentication failed: Namecheap API Key is missing or invalid IP address.';
    }

    // Update status
    this.registrars = this.registrars.map((r) =>
      r.id === id
        ? {
            ...r,
            status: success ? 'connected' : 'error',
            statusMessage: message,
            lastSyncTime: new Date().toISOString(),
          }
        : r
    );
    this.saveRegistrars();

    // Log the API call
    this.addLog({
      registrarId: reg.id,
      registrarName: reg.name,
      provider: reg.provider,
      action: 'test_connection',
      status: success ? 'success' : 'failed',
      requestPayload: JSON.stringify({ testMode: reg.testMode, endpoint: reg.endpointUrl }),
      responsePayload: JSON.stringify({ message, latencyMs, balance: balanceStr }),
      errorMessage: success ? undefined : message,
      executionTimeMs: latencyMs,
    });

    this.notify();
    return { success, message, latencyMs, balance: balanceStr };
  }

  public async registerDomain(params: {
    domain: string;
    years: number;
    customerName: string;
    customerEmail: string;
    nameservers: string[];
    provider?: RegistrarProviderType;
  }): Promise<{ success: boolean; authCode: string; registrar: string; expiryDate: string; errorMessage?: string }> {
    const reg = params.provider ? this.getRegistrarByProvider(params.provider) : this.getDefaultRegistrar();
    const startTime = performance.now();

    // Simulate real external registrar network registration
    await new Promise((resolve) => setTimeout(resolve, 350));
    const latencyMs = Math.round(performance.now() - startTime);

    const now = new Date();
    const expiry = new Date(now.getFullYear() + (params.years || 1), now.getMonth(), now.getDate()).toISOString();
    const authCode = `EPP-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const success = true;

    this.addLog({
      registrarId: reg.id,
      registrarName: reg.name,
      provider: reg.provider,
      action: 'register',
      domain: params.domain,
      status: 'success',
      requestPayload: JSON.stringify({
        domain: params.domain,
        years: params.years,
        registrant: { name: params.customerName, email: params.customerEmail },
        nameservers: params.nameservers,
      }),
      responsePayload: JSON.stringify({
        status: 'ACTIVE',
        domain: params.domain,
        registeredDate: now.toISOString(),
        expiryDate: expiry,
        authCode,
        registrarOrderRef: `REG-${Date.now()}`,
      }),
      executionTimeMs: latencyMs,
    });

    return {
      success,
      authCode,
      registrar: reg.name,
      expiryDate: expiry,
    };
  }

  public async updateNameservers(
    domain: string,
    nameservers: string[],
    provider?: RegistrarProviderType
  ): Promise<{ success: boolean; message: string; errorMessage?: string }> {
    const reg = provider ? this.getRegistrarByProvider(provider) : this.getDefaultRegistrar();
    const startTime = performance.now();

    await new Promise((resolve) => setTimeout(resolve, 200));
    const latencyMs = Math.round(performance.now() - startTime);

    const success = true;
    const message = `Nameservers updated to [${nameservers.filter(Boolean).join(', ')}] on ${reg.name}`;

    this.addLog({
      registrarId: reg.id,
      registrarName: reg.name,
      provider: reg.provider,
      action: 'update_nameservers',
      domain,
      status: 'success',
      requestPayload: JSON.stringify({ domain, nameservers }),
      responsePayload: JSON.stringify({ status: 'SUCCESS', message }),
      executionTimeMs: latencyMs,
    });

    return { success, message };
  }

  public getLogs(): RegistrarApiLog[] {
    return [...this.logs];
  }

  public addLog(log: Omit<RegistrarApiLog, 'id' | 'timestamp'>) {
    const entry: RegistrarApiLog = {
      ...log,
      id: `rlog-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
    };
    this.logs = [entry, ...this.logs.slice(0, 199)];
    this.saveLogs();
    this.notify();
  }

  public clearLogs() {
    this.logs = [];
    this.saveLogs();
    this.notify();
  }
}

export const registrarManager = new RegistrarManager();
