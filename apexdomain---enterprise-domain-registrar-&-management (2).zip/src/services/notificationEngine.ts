import { systemDatabase } from './systemDatabase';

export type NotificationCategory = 'account' | 'order' | 'payment' | 'domain' | 'hosting' | 'support' | 'security';
export type NotificationPriority = 'low' | 'normal' | 'high' | 'urgent';

export interface InAppNotification {
  id: string;
  userId: string;
  category: NotificationCategory;
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  actionUrl?: string;
  actionLabel?: string;
  metadata?: Record<string, any>;
}

export interface QueuedEmailLog {
  id: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  template: string;
  category: NotificationCategory;
  status: 'sent' | 'queued' | 'failed';
  errorMessage?: string;
  sentAt?: string;
  createdAt: string;
  retryCount: number;
  metadata?: Record<string, any>;
}

const STORAGE_NOTIFS_KEY = 'CELOXA_IN_APP_NOTIFICATIONS_V1';
const STORAGE_EMAIL_LOGS_KEY = 'CELOXA_EMAIL_LOGS_V1';

class NotificationEngine {
  private inAppNotifications: InAppNotification[] = [];
  private emailLogs: QueuedEmailLog[] = [];
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      const rawNotifs = localStorage.getItem(STORAGE_NOTIFS_KEY);
      if (rawNotifs) {
        this.inAppNotifications = JSON.parse(rawNotifs);
      } else {
        this.inAppNotifications = this.getInitialNotifications();
        this.saveNotifsToStorage();
      }

      const rawEmails = localStorage.getItem(STORAGE_EMAIL_LOGS_KEY);
      if (rawEmails) {
        this.emailLogs = JSON.parse(rawEmails);
      } else {
        this.emailLogs = this.getInitialEmailLogs();
        this.saveEmailLogsToStorage();
      }
    } catch (e) {
      console.error('[NotificationEngine] Storage load error:', e);
    }
  }

  private saveNotifsToStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_NOTIFS_KEY, JSON.stringify(this.inAppNotifications.slice(0, 200)));
    } catch (e) {
      console.error('[NotificationEngine] Failed to save in-app notifications:', e);
    }
  }

  private saveEmailLogsToStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_EMAIL_LOGS_KEY, JSON.stringify(this.emailLogs.slice(0, 300)));
    } catch (e) {
      console.error('[NotificationEngine] Failed to save email logs:', e);
    }
  }

  private notify() {
    this.listeners.forEach(fn => fn());
  }

  public subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private getInitialNotifications(): InAppNotification[] {
    return [
      {
        id: 'notif-1',
        userId: 'user-admin-101',
        category: 'security',
        title: 'Paystack Gateway Active',
        message: 'Paystack Payment Gateway configured in Live Test Mode with Mobile Money and Cards.',
        timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        isRead: false,
        actionUrl: 'settings',
        actionLabel: 'View Settings'
      },
      {
        id: 'notif-2',
        userId: 'user-admin-google-001',
        category: 'account',
        title: 'Super Admin Access Confirmed',
        message: 'Google Identity baffourgideon05@gmail.com verified as Chief Super Administrator.',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
        isRead: true,
      },
      {
        id: 'notif-3',
        userId: 'user-cust-102',
        category: 'domain',
        title: 'Domain Registration Successful',
        message: 'Your domain enterpriseghana.com is active with DNSSEC and Whois privacy.',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        isRead: false,
        actionUrl: 'management',
        actionLabel: 'Manage DNS'
      }
    ];
  }

  private getInitialEmailLogs(): QueuedEmailLog[] {
    return [
      {
        id: 'eml-1001',
        recipientEmail: 'baffourgideon05@gmail.com',
        recipientName: 'Gideon Baffour',
        subject: 'Welcome to Celoxa Ghana Cloud Systems - Admin Authorization',
        template: 'ACCOUNT_WELCOME_ADMIN',
        category: 'account',
        status: 'sent',
        sentAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
        retryCount: 0,
      },
      {
        id: 'eml-1002',
        recipientEmail: 'kwame@enterpriseghana.com',
        recipientName: 'Kwame Mensah',
        subject: 'Official Payment Receipt - Invoice #INV-100239',
        template: 'PAYMENT_RECEIPT',
        category: 'payment',
        status: 'sent',
        sentAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        retryCount: 0,
        metadata: { invoiceNumber: 'INV-100239', amount: 'GH₵ 420.00', paystackRef: 'PSTK-ORD-100239' }
      },
      {
        id: 'eml-1003',
        recipientEmail: 'kwame@enterpriseghana.com',
        recipientName: 'Kwame Mensah',
        subject: 'Hosting Service Provisioned: enterpriseghana.com',
        template: 'HOSTING_PROVISIONED',
        category: 'hosting',
        status: 'sent',
        sentAt: new Date(Date.now() - 1000 * 60 * 60 * 24 + 60000).toISOString(),
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        retryCount: 0,
        metadata: { server: 'US-EAST-GH1', cpanelUser: 'enterpris' }
      }
    ];
  }

  // --- Dispatch Event Handler (Dual: In-App + Email Log) ---
  public dispatchEvent(event: {
    userId: string;
    recipientEmail: string;
    recipientName: string;
    category: NotificationCategory;
    title: string;
    message: string;
    template: string;
    emailSubject: string;
    actionUrl?: string;
    actionLabel?: string;
    metadata?: Record<string, any>;
  }) {
    // 1. In-App Notification
    const notif: InAppNotification = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId: event.userId,
      category: event.category,
      title: event.title,
      message: event.message,
      timestamp: new Date().toISOString(),
      isRead: false,
      actionUrl: event.actionUrl,
      actionLabel: event.actionLabel,
      metadata: event.metadata,
    };
    this.inAppNotifications.unshift(notif);
    this.saveNotifsToStorage();

    // 2. Queued / Dispatched Email Log
    const emailLog: QueuedEmailLog = {
      id: `eml-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      recipientEmail: event.recipientEmail,
      recipientName: event.recipientName,
      subject: event.emailSubject,
      template: event.template,
      category: event.category,
      status: 'sent',
      sentAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      retryCount: 0,
      metadata: event.metadata,
    };
    this.emailLogs.unshift(emailLog);
    this.saveEmailLogsToStorage();

    this.notify();
  }

  // --- Get Notifications for Current User ---
  public getUserNotifications(userId?: string): InAppNotification[] {
    const user = userId ? { id: userId } : systemDatabase.getCurrentUser();
    if (!user) return [];
    
    return this.inAppNotifications.filter(n => 
      n.userId === user.id || n.userId === 'all' || (user.id.includes('admin') && n.userId.includes('admin'))
    );
  }

  public getUnreadCount(userId?: string): number {
    return this.getUserNotifications(userId).filter(n => !n.isRead).length;
  }

  public markAsRead(notificationId: string) {
    this.inAppNotifications = this.inAppNotifications.map(n => 
      n.id === notificationId ? { ...n, isRead: true } : n
    );
    this.saveNotifsToStorage();
    this.notify();
  }

  public markAllAsRead(userId?: string) {
    const user = userId ? { id: userId } : systemDatabase.getCurrentUser();
    if (!user) return;
    
    this.inAppNotifications = this.inAppNotifications.map(n => 
      (n.userId === user.id || n.userId === 'all' || (user.id.includes('admin') && n.userId.includes('admin')))
        ? { ...n, isRead: true }
        : n
    );
    this.saveNotifsToStorage();
    this.notify();
  }

  public clearAll(userId?: string) {
    const user = userId ? { id: userId } : systemDatabase.getCurrentUser();
    if (!user) return;
    
    this.inAppNotifications = this.inAppNotifications.filter(n => 
      n.userId !== user.id && !((user.id.includes('admin') && n.userId.includes('admin')))
    );
    this.saveNotifsToStorage();
    this.notify();
  }

  // --- Email Logs Management for Admin ---
  public getEmailLogs(): QueuedEmailLog[] {
    return this.emailLogs;
  }

  public retryEmail(logId: string): boolean {
    const log = this.emailLogs.find(l => l.id === logId);
    if (!log) return false;

    log.status = 'sent';
    log.sentAt = new Date().toISOString();
    log.retryCount += 1;
    log.errorMessage = undefined;

    this.saveEmailLogsToStorage();
    this.notify();
    return true;
  }

  public clearEmailLogs() {
    this.emailLogs = [];
    this.saveEmailLogsToStorage();
    this.notify();
  }
}

export const notificationEngine = new NotificationEngine();
