import { CartItem } from '../types';
import { systemDatabase, SystemUser } from './systemDatabase';

const GUEST_SESSION_ID_KEY = 'CELOXA_GUEST_SESSION_ID';
const STORAGE_PREFIX = 'CELOXA_SCOPED_CART_';

class CartScopeManager {
  private guestSessionId: string = '';
  private activeCart: CartItem[] = [];
  private listeners: Set<() => void> = new Set();
  private currentScopeKey: string = '';

  constructor() {
    this.initGuestSession();
    this.refreshActiveScope();
    
    // Listen for database user switches
    systemDatabase.subscribe(() => {
      this.refreshActiveScope();
    });
  }

  private initGuestSession() {
    if (typeof localStorage === 'undefined') return;
    try {
      let id = localStorage.getItem(GUEST_SESSION_ID_KEY);
      if (!id) {
        id = `guest_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
        localStorage.setItem(GUEST_SESSION_ID_KEY, id);
      }
      this.guestSessionId = id;
    } catch (e) {
      this.guestSessionId = `guest_fallback_${Date.now()}`;
    }
  }

  public getScopeKey(user?: SystemUser | null, adminForCustomerId?: string): string {
    if (adminForCustomerId) {
      const adminId = user?.id || 'admin';
      return `${STORAGE_PREFIX}ADMIN_${adminId}_FOR_${adminForCustomerId}`;
    }
    if (user && user.id) {
      return `${STORAGE_PREFIX}USER_${user.id}`;
    }
    return `${STORAGE_PREFIX}${this.guestSessionId}`;
  }

  public refreshActiveScope() {
    const user = systemDatabase.getCurrentUser();
    const newScopeKey = this.getScopeKey(user);

    if (this.currentScopeKey !== newScopeKey) {
      this.currentScopeKey = newScopeKey;
      this.loadCartForScope(newScopeKey);
    }
  }

  private loadCartForScope(scopeKey: string) {
    if (typeof localStorage === 'undefined') return;
    try {
      const raw = localStorage.getItem(scopeKey);
      if (raw) {
        this.activeCart = JSON.parse(raw);
      } else {
        this.activeCart = [];
      }
      this.notify();
    } catch (e) {
      console.error('[CartScopeManager] Failed to load cart for scope:', scopeKey, e);
      this.activeCart = [];
    }
  }

  private saveCartForScope(scopeKey: string, items: CartItem[]) {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(scopeKey, JSON.stringify(items));
    } catch (e) {
      console.error('[CartScopeManager] Failed to save cart:', e);
    }
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  public subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  public getCart(customUser?: SystemUser | null, adminForCustomerId?: string): CartItem[] {
    const scope = this.getScopeKey(customUser !== undefined ? customUser : systemDatabase.getCurrentUser(), adminForCustomerId);
    if (typeof localStorage !== 'undefined') {
      try {
        const raw = localStorage.getItem(scope);
        if (raw) return JSON.parse(raw);
      } catch (e) {}
    }
    return scope === this.currentScopeKey ? [...this.activeCart] : [];
  }

  public setCart(items: CartItem[], customUser?: SystemUser | null, adminForCustomerId?: string) {
    const scope = this.getScopeKey(customUser !== undefined ? customUser : systemDatabase.getCurrentUser(), adminForCustomerId);
    this.saveCartForScope(scope, items);
    if (scope === this.currentScopeKey) {
      this.activeCart = items;
      this.notify();
    }
  }

  public addItem(item: CartItem, customUser?: SystemUser | null, adminForCustomerId?: string) {
    const current = this.getCart(customUser, adminForCustomerId);
    // Prevent exact duplicate domains/plans
    const exists = current.some((i) => i.domain === item.domain && i.itemType === item.itemType);
    let updated: CartItem[];
    if (exists) {
      updated = current.map((i) => (i.domain === item.domain && i.itemType === item.itemType ? item : i));
    } else {
      updated = [...current, item];
    }
    this.setCart(updated, customUser, adminForCustomerId);
  }

  public removeItem(itemId: string, customUser?: SystemUser | null, adminForCustomerId?: string) {
    const current = this.getCart(customUser, adminForCustomerId);
    const updated = current.filter((i) => i.id !== itemId);
    this.setCart(updated, customUser, adminForCustomerId);
  }

  public clearCart(customUser?: SystemUser | null, adminForCustomerId?: string) {
    this.setCart([], customUser, adminForCustomerId);
  }

  public migrateGuestCartToUser(userId: string) {
    const guestKey = `${STORAGE_PREFIX}${this.guestSessionId}`;
    const userKey = `${STORAGE_PREFIX}USER_${userId}`;

    if (typeof localStorage === 'undefined') return;
    try {
      const guestRaw = localStorage.getItem(guestKey);
      if (guestRaw) {
        const guestItems: CartItem[] = JSON.parse(guestRaw);
        if (guestItems.length > 0) {
          const userRaw = localStorage.getItem(userKey);
          const userItems: CartItem[] = userRaw ? JSON.parse(userRaw) : [];
          
          // Merge items
          const merged = [...userItems];
          guestItems.forEach((gItem) => {
            if (!merged.some((m) => m.domain === gItem.domain && m.itemType === gItem.itemType)) {
              merged.push(gItem);
            }
          });

          localStorage.setItem(userKey, JSON.stringify(merged));
          // Clear guest cart
          localStorage.removeItem(guestKey);
        }
      }
      this.refreshActiveScope();
    } catch (e) {
      console.error('[CartScopeManager] Failed to migrate guest cart:', e);
    }
  }
}

export const cartScopeManager = new CartScopeManager();
