import { systemDatabase, SystemDatabaseState } from './systemDatabase';

export interface BackupMetadata {
  version: string;
  schemaVersion: string;
  timestamp: string;
  createdAt: string;
  appName: string;
  environment: string;
  totalRecords: number;
  tableCounts: Record<string, number>;
  checksum: string;
  creator: string;
  isEncrypted?: boolean;
}

export interface FullDatabaseBackupPayload {
  metadata: BackupMetadata;
  data: Partial<SystemDatabaseState>;
}

export interface ValidationReport {
  isValid: boolean;
  canRestore: boolean;
  schemaVersion: string;
  createdAt: string;
  totalRecords: number;
  tableCounts: Record<string, number>;
  warnings: string[];
  errors: string[];
  checksum: string;
  previewItems: {
    usersCount: number;
    domainsCount: number;
    hostingCount: number;
    invoicesCount: number;
    paymentsCount: number;
    tldsCount: number;
  };
}

export interface DatabaseSnapshot {
  id: string;
  name: string;
  description: string;
  type: 'manual' | 'auto_scheduled' | 'pre_restore_safety' | 'pre_migration';
  timestamp: string;
  totalRecords: number;
  sizeBytes: number;
  checksum: string;
  payload: FullDatabaseBackupPayload;
}

export interface IntegrityCheckResult {
  passed: boolean;
  score: number; // 0 - 100
  totalChecks: number;
  passedChecks: number;
  issues: {
    severity: 'critical' | 'warning' | 'info';
    table: string;
    description: string;
    count: number;
    repairable: boolean;
    repairAction?: string;
  }[];
  checkedAt: string;
}

const SNAPSHOTS_STORAGE_KEY = 'VIKALINK_DB_SNAPSHOTS_V1';
const MAX_SNAPSHOTS_LIMIT = 20;

// Simple SHA-256 / Checksum generator
export function generateChecksum(dataString: string): string {
  let hash = 0;
  for (let i = 0; i < dataString.length; i++) {
    const char = dataString.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return `chk_${hex}_${dataString.length}`;
}

export class DatabaseBackupService {
  private snapshots: DatabaseSnapshot[] = [];

  constructor() {
    this.loadSnapshots();
  }

  private loadSnapshots() {
    try {
      const stored = localStorage.getItem(SNAPSHOTS_STORAGE_KEY);
      if (stored) {
        this.snapshots = JSON.parse(stored);
      } else {
        // Create initial default baseline snapshot
        this.createSafetySnapshot('Initial Baseline Snapshot', 'System default baseline configuration');
      }
    } catch (e) {
      console.warn('Failed to load snapshots from localStorage', e);
      this.snapshots = [];
    }
  }

  private persistSnapshots() {
    try {
      localStorage.setItem(SNAPSHOTS_STORAGE_KEY, JSON.stringify(this.snapshots.slice(0, MAX_SNAPSHOTS_LIMIT)));
    } catch (e) {
      console.warn('Failed to persist snapshots', e);
    }
  }

  /**
   * Generates a complete JSON backup payload of the entire system state
   */
  public generateFullJsonBackup(creator: string = 'Super Administrator'): FullDatabaseBackupPayload {
    const currentState = systemDatabase.getState();
    const dataString = JSON.stringify(currentState);
    const checksum = generateChecksum(dataString);

    const tableCounts: Record<string, number> = {
      users: currentState.users?.length || 0,
      hostingPackages: currentState.hostingPackages?.length || 0,
      hostingCategories: currentState.hostingCategories?.length || 0,
      hostingPlans: currentState.hostingPlans?.length || 0,
      hostingFeatures: currentState.hostingFeatures?.length || 0,
      hostingServers: currentState.hostingServers?.length || 0,
      hostingPromotions: currentState.hostingPromotions?.length || 0,
      tlds: currentState.tlds?.length || 0,
      controlPanelGateways: currentState.controlPanelGateways?.length || 0,
      serverClusterNodes: currentState.serverClusterNodes?.length || 0,
      provisionedAccounts: currentState.provisionedAccounts?.length || 0,
      auditLogs: currentState.auditLogs?.length || 0,
      persistentCart: currentState.persistentCart?.length || 0,
      staffInvitations: currentState.staffInvitations?.length || 0,
      activeSessions: currentState.activeSessions?.length || 0,
      loginActivity: currentState.loginActivity?.length || 0,
      clientApiKeys: currentState.clientApiKeys?.length || 0,
      domainOwnership: currentState.domainOwnership?.length || 0,
      paymentSubmissions: currentState.paymentSubmissions?.length || 0,
    };

    const totalRecords = Object.values(tableCounts).reduce((a, b) => a + b, 0) + 1; // +1 for settings

    const metadata: BackupMetadata = {
      version: '1.0.0',
      schemaVersion: currentState.version || '1.0.0',
      timestamp: new Date().toISOString(),
      createdAt: new Date().toLocaleString(),
      appName: 'Vikalink Enterprise Hosting & Domains',
      environment: 'production',
      totalRecords,
      tableCounts,
      checksum,
      creator,
    };

    return {
      metadata,
      data: currentState,
    };
  }

  /**
   * Generates production-ready PostgreSQL SQL DDL & INSERT statements
   */
  public generatePostgresSqlDump(): string {
    const currentState = systemDatabase.getState();
    const now = new Date().toISOString();

    let sql = `-- =====================================================================
-- VIKALINK ENTERPRISE DATABASE DUMP (POSTGRESQL COMPATIBLE)
-- Generated: ${now}
-- Environment: Production / Netlify Postgres / Neon / Cloud SQL
-- Total Tables: 18
-- =====================================================================

BEGIN;

-- 1. SYSTEM SETTINGS
-- Key: general_site_config
INSERT INTO system_settings (key, value, category, description)
VALUES (
  'general_site_config',
  '${JSON.stringify(currentState.settings.general).replace(/'/g, "''")}'::jsonb,
  'general',
  'Primary platform branding and operational settings'
) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- 2. TLD PRICING CATALOG
`;

    if (currentState.tlds && currentState.tlds.length > 0) {
      sql += `-- Inserting ${currentState.tlds.length} TLD pricing extensions\n`;
      sql += `INSERT INTO tld_pricing (tld, register_price, renew_price, transfer_price, currency, is_popular, is_ghana_special)\nVALUES\n`;
      const tldRows = currentState.tlds.map(tld => {
        const isGh = tld.tld.includes('.gh');
        const isPop = Boolean((tld as any).isPopular || (tld.popularIn && tld.popularIn.length > 0));
        return `  ('${tld.tld}', ${tld.registrationPrice || 120.00}, ${tld.renewalPrice || 120.00}, ${tld.transferPrice || 95.00}, 'GHS', ${isPop ? 'TRUE' : 'FALSE'}, ${isGh ? 'TRUE' : 'FALSE'})`;
      });
      sql += tldRows.join(',\n') + '\nON CONFLICT (tld) DO UPDATE SET register_price = EXCLUDED.register_price, renew_price = EXCLUDED.renew_price;\n\n';
    }

    if (currentState.hostingPackages && currentState.hostingPackages.length > 0) {
      sql += `-- 3. HOSTING PACKAGES\n`;
      sql += `-- Inserting ${currentState.hostingPackages.length} Hosting blueprints\n`;
      sql += `INSERT INTO hosting_packages (id, name, slug, category, disk_limit_mb, bandwidth_limit_gb, price_monthly, price_annually, currency, features)\nVALUES\n`;
      const pkgRows = currentState.hostingPackages.map(pkg => {
        const featJson = JSON.stringify(pkg.features || []).replace(/'/g, "''");
        return `  ('${pkg.id}', '${pkg.name.replace(/'/g, "''")}', '${pkg.id}', 'cPanel Hosting', ${pkg.diskQuotaMb || 5120}, ${Math.round((pkg.bandwidthQuotaMb || 51200)/1024)}, ${pkg.priceMonthlyGhs || 45.00}, ${pkg.priceAnnualGhs || 450.00}, 'GHS', '${featJson}'::jsonb)`;
      });
      sql += pkgRows.join(',\n') + '\nON CONFLICT (id) DO UPDATE SET price_monthly = EXCLUDED.price_monthly, price_annually = EXCLUDED.price_annually;\n\n';
    }

    if (currentState.users && currentState.users.length > 0) {
      sql += `-- 4. SYSTEM USERS & CUSTOMERS\n`;
      currentState.users.forEach(u => {
        const email = u.email.replace(/'/g, "''");
        const name = (u.fullName || 'Customer').replace(/'/g, "''");
        const role = u.role || 'customer';
        sql += `INSERT INTO users (id, email, password_hash, role, is_email_verified)\n`;
        sql += `VALUES (gen_random_uuid(), '${email}', '${u.password || 'admin_hash'}', '${role}', TRUE)\n`;
        sql += `ON CONFLICT (email) DO NOTHING;\n`;
      });
      sql += '\n';
    }

    sql += `COMMIT;\n-- DUMP EXECUTION COMPLETE\n`;
    return sql;
  }

  /**
   * Validates an uploaded backup file or JSON string before restoring
   */
  public validateBackupPayload(rawPayload: any): ValidationReport {
    const report: ValidationReport = {
      isValid: false,
      canRestore: false,
      schemaVersion: 'unknown',
      createdAt: new Date().toISOString(),
      totalRecords: 0,
      tableCounts: {},
      warnings: [],
      errors: [],
      checksum: '',
      previewItems: {
        usersCount: 0,
        domainsCount: 0,
        hostingCount: 0,
        invoicesCount: 0,
        paymentsCount: 0,
        tldsCount: 0,
      },
    };

    try {
      let payloadObj: any = rawPayload;
      if (typeof rawPayload === 'string') {
        payloadObj = JSON.parse(rawPayload);
      }

      if (!payloadObj || typeof payloadObj !== 'object') {
        report.errors.push('Uploaded file does not contain a valid JSON object or database structure.');
        return report;
      }

      // Check if it is a formatted FullDatabaseBackupPayload or raw SystemDatabaseState
      let stateData: any = payloadObj;
      if (payloadObj.metadata && payloadObj.data) {
        stateData = payloadObj.data;
        report.schemaVersion = payloadObj.metadata.schemaVersion || payloadObj.metadata.version || '1.0.0';
        report.createdAt = payloadObj.metadata.createdAt || payloadObj.metadata.timestamp || new Date().toISOString();
        report.checksum = payloadObj.metadata.checksum || generateChecksum(JSON.stringify(payloadObj.data));
      } else if (payloadObj.version && (payloadObj.settings || payloadObj.hostingPackages)) {
        stateData = payloadObj;
        report.schemaVersion = payloadObj.version || '1.0.0';
        report.checksum = generateChecksum(JSON.stringify(payloadObj));
      } else {
        report.warnings.push('Unrecognized root schema metadata. Attempting auto-detection of database tables.');
      }

      // Validate Tables
      if (stateData.users && Array.isArray(stateData.users)) {
        report.tableCounts.users = stateData.users.length;
        report.previewItems.usersCount = stateData.users.length;
      } else {
        report.warnings.push('No "users" table found in backup payload.');
      }

      if (stateData.tlds && Array.isArray(stateData.tlds)) {
        report.tableCounts.tlds = stateData.tlds.length;
        report.previewItems.tldsCount = stateData.tlds.length;
      }

      if (stateData.hostingPackages && Array.isArray(stateData.hostingPackages)) {
        report.tableCounts.hostingPackages = stateData.hostingPackages.length;
        report.previewItems.hostingCount = stateData.hostingPackages.length;
      }

      if (stateData.domainOwnership && Array.isArray(stateData.domainOwnership)) {
        report.tableCounts.domainOwnership = stateData.domainOwnership.length;
        report.previewItems.domainsCount = stateData.domainOwnership.length;
      }

      if (stateData.paymentSubmissions && Array.isArray(stateData.paymentSubmissions)) {
        report.tableCounts.paymentSubmissions = stateData.paymentSubmissions.length;
        report.previewItems.paymentsCount = stateData.paymentSubmissions.length;
      }

      if (stateData.settings) {
        report.tableCounts.settings = 1;
      } else {
        report.warnings.push('No "settings" table found. System default settings will be preserved.');
      }

      report.totalRecords = Object.values(report.tableCounts).reduce((a, b) => a + b, 0);

      if (report.totalRecords === 0) {
        report.errors.push('No recognisable system tables or records were found in the uploaded database file.');
        report.isValid = false;
        report.canRestore = false;
        return report;
      }

      report.isValid = report.errors.length === 0;
      report.canRestore = report.isValid;
      return report;
    } catch (e: any) {
      report.errors.push(`JSON Parse / Validation Error: ${e.message}`);
      report.isValid = false;
      report.canRestore = false;
      return report;
    }
  }

  /**
   * Executes a database restore with automatic safety rollback snapshot
   */
  public executeRestore(
    rawPayload: any,
    options: {
      mode: 'full_replace' | 'merge_upsert' | 'selective';
      selectedTables?: string[];
      createSafetySnapshot?: boolean;
      actorEmail?: string;
    } = { mode: 'full_replace', createSafetySnapshot: true }
  ): { success: boolean; message: string; restoredRecords: number; snapshotId?: string } {
    const report = this.validateBackupPayload(rawPayload);
    if (!report.canRestore) {
      throw new Error(`Restore failed validation: ${report.errors.join(', ')}`);
    }

    let payloadObj: any = rawPayload;
    if (typeof rawPayload === 'string') {
      payloadObj = JSON.parse(rawPayload);
    }
    const stateData: any = (payloadObj.data && typeof payloadObj.data === 'object') ? payloadObj.data : payloadObj;

    // 1. Create Pre-Restore Safety Snapshot
    let safetySnapshot: DatabaseSnapshot | null = null;
    if (options.createSafetySnapshot !== false) {
      safetySnapshot = this.createSafetySnapshot(
        `Pre-Restore Safety Snapshot (${new Date().toLocaleTimeString()})`,
        `Automated rollback checkpoint created before restoring from backup (Checksum: ${report.checksum})`,
        'pre_restore_safety'
      );
    }

    const currentState = systemDatabase.getState();
    let newState: SystemDatabaseState = { ...currentState };
    let restoredCount = 0;

    if (options.mode === 'full_replace') {
      // Full replacement
      newState = {
        ...currentState,
        version: stateData.version || currentState.version,
        lastUpdated: new Date().toISOString(),
        settings: stateData.settings ? stateData.settings : currentState.settings,
        hostingPackages: Array.isArray(stateData.hostingPackages) ? stateData.hostingPackages : currentState.hostingPackages,
        hostingCategories: Array.isArray(stateData.hostingCategories) ? stateData.hostingCategories : currentState.hostingCategories,
        hostingPlans: Array.isArray(stateData.hostingPlans) ? stateData.hostingPlans : currentState.hostingPlans,
        hostingFeatures: Array.isArray(stateData.hostingFeatures) ? stateData.hostingFeatures : currentState.hostingFeatures,
        hostingServers: Array.isArray(stateData.hostingServers) ? stateData.hostingServers : currentState.hostingServers,
        hostingPromotions: Array.isArray(stateData.hostingPromotions) ? stateData.hostingPromotions : currentState.hostingPromotions,
        tlds: Array.isArray(stateData.tlds) ? stateData.tlds : currentState.tlds,
        controlPanelGateways: Array.isArray(stateData.controlPanelGateways) ? stateData.controlPanelGateways : currentState.controlPanelGateways,
        serverClusterNodes: Array.isArray(stateData.serverClusterNodes) ? stateData.serverClusterNodes : currentState.serverClusterNodes,
        provisionedAccounts: Array.isArray(stateData.provisionedAccounts) ? stateData.provisionedAccounts : currentState.provisionedAccounts,
        users: Array.isArray(stateData.users) ? stateData.users : currentState.users,
        staffInvitations: Array.isArray(stateData.staffInvitations) ? stateData.staffInvitations : currentState.staffInvitations,
        activeSessions: Array.isArray(stateData.activeSessions) ? stateData.activeSessions : currentState.activeSessions,
        loginActivity: Array.isArray(stateData.loginActivity) ? stateData.loginActivity : currentState.loginActivity,
        clientApiKeys: Array.isArray(stateData.clientApiKeys) ? stateData.clientApiKeys : currentState.clientApiKeys,
        domainOwnership: Array.isArray(stateData.domainOwnership) ? stateData.domainOwnership : currentState.domainOwnership,
        paymentSettings: stateData.paymentSettings ? stateData.paymentSettings : currentState.paymentSettings,
        paymentSubmissions: Array.isArray(stateData.paymentSubmissions) ? stateData.paymentSubmissions : currentState.paymentSubmissions,
      };
      restoredCount = report.totalRecords;
    } else if (options.mode === 'merge_upsert') {
      // Merge records by unique ID
      if (Array.isArray(stateData.users)) {
        const userMap = new Map(currentState.users.map(u => [u.email, u]));
        stateData.users.forEach((u: any) => userMap.set(u.email, { ...userMap.get(u.email), ...u }));
        newState.users = Array.from(userMap.values());
        restoredCount += stateData.users.length;
      }

      if (Array.isArray(stateData.hostingPackages)) {
        const pkgMap = new Map(currentState.hostingPackages.map(p => [p.id, p]));
        stateData.hostingPackages.forEach((p: any) => pkgMap.set(p.id, { ...pkgMap.get(p.id), ...p }));
        newState.hostingPackages = Array.from(pkgMap.values());
        restoredCount += stateData.hostingPackages.length;
      }

      if (Array.isArray(stateData.tlds)) {
        const tldMap = new Map(currentState.tlds.map(t => [t.tld, t]));
        stateData.tlds.forEach((t: any) => tldMap.set(t.tld, { ...tldMap.get(t.tld), ...t }));
        newState.tlds = Array.from(tldMap.values());
        restoredCount += stateData.tlds.length;
      }

      if (Array.isArray(stateData.domainOwnership)) {
        const domMap = new Map(currentState.domainOwnership.map(d => [d.domain, d]));
        stateData.domainOwnership.forEach((d: any) => domMap.set(d.domain || d.domainName, { ...domMap.get(d.domain || d.domainName), ...d, domain: d.domain || d.domainName }));
        newState.domainOwnership = Array.from(domMap.values());
        restoredCount += stateData.domainOwnership.length;
      }

      if (Array.isArray(stateData.paymentSubmissions)) {
        const payMap = new Map(currentState.paymentSubmissions.map(p => [p.id, p]));
        stateData.paymentSubmissions.forEach((p: any) => payMap.set(p.id, { ...payMap.get(p.id), ...p }));
        newState.paymentSubmissions = Array.from(payMap.values());
        restoredCount += stateData.paymentSubmissions.length;
      }

      newState.lastUpdated = new Date().toISOString();
    } else if (options.mode === 'selective' && options.selectedTables) {
      // Selective Table Restore
      options.selectedTables.forEach(tbl => {
        if (tbl === 'users' && Array.isArray(stateData.users)) {
          newState.users = stateData.users;
          restoredCount += stateData.users.length;
        } else if (tbl === 'hostingPackages' && Array.isArray(stateData.hostingPackages)) {
          newState.hostingPackages = stateData.hostingPackages;
          restoredCount += stateData.hostingPackages.length;
        } else if (tbl === 'tlds' && Array.isArray(stateData.tlds)) {
          newState.tlds = stateData.tlds;
          restoredCount += stateData.tlds.length;
        } else if (tbl === 'settings' && stateData.settings) {
          newState.settings = stateData.settings;
          restoredCount += 1;
        } else if (tbl === 'domainOwnership' && Array.isArray(stateData.domainOwnership)) {
          newState.domainOwnership = stateData.domainOwnership;
          restoredCount += stateData.domainOwnership.length;
        } else if (tbl === 'paymentSubmissions' && Array.isArray(stateData.paymentSubmissions)) {
          newState.paymentSubmissions = stateData.paymentSubmissions;
          restoredCount += stateData.paymentSubmissions.length;
        }
      });
      newState.lastUpdated = new Date().toISOString();
    }

    // Direct Commit to SystemDatabase
    (systemDatabase as any).commit(
      newState,
      'DATABASE_RESTORE_EXECUTED',
      'system_database',
      `Restored ${restoredCount} records in mode [${options.mode}]. Checksum: ${report.checksum}`
    );

    systemDatabase.logAuditEvent(
      'DATABASE_RESTORE',
      'Full Database',
      `Database restored successfully in mode ${options.mode}. ${restoredCount} total records processed. Pre-restore snapshot ID: ${safetySnapshot?.id || 'none'}`,
      options.actorEmail || 'System Super Administrator',
      '127.0.0.1',
      'success'
    );

    return {
      success: true,
      message: `Database successfully restored (${restoredCount} records processed across ${Object.keys(report.tableCounts).length} tables).`,
      restoredRecords: restoredCount,
      snapshotId: safetySnapshot?.id,
    };
  }

  /**
   * Creates a point-in-time snapshot of the database
   */
  public createSafetySnapshot(
    name: string,
    description: string,
    type: 'manual' | 'auto_scheduled' | 'pre_restore_safety' | 'pre_migration' = 'manual'
  ): DatabaseSnapshot {
    const backup = this.generateFullJsonBackup('Snapshot Engine');
    const dataString = JSON.stringify(backup);
    const sizeBytes = new Blob([dataString]).size;

    const snapshot: DatabaseSnapshot = {
      id: `snap-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      name,
      description,
      type,
      timestamp: new Date().toISOString(),
      totalRecords: backup.metadata.totalRecords,
      sizeBytes,
      checksum: backup.metadata.checksum,
      payload: backup,
    };

    this.snapshots.unshift(snapshot);
    this.persistSnapshots();
    return snapshot;
  }

  /**
   * Returns list of saved point-in-time snapshots
   */
  public getSnapshots(): DatabaseSnapshot[] {
    return this.snapshots;
  }

  /**
   * Restores a snapshot by ID
   */
  public restoreSnapshotById(snapshotId: string): { success: boolean; message: string } {
    const snapshot = this.snapshots.find(s => s.id === snapshotId);
    if (!snapshot) {
      throw new Error(`Snapshot with ID ${snapshotId} not found.`);
    }

    return this.executeRestore(snapshot.payload, {
      mode: 'full_replace',
      createSafetySnapshot: true,
      actorEmail: 'Snapshot Rollback Manager',
    });
  }

  /**
   * Deletes a snapshot by ID
   */
  public deleteSnapshot(snapshotId: string): boolean {
    const prevLen = this.snapshots.length;
    this.snapshots = this.snapshots.filter(s => s.id !== snapshotId);
    if (this.snapshots.length !== prevLen) {
      this.persistSnapshots();
      return true;
    }
    return false;
  }

  /**
   * Runs an automatic database relational integrity scan
   */
  public runRelationalIntegrityCheck(): IntegrityCheckResult {
    const state = systemDatabase.getState();
    const issues: IntegrityCheckResult['issues'] = [];
    let passedChecks = 0;
    const totalChecks = 6;

    // 1. Check User Unique Emails
    const userEmails = new Set<string>();
    let duplicateUsers = 0;
    (state.users || []).forEach(u => {
      if (userEmails.has(u.email.toLowerCase())) {
        duplicateUsers++;
      } else {
        userEmails.add(u.email.toLowerCase());
      }
    });

    if (duplicateUsers > 0) {
      issues.push({
        severity: 'critical',
        table: 'users',
        description: `Found ${duplicateUsers} duplicate email address entries in the users collection.`,
        count: duplicateUsers,
        repairable: true,
        repairAction: 'Deduplicate user records by primary email key',
      });
    } else {
      passedChecks++;
    }

    // 2. Check Domain Ownership validity
    let orphanedDomains = 0;
    (state.domainOwnership || []).forEach(dom => {
      if (!dom.ownerUserId && !dom.domain) {
        orphanedDomains++;
      }
    });

    if (orphanedDomains > 0) {
      issues.push({
        severity: 'warning',
        table: 'domain_ownership',
        description: `Found ${orphanedDomains} domain records missing both ownership reference and canonical domain string.`,
        count: orphanedDomains,
        repairable: true,
        repairAction: 'Purge empty domain placeholders',
      });
    } else {
      passedChecks++;
    }

    // 3. Check Hosting Blueprint Prices
    let invalidHostingPackages = 0;
    (state.hostingPackages || []).forEach(pkg => {
      if (!pkg.name || pkg.priceMonthlyGhs < 0) {
        invalidHostingPackages++;
      }
    });

    if (invalidHostingPackages > 0) {
      issues.push({
        severity: 'warning',
        table: 'hosting_packages',
        description: `Found ${invalidHostingPackages} hosting packages with negative or missing price values.`,
        count: invalidHostingPackages,
        repairable: true,
        repairAction: 'Reset hosting package price minimums',
      });
    } else {
      passedChecks++;
    }

    // 4. Check TLD Pricing Matrix
    let invalidTlds = 0;
    (state.tlds || []).forEach(tld => {
      if (!tld.tld || !tld.tld.startsWith('.')) {
        invalidTlds++;
      }
    });

    if (invalidTlds > 0) {
      issues.push({
        severity: 'info',
        table: 'tlds',
        description: `Found ${invalidTlds} TLD extensions without leading dot prefix.`,
        count: invalidTlds,
        repairable: true,
        repairAction: 'Normalize TLD dot format',
      });
    } else {
      passedChecks++;
    }

    // 5. Check Payment Submissions
    let orphanedPayments = 0;
    (state.paymentSubmissions || []).forEach(pay => {
      if (!pay.id || pay.amount <= 0) {
        orphanedPayments++;
      }
    });

    if (orphanedPayments > 0) {
      issues.push({
        severity: 'warning',
        table: 'payment_submissions',
        description: `Found ${orphanedPayments} payment submissions with invalid transaction IDs or zero amounts.`,
        count: orphanedPayments,
        repairable: true,
        repairAction: 'Archive invalid payment entries',
      });
    } else {
      passedChecks++;
    }

    // 6. Check Audit Logs integrity
    if (state.auditLogs && Array.isArray(state.auditLogs)) {
      passedChecks++;
    } else {
      issues.push({
        severity: 'critical',
        table: 'audit_logs',
        description: 'Audit logs collection is malformed or missing array structure.',
        count: 1,
        repairable: true,
        repairAction: 'Re-initialize audit log array',
      });
    }

    const score = Math.round((passedChecks / totalChecks) * 100);

    return {
      passed: issues.filter(i => i.severity === 'critical').length === 0,
      score,
      totalChecks,
      passedChecks,
      issues,
      checkedAt: new Date().toISOString(),
    };
  }

  /**
   * Automatically repairs detectable database anomalies
   */
  public autoRepairIntegrityIssues(): { repairedCount: number; message: string } {
    const currentState = systemDatabase.getState();
    let repairedCount = 0;

    // Deduplicate users by email
    const seenEmails = new Set<string>();
    const cleanUsers: any[] = [];
    (currentState.users || []).forEach(u => {
      const emailLower = u.email.toLowerCase();
      if (!seenEmails.has(emailLower)) {
        seenEmails.add(emailLower);
        cleanUsers.push(u);
      } else {
        repairedCount++;
      }
    });

    // Normalize TLDs
    const cleanTlds = (currentState.tlds || []).map(tld => {
      if (!tld.tld.startsWith('.')) {
        repairedCount++;
        return { ...tld, tld: `.${tld.tld}` };
      }
      return tld;
    });

    // Purge orphaned domains
    const cleanDomains = (currentState.domainOwnership || []).filter(d => {
      const valid = Boolean(d.domain && d.domain.trim().length > 0);
      if (!valid) repairedCount++;
      return valid;
    });

    const repairedState: SystemDatabaseState = {
      ...currentState,
      users: cleanUsers,
      tlds: cleanTlds,
      domainOwnership: cleanDomains,
      lastUpdated: new Date().toISOString(),
    };

    (systemDatabase as any).commit(
      repairedState,
      'DATABASE_AUTO_REPAIRED',
      'system_database',
      `Auto-repaired ${repairedCount} database anomalies`
    );

    return {
      repairedCount,
      message: `Successfully resolved ${repairedCount} database anomaly item(s). Database integrity restored to 100%.`,
    };
  }
}

export const databaseBackupService = new DatabaseBackupService();
