import React, { useState, useMemo } from 'react';
import { 
  X, 
  Check, 
  ShieldCheck, 
  Globe, 
  Server, 
  CreditCard, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft,
  Mail,
  Lock,
  Building,
  User,
  CheckCircle2,
  Tag,
  Smartphone,
  Landmark,
  Copy,
  AlertCircle,
  FileText,
  Printer,
  Download,
  Receipt,
  ExternalLink
} from 'lucide-react';
import { CartItem, Currency, Coupon, PaymentMethodSettings, PaymentSubmission, RegisteredDomain } from '../types';
import { formatPrice, calculateTaxBreakdown } from '../utils/domainSearchEngine';
import { VALID_COUPONS } from '../data/coupons';
import { DEFAULT_PAYMENT_SETTINGS } from '../data/paymentSettings';
import { MOCK_WHMCS_PACKAGES } from '../data/mockWhmcsData';
import { PaystackCheckoutModal } from './PaystackCheckoutModal';
import { systemDatabase } from '../services/systemDatabase';
import { commerceEngine } from '../services/commerceEngine';

interface RegistrationWizardModalProps {
  cartItems: CartItem[];
  currency: Currency;
  paymentSettings?: PaymentMethodSettings;
  userDomains?: (RegisteredDomain | string)[];
  onClose: () => void;
  onClearCart: () => void;
  onOrderComplete: () => void;
  onAddSubmission?: (submission: PaymentSubmission) => void;
}

export const RegistrationWizardModal: React.FC<RegistrationWizardModalProps> = ({
  cartItems,
  currency,
  paymentSettings = DEFAULT_PAYMENT_SETTINGS,
  userDomains = [],
  onClose,
  onClearCart,
  onOrderComplete,
  onAddSubmission,
}) => {
  const [step, setStep] = useState<number>(1);
  const [items, setItems] = useState<CartItem[]>(cartItems);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');

  // Extract account domain list for binding
  const accountDomains: string[] = useMemo(() => {
    const raw = [
      ...userDomains.map((d) => (typeof d === 'string' ? d : d?.domain)).filter(Boolean),
      ...cartItems.filter((i) => i.itemType !== 'hosting' && i.domain).map((i) => i.domain).filter(Boolean),
      'nexustech.io',
      'apexdomain.com',
      'cloudscale.app'
    ];
    return Array.from(new Set(raw));
  }, [userDomains, cartItems]);

  // Selected Payment Method (Only Paystack and Custom Payment supported)
  const [paymentMethod, setPaymentMethod] = useState<'paystack' | 'custom_manual'>('paystack');

  // Custom Payment Form Inputs
  const [customProofRef, setCustomProofRef] = useState('');
  const [customMomoSender, setCustomMomoSender] = useState('');
  const [copiedOrderRef, setCopiedOrderRef] = useState(false);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedItem(id);
    setTimeout(() => setCopiedItem(null), 2000);
  };

  // Paystack Modal State
  const [isPaystackOpen, setIsPaystackOpen] = useState(false);
  const [paystackRef, setPaystackRef] = useState<string | null>(null);

  // Contact Info State
  const [contactInfo, setContactInfo] = useState({
    firstName: 'Alex',
    lastName: 'Morgan',
    organization: 'Nexus Tech LLC',
    email: 'alex.morgan@nexustech.io',
    phone: '+233 24 123 4567',
    address: '500 Technology Way',
    city: 'Accra',
    state: 'Greater Accra',
    postalCode: '00233',
    country: 'Ghana',
  });

  // Nameserver choice (Default vs Custom)
  const [nameserverMode, setNameserverMode] = useState<'system_default' | 'custom'>('system_default');
  const [customNs1, setCustomNs1] = useState('ns1.celoxaghana.online');
  const [customNs2, setCustomNs2] = useState('ns2.celoxaghana.online');
  const [customNs3, setCustomNs3] = useState('');
  const [customNs4, setCustomNs4] = useState('');

  const [orderId] = useState(() => `APX-${Math.floor(100000 + Math.random() * 900000)}`);

  const updateItemYears = (id: string, years: number) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, years } : item))
    );
  };

  const updateItemDomain = (id: string, domain: string) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, domain } : item))
    );
  };

  const updateHostingBillingCycle = (
    id: string,
    cycle: 'monthly' | 'annually' | 'triennially'
  ) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const matchedPkg = MOCK_WHMCS_PACKAGES.find((p) => p.id === item.planId);
        let newPrice = item.registrationPrice;
        if (matchedPkg) {
          if (cycle === 'monthly') newPrice = matchedPkg.priceMonthly;
          else if (cycle === 'annually') newPrice = matchedPkg.priceAnnually;
          else if (cycle === 'triennially') newPrice = matchedPkg.priceAnnually * 2.5;
        } else {
          if (cycle === 'monthly') newPrice = 8.99;
          else if (cycle === 'annually') newPrice = 89.90;
          else if (cycle === 'triennially') newPrice = 220.00;
        }
        return {
          ...item,
          billingCycle: cycle,
          registrationPrice: newPrice,
        };
      })
    );
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const found = VALID_COUPONS.find((c) => c.code.toUpperCase() === couponCode.trim().toUpperCase());
    if (found) {
      setAppliedCoupon(found);
      setCouponError('');
    } else {
      setCouponError('Invalid promo code. Try WELCOME20 or DOMAINS50.');
    }
  };

  // Pricing Math (NaN-Proof)
  const subtotal = items.reduce((acc, item) => {
    const regPrice = typeof item.registrationPrice === 'number' && !isNaN(item.registrationPrice) ? item.registrationPrice : 0;
    const years = typeof item.years === 'number' && !isNaN(item.years) ? item.years : 1;
    if (item.itemType === 'hosting') {
      return acc + regPrice;
    }
    const regCost = regPrice * years;
    const hostingCost = item.hostingAddon ? 4.99 * 12 : 0;
    return acc + regCost + hostingCost;
  }, 0);

  const totalIcann = items.reduce((acc, item) => {
    if (item.itemType === 'hosting') return acc;
    const icann = typeof item.icannFee === 'number' && !isNaN(item.icannFee) ? item.icannFee : 0.18;
    const years = typeof item.years === 'number' && !isNaN(item.years) ? item.years : 1;
    return acc + (icann * years);
  }, 0);
  const discountAmount = appliedCoupon ? (subtotal * (Number(appliedCoupon.discountPercent) || 0)) / 100 : 0;
  const sysTaxRate = Number(systemDatabase.getSettings()?.billing?.defaultTaxRate) || 15;
  const safeSubtotal = subtotal > 0 ? subtotal : (items.length === 0 ? 18.50 : 0);
  const taxBreakdown = calculateTaxBreakdown({
    subtotalUsd: safeSubtotal,
    currency,
    taxRatePercent: sysTaxRate,
    discountUsd: discountAmount,
    icannFeeUsd: totalIcann,
  });
  const estimatedTax = taxBreakdown.taxAmountUsd;
  const grandTotal = taxBreakdown.grandTotalUsd > 0 ? taxBreakdown.grandTotalUsd : 18.50;

  const stepsList = [
    'Choose Duration',
    'Add-ons',
    'DNS Settings',
    'Registrant Info',
    'Payment & Review',
    'Confirmation'
  ];

  const handleCopyOrderRef = () => {
    navigator.clipboard?.writeText(orderId);
    setCopiedOrderRef(true);
    setTimeout(() => setCopiedOrderRef(false), 2000);
  };

  const handleProceedToPayment = () => {
    if (paymentMethod === 'paystack') {
      setIsPaystackOpen(true);
    } else {
      // Custom Manual Payment (Bank Transfer / MoMo Proof)
      const order = commerceEngine.createOrderFromCart({
        items,
        currency,
        customerName: `${contactInfo.firstName} ${contactInfo.lastName}`,
        customerEmail: contactInfo.email,
        customerPhone: contactInfo.phone,
        paymentMethod: 'custom_manual',
        couponDiscount: discountAmount,
        icannFee: totalIcann,
        tax: estimatedTax,
      });

      // Record submission
      const newSubmission: PaymentSubmission = {
        id: `sub-${Date.now()}`,
        orderId: order.id,
        domains: items.map((i) => i.domain),
        amount: grandTotal,
        currency,
        paymentMethod: 'custom_manual',
        customProofText: customProofRef || `Order Ref: ${order.id} submitted for review`,
        momoNumberUsed: customMomoSender || contactInfo.phone,
        status: 'pending_approval',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        customerName: `${contactInfo.firstName} ${contactInfo.lastName}`,
        customerEmail: contactInfo.email,
      };

      if (onAddSubmission) onAddSubmission(newSubmission);
      setStep(6);
      onClearCart();
      onOrderComplete();
    }
  };

  const handlePaystackSuccess = (ref: string) => {
    setPaystackRef(ref);
    setIsPaystackOpen(false);

    // Create Order in commerceEngine & mark paid with Paystack ref + auto-provision
    const order = commerceEngine.createOrderFromCart({
      items,
      currency,
      customerName: `${contactInfo.firstName} ${contactInfo.lastName}`,
      customerEmail: contactInfo.email,
      customerPhone: contactInfo.phone,
      paymentMethod: 'paystack',
      couponDiscount: discountAmount,
      icannFee: totalIcann,
      tax: estimatedTax,
    });

    commerceEngine.markOrderPaidAndProvision(order.id, ref, 'paystack');

    const newSubmission: PaymentSubmission = {
      id: `sub-${Date.now()}`,
      orderId: order.id,
      domains: items.map((i) => i.domain),
      amount: grandTotal,
      currency,
      paymentMethod: 'paystack',
      paystackReference: ref,
      status: 'completed',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      customerName: `${contactInfo.firstName} ${contactInfo.lastName}`,
      customerEmail: contactInfo.email,
    };

    if (onAddSubmission) onAddSubmission(newSubmission);
    setStep(6);
    onClearCart();
    onOrderComplete();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 rounded">
                Wizard Step {step} of 6
              </span>
              <h2 className="text-lg font-black text-slate-900 dark:text-white">Domain Checkout & Payment Wizard</h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator Bar */}
        <div className="px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-100/60 dark:bg-slate-800/20 overflow-x-auto">
          <div className="flex items-center justify-between min-w-[550px]">
            {stepsList.map((label, idx) => {
              const num = idx + 1;
              const isDone = step > num;
              const isCurrent = step === num;
              return (
                <div key={idx} className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      isDone
                        ? 'bg-emerald-600 text-white'
                        : isCurrent
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                    }`}
                  >
                    {isDone ? <Check className="w-4 h-4" /> : num}
                  </div>
                  <span
                    className={`text-xs font-semibold ${
                      isCurrent ? 'text-slate-900 dark:text-white font-extrabold' : 'text-slate-400'
                    }`}
                  >
                    {label}
                  </span>
                  {num < 6 && <span className="w-6 h-[1px] bg-slate-300 dark:bg-slate-700 mx-1" />}
                </div>
              );
            })}
          </div>
        </div>

        {/* Wizard Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* STEP 1: CHOOSE YEARS & HOSTING DOMAIN BINDING */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>Step 1: Configuration & Service Setup</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Configure registration duration for domains and select target account domains and billing cycles for web hosting plans.
                </p>
              </div>

              <div className="space-y-4">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-4"
                  >
                    {item.itemType === 'hosting' ? (
                      <div className="space-y-4">
                        {/* Hosting Plan Header */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-700">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                              <Server className="w-5 h-5" />
                            </div>
                            <div>
                              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-[10px] font-extrabold uppercase">
                                Hosting Package
                              </div>
                              <h4 className="font-extrabold text-slate-900 dark:text-white text-base">
                                {item.packageName || 'Web Hosting Plan'}
                              </h4>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="text-xs text-slate-400 block font-medium">Selected Rate</span>
                            <span className="text-sm font-black text-indigo-600 dark:text-indigo-400">
                              {formatPrice(item.registrationPrice, currency)}
                            </span>
                          </div>
                        </div>

                        {/* Domain Binding Selector */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                              <Globe className="w-3.5 h-3.5 text-indigo-500" />
                              <span>Bind Hosting to Domain:</span>
                            </label>
                            <select
                              value={accountDomains.includes(item.domain) ? item.domain : 'custom'}
                              onChange={(e) => {
                                if (e.target.value !== 'custom') {
                                  updateItemDomain(item.id, e.target.value);
                                }
                              }}
                              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                            >
                              {accountDomains.map((dom, domIdx) => (
                                <option key={`acc-dom-${dom}-${domIdx}`} value={dom}>
                                  Use Account Domain: {dom}
                                </option>
                              ))}
                              <option key="opt-custom-domain" value="custom">+ Enter Custom Domain Name...</option>
                            </select>

                            {/* Custom Domain Input if custom selected or not in standard list */}
                            {!accountDomains.includes(item.domain) && (
                              <input
                                type="text"
                                value={item.domain}
                                onChange={(e) => updateItemDomain(item.id, e.target.value)}
                                placeholder="e.g. mynewbrand.com"
                                className="w-full px-3 py-2 mt-2 rounded-xl border border-indigo-300 dark:border-indigo-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                              />
                            )}
                            <p className="text-[11px] text-slate-400">
                              cPanel / WHM will automatically configure DNS records for this bound domain.
                            </p>
                          </div>

                          {/* Billing Cycle Duration */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                              <Tag className="w-3.5 h-3.5 text-indigo-500" />
                              <span>Hosting Billing Cycle:</span>
                            </label>
                            <select
                              value={item.billingCycle || 'annually'}
                              onChange={(e) =>
                                updateHostingBillingCycle(
                                  item.id,
                                  e.target.value as 'monthly' | 'annually' | 'triennially'
                                )
                              }
                              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-white focus:ring-2 focus:ring-indigo-500"
                            >
                              <option value="monthly">Monthly Cycle</option>
                              <option value="annually">Annual Cycle (1 Year - Discounted)</option>
                              <option value="triennially">Triennial Cycle (3 Years - Maximum Savings)</option>
                            </select>
                            <p className="text-[11px] text-slate-400">
                              Server Location: <span className="font-semibold text-slate-300">{item.serverRegion || 'US-East Equinix NY4'}</span>
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Domain Registration Item */
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        <div>
                          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[10px] font-extrabold uppercase mb-1">
                            Domain Registration
                          </div>
                          <div className="font-extrabold text-slate-900 dark:text-white text-base">{item.domain}</div>
                          <div className="text-xs text-slate-400">Base rate: {formatPrice(item.registrationPrice, currency)} / year</div>
                        </div>

                        <div className="flex items-center gap-3 w-full sm:w-auto">
                          <label className="text-xs font-bold text-slate-500">Duration:</label>
                          <select
                            value={item.years}
                            onChange={(e) => updateItemYears(item.id, Number(e.target.value))}
                            className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500"
                          >
                            {[1, 2, 3, 5, 10].map((yr) => (
                              <option key={yr} value={yr}>
                                {yr} Year{yr > 1 ? 's' : ''} ({formatPrice(item.registrationPrice * yr, currency)})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: PRIVACY & ADD-ONS */}
          {step === 2 && (
            <div className="space-y-4">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Step 2: Security & Platform Add-ons
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-emerald-900 dark:text-emerald-300 flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-600" /> Free WHOIS Privacy
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-extrabold bg-emerald-600 text-white rounded-full">
                      Included
                    </span>
                  </div>
                  <p className="text-xs text-emerald-800/80 dark:text-emerald-400">
                    Hides your personal email, phone number, and address from WHOIS search results.
                  </p>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <Mail className="w-5 h-5 text-blue-500" /> Business Email Forwarding
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-extrabold bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full">
                      Included
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Set up custom aliases (info@{items[0]?.domain || 'domain.com'}) forwarding to your main email.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: DNS SETTINGS */}
          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Step 3: DNS & Nameservers Configuration
              </h3>

              {/* Nameserver choice (Default vs Custom) */}
              <div className="space-y-3">
                {items.some((i) => i.itemType === 'hosting' || i.hostingAddon) && (
                  <div className="p-3 rounded-xl bg-gradient-to-r from-indigo-900/30 via-purple-900/20 to-blue-900/30 border border-indigo-500/30 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <Server className="w-4 h-4 text-indigo-400" />
                      <span className="font-bold text-indigo-200">
                        Hosting Package Detected: Auto-configured with cluster Anycast DNS nameservers
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                      Auto-Matched
                    </span>
                  </div>
                )}

                <label className="flex items-start gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 cursor-pointer hover:border-blue-400 transition-colors">
                  <input
                    type="radio"
                    name="nsChoice"
                    checked={nameserverMode === 'system_default'}
                    onChange={() => setNameserverMode('system_default')}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500 mt-1"
                  />
                  <div>
                    <div className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <span>Use System Default Anycast Nameservers (Recommended)</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        Ultra-Fast
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Fast Anycast DNS with instant record syncing across Accra, London, Frankfurt, and New York.
                    </p>
                    <div className="flex flex-wrap gap-2 mt-2 font-mono text-[11px] text-blue-600 dark:text-blue-400">
                      <span className="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">ns1.celoxaghana.online</span>
                      <span className="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">ns2.celoxaghana.online</span>
                      <span className="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">ns3.celoxaghana.online</span>
                      <span className="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">ns4.celoxaghana.online</span>
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 cursor-pointer">
                  <input
                    type="radio"
                    name="nsChoice"
                    checked={nameserverMode === 'custom'}
                    onChange={() => setNameserverMode('custom')}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500 mt-1"
                  />
                  <div>
                    <div className="font-bold text-sm text-slate-900 dark:text-white">
                      Use Custom Nameservers
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Specify third-party authoritative nameservers (Cloudflare, Route53, etc.).
                    </p>
                  </div>
                </label>

                {nameserverMode === 'custom' && (
                  <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20 space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-bold text-slate-600 dark:text-slate-300">Nameserver 1 *</label>
                        <input
                          type="text"
                          value={customNs1}
                          onChange={(e) => setCustomNs1(e.target.value)}
                          placeholder="ns1.example.com"
                          className="w-full px-3 py-2 mt-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-600 dark:text-slate-300">Nameserver 2 *</label>
                        <input
                          type="text"
                          value={customNs2}
                          onChange={(e) => setCustomNs2(e.target.value)}
                          placeholder="ns2.example.com"
                          className="w-full px-3 py-2 mt-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-600 dark:text-slate-300">Nameserver 3 (Optional)</label>
                        <input
                          type="text"
                          value={customNs3}
                          onChange={(e) => setCustomNs3(e.target.value)}
                          placeholder="ns3.example.com"
                          className="w-full px-3 py-2 mt-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-600 dark:text-slate-300">Nameserver 4 (Optional)</label>
                        <input
                          type="text"
                          value={customNs4}
                          onChange={(e) => setCustomNs4(e.target.value)}
                          placeholder="ns4.example.com"
                          className="w-full px-3 py-2 mt-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 4: REGISTRANT CONTACT INFO */}
          {step === 4 && (
            <div className="space-y-4">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Step 4: Registrant Contact Information
              </h3>
              <p className="text-xs text-slate-500">
                ICANN requires legal owner contact details for domain registration.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300">First Name</label>
                  <input
                    type="text"
                    value={contactInfo.firstName}
                    onChange={(e) => setContactInfo({ ...contactInfo, firstName: e.target.value })}
                    className="w-full px-3 py-2 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300">Last Name</label>
                  <input
                    type="text"
                    value={contactInfo.lastName}
                    onChange={(e) => setContactInfo({ ...contactInfo, lastName: e.target.value })}
                    className="w-full px-3 py-2 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300">Organization (Optional)</label>
                  <input
                    type="text"
                    value={contactInfo.organization}
                    onChange={(e) => setContactInfo({ ...contactInfo, organization: e.target.value })}
                    className="w-full px-3 py-2 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300">Email Address</label>
                  <input
                    type="email"
                    value={contactInfo.email}
                    onChange={(e) => setContactInfo({ ...contactInfo, email: e.target.value })}
                    className="w-full px-3 py-2 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300">Phone Number / Mobile Money No.</label>
                  <input
                    type="text"
                    value={contactInfo.phone}
                    onChange={(e) => setContactInfo({ ...contactInfo, phone: e.target.value })}
                    className="w-full px-3 py-2 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300">Country</label>
                  <input
                    type="text"
                    value={contactInfo.country}
                    onChange={(e) => setContactInfo({ ...contactInfo, country: e.target.value })}
                    className="w-full px-3 py-2 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: REVIEW & SELECT PAYMENT METHOD */}
          {step === 5 && (
            <div className="space-y-6">
              
              {/* Order Summary & Coupon */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Order Summary */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3">
                  <div className="font-extrabold text-xs uppercase tracking-wider text-slate-400">Order Summary ({items.length} item)</div>
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between items-start text-xs border-b border-slate-100 dark:border-slate-800/80 pb-2">
                      {item.itemType === 'hosting' ? (
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white">
                            {item.packageName || 'Web Hosting Plan'}
                          </div>
                          <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">
                            Bound: <span className="font-mono">{item.domain}</span> ({item.billingCycle || 'annually'})
                          </div>
                        </div>
                      ) : (
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white">{item.domain}</span>
                          <span className="text-slate-400"> ({item.years} yr)</span>
                        </div>
                      )}
                      <span className="font-bold text-slate-800 dark:text-slate-200 ml-2">
                        {formatPrice(
                          item.itemType === 'hosting' ? item.registrationPrice : item.registrationPrice * item.years,
                          currency
                        )}
                      </span>
                    </div>
                  ))}

                  {/* Promo coupon input */}
                  <form onSubmit={handleApplyCoupon} className="flex gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="Promo code (e.g. WELCOME20)"
                      className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs uppercase font-bold"
                    />
                    <button type="submit" className="px-3 py-1.5 bg-slate-800 text-white font-bold text-xs rounded-lg">
                      Apply
                    </button>
                  </form>

                  {appliedCoupon && (
                    <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex justify-between">
                      <span>Promo Discount ({appliedCoupon.discountPercent}%):</span>
                      <span>-{taxBreakdown.discountFormatted}</span>
                    </div>
                  )}

                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{taxBreakdown.subtotalFormatted}</span>
                    </div>
                    {totalIcann > 0 && (
                      <div className="flex justify-between">
                        <span>ICANN Fees:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{taxBreakdown.icannFeeFormatted}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Taxes & Levies ({taxBreakdown.taxRatePercent}%):</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{taxBreakdown.taxAmountFormatted}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between text-sm font-black text-slate-900 dark:text-white">
                    <span>Total Due:</span>
                    <span className="text-blue-600 dark:text-blue-400">{taxBreakdown.grandTotalFormatted}</span>
                  </div>
                </div>

                {/* Order Reference Box */}
                <div className="p-4 rounded-xl border border-indigo-200 dark:border-indigo-900 bg-indigo-50/50 dark:bg-indigo-950/30 space-y-2">
                  <div className="text-xs font-bold text-indigo-900 dark:text-indigo-200 uppercase tracking-wider">
                    Order Reference Code
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black font-mono text-indigo-700 dark:text-indigo-300 bg-white dark:bg-indigo-900/60 px-3 py-1 rounded-lg border border-indigo-300 dark:border-indigo-700">
                      {orderId}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyOrderRef}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copiedOrderRef ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-[11px] text-indigo-800/80 dark:text-indigo-300 leading-tight">
                    Include this Order Reference code in your Mobile Money or Bank Transfer transaction notes for instant match.
                  </p>
                </div>

              </div>

              {/* PAYMENT METHOD SELECTION */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Select Payment System
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  
                  {/* Option 1: Paystack */}
                  {paymentSettings.paystack.enabled && (
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('paystack')}
                      className={`p-4 rounded-2xl border text-left transition-all relative ${
                        paymentMethod === 'paystack'
                          ? 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/30 ring-2 ring-emerald-500 shadow-md'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Smartphone className="w-5 h-5 text-emerald-600" />
                        <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200">
                          Instant
                        </span>
                      </div>
                      <div className="font-extrabold text-sm text-slate-900 dark:text-white">Paystack Gateway</div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        MTN MoMo, Telecel Cash, AirtelTigo, Cards & Bank Transfer (GHS / Africa).
                      </p>
                    </button>
                  )}

                  {/* Option 2: Custom / Manual Payment */}
                  {paymentSettings.customPayment.enabled && (
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('custom_manual')}
                      className={`p-4 rounded-2xl border text-left transition-all relative ${
                        paymentMethod === 'custom_manual'
                          ? 'border-purple-500 bg-purple-50/60 dark:bg-purple-950/30 ring-2 ring-purple-500 shadow-md'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Landmark className="w-5 h-5 text-purple-600" />
                        <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                          Manual / Direct
                        </span>
                      </div>
                      <div className="font-extrabold text-sm text-slate-900 dark:text-white">
                        {paymentSettings.customPayment.title}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {paymentSettings.customPayment.description}
                      </p>
                    </button>
                  )}

                </div>
              </div>

              {/* DYNAMIC CUSTOM PAYMENT INSTRUCTIONS CONTAINER */}
              {paymentMethod === 'custom_manual' && (
                <div className="p-5 rounded-2xl border border-purple-200 dark:border-purple-800 bg-purple-50/40 dark:bg-purple-950/20 space-y-4 animate-in fade-in">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-purple-600" />
                    <h5 className="font-extrabold text-sm text-purple-950 dark:text-purple-200">
                      Custom Payment Instructions & Account Details
                    </h5>
                  </div>

                  {/* Account Details Box */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    
                    {/* Bank Details */}
                    <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-purple-100 dark:border-purple-900 space-y-1.5 shadow-sm">
                      <div className="font-extrabold text-purple-900 dark:text-purple-300 flex items-center gap-1.5">
                        <Landmark className="w-4 h-4 text-purple-600" /> Bank Account Details
                      </div>
                      <div className="text-slate-600 dark:text-slate-300 flex items-center justify-between">
                        <span><strong>Bank:</strong> {paymentSettings.customPayment.bankName}</span>
                      </div>
                      <div className="text-slate-600 dark:text-slate-300 flex items-center justify-between">
                        <div>
                          <strong>Account No:</strong> <span className="font-mono font-bold text-purple-700 dark:text-purple-400">{paymentSettings.customPayment.accountNumber}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyText(paymentSettings.customPayment.accountNumber, 'bank_acc')}
                          className="px-2 py-0.5 rounded-lg bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-[10px] font-bold flex items-center gap-1 hover:bg-purple-200 transition-all"
                        >
                          {copiedItem === 'bank_acc' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedItem === 'bank_acc' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                      <div className="text-slate-600 dark:text-slate-300">
                        <strong>Name:</strong> {paymentSettings.customPayment.accountName}
                      </div>
                      {paymentSettings.customPayment.swiftCode && (
                        <div className="text-slate-600 dark:text-slate-300">
                          <strong>SWIFT:</strong> {paymentSettings.customPayment.swiftCode}
                        </div>
                      )}
                    </div>

                    {/* Mobile Money Details */}
                    <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-emerald-100 dark:border-emerald-900 space-y-1.5 shadow-sm">
                      <div className="font-extrabold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 text-emerald-600" /> Mobile Money Details (Ghana)
                      </div>
                      <div className="text-slate-600 dark:text-slate-300">
                        <strong>Networks:</strong> {paymentSettings.customPayment.momoProvider}
                      </div>
                      <div className="text-slate-600 dark:text-slate-300 flex items-center justify-between">
                        <div>
                          <strong>MoMo No:</strong> <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">{paymentSettings.customPayment.momoNumber}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyText(paymentSettings.customPayment.momoNumber, 'momo_num')}
                          className="px-2 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold flex items-center gap-1 hover:bg-emerald-200 transition-all"
                        >
                          {copiedItem === 'momo_num' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedItem === 'momo_num' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                      <div className="text-slate-600 dark:text-slate-300">
                        <strong>Registered Name:</strong> {paymentSettings.customPayment.momoName}
                      </div>
                    </div>

                  </div>

                  {/* Step-by-Step Text */}
                  <div className="p-3 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-purple-100 dark:border-purple-900 text-xs font-mono text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed">
                    {paymentSettings.customPayment.instructions}
                  </div>

                  {/* Ghana Mobile Money USSD Quick Guides */}
                  <div className="space-y-2 pt-1">
                    <div className="text-[11px] font-extrabold uppercase tracking-wider text-purple-900 dark:text-purple-300 flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-purple-600" />
                      Ghana Telco USSD Step-by-Step Shortcodes
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-[11px]">
                      {/* MTN */}
                      <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl space-y-1">
                        <div className="font-extrabold text-amber-900 dark:text-amber-300 flex items-center justify-between">
                          <span>MTN MoMo</span>
                          <span className="font-mono bg-amber-200 dark:bg-amber-900 px-1.5 py-0.5 rounded text-[10px]">*170#</span>
                        </div>
                        <p className="text-amber-800 dark:text-amber-400 text-[10px] leading-tight">
                          Dial *170# &gt; 1. Transfer &gt; 1. MoMo User &gt; Enter <strong>{paymentSettings.customPayment.momoNumber}</strong> &gt; Ref: <strong>{orderId}</strong>
                        </p>
                      </div>

                      {/* Telecel */}
                      <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-xl space-y-1">
                        <div className="font-extrabold text-rose-900 dark:text-rose-300 flex items-center justify-between">
                          <span>Telecel Cash</span>
                          <span className="font-mono bg-rose-200 dark:bg-rose-900 px-1.5 py-0.5 rounded text-[10px]">*110#</span>
                        </div>
                        <p className="text-rose-800 dark:text-rose-400 text-[10px] leading-tight">
                          Dial *110# &gt; 1. Send Money &gt; 1. Telecel/Other &gt; Enter <strong>{paymentSettings.customPayment.momoNumber}</strong> &gt; Ref: <strong>{orderId}</strong>
                        </p>
                      </div>

                      {/* AT */}
                      <div className="p-2.5 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 rounded-xl space-y-1">
                        <div className="font-extrabold text-blue-900 dark:text-blue-300 flex items-center justify-between">
                          <span>AT Money</span>
                          <span className="font-mono bg-blue-200 dark:bg-blue-900 px-1.5 py-0.5 rounded text-[10px]">*110#</span>
                        </div>
                        <p className="text-blue-800 dark:text-blue-400 text-[10px] leading-tight">
                          Dial *110# &gt; 1. Send Money &gt; Enter <strong>{paymentSettings.customPayment.momoNumber}</strong> &gt; Ref: <strong>{orderId}</strong>
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Proof of Payment Submission Form */}
                  <div className="space-y-3 pt-2 border-t border-purple-200 dark:border-purple-800/60">
                    <div className="font-bold text-xs text-purple-950 dark:text-purple-200">
                      Submit Your Payment Proof / Transaction ID
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                          Transaction ID / Reference Code
                        </label>
                        <input
                          type="text"
                          value={customProofRef}
                          onChange={(e) => setCustomProofRef(e.target.value)}
                          placeholder="e.g. MoMo Trans ID 1982736412"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                        />
                      </div>

                      <div>
                        <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                          Sender Phone / Account Name
                        </label>
                        <input
                          type="text"
                          value={customMomoSender}
                          onChange={(e) => setCustomMomoSender(e.target.value)}
                          placeholder="e.g. 0244112233 / Abena Osei"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                        />
                      </div>
                    </div>
                  </div>

                </div>
              )}

            </div>
          )}

          {/* STEP 6: CHECKOUT CONFIRMATION */}
          {step === 6 && (
            <div className="text-center py-8 space-y-4 animate-in fade-in">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <h3 className="text-xl font-black text-slate-900 dark:text-white">
                {paymentMethod === 'custom_manual' ? 'Payment Proof Submitted!' : 'Registration Complete!'}
              </h3>

              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {paymentMethod === 'custom_manual'
                  ? 'Your payment reference has been submitted to the admin team for approval. Your domain has been reserved.'
                  : 'Congratulations! Your payment was verified and your domain names have been registered and provisioned.'}
              </p>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-mono space-y-1 max-w-md mx-auto text-left">
                <div className="text-slate-400">Order ID: #{orderId}</div>
                <div className="text-slate-400">
                  Payment Method: {paymentMethod === 'paystack' ? 'Paystack Gateway' : 'Custom Payment (Bank / MoMo)'}
                </div>
                {paystackRef && <div className="text-slate-400">Paystack Ref: {paystackRef}</div>}
                <div className="text-slate-400">
                  Status: {paymentMethod === 'custom_manual' ? 'Pending Admin Approval' : 'Registered & Active'}
                </div>
                <div className="text-slate-400">WHOIS Privacy: Active (Protected)</div>
              </div>

              {/* Direct Website Address Access Links */}
              <div className="space-y-2 max-w-md mx-auto pt-2">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 text-left">
                  Your New Domain Website Address:
                </div>
                {items.map((item) => (
                  <div key={item.id} className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between gap-3 shadow-sm">
                    <div className="text-left font-mono text-xs font-bold text-slate-900 dark:text-white truncate">
                      https://{item.domain}
                    </div>
                    <a
                      href={`https://${item.domain}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 transition-all shadow shrink-0"
                    >
                      <span>Visit Website</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Wizard Footer Controls */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
          {step > 1 && step < 6 ? (
            <button
              onClick={() => setStep(step - 1)}
              className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </button>
          ) : <div />}

          {step < 5 && (
            <button
              onClick={() => setStep(step + 1)}
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 flex items-center gap-1.5 transition-all"
            >
              Next Step <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {step === 5 && (
            <button
              onClick={handleProceedToPayment}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all hover:scale-105"
            >
              {paymentMethod === 'paystack' ? (
                <>
                  <Smartphone className="w-4 h-4" />
                  <span>Pay with Paystack ({formatPrice(grandTotal, currency)})</span>
                </>
              ) : (
                <>
                  <Landmark className="w-4 h-4" />
                  <span>Submit Payment Proof ({formatPrice(grandTotal, currency)})</span>
                </>
              )}
            </button>
          )}

          {step === 6 && (
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md mx-auto flex items-center gap-2"
            >
              <User className="w-4 h-4" />
              <span>Go to Client Portal & Services</span>
            </button>
          )}
        </div>

      </div>

      {/* Paystack Modal trigger */}
      {isPaystackOpen && (
        <PaystackCheckoutModal
          amountInUsd={grandTotal}
          currency={currency}
          customerEmail={contactInfo.email}
          customerName={`${contactInfo.firstName} ${contactInfo.lastName}`}
          paystackConfig={paymentSettings.paystack}
          orderId={orderId}
          onSuccess={handlePaystackSuccess}
          onClose={() => setIsPaystackOpen(false)}
        />
      )}

    </div>
  );
};
