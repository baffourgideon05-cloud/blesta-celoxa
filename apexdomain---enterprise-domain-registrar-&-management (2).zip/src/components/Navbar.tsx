import React, { useState } from 'react';
import { 
  Globe, 
  Search, 
  FolderGit2, 
  Sparkles, 
  Layers, 
  BookOpen, 
  ShoppingCart, 
  User, 
  ChevronDown, 
  Building2, 
  Menu, 
  X, 
  LayoutGrid, 
  Server, 
  Zap, 
  CreditCard, 
  Headphones, 
  HelpCircle, 
  ShieldCheck, 
  Compass, 
  Settings, 
  Lock, 
  ShieldAlert, 
  TrendingUp,
  Sun,
  Moon,
  LogOut
} from 'lucide-react';
import { Currency, Language } from '../types';
import { CURRENCY_RATES } from '../utils/domainSearchEngine';
import { FeatureAuditMatrixModal } from './FeatureAuditMatrixModal';
import { systemDatabase } from '../services/systemDatabase';

interface NavbarProps {
  currentView?: string;
  activeTab?: string;
  siteName?: string;
  logoUrl?: string;
  setCurrentView?: (view: any) => void;
  setActiveTab?: (tab: string) => void;
  cartCount?: number;
  wishlistCount?: number;
  compareCount?: number;
  userDomainsCount?: number;
  onOpenCart?: () => void;
  openCart?: () => void;
  onOpenCompare?: () => void;
  openCompare?: () => void;
  openAiBrain?: () => void;
  onOpenAiBrain?: () => void;
  currency?: Currency;
  setCurrency?: (curr: Currency) => void;
  language?: Language;
  setLanguage?: (lang: Language) => void;
  isDarkMode?: boolean;
  darkMode?: boolean;
  setIsDarkMode?: (val: boolean) => void;
  setDarkMode?: (val: boolean) => void;
  onOpenSearch?: () => void;
  onOpenCommandCenter?: () => void;
  onOpenAuthModal?: () => void;
  onLockSession?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  activeTab,
  siteName = 'Celoxa Ghana Cloud Systems',
  logoUrl,
  setCurrentView,
  setActiveTab,
  cartCount = 0,
  wishlistCount = 0,
  compareCount = 0,
  userDomainsCount = 0,
  onOpenCart,
  openCart,
  onOpenCompare,
  openCompare,
  openAiBrain,
  onOpenAiBrain,
  currency = 'USD',
  setCurrency,
  language = 'EN',
  setLanguage,
  isDarkMode,
  darkMode,
  setIsDarkMode,
  setDarkMode,
  onOpenSearch,
  onOpenCommandCenter,
  onOpenAuthModal,
  onLockSession,
}) => {
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);
  const [allPagesOpen, setAllPagesOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [auditModalOpen, setAuditModalOpen] = useState(false);

  const activeView = currentView || activeTab || 'search';
  const currentUser = systemDatabase.getCurrentUser();
  const isAdminOrStaff = currentUser && ['admin', 'super_admin', 'administrator', 'staff'].includes(currentUser.role);

  const handleNavigate = (view: string, isAdminOnly = false) => {
    if (isAdminOnly && !isAdminOrStaff) {
      alert(
        `ACCESS DENIED: The module "${view}" is restricted to Admin and Staff accounts only.\n\nPlease sign in with your Google Admin account (e.g., baffourgideon05@gmail.com) or Admin credentials.`
      );
      if (onOpenAuthModal) onOpenAuthModal();
      return;
    }

    const clientProtectedViews = ['client_portal', 'dashboard', 'management', 'command_center'];
    if (clientProtectedViews.includes(view) && !currentUser) {
      if (onOpenAuthModal) onOpenAuthModal();
      setAllPagesOpen(false);
      setMobileMenuOpen(false);
      return;
    }

    let target = view;
    if (view === 'directory') target = 'tlds';
    if (view === 'guides') target = 'academy';

    if (setCurrentView) setCurrentView(target);
    if (setActiveTab) setActiveTab(view);
    setAllPagesOpen(false);
    setMobileMenuOpen(false);
  };

  const handleCartClick = () => {
    if (onOpenCart) onOpenCart();
    else if (openCart) openCart();
  };

  const handleCompareClick = () => {
    if (onOpenCompare) onOpenCompare();
    else if (openCompare) openCompare();
  };

  const handleAiClick = () => {
    if (onOpenAiBrain) onOpenAiBrain();
    else if (openAiBrain) openAiBrain();
    setAllPagesOpen(false);
    setMobileMenuOpen(false);
  };

  const darkVal = isDarkMode ?? darkMode ?? false;
  const handleToggleDark = () => {
    if (setIsDarkMode) setIsDarkMode(!darkVal);
    else if (setDarkMode) setDarkMode(!darkVal);
  };

  const clientPagesList = [
    {
      id: 'client_portal',
      title: 'Client Account Dashboard',
      subtitle: 'Overview, Wallet Balance, Active Services & Orders',
      icon: LayoutGrid,
      badge: 'Client Area',
      color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/80',
      action: () => handleNavigate('client_portal'),
    },
    {
      id: 'search',
      title: 'Domain Search Engine',
      subtitle: 'Instant availability, valuation & AI suggestions',
      icon: Search,
      badge: 'Client',
      color: 'text-blue-500 bg-blue-50 dark:bg-blue-950/60',
      action: () => handleNavigate('search'),
    },
    {
      id: 'tlds',
      title: 'TLD Directory Catalog',
      subtitle: 'Browse 500+ extensions (.com, .ai, .io, .gh, .org)',
      icon: FolderGit2,
      badge: 'Catalog',
      color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/60',
      action: () => handleNavigate('tlds'),
    },
    {
      id: 'ai_brain',
      title: 'AI Domain Brain Generator',
      subtitle: 'Smart startup naming, valuation & brand generator',
      icon: Sparkles,
      badge: 'AI Powered',
      color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-950/60',
      action: handleAiClick,
    },
    {
      id: 'bulk',
      title: 'Bulk Operations Hub',
      subtitle: 'Batch domain search, multi-TLD lookup & registration',
      icon: Layers,
      badge: 'Pro Tool',
      color: 'text-amber-500 bg-amber-50 dark:bg-amber-950/60',
      action: () => handleNavigate('bulk'),
    },
    {
      id: 'hosting_packages',
      title: 'Web Hosting & Cloud VPS',
      subtitle: 'cPanel NVMe shared hosting, Managed WordPress & KVM VPS servers',
      icon: Server,
      badge: 'NVMe Speed',
      color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/80',
      action: () => handleNavigate('hosting_packages'),
    },
    {
      id: 'command_center',
      title: 'Customer Command Center',
      subtitle: 'cPanel Hosting, Server Clusters, Invoices & Support',
      icon: User,
      badge: 'Client Hub',
      color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/80',
      action: () => {
        if (onOpenCommandCenter) onOpenCommandCenter();
        else handleNavigate('command_center');
      },
    },
    {
      id: 'academy',
      title: 'Learning Hub & Academy',
      subtitle: 'Registrar tutorials, ICANN compliance & DNS guides',
      icon: BookOpen,
      badge: 'Docs',
      color: 'text-sky-500 bg-sky-50 dark:bg-sky-950/60',
      action: () => handleNavigate('academy'),
    },
  ];

  const adminPagesList = [
    {
      id: 'management',
      title: 'Domain Infrastructure & Registrar Hub',
      subtitle: 'Registrar API sync, EPP authorization keys, authoritative DNS audits',
      icon: Building2,
      badge: 'Admin Only',
      color: 'text-purple-600 bg-purple-50 dark:bg-purple-950/80',
      action: () => handleNavigate('management', true),
    },
    {
      id: 'visitor_analytics',
      title: 'Visitor Analytics & Trends',
      subtitle: 'Monthly domain search trends, conversion rates & traffic insights',
      icon: TrendingUp,
      badge: 'Admin Analytics',
      color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/80',
      action: () => handleNavigate('visitor_analytics', true),
    },
    {
      id: 'admin_hosting_packages',
      title: 'Hosting Packages Manager',
      subtitle: 'Create, edit & publish Web Hosting and KVM VPS plans live',
      icon: Server,
      badge: 'Admin Catalog',
      color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/80',
      action: () => handleNavigate('admin_hosting_packages', true),
    },
    {
      id: 'hosting_provision',
      title: 'Hosting Auto-Provisioning System',
      subtitle: 'cPanel, DirectAdmin, Plesk & Cloud instant account builds',
      icon: Server,
      badge: 'Admin Only',
      color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/80',
      action: () => handleNavigate('hosting_provision', true),
    },
    {
      id: 'staff_portal',
      title: 'Staff Operations Portal',
      subtitle: 'Internal ticketing desk, server health & client lookup',
      icon: Headphones,
      badge: 'Staff Only',
      color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/80',
      action: () => handleNavigate('staff_portal', true),
    },
    {
      id: 'admin_iam',
      title: 'Admin IAM & Staff Access',
      subtitle: 'Manage RBAC permissions, invite staff & audit security logs',
      icon: ShieldCheck,
      badge: 'Admin IAM',
      color: 'text-purple-600 bg-purple-50 dark:bg-purple-950/80',
      action: () => handleNavigate('admin_iam', true),
    },
    {
      id: 'settings',
      title: 'System Settings Control Panel',
      subtitle: 'Global parameters, anti-spam, SMTP, security & currency sync',
      icon: Settings,
      badge: 'Admin Panel',
      color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/80',
      action: () => handleNavigate('settings', true),
    },
    {
      id: 'feature_audit',
      title: 'System Feature Capability Audit Matrix',
      subtitle: 'Specs for Currency, Anti-Spam, Hosting, Domains & PDFs',
      icon: ShieldAlert,
      badge: 'Audit Specs',
      color: 'text-rose-600 bg-rose-50 dark:bg-rose-950/80',
      action: () => {
        if (!isAdminOrStaff) {
          alert('ACCESS DENIED: Capability matrix logs are restricted to Admin/Staff.');
          if (onOpenAuthModal) onOpenAuthModal();
          return;
        }
        setAuditModalOpen(true);
        setAllPagesOpen(false);
        setMobileMenuOpen(false);
      },
    },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-2 sm:gap-4">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 xl:gap-6 min-w-0">
            <button 
              onClick={() => handleNavigate('search')}
              className="flex items-center gap-2 sm:gap-2.5 text-left focus:outline-none group shrink-0 min-w-0"
            >
              {logoUrl ? (
                <div className="h-9 sm:h-10 px-1.5 sm:px-2 bg-slate-900/10 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center overflow-hidden shadow-sm group-hover:scale-105 transition-transform shrink-0">
                  <img src={logoUrl} alt={siteName} className="h-6 sm:h-7 w-auto object-contain max-w-[100px] sm:max-w-[140px]" />
                </div>
              ) : (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform shrink-0">
                  <Globe className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
              )}
              <div className="min-w-0">
                <div className="flex items-center gap-1">
                  <span className="font-extrabold text-sm sm:text-base lg:text-xl tracking-tight text-slate-900 dark:text-white truncate max-w-[160px] xs:max-w-[220px] sm:max-w-[300px] md:max-w-none">{siteName}</span>
                </div>
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 font-medium -mt-0.5 truncate hidden sm:block">Accredited Cloud & Domain Platform</p>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1">
              {/* Dedicated Client Dashboard Button */}
              <button
                onClick={() => handleNavigate('client_portal')}
                className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 shadow-sm ${
                  activeView === 'client_portal' || activeView === 'dashboard'
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-blue-500/30 ring-2 ring-blue-400'
                    : 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/50 border border-blue-200 dark:border-blue-800'
                }`}
                title="Access Client Account Dashboard"
              >
                <LayoutGrid className="w-3.5 h-3.5 text-blue-500" />
                <span>Dashboard</span>
                {!currentUser && (
                  <span className="px-1 py-0.2 text-[8px] uppercase font-black bg-blue-200 dark:bg-blue-800 text-blue-900 dark:text-blue-100 rounded">
                    Login
                  </span>
                )}
              </button>

              <button
                onClick={() => handleNavigate('search')}
                className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                  activeView === 'search'
                    ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 font-extrabold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                Domain Search
              </button>

              <button
                onClick={() => handleNavigate('tlds')}
                className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                  activeView === 'tlds' || activeView === 'directory'
                    ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 font-extrabold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <FolderGit2 className="w-3.5 h-3.5" />
                TLD Directory
              </button>

              <button
                onClick={handleAiClick}
                className="px-3 py-2 rounded-lg text-xs font-extrabold transition-all text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 flex items-center gap-1.5 relative group"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
                AI Brain
                <span className="px-1 py-0.2 text-[8px] font-black uppercase bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded">AI</span>
              </button>

              <button
                onClick={() => handleNavigate('bulk')}
                className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                  activeView === 'bulk'
                    ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 font-extrabold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                Bulk Tools
              </button>

              <button
                onClick={() => handleNavigate('hosting_packages')}
                className={`px-3 py-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 ${
                  activeView === 'hosting_packages'
                    ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-extrabold ring-1 ring-indigo-500'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Server className="w-3.5 h-3.5 text-indigo-500" />
                Hosting Plans
              </button>

              <button
                onClick={() => handleNavigate('management')}
                className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                  activeView === 'management'
                    ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 font-extrabold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                Domain Hub
              </button>

              <button
                onClick={() => {
                  if (onOpenCommandCenter) onOpenCommandCenter();
                  else handleNavigate('command_center');
                }}
                className={`px-3 py-2 rounded-lg text-xs font-extrabold transition-colors flex items-center gap-1.5 ${
                  activeView === 'command_center'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                Command Center
                <span className="px-1 py-0.2 text-[8px] uppercase font-black bg-emerald-200 dark:bg-emerald-800 text-emerald-900 dark:text-emerald-100 rounded">Client</span>
              </button>

              <button
                onClick={() => handleNavigate('academy')}
                className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                  activeView === 'academy' || activeView === 'guides'
                    ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 font-extrabold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                Academy
              </button>

              {/* ALL PAGES MEGA MENU DROPDOWN BUTTON */}
              <div className="relative">
                <button
                  onClick={() => setAllPagesOpen(!allPagesOpen)}
                  className={`px-3 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 border ${
                    allPagesOpen
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
                      : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  title="View All Site Pages"
                >
                  <LayoutGrid className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                  <span>All Pages</span>
                  <ChevronDown className={`w-3 h-3 transition-transform ${allPagesOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* ALL PAGES DROPDOWN PANEL */}
                {allPagesOpen && (
                  <div className="absolute left-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-3 z-50 animate-in fade-in zoom-in-95 max-h-[80vh] overflow-y-auto">
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800 px-2">
                      <div className="flex items-center gap-2">
                        <Compass className="w-4 h-4 text-indigo-500" />
                        <span className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">Site Directory & Navigation</span>
                      </div>
                      <span className="text-[10px] font-bold text-slate-400">12 Total Pages</span>
                    </div>

                    {/* SECTION 1: CLIENT ACCESSIBLE PAGES */}
                    <div className="space-y-1 mb-3">
                      <div className="px-2 py-1 text-[10px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/40 rounded-lg flex items-center justify-between">
                        <span>Client Portal Pages</span>
                        <span className="text-[9px] font-bold text-slate-400">Public / Client Access</span>
                      </div>

                      {clientPagesList.map((page) => {
                        const PageIcon = page.icon;
                        const isCurrent = activeView === page.id;
                        return (
                          <button
                            key={page.id}
                            onClick={page.action}
                            className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start gap-3 group ${
                              isCurrent
                                ? 'bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800/60'
                                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60 border border-transparent'
                            }`}
                          >
                            <div className={`p-2 rounded-lg shrink-0 ${page.color}`}>
                              <PageIcon className="w-4 h-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                                  {page.title}
                                </span>
                                {page.badge && (
                                  <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0">
                                    {page.badge}
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight mt-0.5 line-clamp-1">
                                {page.subtitle}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* SECTION 2: ADMIN & STAFF RESTRICTED SYSTEM - ONLY DISPLAYED FOR ADMIN/STAFF */}
                    {isAdminOrStaff && (
                      <div className="space-y-1">
                        <div className="px-2 py-1 text-[10px] font-black uppercase tracking-wider text-rose-600 dark:text-rose-400 bg-rose-50/50 dark:bg-rose-950/40 rounded-lg flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3 text-rose-500" />
                            <span>Admin & Staff System Control</span>
                          </div>
                          <span className="text-[9px] font-bold text-amber-500">
                            Admin Granted
                          </span>
                        </div>

                        {adminPagesList.map((page) => {
                          const PageIcon = page.icon;
                          const isCurrent = activeView === page.id;
                          return (
                            <button
                              key={page.id}
                              onClick={page.action}
                              className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start gap-3 group relative ${
                                isCurrent
                                  ? 'bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60'
                                  : 'hover:bg-slate-50 dark:hover:bg-slate-800/60 border border-transparent'
                              }`}
                            >
                              <div className={`p-2 rounded-lg shrink-0 ${page.color}`}>
                                <PageIcon className="w-4 h-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1">
                                  <span className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors flex items-center gap-1">
                                    {page.title}
                                  </span>
                                  {page.badge && (
                                    <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 shrink-0">
                                      {page.badge}
                                    </span>
                                  )}
                                </div>
                                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight mt-0.5 line-clamp-1">
                                  {page.subtitle}
                                </p>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </nav>
          </div>

          {/* Right Action Bar */}
          <div className="flex items-center gap-1.5 sm:gap-3">
            {/* Global Search Button - Compact on Mobile */}
            {onOpenSearch && (
              <button
                onClick={onOpenSearch}
                className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center gap-1.5 transition-colors text-xs font-bold shrink-0"
                title="Global Search (Ctrl+K)"
                aria-label="Search"
              >
                <Search className="w-4 h-4 text-emerald-500" />
                <span className="hidden sm:inline">Search</span>
              </button>
            )}
            
            {/* Lock Session Button - Hidden on mobile screens to free up header space */}
            {onLockSession && (
              <button
                onClick={onLockSession}
                className="hidden lg:flex p-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-600 dark:text-amber-400 text-xs font-bold items-center gap-1.5 transition-all shrink-0"
                title="Lock Session Now (Security Auto-Lock Active)"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden xl:inline">Lock Screen</span>
              </button>
            )}
            
            {/* Currency Selector - Hidden on mobile screens, accessible inside Mobile Drawer */}
            <div className="relative hidden sm:block">
              <button
                onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors shrink-0"
              >
                <span>{currency} ({CURRENCY_RATES[currency]?.symbol})</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {currencyDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1 z-50 animate-in fade-in zoom-in-95">
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">Select Currency</div>
                  {Object.keys(CURRENCY_RATES).map((curr) => (
                    <button
                      key={curr}
                      onClick={() => {
                        if (setCurrency) setCurrency(curr as Currency);
                        setCurrencyDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs font-medium flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors ${
                        currency === curr ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-900/20' : 'text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span>{CURRENCY_RATES[curr].name}</span>
                      <span className="font-mono text-slate-400">{CURRENCY_RATES[curr].symbol}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Cart Drawer Button - Prominent & Compact */}
            <button
              onClick={handleCartClick}
              className="relative p-2 sm:px-3 sm:py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center gap-1.5 sm:gap-2 shadow-md shadow-blue-600/20 transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0"
              title={currentUser ? 'Shopping Cart' : 'Sign in to View Cart'}
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="w-4 h-4" />
              <span className="hidden sm:inline">Cart</span>
              {currentUser ? (
                <span className="px-1.5 py-0.2 sm:py-0.5 rounded-full bg-white/20 text-white text-[10px] sm:text-[11px] font-bold">
                  {cartCount}
                </span>
              ) : (
                <span className="px-1.5 py-0.2 sm:py-0.5 rounded-full bg-amber-400/30 text-amber-100 text-[10px] sm:text-[11px] font-bold flex items-center gap-0.5" title="Login Required">
                  <Lock className="w-2.5 h-2.5" />
                </span>
              )}
            </button>

            {/* User Account / Auth Button - Compact on Mobile */}
            <button
              onClick={onOpenAuthModal}
              className="p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 font-extrabold text-xs flex items-center gap-2 transition-all shadow-sm shrink-0"
              title="Client Account & Profile"
              aria-label="User Profile"
            >
              {currentUser ? (
                <>
                  <img
                    src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop'}
                    alt="User Avatar"
                    className="w-6 h-6 sm:w-5 sm:h-5 rounded-full object-cover border border-blue-500"
                  />
                  <span className="hidden md:inline">{currentUser.fullName.split(' ')[0]}</span>
                  <span className="hidden md:inline px-1.5 py-0.2 text-[9px] bg-emerald-500/20 text-emerald-400 rounded font-black uppercase">
                    {currentUser.role}
                  </span>
                </>
              ) : (
                <>
                  <User className="w-4 h-4 text-indigo-500" />
                  <span className="hidden sm:inline">Sign In</span>
                </>
              )}
            </button>

            {/* Mobile Menu Toggle - Clean Touch Target */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 flex items-center justify-center shrink-0"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-rose-500" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu - COMPLETE CLEAN CONTROLS */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-4 max-h-[85vh] overflow-y-auto animate-in slide-in-from-top-2 shadow-2xl">
          
          {/* USER ACCOUNT QUICK CARD */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3">
            {currentUser ? (
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop'}
                  alt={currentUser.fullName}
                  className="w-10 h-10 rounded-full object-cover border-2 border-blue-500 shrink-0"
                />
                <div className="min-w-0">
                  <div className="text-xs font-black text-slate-900 dark:text-white truncate">
                    {currentUser.fullName}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {currentUser.email}
                  </div>
                  <span className="inline-block mt-0.5 px-1.5 py-0.2 text-[9px] bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded font-black uppercase">
                    {currentUser.role}
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-900 dark:text-white">Guest User</div>
                  <div className="text-[11px] text-slate-500">Sign in to manage domains & billing</div>
                </div>
              </div>
            )}

            <button
              onClick={() => {
                if (onOpenAuthModal) onOpenAuthModal();
                setMobileMenuOpen(false);
              }}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm shrink-0"
            >
              {currentUser ? 'Manage' : 'Sign In'}
            </button>
          </div>

          {/* QUICK PREFERENCES TOOLBAR: CURRENCY & THEME & LOCK */}
          <div className="space-y-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Display Currency
              </span>
              <span className="text-[10px] font-mono font-bold text-blue-600 dark:text-blue-400">
                Active: {currency} ({CURRENCY_RATES[currency]?.symbol})
              </span>
            </div>

            {/* Interactive Currency Chips for Mobile */}
            <div className="grid grid-cols-3 gap-1.5">
              {Object.keys(CURRENCY_RATES).map((curr) => {
                const isSelected = currency === curr;
                return (
                  <button
                    key={curr}
                    onClick={() => {
                      if (setCurrency) setCurrency(curr as Currency);
                    }}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-sm ring-1 ring-blue-400'
                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <span>{curr}</span>
                    <span className="text-[10px] opacity-75 font-mono">({CURRENCY_RATES[curr].symbol})</span>
                  </button>
                );
              })}
            </div>

            {/* Theme Toggle & Security Lock */}
            <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between gap-2">
              <button
                onClick={handleToggleDark}
                className="flex-1 py-2 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                {darkVal ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-500" />}
                <span>{darkVal ? 'Light Mode' : 'Dark Mode'}</span>
              </button>

              {onLockSession && (
                <button
                  onClick={() => {
                    onLockSession();
                    setMobileMenuOpen(false);
                  }}
                  className="py-2 px-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-amber-500/20 transition-all"
                  title="Lock Session Screen"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Lock Screen</span>
                </button>
              )}
            </div>
          </div>

          {/* GLOBAL SEARCH TRIGGER */}
          {onOpenSearch && (
            <button
              onClick={() => {
                onOpenSearch();
                setMobileMenuOpen(false);
              }}
              className="w-full p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-extrabold text-emerald-800 dark:text-emerald-300 flex items-center justify-center gap-2 shadow-sm"
            >
              <Search className="w-4 h-4 text-emerald-500" />
              <span>Universal Search (Domains, Billing, Hosting)</span>
            </button>
          )}

          {/* GROUP 1: CLIENT PORTAL PAGES */}
          <div className="space-y-1">
            <div className="text-[10px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 px-2 pb-1 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span>Client Services & Tools ({clientPagesList.length})</span>
              <span className="text-blue-500 font-bold">Fast Access</span>
            </div>

            <div className="space-y-1 pt-1">
              {clientPagesList.map((page) => {
                const PageIcon = page.icon;
                const isCurrent = activeView === page.id;
                return (
                  <button
                    key={page.id}
                    onClick={page.action}
                    className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between gap-3 ${
                      isCurrent
                        ? 'bg-blue-600 text-white font-extrabold shadow-sm'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${isCurrent ? 'bg-white/20 text-white' : page.color}`}>
                        <PageIcon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold leading-tight">{page.title}</div>
                        <p className={`text-[10px] leading-tight mt-0.5 ${isCurrent ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'}`}>
                          {page.subtitle}
                        </p>
                      </div>
                    </div>
                    {page.badge && (
                      <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                        isCurrent ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}>
                        {page.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* GROUP 2: ADMIN & STAFF SYSTEM CONTROL - ONLY DISPLAYED FOR ADMIN/STAFF */}
          {isAdminOrStaff && (
            <div className="space-y-1">
              <div className="text-[10px] font-black uppercase tracking-wider text-rose-600 dark:text-rose-400 px-2 pb-1 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-rose-500" />
                  <span>Admin & Staff Control ({adminPagesList.length})</span>
                </span>
                <span className="text-amber-500 font-bold">Granted</span>
              </div>

              <div className="space-y-1 pt-1">
                {adminPagesList.map((page) => {
                  const PageIcon = page.icon;
                  const isCurrent = activeView === page.id;
                  return (
                    <button
                      key={page.id}
                      onClick={page.action}
                      className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between gap-3 ${
                        isCurrent
                          ? 'bg-rose-600 text-white font-extrabold shadow-sm'
                          : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${isCurrent ? 'bg-white/20 text-white' : page.color}`}>
                          <PageIcon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold leading-tight flex items-center gap-1">
                            {page.title}
                          </div>
                          <p className={`text-[10px] leading-tight mt-0.5 ${isCurrent ? 'text-rose-100' : 'text-slate-500 dark:text-slate-400'}`}>
                            {page.subtitle}
                          </p>
                        </div>
                      </div>
                      {page.badge && (
                        <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                          isCurrent ? 'bg-white/20 text-white' : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                        }`}>
                          {page.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SYSTEM FEATURE AUDIT MATRIX MODAL */}
      <FeatureAuditMatrixModal
        isOpen={auditModalOpen}
        onClose={() => setAuditModalOpen(false)}
      />
    </header>
  );
};
