import React, { useState } from 'react';
import { 
  X, 
  UserPlus, 
  ShoppingBag, 
  Globe, 
  Server, 
  CheckCircle2, 
  Send, 
  CreditCard, 
  DollarSign, 
  ShieldCheck, 
  Layers, 
  Sliders,
  Sparkles,
  Info
} from 'lucide-react';
import { SystemUser, systemDatabase } from '../services/systemDatabase';
import { INITIAL_HOSTING_PLANS } from '../data/hostingCatalogueData';
import { registrarManager } from '../services/registrarManager';
import { hostingControlPanelManager } from '../services/hostingControlPanelManager';
import { provisioningQueueEngine } from '../services/provisioningQueueEngine';
import { commerceEngine } from '../services/commerceEngine';
import { emailTemplateEngine } from '../services/emailTemplateEngine';
import { RegistrarProviderType, ControlPanelProviderType, CartItem } from '../types';

interface AdminOrderOnBehalfModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const AdminOrderOnBehalfModal: React.FC<AdminOrderOnBehalfModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const users = systemDatabase.getAllUsers().filter((u) => u.role === 'customer' || !u.role);
  const registrars = registrarManager.getRegistrars();
  const servers = hostingControlPanelManager.getServers();

  const [selectedUserId, setSelectedUserId] = useState<string>(users[0]?.id || '');
  const [isNewUser, setIsNewUser] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');

  const [serviceType, setServiceType] = useState<'domain' | 'hosting' | 'bundle'>('bundle');
  const [targetDomain, setTargetDomain] = useState('enterprise-client.com.gh');
  const [selectedPlanId, setSelectedPlanId] = useState(INITIAL_HOSTING_PLANS[0]?.id || 'starter');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually' | 'triennially'>('annually');
  const [customPrice, setCustomPrice] = useState<number>(18.5);

  const [registrarProvider, setRegistrarProvider] = useState<RegistrarProviderType>('internal');
  const [hostingServerId, setHostingServerId] = useState<string>(servers[0]?.id || '');

  // Nameservers
  const [nameserverMode, setNameserverMode] = useState<'system_default' | 'custom'>('system_default');
  const [customNs1, setCustomNs1] = useState('ns1.celoxaghana.online');
  const [customNs2, setCustomNs2] = useState('ns2.celoxaghana.online');
  const [customNs3, setCustomNs3] = useState('');
  const [customNs4, setCustomNs4] = useState('');

  // Action mode
  const [fulfillmentMode, setFulfillmentMode] = useState<'instant_paid' | 'send_invoice'>('instant_paid');
  const [adminNotes, setAdminNotes] = useState('VIP Corporate Onboarding - Direct Admin Order');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successResult, setSuccessResult] = useState<{ orderNumber: string; invoiceNumber: string; mode: string } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let customer: SystemUser | undefined;

      if (isNewUser) {
        if (!newUserName || !newUserEmail) {
          alert('Please enter customer full name and email.');
          setIsSubmitting(false);
          return;
        }
        customer = systemDatabase.createCustomerUser({
          fullName: newUserName,
          email: newUserEmail,
          phone: newUserPhone,
          role: 'customer',
        });
      } else {
        customer = users.find((u) => u.id === selectedUserId) || users[0];
      }

      if (!customer) {
        alert('Customer record required.');
        setIsSubmitting(false);
        return;
      }

      const plan = INITIAL_HOSTING_PLANS.find((p) => p.id === selectedPlanId) || INITIAL_HOSTING_PLANS[0];
      const selectedServer = servers.find((s) => s.id === hostingServerId) || servers[0];

      const activeNameservers =
        nameserverMode === 'system_default'
          ? selectedServer.defaultNameservers
          : [customNs1, customNs2, customNs3, customNs4].filter(Boolean);

      const domainTrimmed = targetDomain.toLowerCase().trim();
      const dotIndex = domainTrimmed.indexOf('.');
      const tld = dotIndex !== -1 ? domainTrimmed.substring(dotIndex + 1) : 'com';

      const cartItem: CartItem = {
        id: `cart-admin-${Date.now()}`,
        itemType: serviceType === 'domain' ? ('domain' as const) : ('hosting' as const),
        domain: domainTrimmed,
        tld,
        packageName: plan.name,
        planId: plan.id,
        registrationPrice: customPrice,
        renewalPrice: customPrice,
        years: 1,
        billingCycle,
        privacyProtection: true,
        emailForwarding: true,
        dnssecEnabled: false,
        hostingAddon: serviceType !== 'domain',
        icannFee: 0.18,
        isPremium: false,
        nameserverConfig: {
          mode: nameserverMode,
          ns1: activeNameservers[0] || 'ns1.celoxaghana.online',
          ns2: activeNameservers[1] || 'ns2.celoxaghana.online',
          ns3: activeNameservers[2],
          ns4: activeNameservers[3],
          lastUpdated: new Date().toISOString(),
          syncStatus: 'synced',
        },
        registrarProvider,
        hostingServerId,
      };

      const adminUser = systemDatabase.getCurrentUser();

      // Create Order & Invoice in Commerce Engine
      const order = commerceEngine.createOrderFromCart({
        user: customer,
        customerName: customer.fullName,
        customerEmail: customer.email,
        customerPhone: customer.phone,
        cartItems: [cartItem],
        currency: 'GHS',
        appliedDiscount: 0,
        tax: 0,
        paymentChannel: fulfillmentMode === 'instant_paid' ? 'custom_manual' : 'custom_manual',
      });

      if (fulfillmentMode === 'instant_paid') {
        // Mark as Paid & Auto-Provision immediately
        commerceEngine.markOrderPaidAndProvision({
          orderId: order.id,
          paymentReference: `ADMIN-ONBEHALF-${adminUser.fullName || 'Admin'}`,
          paymentChannel: 'Admin Direct Authorized Provisioning',
          paidAmount: customPrice,
        });

        // Trigger Queue Job explicitly
        provisioningQueueEngine.enqueueJob({
          orderId: order.orderNumber,
          invoiceId: order.invoiceId,
          customerId: customer.id,
          customerName: customer.fullName,
          customerEmail: customer.email,
          domain: targetDomain,
          packageName: plan.name,
          planId: plan.id,
          serviceType,
          registrarProvider,
          hostingProvider: selectedServer.provider,
          hostingServerId: selectedServer.id,
          nameserverMode,
          nameservers: activeNameservers,
        });

        systemDatabase.logAuditEvent(
          'ADMIN_PURCHASE_ON_BEHALF_PAID',
          order.orderNumber,
          `Admin ${adminUser.fullName} provisioned ${targetDomain} directly for customer ${customer.fullName}`
        );
      } else {
        // Generate Invoice and Send Payment Instructions
        emailTemplateEngine.dispatchEmail({
          templateId: 'INVOICE_CREATED',
          recipientEmail: customer.email,
          recipientName: customer.fullName,
          variables: {
            customerName: customer.fullName,
            invoiceNumber: order.invoiceId,
            orderId: order.orderNumber,
            amount: customPrice.toFixed(2),
            currency: 'GH₵',
            paymentInstructions: `Please transfer to Celoxa Ghana Mobile Money: 0244123456 (MTN MoMo: Celoxa Cloud Ltd) or Bank: Ecobank 1441002345678. Reference: ${order.invoiceId}`,
            dueDate: new Date(Date.now() + 7 * 86400000).toLocaleDateString(),
            viewInvoiceUrl: '#',
            userId: customer.id,
          },
          relatedOrderId: order.id,
        });

        systemDatabase.logAuditEvent(
          'ADMIN_PURCHASE_ON_BEHALF_INVOICED',
          order.orderNumber,
          `Admin ${adminUser.fullName} created invoice ${order.invoiceId} for customer ${customer.fullName}`
        );
      }

      setSuccessResult({
        orderNumber: order.orderNumber,
        invoiceNumber: order.invoiceId,
        mode: fulfillmentMode,
      });

      if (onSuccess) onSuccess();
    } catch (err: any) {
      console.error('Failed to create order on behalf:', err);
      alert(`Error creating order: ${err?.message || 'Unknown error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl my-8">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950/50 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">Purchase & Provision On Behalf of Customer</h2>
              <p className="text-xs text-slate-400">Staff Assisted Service Checkout & Immediate WHM/Registrar Dispatch</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {successResult ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black text-white">
              {successResult.mode === 'instant_paid' ? 'Services Provisioned Successfully!' : 'Invoice Issued & Dispatched!'}
            </h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              Order <strong>#{successResult.orderNumber}</strong> and Invoice <strong>#{successResult.invoiceNumber}</strong> have been created in the commerce registry.
            </p>
            <div className="pt-4">
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black shadow-lg shadow-indigo-600/30 transition-all"
              >
                Close & Return to Staff Portal
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
            {/* Step 1: Select Customer */}
            <div className="space-y-3 bg-slate-950/60 border border-slate-800 p-4 rounded-2xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-indigo-400 uppercase tracking-wider">1. Customer Selection</span>
                <button
                  type="button"
                  onClick={() => setIsNewUser(!isNewUser)}
                  className="text-xs font-bold text-indigo-400 hover:underline flex items-center gap-1"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  {isNewUser ? 'Select Existing Customer' : '+ New Customer Profile'}
                </button>
              </div>

              {isNewUser ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={newUserName}
                      onChange={(e) => setNewUserName(e.target.value)}
                      placeholder="e.g. Ama Osei"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={newUserEmail}
                      onChange={(e) => setNewUserEmail(e.target.value)}
                      placeholder="ama@company.com.gh"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={newUserPhone}
                      onChange={(e) => setNewUserPhone(e.target.value)}
                      placeholder="+233 24 123 4567"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              ) : (
                <div>
                  <select
                    value={selectedUserId}
                    onChange={(e) => setSelectedUserId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  >
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.fullName} ({u.email}) {u.companyName ? `• ${u.companyName}` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Step 2: Service & Domain Specification */}
            <div className="space-y-3 bg-slate-950/60 border border-slate-800 p-4 rounded-2xl">
              <span className="text-xs font-black text-cyan-400 uppercase tracking-wider block">2. Service Details & Domain</span>

              <div className="grid grid-cols-3 gap-2">
                {(['bundle', 'hosting', 'domain'] as const).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setServiceType(type)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold capitalize border transition-all ${
                      serviceType === type
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/20'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {type === 'bundle' ? 'Domain + Hosting' : type}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Target Domain Name *</label>
                  <input
                    type="text"
                    required
                    value={targetDomain}
                    onChange={(e) => setTargetDomain(e.target.value)}
                    placeholder="e.g. clientcorp.com.gh"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none focus:border-cyan-500"
                  />
                </div>

                {serviceType !== 'domain' && (
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">Hosting Package</label>
                    <select
                      value={selectedPlanId}
                      onChange={(e) => setSelectedPlanId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-500"
                    >
                      {INITIAL_HOSTING_PLANS.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} (GH₵ {(p.pricing?.monthly || 19.99).toFixed(2)}/mo)
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Billing Cycle</label>
                  <select
                    value={billingCycle}
                    onChange={(e) => setBillingCycle(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-500"
                  >
                    <option value="monthly">Monthly</option>
                    <option value="annually">Annually (1 Year)</option>
                    <option value="triennially">Triennially (3 Years)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Price (GH₵)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={customPrice}
                    onChange={(e) => setCustomPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
            </div>

            {/* Step 3: Infrastructure Adapters & Nameservers */}
            <div className="space-y-3 bg-slate-950/60 border border-slate-800 p-4 rounded-2xl">
              <span className="text-xs font-black text-purple-400 uppercase tracking-wider block">3. Infrastructure Adapters & DNS</span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Domain Registrar Provider</label>
                  <select
                    value={registrarProvider}
                    onChange={(e) => setRegistrarProvider(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-500"
                  >
                    {registrars.map((r) => (
                      <option key={r.id} value={r.provider}>
                        {r.name} ({r.provider.toUpperCase()})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Hosting Server Node</label>
                  <select
                    value={hostingServerId}
                    onChange={(e) => setHostingServerId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-500"
                  >
                    {servers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.hostname})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Nameservers Toggle */}
              <div className="pt-2 border-t border-slate-800/80">
                <label className="block text-[11px] font-bold text-slate-300 mb-2">Nameserver Configuration</label>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <button
                    type="button"
                    onClick={() => setNameserverMode('system_default')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                      nameserverMode === 'system_default'
                        ? 'bg-purple-600 text-white border-purple-500'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    Use System Default Nameservers
                  </button>
                  <button
                    type="button"
                    onClick={() => setNameserverMode('custom')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                      nameserverMode === 'custom'
                        ? 'bg-purple-600 text-white border-purple-500'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    Use Custom Nameservers
                  </button>
                </div>

                {nameserverMode === 'custom' && (
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="NS 1 (e.g. ns1.myhost.com)"
                      value={customNs1}
                      onChange={(e) => setCustomNs1(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono outline-none"
                    />
                    <input
                      type="text"
                      placeholder="NS 2 (e.g. ns2.myhost.com)"
                      value={customNs2}
                      onChange={(e) => setCustomNs2(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono outline-none"
                    />
                    <input
                      type="text"
                      placeholder="NS 3 (Optional)"
                      value={customNs3}
                      onChange={(e) => setCustomNs3(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono outline-none"
                    />
                    <input
                      type="text"
                      placeholder="NS 4 (Optional)"
                      value={customNs4}
                      onChange={(e) => setCustomNs4(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono outline-none"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Step 4: Fulfillment Action Selection */}
            <div className="space-y-3 bg-slate-950/60 border border-slate-800 p-4 rounded-2xl">
              <span className="text-xs font-black text-emerald-400 uppercase tracking-wider block">4. Fulfillment & Payment Action</span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  onClick={() => setFulfillmentMode('instant_paid')}
                  className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                    fulfillmentMode === 'instant_paid'
                      ? 'bg-emerald-500/10 border-emerald-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-xs">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>Instant Provision & Mark Paid</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Bypasses billing checkout, creates paid invoice, provisions hosting & registrar immediately, and emails credentials.
                  </p>
                </div>

                <div
                  onClick={() => setFulfillmentMode('send_invoice')}
                  className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                    fulfillmentMode === 'send_invoice'
                      ? 'bg-amber-500/10 border-amber-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-xs">
                    <Send className="w-4 h-4 text-amber-400" />
                    <span>Issue Unpaid Invoice & Send Link</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Generates invoice with Custom Payment instructions and emails the payment request link to the customer.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit */}
            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black shadow-lg shadow-indigo-600/30 flex items-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Processing Provisioning...</span>
                ) : (
                  <span>Execute Order On Behalf</span>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
