import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Globe, 
  AlertCircle, 
  Lock, 
  HelpCircle, 
  Activity, 
  Calendar, 
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Server
} from 'lucide-react';
import { DomainDetailedStatus, DomainOwnershipRecord } from '../types';

interface DomainStatusTimelineProps {
  domain: string;
  detailedStatus?: DomainDetailedStatus;
  creationDate?: string;
  expiryDate?: string;
  updatedDate?: string;
  registrar?: string;
  isOwnedByYou?: boolean;
  ownershipRecord?: DomainOwnershipRecord;
  onManageDomain?: (domain: string) => void;
  onAddToCart?: () => void;
}

export const DomainStatusTimeline: React.FC<DomainStatusTimelineProps> = ({
  domain,
  detailedStatus = 'available',
  creationDate,
  expiryDate,
  updatedDate,
  registrar,
  isOwnedByYou,
  ownershipRecord,
  onManageDomain,
  onAddToCart,
}) => {
  // Calculate remaining days if expiryDate is valid
  let daysRemaining: number | null = null;
  if (expiryDate && expiryDate !== 'N/A' && expiryDate !== 'Active Registration') {
    const expTime = new Date(expiryDate).getTime();
    if (!isNaN(expTime)) {
      const diff = expTime - Date.now();
      daysRemaining = Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
    }
  }

  // Determine stage active states based on detailedStatus
  const isAvailable = detailedStatus === 'available' || detailedStatus === 'premium';
  const isPending = detailedStatus === 'registration_pending';
  const isOwned = detailedStatus === 'owned_by_you';
  const isPlatformOwned = detailedStatus === 'owned_by_platform_customer';
  const isExternal = detailedStatus === 'external_registered';
  const isReserved = detailedStatus === 'reserved';
  const isUnable = detailedStatus === 'unable_to_verify';
  const isActive = isOwned || isPlatformOwned || isExternal;

  return (
    <div id={`timeline-${domain.replace(/[^a-z0-9]/g, '-')}`} className="bg-slate-50 dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-5">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-black uppercase tracking-wider text-slate-400">Lifecycle & Verification Timeline</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
              Live State
            </span>
          </div>
          <h4 className="text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
            {domain}
          </h4>
        </div>

        {/* Current status pill */}
        <div>
          {isOwned ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-blue-600 text-white shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5" /> Owned By You (ApexDomain)
            </span>
          ) : isPlatformOwned ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-slate-800 text-slate-200 border border-slate-700 shadow-sm">
              <Lock className="w-3.5 h-3.5" /> Registered In-House
            </span>
          ) : isExternal ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
              <Globe className="w-3.5 h-3.5" /> Externally Registered
            </span>
          ) : isPending ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 animate-pulse">
              <Clock className="w-3.5 h-3.5" /> Processing Registration
            </span>
          ) : isReserved ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
              <ShieldAlert className="w-3.5 h-3.5" /> Registry Reserved
            </span>
          ) : isUnable ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300">
              <AlertCircle className="w-3.5 h-3.5" /> Verification Pending
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-600 text-white shadow-sm">
              <CheckCircle2 className="w-3.5 h-3.5" /> Available to Register
            </span>
          )}
        </div>
      </div>

      {/* Visual Timeline Steps */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 relative">
        
        {/* Step 1: Search & Registry Lookup */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          isUnable 
            ? 'bg-orange-50 dark:bg-orange-950/30 border-orange-200 dark:border-orange-900/50' 
            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-black uppercase text-slate-400">1. Verification</span>
            {isUnable ? (
              <AlertCircle className="w-4 h-4 text-orange-500" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            )}
          </div>
          <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
            {isUnable ? 'Registry Lookup Timeout' : 'RDAP & DNS Verified'}
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {isUnable 
              ? 'Could not obtain confirmed response. Marked unverified.'
              : 'Multi-point check with root zone & in-house DB.'}
          </p>
        </div>

        {/* Step 2: Ownership Allocation */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          isOwned 
            ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-300 dark:border-blue-800 ring-1 ring-blue-500/20' 
            : isActive 
            ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800' 
            : isAvailable 
            ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800' 
            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-black uppercase text-slate-400">2. Ownership</span>
            {isOwned ? (
              <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            ) : isAvailable ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            ) : (
              <Lock className="w-4 h-4 text-slate-400" />
            )}
          </div>
          <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
            {isOwned 
              ? 'Your Account' 
              : isPlatformOwned 
              ? 'In-House Client' 
              : isExternal 
              ? (registrar ? `${registrar.slice(0, 20)}...` : 'External Registrar') 
              : isAvailable 
              ? 'Open for Claim' 
              : 'Reserved / Inactive'}
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {isOwned 
              ? 'Managed under your active authenticated identity.' 
              : isPlatformOwned 
              ? 'Registered on ApexDomain (Identity redacted).' 
              : isExternal 
              ? 'Registered via third-party registrar.' 
              : isAvailable 
              ? 'Ready for first-come, first-served registration.' 
              : 'Protected from public registration.'}
          </p>
        </div>

        {/* Step 3: DNS & Delegation */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          isActive 
            ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800' 
            : 'bg-slate-100/50 dark:bg-slate-900/30 border-dashed border-slate-200 dark:border-slate-800 opacity-75'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-black uppercase text-slate-400">3. Delegation</span>
            {isActive ? (
              <Server className="w-4 h-4 text-blue-500" />
            ) : (
              <Clock className="w-4 h-4 text-slate-300 dark:text-slate-600" />
            )}
          </div>
          <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
            {isActive ? 'Active Anycast Zone' : 'Pending Zone Setup'}
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {isActive 
              ? 'Nameservers mapped and DNSSEC delegation signed.' 
              : 'Will be deployed automatically upon purchase.'}
          </p>
        </div>

        {/* Step 4: Expiration & Renewal Lifecycle */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          isActive 
            ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800' 
            : 'bg-slate-100/50 dark:bg-slate-900/30 border-dashed border-slate-200 dark:border-slate-800 opacity-75'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-black uppercase text-slate-400">4. Expiry / Renewal</span>
            <Calendar className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
            {expiryDate && expiryDate !== 'N/A' 
              ? `Expires: ${expiryDate}` 
              : isAvailable 
              ? '1-10 Year Term' 
              : 'Active Lifecycle'}
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {daysRemaining !== null 
              ? `${daysRemaining} days remaining until renewal.` 
              : 'Auto-renew protection enabled by default.'}
          </p>
        </div>

      </div>

      {/* Lifecycle Breakdown Guide */}
      <div className="p-3.5 rounded-xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200/50 dark:border-blue-900/30 text-xs text-slate-600 dark:text-slate-400 space-y-1.5">
        <div className="flex items-center justify-between text-slate-900 dark:text-white font-bold">
          <span className="flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-blue-500" />
            ICANN Registrar Lifecycle Timeline
          </span>
          <span className="text-[11px] font-mono text-slate-500">Standard Rule Hierarchy</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
          <div className="p-2 rounded-lg bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800">
            <strong className="text-emerald-600 dark:text-emerald-400 block">Active Term</strong>
            <span>1–10 Years Valid</span>
          </div>
          <div className="p-2 rounded-lg bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800">
            <strong className="text-blue-600 dark:text-blue-400 block">Grace Period</strong>
            <span>0–30 Days Post-Expiry</span>
          </div>
          <div className="p-2 rounded-lg bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800">
            <strong className="text-amber-600 dark:text-amber-400 block">Redemption</strong>
            <span>30–60 Days Restore</span>
          </div>
          <div className="p-2 rounded-lg bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800">
            <strong className="text-rose-600 dark:text-rose-400 block">Pending Delete</strong>
            <span>60–75 Days Drop</span>
          </div>
        </div>
      </div>

      {/* Action CTA Bar */}
      {isOwned && onManageDomain && (
        <div className="flex items-center justify-between p-3 rounded-xl bg-blue-600 text-white shadow-sm">
          <div>
            <p className="text-xs font-black">You are the authenticated owner of this domain</p>
            <p className="text-[11px] text-blue-100">Manage DNS records, configure email forwarding, or extend your registration period.</p>
          </div>
          <button
            onClick={() => onManageDomain(domain)}
            className="px-3.5 py-1.5 rounded-lg text-xs font-black bg-white text-blue-700 hover:bg-blue-50 shadow transition-all shrink-0 flex items-center gap-1"
          >
            <span>Open Domain Hub</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {isAvailable && onAddToCart && (
        <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
          <div>
            <p className="text-xs font-black text-emerald-800 dark:text-emerald-200">Domain is Unregistered & Available</p>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400">Lock down this domain name before competitors claim it.</p>
          </div>
          <button
            onClick={onAddToCart}
            className="px-3.5 py-1.5 rounded-lg text-xs font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow transition-all shrink-0"
          >
            Add to Cart
          </button>
        </div>
      )}

    </div>
  );
};
