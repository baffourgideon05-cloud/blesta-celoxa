import React, { useState, useEffect } from 'react';
import { 
  Server, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Key, 
  Sliders, 
  FileText, 
  Cpu, 
  HardDrive, 
  ShieldCheck, 
  ExternalLink, 
  Check, 
  X, 
  Search, 
  Activity, 
  Zap,
  Plus
} from 'lucide-react';
import { HostingControlPanelConfig, ControlPanelApiLog, ControlPanelProviderType } from '../types';
import { hostingControlPanelManager } from '../services/hostingControlPanelManager';

export const AdminHostingIntegrationHub: React.FC = () => {
  const [servers, setServers] = useState<HostingControlPanelConfig[]>(() => hostingControlPanelManager.getServers());
  const [logs, setLogs] = useState<ControlPanelApiLog[]>(() => hostingControlPanelManager.getLogs());
  const [selectedServer, setSelectedServer] = useState<HostingControlPanelConfig | null>(() => hostingControlPanelManager.getDefaultServer());
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; success: boolean; message: string; latencyMs: number } | null>(null);
  const [logFilter, setLogFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<HostingControlPanelConfig>>({});
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const unsub = hostingControlPanelManager.subscribe(() => {
      setServers(hostingControlPanelManager.getServers());
      setLogs(hostingControlPanelManager.getLogs());
    });
    return unsub;
  }, []);

  const handleTestConnection = async (id: string) => {
    setTestingId(id);
    setTestResult(null);
    try {
      const res = await hostingControlPanelManager.testConnection(id);
      setTestResult({ id, success: res.success, message: res.message, latencyMs: res.latencyMs });
      setStatusMessage({ type: res.success ? 'success' : 'error', text: res.message });
    } catch (e: any) {
      setTestResult({ id, success: false, message: e.message || 'Connection failed', latencyMs: 0 });
    } finally {
      setTestingId(null);
    }
  };

  const handleSetDefault = (id: string) => {
    hostingControlPanelManager.setDefaultServer(id);
    setStatusMessage({ type: 'success', text: 'Default hosting server cluster updated.' });
  };

  const handleStartEdit = (server: HostingControlPanelConfig) => {
    setSelectedServer(server);
    setEditForm({ ...server });
    setIsEditing(true);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.id || !editForm.name) return;

    hostingControlPanelManager.saveServer(editForm as HostingControlPanelConfig);
    setIsEditing(false);
    setStatusMessage({ type: 'success', text: `Saved configuration for ${editForm.name}` });
  };

  const filteredLogs = logs.filter((l) => {
    if (logFilter !== 'all' && l.provider !== logFilter) return false;
    if (searchTerm) {
      const s = searchTerm.toLowerCase();
      return (
        l.panelName.toLowerCase().includes(s) ||
        l.action.toLowerCase().includes(s) ||
        (l.domain && l.domain.toLowerCase().includes(s)) ||
        (l.username && l.username.toLowerCase().includes(s))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Server className="w-4 h-4" />
              <span>Hosting Control Panel & Server Node Manager</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">cPanel/WHM, DirectAdmin & Plesk Provisioning Adapters</h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Manage live control panel integrations and server clusters. The provisioning engine interacts with these APIs to automatically create hosting accounts, setup AutoSSL, and dispatch access credentials.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                const def = hostingControlPanelManager.getDefaultServer();
                if (def) handleTestConnection(def.id);
              }}
              disabled={!!testingId}
              className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg shadow-cyan-600/30 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${testingId ? 'animate-spin' : ''}`} />
              <span>Test Default Server</span>
            </button>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between border ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
          }`}
        >
          <span>{statusMessage.text}</span>
          <button onClick={() => setStatusMessage(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Main Grid: Server List + Details / Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Server Cluster Nodes */}
        <div className="lg:col-span-1 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 px-1">
            <span>Server Nodes ({servers.length})</span>
            <span className="text-[11px] text-cyan-400">WHM / API v1</span>
          </div>

          {servers.map((srv) => {
            const isSelected = selectedServer?.id === srv.id;
            const isDefault = srv.isDefault;
            return (
              <div
                key={srv.id}
                onClick={() => {
                  setSelectedServer(srv);
                  setIsEditing(false);
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-500 shadow-lg shadow-cyan-500/10'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-white">{srv.name}</span>
                      {isDefault && (
                        <span className="px-2 py-0.5 bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 rounded-full text-[10px] font-black uppercase">
                          Default
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                      {srv.hostname} ({srv.ipAddress})
                    </span>
                  </div>

                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      srv.status === 'connected'
                        ? 'bg-emerald-400 shadow-sm shadow-emerald-400/50'
                        : 'bg-rose-400'
                    }`}
                  />
                </div>

                <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">
                    Accounts: <strong className="text-slate-200">{srv.activeAccounts}/{srv.maxAccounts}</strong>
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTestConnection(srv.id);
                      }}
                      disabled={testingId === srv.id}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
                    >
                      <RefreshCw className={`w-3 h-3 ${testingId === srv.id ? 'animate-spin' : ''}`} />
                      Test
                    </button>
                    {!isDefault && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSetDefault(srv.id);
                        }}
                        className="px-2.5 py-1 bg-cyan-600/20 hover:bg-cyan-600 text-cyan-300 hover:text-white rounded-lg text-[10px] font-bold transition-all"
                      >
                        Set Default
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Server Details + API Logs */}
        <div className="lg:col-span-2 space-y-6">
          {selectedServer && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-3">
                    <h2 className="text-lg font-black text-white">{selectedServer.name}</h2>
                    <span
                      className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold flex items-center gap-1.5 ${
                        selectedServer.status === 'connected'
                          ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
                          : 'bg-rose-500/10 border border-rose-500/30 text-rose-400'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      {selectedServer.status === 'connected' ? 'Connected & Healthy' : 'Error'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{selectedServer.statusMessage || 'cPanel & WHM Engine Active'}</p>
                </div>

                <div className="flex items-center gap-2">
                  {isEditing ? (
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all"
                    >
                      Cancel
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStartEdit(selectedServer)}
                      className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-lg shadow-cyan-600/20"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      Configure Node
                    </button>
                  )}
                </div>
              </div>

              {isEditing ? (
                <form onSubmit={handleSaveEdit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Cluster Display Name</label>
                      <input
                        type="text"
                        value={editForm.name || ''}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-cyan-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Control Panel Type</label>
                      <select
                        value={editForm.provider || 'cpanel'}
                        onChange={(e) => setEditForm({ ...editForm, provider: e.target.value as any })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-cyan-500 outline-none"
                      >
                        <option value="cpanel">cPanel / WHM (API v1)</option>
                        <option value="directadmin">DirectAdmin Enhanced</option>
                        <option value="plesk">Plesk Obsidian REST</option>
                        <option value="cyberpanel">CyberPanel Cloud</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Server Hostname</label>
                      <input
                        type="text"
                        value={editForm.hostname || ''}
                        onChange={(e) => setEditForm({ ...editForm, hostname: e.target.value })}
                        placeholder="whm01.accra.celoxaghana.online"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">IP Address</label>
                      <input
                        type="text"
                        value={editForm.ipAddress || ''}
                        onChange={(e) => setEditForm({ ...editForm, ipAddress: e.target.value })}
                        placeholder="154.160.10.45"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Admin Username</label>
                      <input
                        type="text"
                        value={editForm.username || ''}
                        onChange={(e) => setEditForm({ ...editForm, username: e.target.value })}
                        placeholder="root"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">WHM API Token / Remote Key</label>
                      <input
                        type="password"
                        value={editForm.apiToken || ''}
                        onChange={(e) => setEditForm({ ...editForm, apiToken: e.target.value })}
                        placeholder="••••••••••••"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">API Endpoint URL</label>
                      <input
                        type="text"
                        value={editForm.apiEndpoint || ''}
                        onChange={(e) => setEditForm({ ...editForm, apiEndpoint: e.target.value })}
                        placeholder="https://whm01.accra.celoxaghana.online:2087/json-api/"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold hover:bg-slate-700"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-cyan-600 text-white rounded-xl text-xs font-extrabold hover:bg-cyan-500 shadow-lg shadow-cyan-600/30"
                    >
                      Save Server Node
                    </button>
                  </div>
                </form>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Node Connection Details</span>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Control Panel</span>
                      <span className="font-mono font-bold text-slate-200">{selectedServer.provider.toUpperCase()}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Hostname</span>
                      <span className="font-mono text-cyan-300">{selectedServer.hostname}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Primary IP</span>
                      <span className="font-mono text-slate-300">{selectedServer.ipAddress}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-400">AutoSSL Engine</span>
                      <span className="text-emerald-400 font-bold">Enabled (Let's Encrypt)</span>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Default Cluster Nameservers</span>
                    <ul className="space-y-1.5 font-mono text-[11px] text-slate-300">
                      {selectedServer.defaultNameservers.map((ns, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <span className="text-cyan-400 font-bold">NS{idx + 1}:</span>
                          <span>{ns}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Control Panel Logs */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-black text-white">Hosting Provisioning API Logs</h3>
                <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded-full text-[10px] font-bold">
                  {filteredLogs.length} events
                </span>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search logs..."
                    className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:border-cyan-500 outline-none w-36 sm:w-48"
                  />
                </div>
                <select
                  value={logFilter}
                  onChange={(e) => setLogFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:border-cyan-500 outline-none"
                >
                  <option value="all">All Panels</option>
                  <option value="cpanel">cPanel</option>
                  <option value="directadmin">DirectAdmin</option>
                  <option value="plesk">Plesk</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase font-extrabold tracking-wider">
                    <th className="pb-3 px-3">Timestamp</th>
                    <th className="pb-3 px-3">Server Cluster</th>
                    <th className="pb-3 px-3">Action</th>
                    <th className="pb-3 px-3">Account / User</th>
                    <th className="pb-3 px-3">Latency</th>
                    <th className="pb-3 px-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-white block">{log.panelName}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{log.provider.toUpperCase()}</span>
                      </td>
                      <td className="py-3 px-3 font-mono text-cyan-300">
                        {log.action}
                      </td>
                      <td className="py-3 px-3 text-slate-200">
                        {log.username || log.domain || '—'}
                      </td>
                      <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">
                        {log.executionTimeMs} ms
                      </td>
                      <td className="py-3 px-3 text-right">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                            log.status === 'success'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {log.status === 'success' ? <Check className="w-2.5 h-2.5" /> : <X className="w-2.5 h-2.5" />}
                          {log.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filteredLogs.length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-slate-500">
                        No hosting provisioning API logs recorded.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
