import React, { useState, useEffect } from 'react';
import {
  Server,
  Zap,
  ShieldCheck,
  Check,
  Sparkles,
  ShoppingBag,
  Globe,
  HardDrive,
  Cpu,
  ArrowRight,
  HelpCircle,
  Clock,
  Database,
  Mail,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  RefreshCw,
  Lock,
  ChevronDown,
  ChevronUp,
  Tag,
  AlertCircle,
  ShoppingCart,
  CheckCircle,
  Info
} from 'lucide-react';
import {
  HostingCategory,
  HostingPlan,
  HostingFeature,
  HostingServer,
  HostingBillingCycle,
  HostingPromotion,
  CartItem,
  Currency,
  WhmcsHostingPackage
} from '../types';
import { systemDatabase } from '../services/systemDatabase';
import { formatPrice } from '../utils/domainSearchEngine';

interface HostingPackagesFrontendPageProps {
  hostingPackages?: WhmcsHostingPackage[];
  cartItems: CartItem[];
  onAddToCart: (item: CartItem) => void;
  onOpenCart: () => void;
  userDomains?: string[];
  currency?: Currency;
  onNavigateView?: (view: string) => void;
}

export const HostingPackagesFrontendPage: React.FC<HostingPackagesFrontendPageProps> = ({
  cartItems,
  onAddToCart,
  onOpenCart,
  userDomains = ['nexustech.io', 'apexdomain.com'],
  currency = 'USD',
  onNavigateView
}) => {
  // Database State
  const [categories, setCategories] = useState<HostingCategory[]>([]);
  const [plans, setPlans] = useState<HostingPlan[]>([]);
  const [features, setFeatures] = useState<HostingFeature[]>([]);
  const [servers, setServers] = useState<HostingServer[]>([]);

  // Selection States
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string>('all');
  const [billingCycle, setBillingCycle] = useState<HostingBillingCycle>('annual');
  const [selectedServerId, setSelectedServerId] = useState<string>('srv-gh-01');
  const [targetDomain, setTargetDomain] = useState<string>(userDomains[0] || 'mysite.com');
  const [customDomainInput, setCustomDomainInput] = useState<string>('');
  const [useCustomDomain, setUseCustomDomain] = useState<boolean>(false);
  const [addedSuccessId, setAddedSuccessId] = useState<string | null>(null);

  // Coupon / Promo Code State
  const [couponInput, setCouponInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discountPercent: number; message: string } | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  // Comparison Matrix & FAQ States
  const [showComparison, setShowComparison] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Load active data from systemDatabase
  const loadData = () => {
    const activeCats = systemDatabase.getHostingCategories(false);
    const activePlans = systemDatabase.getHostingPlans({ includeAll: false, status: 'active' });
    const featList = systemDatabase.getHostingFeatures('all');
    const srvList = systemDatabase.getHostingServers();

    setCategories(activeCats);
    setPlans(activePlans);
    setFeatures(featList);
    setServers(srvList);

    if (srvList.length > 0 && !selectedServerId) {
      setSelectedServerId(srvList[0].id);
    }
  };

  useEffect(() => {
    loadData();
    const unsub = systemDatabase.subscribe(() => {
      loadData();
    });
    return () => unsub();
  }, []);

  // Filter plans based on category
  const currentCategory = categories.find((c) => c.slug === selectedCategorySlug);
  const filteredPlans = plans.filter((plan) => {
    if (selectedCategorySlug === 'all') return true;
    return currentCategory ? plan.categoryId === currentCategory.id : true;
  });

  // Calculate pricing for a plan based on current billing cycle
  const getCyclePricing = (plan: HostingPlan) => {
    let rawTotal = plan.pricing.annual || 79.90;
    let monthsInCycle = 12;
    let years = 1;

    switch (billingCycle) {
      case 'monthly':
        rawTotal = plan.pricing.monthly || (plan.pricing.annual ? plan.pricing.annual / 12 : 7.99);
        monthsInCycle = 1;
        years = 1;
        break;
      case 'quarterly':
        rawTotal = plan.pricing.quarterly || (plan.pricing.monthly ? plan.pricing.monthly * 3 : 22.50);
        monthsInCycle = 3;
        years = 1;
        break;
      case 'semiAnnual':
        rawTotal = plan.pricing.semiAnnual || (plan.pricing.monthly ? plan.pricing.monthly * 6 : 43.15);
        monthsInCycle = 6;
        years = 1;
        break;
      case 'annual':
        rawTotal = plan.pricing.annual || (plan.pricing.monthly ? plan.pricing.monthly * 10 : 79.90);
        monthsInCycle = 12;
        years = 1;
        break;
      case 'biennial':
        rawTotal = plan.pricing.biennial || (plan.pricing.annual ? plan.pricing.annual * 1.8 : 143.80);
        monthsInCycle = 24;
        years = 2;
        break;
      case 'triennial':
        rawTotal = plan.pricing.triennial || (plan.pricing.annual ? plan.pricing.annual * 2.4 : 191.70);
        monthsInCycle = 36;
        years = 3;
        break;
    }

    // Apply active coupon discount if applicable
    let finalTotal = rawTotal;
    let discountAmount = 0;
    if (appliedPromo) {
      discountAmount = (rawTotal * appliedPromo.discountPercent) / 100;
      finalTotal = Math.max(0, rawTotal - discountAmount);
    }

    const monthlyEquivalent = finalTotal / monthsInCycle;

    return {
      monthlyEquivalent,
      totalBilled: finalTotal,
      rawTotal,
      discountAmount,
      monthsInCycle,
      years,
    };
  };

  // Handle Add to Cart
  const handleAddPlanToCart = (plan: HostingPlan, checkoutImmediately: boolean = false) => {
    const boundDomain = useCustomDomain && customDomainInput.trim() ? customDomainInput.trim() : targetDomain;
    const pricing = getCyclePricing(plan);
    const selectedServer = servers.find((s) => s.id === selectedServerId);

    const categoryObj = categories.find((c) => c.id === plan.categoryId);

    const newItem: CartItem = {
      id: `cart-hosting-${plan.id}-${Date.now()}`,
      domain: boundDomain,
      tld: boundDomain.split('.').pop() || 'com',
      registrationPrice: pricing.totalBilled,
      renewalPrice: pricing.rawTotal,
      years: pricing.years,
      privacyProtection: true,
      emailForwarding: true,
      dnssecEnabled: true,
      hostingAddon: false,
      icannFee: 0,
      isPremium: false,
      itemType: 'hosting',
      packageName: plan.name,
      planId: plan.id,
      billingCycle,
      serverRegion: selectedServer ? `${selectedServer.name} (${selectedServer.location})` : 'Accra MDXi Datacenter',
      diskLimitMb: plan.resources.storageGb === 'unlimited' ? 0 : Number(plan.resources.storageGb) * 1024,
      bandwidthLimitGb: plan.resources.bandwidthGb === 'unlimited' ? 0 : Number(plan.resources.bandwidthGb),
      module: plan.controlPanels[0] || 'cpanel',
    };

    onAddToCart(newItem);
    setAddedSuccessId(plan.id);
    setTimeout(() => setAddedSuccessId(null), 3000);

    if (checkoutImmediately) {
      onOpenCart();
    }
  };

  // Coupon Verification
  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;

    const result = systemDatabase.validatePromotion(couponInput.trim(), currentCategory?.id, undefined, billingCycle);
    if (result.valid && result.discountPercent) {
      setAppliedPromo({
        code: couponInput.trim().toUpperCase(),
        discountPercent: result.discountPercent,
        message: result.message || `${result.discountPercent}% discount applied!`,
      });
      setCouponError(null);
    } else {
      setAppliedPromo(null);
      setCouponError(result.message || 'Invalid coupon code.');
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedPromo(null);
    setCouponInput('');
    setCouponError(null);
  };

  return (
    <div className="space-y-12 pb-20 animate-in fade-in duration-300">
      
      {/* ========================================================================= */}
      {/* 1. HERO HOSTING HEADER */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white pt-12 pb-16 border-b border-slate-800">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(14,165,233,0.15),rgba(255,255,255,0))] pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-6">
          
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-cyan-300 text-xs font-black uppercase tracking-wider shadow-inner">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Next-Gen Enterprise NVMe Cloud Infrastructure</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight max-w-4xl mx-auto leading-tight">
            High-Performance Web Hosting <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-300">
              Engineered for Speed & Reliability
            </span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Choose from shared NVMe hosting, managed WordPress, reseller accounts, and dedicated KVM Cloud VPS. Backed by 100% pure NVMe SSDs, free SSL, automated snapshots, and 99.9% uptime SLA.
          </p>

          {/* Quick Category Tab Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
            <button
              onClick={() => setSelectedCategorySlug('all')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all flex items-center gap-2 ${
                selectedCategorySlug === 'all'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 ring-2 ring-blue-400/50'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>All Plans ({plans.length})</span>
            </button>

            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategorySlug(cat.slug)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all flex items-center gap-2 ${
                  selectedCategorySlug === cat.slug
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 ring-2 ring-blue-400/50'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                }`}
              >
                <Globe className="w-4 h-4 text-cyan-400" />
                <span>{cat.name}</span>
                {cat.badge && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                    {cat.badge}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Billing Cycle Switcher with Savings Callout */}
          <div className="pt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
            <div className="bg-slate-900/90 p-1.5 rounded-2xl border border-slate-700 shadow-xl inline-flex flex-wrap gap-1">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-3 sm:px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  billingCycle === 'monthly'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Monthly
              </button>

              <button
                onClick={() => setBillingCycle('quarterly')}
                className={`px-3 sm:px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  billingCycle === 'quarterly'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Quarterly
              </button>

              <button
                onClick={() => setBillingCycle('annual')}
                className={`px-3 sm:px-5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  billingCycle === 'annual'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>Annual (1 Year)</span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-black border border-emerald-500/40">
                  Save 20-30%
                </span>
              </button>

              <button
                onClick={() => setBillingCycle('biennial')}
                className={`px-3 sm:px-4 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  billingCycle === 'biennial'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>2 Years</span>
                <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-400 text-[10px] font-black border border-cyan-500/40">
                  Best Value
                </span>
              </button>

              <button
                onClick={() => setBillingCycle('triennial')}
                className={`px-3 sm:px-4 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  billingCycle === 'triennial'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>3 Years</span>
                <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[10px] font-black border border-amber-500/40">
                  Max Savings
                </span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 2. CATEGORY SPOTLIGHT BANNER & DOMAIN BINDING CONTROL */}
      {/* ========================================================================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {currentCategory && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row items-start justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-cyan-300 text-xs font-black uppercase">
                <Globe className="w-3.5 h-3.5" />
                Category Overview
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                {currentCategory.name}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {currentCategory.fullDescription || currentCategory.shortDescription}
              </p>
            </div>

            {currentCategory.commonFeatures && currentCategory.commonFeatures.length > 0 && (
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 w-full md:w-auto min-w-[280px]">
                <div className="text-xs font-black text-slate-900 dark:text-white mb-2 uppercase tracking-wider">
                  Included in all plans:
                </div>
                <div className="space-y-1.5">
                  {currentCategory.commonFeatures.map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Global Configuration Bar: Datacenter Server Node & Target Domain */}
        <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-slate-800 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-4">
          {/* Datacenter selection */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 w-full lg:w-auto">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
              <Server className="w-4 h-4 text-cyan-400" />
              <span>Provisioning Location:</span>
            </div>
            <select
              value={selectedServerId}
              onChange={(e) => setSelectedServerId(e.target.value)}
              className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
            >
              {servers.map((srv) => (
                <option key={srv.id} value={srv.id}>
                  {srv.location} — {srv.name} ({srv.pingMs}ms)
                </option>
              ))}
            </select>
          </div>

          {/* Domain binding configuration */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 w-full lg:w-auto">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
              <Globe className="w-4 h-4 text-cyan-400" />
              <span>Link Domain to Package:</span>
            </div>

            {useCustomDomain ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="e.g. mynewbrand.com"
                  value={customDomainInput}
                  onChange={(e) => setCustomDomainInput(e.target.value)}
                  className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400"
                />
                <button
                  onClick={() => setUseCustomDomain(false)}
                  className="text-xs text-cyan-400 hover:underline font-bold"
                >
                  Choose Existing
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <select
                  value={targetDomain}
                  onChange={(e) => setTargetDomain(e.target.value)}
                  className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
                >
                  {userDomains.map((dom, domIdx) => (
                    <option key={`usr-dom-${dom}-${domIdx}`} value={dom}>
                      {dom}
                    </option>
                  ))}
                  <option key="opt-default-demo" value="mysite.com">mysite.com (Default Demo)</option>
                </select>
                <button
                  onClick={() => setUseCustomDomain(true)}
                  className="text-xs text-cyan-400 hover:underline font-bold whitespace-nowrap"
                >
                  + Enter Other
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Live Promotional Coupon Validation Bar */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-2">
                <span>Have a Promo or Coupon Code?</span>
                <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  Try "WELCOME20" or "ANNUAL30"
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Apply special discounts directly to your cart checkout session.
              </p>
            </div>
          </div>

          {appliedPromo ? (
            <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/30 px-4 py-2 rounded-xl">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                {appliedPromo.code} Applied ({appliedPromo.discountPercent}% OFF)
              </span>
              <button
                onClick={handleRemoveCoupon}
                className="text-xs text-rose-500 hover:underline font-bold ml-2"
              >
                Remove
              </button>
            </div>
          ) : (
            <form onSubmit={handleApplyCoupon} className="flex items-center gap-2 w-full sm:w-auto">
              <input
                type="text"
                placeholder="Enter Promo Code"
                value={couponInput}
                onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold uppercase focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 text-white dark:text-slate-900 font-black text-xs rounded-xl transition-all"
              >
                Apply
              </button>
            </form>
          )}
        </div>

        {couponError && (
          <div className="text-xs font-bold text-rose-500 flex items-center gap-1.5 px-2">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{couponError}</span>
          </div>
        )}
      </section>

      {/* ========================================================================= */}
      {/* 3. DYNAMIC HOSTING PLANS GRID */}
      {/* ========================================================================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
          {filteredPlans.map((plan) => {
            const pricing = getCyclePricing(plan);
            const isFeatured = plan.featured;
            const isAdded = addedSuccessId === plan.id;

            return (
              <div
                key={plan.id}
                className={`rounded-3xl border transition-all duration-300 flex flex-col justify-between relative bg-white dark:bg-slate-900 overflow-hidden ${
                  isFeatured
                    ? 'border-blue-500 shadow-2xl shadow-blue-500/10 ring-2 ring-blue-500/30'
                    : 'border-slate-200 dark:border-slate-800 shadow-lg hover:shadow-xl'
                }`}
              >
                {/* Highlight Tag */}
                {isFeatured && (
                  <div className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white py-1.5 text-center text-xs font-black uppercase tracking-widest">
                    ★ Recommended & Most Popular ★
                  </div>
                )}

                <div className="p-6 sm:p-8 space-y-6">
                  {/* Title & Badge */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      {plan.badge && (
                        <span className="px-2.5 py-1 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-cyan-300 text-[10px] font-black uppercase tracking-wider border border-blue-200 dark:border-blue-700">
                          {plan.badge}
                        </span>
                      )}
                      <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-2">
                        {plan.name}
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                        {plan.shortDescription}
                      </p>
                    </div>

                    <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-cyan-400 border border-blue-200 dark:border-blue-800 shrink-0">
                      <HardDrive className="w-6 h-6" />
                    </div>
                  </div>

                  {/* Pricing Box */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 space-y-1">
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
                        {formatPrice(pricing.monthlyEquivalent, currency)}
                      </span>
                      <span className="text-xs font-bold text-slate-500 dark:text-slate-400">/ month</span>
                    </div>

                    <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between pt-1">
                      <span>Billed {formatPrice(pricing.totalBilled, currency)} for {billingCycle}</span>
                      {pricing.discountAmount > 0 && (
                        <span className="text-emerald-500 font-bold">Save {formatPrice(pricing.discountAmount, currency)}</span>
                      )}
                    </div>
                  </div>

                  {/* Core Hardware & Limits Specs */}
                  <div className="space-y-3 pt-2">
                    <div className="text-xs font-black uppercase text-slate-400 tracking-wider">
                      Hardware & Resource Allocations
                    </div>

                    <div className="space-y-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="flex items-center gap-2">
                          <HardDrive className="w-4 h-4 text-blue-500" />
                          Storage
                        </span>
                        <strong className="text-slate-900 dark:text-white">
                          {plan.resources.storageGb === 'unlimited' ? 'Unlimited' : `${plan.resources.storageGb} GB`} {plan.resources.storageType}
                        </strong>
                      </div>

                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="flex items-center gap-2">
                          <Globe className="w-4 h-4 text-cyan-500" />
                          Websites Hosted
                        </span>
                        <strong className="text-slate-900 dark:text-white">
                          {plan.resources.websites === 'unlimited' ? 'Unlimited Sites' : `${plan.resources.websites} Website(s)`}
                        </strong>
                      </div>

                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="flex items-center gap-2">
                          <Zap className="w-4 h-4 text-amber-500" />
                          Bandwidth
                        </span>
                        <strong className="text-slate-900 dark:text-white">
                          {plan.resources.bandwidthGb === 'unlimited' ? 'Unmetered' : `${plan.resources.bandwidthGb} GB/mo`}
                        </strong>
                      </div>

                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="flex items-center gap-2">
                          <Cpu className="w-4 h-4 text-purple-500" />
                          Compute Resources
                        </span>
                        <strong className="text-slate-900 dark:text-white">
                          {plan.resources.cpuCores} CPU / {plan.resources.ramGb} GB RAM
                        </strong>
                      </div>

                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-emerald-500" />
                          Mailboxes
                        </span>
                        <strong className="text-slate-900 dark:text-white">
                          {plan.resources.emailAccounts === 'unlimited' ? 'Unlimited' : `${plan.resources.emailAccounts} Accounts`}
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* Included Technical Features */}
                  <div className="space-y-2 pt-2">
                    <div className="text-xs font-black uppercase text-slate-400 tracking-wider">
                      What's Included
                    </div>

                    <div className="space-y-1.5">
                      {plan.freeDomainEligible && (
                        <div className="flex items-center gap-2 text-xs font-bold text-cyan-600 dark:text-cyan-400">
                          <Sparkles className="w-3.5 h-3.5 shrink-0" />
                          <span>Free Domain for 1st Year</span>
                        </div>
                      )}

                      <div className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>{plan.resources.ssl}</span>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>{plan.resources.backups}</span>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>Control Panel: {plan.controlPanels.join(' / ').toUpperCase()}</span>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        <span>24/7/365 Expert Support & 99.9% SLA</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Area */}
                <div className="p-6 bg-slate-50/50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <button
                    onClick={() => handleAddPlanToCart(plan, true)}
                    className={`w-full py-3 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all hover:scale-[1.02] active:scale-[0.98] ${
                      isFeatured
                        ? 'bg-gradient-to-r from-blue-600 via-cyan-600 to-blue-700 hover:from-blue-500 hover:to-cyan-500 text-white shadow-blue-500/20'
                        : 'bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 text-white dark:text-slate-900'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Order Now & Checkout</span>
                  </button>

                  <button
                    onClick={() => handleAddPlanToCart(plan, false)}
                    className="w-full py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all"
                  >
                    {isAdded ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                        <span className="text-emerald-600 dark:text-emerald-400">Added to Cart!</span>
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>Add to Cart (Keep Browsing)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. COMPREHENSIVE PLAN COMPARISON TABLE */}
      {/* ========================================================================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                Detailed Technical Comparison
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Compare compute specs, storage speed, subdomains, email accounts, and security layers.
              </p>
            </div>

            <button
              onClick={() => setShowComparison(!showComparison)}
              className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl flex items-center gap-2 self-start sm:self-auto"
            >
              <span>{showComparison ? 'Collapse Table' : 'Expand Side-by-Side Table'}</span>
              {showComparison ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>

          {showComparison && (
            <div className="overflow-x-auto pt-6">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800">
                    <th className="py-3 px-4 font-black text-slate-900 dark:text-white w-1/4">Technical Feature</th>
                    {filteredPlans.map((plan) => (
                      <th key={plan.id} className="py-3 px-4 font-black text-blue-600 dark:text-cyan-400 text-center">
                        {plan.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium text-slate-700 dark:text-slate-300">
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Storage Tech & Limit</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center">
                        {plan.resources.storageGb === 'unlimited' ? 'Unlimited' : `${plan.resources.storageGb} GB`} {plan.resources.storageType}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Hosted Websites</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center">
                        {plan.resources.websites === 'unlimited' ? 'Unlimited' : plan.resources.websites}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Monthly Bandwidth</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center font-bold text-emerald-500">
                        {plan.resources.bandwidthGb === 'unlimited' ? 'Unmetered' : `${plan.resources.bandwidthGb} GB`}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Compute (CPU / RAM)</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center">
                        {plan.resources.cpuCores} Core(s) / {plan.resources.ramGb} GB RAM
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Email Mailboxes</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center">
                        {plan.resources.emailAccounts === 'unlimited' ? 'Unlimited' : plan.resources.emailAccounts}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Free SSL Certificates</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center text-emerald-500 font-bold">
                        ✓ Included
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Automated Backups</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center">
                        {plan.resources.backups}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Free Domain Registration</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center">
                        {plan.freeDomainEligible ? (
                          <span className="text-cyan-500 font-bold">✓ 1st Year Free</span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">Control Panel</td>
                    {filteredPlans.map((plan) => (
                      <td key={plan.id} className="py-3 px-4 text-center uppercase font-mono">
                        {plan.controlPanels.join(' / ')}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. ENTERPRISE INFRASTRUCTURE & TRUST METRICS */}
      {/* ========================================================================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 rounded-3xl p-8 sm:p-12 text-white shadow-2xl space-y-8">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Why 10,000+ Businesses Trust Our Cloud Hosting
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm">
              We operate enterprise-grade hardware nodes across Accra, London, Frankfurt, and New York with zero compromises on speed or security.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-4">
            <div className="bg-slate-800/60 backdrop-blur rounded-2xl p-5 border border-slate-700/60 space-y-2">
              <div className="p-3 rounded-xl bg-blue-500/20 text-cyan-400 w-fit">
                <HardDrive className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black text-white">100% NVMe Enterprise SSDs</h3>
              <p className="text-xs text-slate-400">
                PCIe Gen 4.0 NVMe drives deliver up to 10x faster I/O speed than standard SATA SSDs.
              </p>
            </div>

            <div className="bg-slate-800/60 backdrop-blur rounded-2xl p-5 border border-slate-700/60 space-y-2">
              <div className="p-3 rounded-xl bg-purple-500/20 text-purple-400 w-fit">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black text-white">Tbps+ DDoS Defense</h3>
              <p className="text-xs text-slate-400">
                Automated multi-layer traffic scrubbing to keep your applications online during volumetric attacks.
              </p>
            </div>

            <div className="bg-slate-800/60 backdrop-blur rounded-2xl p-5 border border-slate-700/60 space-y-2">
              <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-400 w-fit">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black text-white">LiteSpeed Web Server</h3>
              <p className="text-xs text-slate-400">
                LiteSpeed Enterprise + LSCache built-in for sub-second WordPress response times.
              </p>
            </div>

            <div className="bg-slate-800/60 backdrop-blur rounded-2xl p-5 border border-slate-700/60 space-y-2">
              <div className="p-3 rounded-xl bg-amber-500/20 text-amber-400 w-fit">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black text-white">99.9% Uptime Guarantee</h3>
              <p className="text-xs text-slate-400">
                Tier-3/Tier-4 redundant power and carrier-neutral fiber uplinks ensure zero unexpected downtime.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6. FAQ ACCORDION SECTION */}
      {/* ========================================================================= */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-black text-slate-900 dark:text-white">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-slate-500">
            Everything you need to know about migrations, billing, control panels, and server locations.
          </p>
        </div>

        <div className="space-y-3">
          {[
            {
              q: 'Can you migrate my existing website from another hosting company?',
              a: 'Yes! We provide 100% free white-glove website migration for all cPanel and WordPress sites with zero downtime. Simply submit a migration request from your client dashboard after ordering.'
            },
            {
              q: 'How does the free domain name work with annual plans?',
              a: 'When you purchase any hosting plan on an Annual, 2-Year, or 3-Year billing cycle, you are eligible for 1 free domain registration (.com, .org, .online, .com.gh) for your first year.'
            },
            {
              q: 'Can I upgrade or downgrade my hosting plan at any time?',
              a: 'Absolutely! Our system features instant mid-cycle proration. You only pay the exact prorated difference for remaining days in your billing cycle, and your new limits activate immediately.'
            },
            {
              q: 'What control panels are supported?',
              a: 'We natively support cPanel, DirectAdmin, and Plesk Obsidian. All shared and WordPress hosting packages include industry-standard cPanel by default.'
            }
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm"
            >
              <button
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 font-black text-sm text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all"
              >
                <span>{item.q}</span>
                {openFaq === idx ? <ChevronUp className="w-4 h-4 text-blue-500" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
              </button>
              {openFaq === idx && (
                <div className="px-4 sm:px-5 pb-5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/60 pt-3">
                  {item.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
