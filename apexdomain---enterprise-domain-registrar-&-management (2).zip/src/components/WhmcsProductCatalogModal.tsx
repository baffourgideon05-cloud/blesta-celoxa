import React, { useState } from 'react';
import { 
  Server, 
  Check, 
  Zap, 
  Globe, 
  Layers, 
  ShoppingBag, 
  ShieldCheck, 
  ArrowRight,
  Sparkles,
  HelpCircle
} from 'lucide-react';

import { WhmcsHostingPackage, HostingService, CartItem } from '../types';
import { MOCK_WHMCS_PACKAGES } from '../data/mockWhmcsData';
import { formatPrice, calculateTaxBreakdown } from '../utils/domainSearchEngine';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onOrderComplete: (newService: HostingService) => void;
  onAddToCart?: (item: CartItem) => void;
  userDomains?: string[];
  currency?: string;
}

export const WhmcsProductCatalogModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onOrderComplete,
  onAddToCart,
  userDomains = ['nexustech.io', 'apexdomain.com'],
  currency = 'USD'
}) => {
  const [selectedPackage, setSelectedPackage] = useState<WhmcsHostingPackage>(MOCK_WHMCS_PACKAGES[1]);
  const [targetDomain, setTargetDomain] = useState<string>(userDomains[0] || 'nexustech.io');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually'>('annually');
  const [selectedServerRegion, setSelectedServerRegion] = useState('US-East Equinix NY4');

  // Addons
  const [addDedicatedIp, setAddDedicatedIp] = useState(false);
  const [addDailyBackups, setAddDailyBackups] = useState(true);

  if (!isOpen) return null;

  const calculateTotal = () => {
    let base = billingCycle === 'annually' ? selectedPackage.priceAnnually : selectedPackage.priceMonthly;
    if (addDedicatedIp) base += billingCycle === 'annually' ? 36 : 3.50;
    if (addDailyBackups) base += billingCycle === 'annually' ? 24 : 2.50;
    return base;
  };

  const taxDetails = calculateTaxBreakdown({
    subtotalUsd: calculateTotal(),
    currency,
    taxRatePercent: 15,
  });

  const handleAddToCartClick = () => {
    if (onAddToCart) {
      const price = calculateTotal();
      const newItem: CartItem = {
        id: `cart-hosting-${selectedPackage.id}-${Date.now()}`,
        domain: targetDomain,
        tld: targetDomain.split('.').pop() || 'com',
        registrationPrice: price,
        renewalPrice: price,
        years: billingCycle === 'annually' ? 1 : 1,
        privacyProtection: true,
        emailForwarding: true,
        dnssecEnabled: true,
        hostingAddon: false,
        icannFee: 0,
        isPremium: false,
        itemType: 'hosting',
        packageName: selectedPackage.name,
        planId: selectedPackage.id,
        billingCycle: billingCycle,
        serverRegion: selectedServerRegion,
        diskLimitMb: selectedPackage.diskLimitMb,
        bandwidthLimitGb: selectedPackage.bandwidthLimitGb,
        module: selectedPackage.module
      };
      onAddToCart(newItem);
    }
    onClose();
  };

  const handleCheckout = () => {
    const newService: HostingService = {
      id: `hs-${Date.now()}`,
      name: `${selectedPackage.name} (${targetDomain})`,
      domain: targetDomain,
      planName: selectedPackage.name,
      diskUsageMb: 120,
      diskLimitMb: selectedPackage.diskLimitMb || 50000,
      bandwidthUsageGb: 4.2,
      bandwidthLimitGb: selectedPackage.bandwidthLimitGb || 1000,
      ipAddress: addDedicatedIp ? '198.51.100.99' : '198.51.100.42',
      phpVersion: '8.2',
      cpanelUser: targetDomain.replace(/[^a-zA-Z0-0]/g, '').substring(0, 8),
      price: calculateTotal(),
      billingCycle: billingCycle === 'annually' ? 'annually' : 'monthly',
      startDate: new Date().toISOString().split('T')[0],
      expiryDate: new Date(Date.now() + (billingCycle === 'annually' ? 365 : 30) * 86400000).toISOString().split('T')[0],
      autoRenew: true,
      status: 'active',
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
          title: 'Instant Auto-Provisioning Complete',
          description: `Account created via cPanel/WHM API module on server ${selectedServerRegion}.`,
          type: 'provisioned',
        }
      ]
    };

    onOrderComplete(newService);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 md:p-8 space-y-6 shadow-2xl my-8 text-slate-900 dark:text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-600 text-white">
                Hosting Product Catalog
              </span>
              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-mono font-bold">
                ✓ Instant Provisioning Guarantee
              </span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              Select Web Hosting Package
            </h2>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 dark:hover:text-white font-bold text-sm p-1">
            ✕
          </button>
        </div>

        {/* Package Selector Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {MOCK_WHMCS_PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              onClick={() => setSelectedPackage(pkg)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                selectedPackage.id === pkg.id
                  ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 shadow-lg ring-1 ring-indigo-500'
                  : 'bg-slate-50 dark:bg-slate-950/60 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400">{pkg.category}</div>
              <div className="font-extrabold text-slate-900 dark:text-white text-sm mt-0.5">{pkg.name}</div>
              <div className="mt-2 text-lg font-black text-emerald-600 dark:text-emerald-400 font-mono">
                {formatPrice(billingCycle === 'annually' ? pkg.priceAnnually : pkg.priceMonthly, currency)}
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-sans">/{billingCycle === 'annually' ? 'yr' : 'mo'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Order Details Form */}
        <div className="p-5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
          {/* Column 1: Configuration */}
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <Server className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>1. Configure Hosting Options</span>
            </h3>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Target Primary Domain</label>
              <select
                value={targetDomain}
                onChange={(e) => setTargetDomain(e.target.value)}
                className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono font-bold focus:outline-none"
              >
                {userDomains.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Billing Cycle</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setBillingCycle('monthly')}
                  className={`p-2.5 rounded-xl border text-center font-bold transition-all ${
                    billingCycle === 'monthly' ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-800'
                  }`}
                >
                  Monthly Billing
                </button>
                <button
                  type="button"
                  onClick={() => setBillingCycle('annually')}
                  className={`p-2.5 rounded-xl border text-center font-bold transition-all relative ${
                    billingCycle === 'annually' ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-800'
                  }`}
                >
                  <span>Annual Billing</span>
                  <span className="absolute -top-2 -right-1 px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 text-[9px] font-black uppercase">Save 20%</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Server Cluster Region</label>
              <select
                value={selectedServerRegion}
                onChange={(e) => setSelectedServerRegion(e.target.value)}
                className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none"
              >
                <option value="US-East Equinix NY4">US-East Equinix NY4 (New Jersey, US)</option>
                <option value="EU-Central Interxion FRA1">EU-Central Interxion FRA1 (Frankfurt, DE)</option>
                <option value="Asia-Pacific Singtel DC">Asia-Pacific Singtel DC (Singapore)</option>
              </select>
            </div>
          </div>

          {/* Column 2: Addons & Total */}
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>2. Configurable Hosting Addons</span>
            </h3>

            <div className="space-y-2">
              <label className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 cursor-pointer">
                <div>
                  <div className="font-extrabold text-slate-900 dark:text-white">Dedicated IPv4 Address</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Boost SEO & deliverability reputation ({formatPrice(billingCycle === 'annually' ? 36 : 3.50, currency)})</div>
                </div>
                <input
                  type="checkbox"
                  checked={addDedicatedIp}
                  onChange={(e) => setAddDedicatedIp(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600"
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 cursor-pointer">
                <div>
                  <div className="font-extrabold text-slate-900 dark:text-white">Automated Daily Cloud Backups</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">30-day restore points with cPanel Backup API ({formatPrice(billingCycle === 'annually' ? 24 : 2.50, currency)})</div>
                </div>
                <input
                  type="checkbox"
                  checked={addDailyBackups}
                  onChange={(e) => setAddDailyBackups(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600"
                />
              </label>
            </div>

            {/* Total Box */}
            <div className="p-4 bg-indigo-50 dark:bg-indigo-950/60 rounded-xl border border-indigo-200 dark:border-indigo-800/80 space-y-3">
              <div className="space-y-1">
                <div className="flex justify-between items-center text-xs text-slate-600 dark:text-slate-400">
                  <span>Subtotal:</span>
                  <span className="font-mono font-bold">{taxDetails.subtotalFormatted}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-600 dark:text-slate-400">
                  <span>Est. VAT / Taxes (15%):</span>
                  <span className="font-mono font-bold">{taxDetails.taxAmountFormatted}</span>
                </div>
                <div className="flex justify-between items-center text-sm pt-2 border-t border-indigo-200 dark:border-indigo-800">
                  <span className="font-extrabold text-slate-900 dark:text-white">Total Order Price:</span>
                  <span className="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
                    {taxDetails.grandTotalFormatted}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleAddToCartClick}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5 transition-all"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Cart</span>
                </button>

                <button
                  type="button"
                  onClick={handleCheckout}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5 transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Instant Provision</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
