import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  RefreshCw, 
  Play, 
  Server, 
  Globe, 
  ExternalLink, 
  User, 
  Mail, 
  Search, 
  RotateCcw, 
  Check, 
  X,
  Layers,
  ChevronRight,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';
import { ProvisioningJob } from '../types';
import { provisioningQueueEngine } from '../services/provisioningQueueEngine';
import { registrarManager } from '../services/registrarManager';
import { hostingControlPanelManager } from '../services/hostingControlPanelManager';

export const AdminProvisioningQueueDashboard: React.FC = () => {
  const [jobs, setJobs] = useState<ProvisioningJob[]>(() => provisioningQueueEngine.getJobs());
  const [selectedJob, setSelectedJob] = useState<ProvisioningJob | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [retryingId, setRetryingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = provisioningQueueEngine.subscribe(() => {
      const all = provisioningQueueEngine.getJobs();
      setJobs(all);
      if (selectedJob) {
        const fresh = all.find((j) => j.id === selectedJob.id);
        if (fresh) setSelectedJob(fresh);
      }
    });
    return unsub;
  }, [selectedJob]);

  const filteredJobs = jobs.filter((j) => {
    if (statusFilter !== 'all' && j.status !== statusFilter) return false;
    if (searchTerm) {
      const s = searchTerm.toLowerCase();
      return (
        j.orderId.toLowerCase().includes(s) ||
        (j.invoiceId && j.invoiceId.toLowerCase().includes(s)) ||
        j.customerName.toLowerCase().includes(s) ||
        j.customerEmail.toLowerCase().includes(s) ||
        (j.domain && j.domain.toLowerCase().includes(s)) ||
        (j.packageName && j.packageName.toLowerCase().includes(s))
      );
    }
    return true;
  });

  const handleRetry = (jobId: string) => {
    setRetryingId(jobId);
    provisioningQueueEngine.retryJob(jobId);
    setTimeout(() => setRetryingId(null), 1000);
  };

  const getStatusBadge = (status: ProvisioningJob['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full text-[10px] font-black uppercase flex items-center gap-1">
            <Check className="w-3 h-3" /> Completed
          </span>
        );
      case 'provisioning':
        return (
          <span className="px-2.5 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded-full text-[10px] font-black uppercase flex items-center gap-1">
            <RefreshCw className="w-3 h-3 animate-spin" /> Provisioning
          </span>
        );
      case 'queued':
        return (
          <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-full text-[10px] font-black uppercase flex items-center gap-1">
            <Clock className="w-3 h-3" /> Queued
          </span>
        );
      case 'failed':
        return (
          <span className="px-2.5 py-1 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-full text-[10px] font-black uppercase flex items-center gap-1">
            <X className="w-3 h-3" /> Failed
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Zap className="w-4 h-4" />
              <span>Real-Time Orchestration Queue</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">Asynchronous Provisioning Queue</h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Tracks every paid order through registrar API registration, WHM/cPanel hosting creation, DNS nameserver delegation, and branded welcome email dispatch.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                const queuedOrFailed = jobs.filter((j) => j.status === 'queued' || j.status === 'failed');
                queuedOrFailed.forEach((j) => provisioningQueueEngine.retryJob(j.id));
              }}
              className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg shadow-purple-600/30"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Process All Pending</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total In Queue</span>
          <div className="text-2xl font-black text-white mt-1">{jobs.length}</div>
        </div>
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">Completed</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">
            {jobs.filter((j) => j.status === 'completed').length}
          </div>
        </div>
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">In Progress</span>
          <div className="text-2xl font-black text-cyan-400 mt-1">
            {jobs.filter((j) => j.status === 'provisioning' || j.status === 'queued').length}
          </div>
        </div>
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-[11px] font-bold text-rose-400 uppercase tracking-wider">Failed / Needs Retry</span>
          <div className="text-2xl font-black text-rose-400 mt-1">
            {jobs.filter((j) => j.status === 'failed').length}
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-3 rounded-2xl">
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {(['all', 'queued', 'provisioning', 'completed', 'failed'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all ${
                statusFilter === st
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by order, customer, domain..."
            className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:border-purple-500 outline-none w-full sm:w-64"
          />
        </div>
      </div>

      {/* Jobs Table & Step Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-sm font-black text-white">Queue Workloads</h3>
            <span className="text-xs text-slate-400">{filteredJobs.length} jobs</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase font-extrabold tracking-wider bg-slate-950/40">
                  <th className="py-3 px-4">Order / Service</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Current Step</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredJobs.map((job) => {
                  const isSelected = selectedJob?.id === job.id;
                  return (
                    <tr
                      key={job.id}
                      onClick={() => setSelectedJob(job)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-purple-950/20' : 'hover:bg-slate-800/40'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          {job.serviceType === 'domain' ? (
                            <Globe className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          ) : (
                            <Server className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                          )}
                          <span>{job.domain || job.packageName}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">
                          Order #{job.orderId} • {job.serviceType.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-300">{job.customerName}</div>
                        <div className="text-[10px] text-slate-500 truncate max-w-[120px]">{job.customerEmail}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-slate-300 font-medium block truncate max-w-[150px]">
                          {job.currentStep}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(job.updatedAt).toLocaleTimeString()}
                        </span>
                      </td>
                      <td className="py-3 px-4">{getStatusBadge(job.status)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                          {(job.status === 'failed' || job.status === 'queued') && (
                            <button
                              onClick={() => handleRetry(job.id)}
                              disabled={retryingId === job.id}
                              className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
                            >
                              <RotateCcw className={`w-3 h-3 ${retryingId === job.id ? 'animate-spin' : ''}`} />
                              Retry
                            </button>
                          )}
                          <button
                            onClick={() => setSelectedJob(job)}
                            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-all"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {filteredJobs.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-10 text-slate-500">
                      No matching provisioning queue jobs found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pipeline Step Inspector */}
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5">
          {selectedJob ? (
            <>
              <div className="flex items-start justify-between border-b border-slate-800 pb-4">
                <div>
                  <span className="text-[10px] font-black uppercase text-purple-400 tracking-wider">
                    Pipeline Execution Steps
                  </span>
                  <h3 className="text-base font-black text-white mt-0.5">{selectedJob.domain || selectedJob.packageName}</h3>
                  <p className="text-xs text-slate-400 font-mono">Order: #{selectedJob.orderId}</p>
                </div>
                {getStatusBadge(selectedJob.status)}
              </div>

              {/* Steps Checklist */}
              <div className="space-y-3">
                {selectedJob.steps.map((step, idx) => {
                  const isDone = step.status === 'completed';
                  const isProgress = step.status === 'in_progress';
                  const isFailed = step.status === 'failed';
                  return (
                    <div
                      key={idx}
                      className={`p-3 rounded-2xl border transition-all ${
                        isDone
                          ? 'bg-emerald-500/5 border-emerald-500/20'
                          : isProgress
                          ? 'bg-cyan-500/10 border-cyan-500/40 shadow-md shadow-cyan-500/10'
                          : isFailed
                          ? 'bg-rose-500/10 border-rose-500/30'
                          : 'bg-slate-950/40 border-slate-800/60 opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                              isDone
                                ? 'bg-emerald-500 text-slate-950'
                                : isProgress
                                ? 'bg-cyan-500 text-slate-950 animate-pulse'
                                : isFailed
                                ? 'bg-rose-500 text-white'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {isDone ? '✓' : idx + 1}
                          </span>
                          <span className="text-xs font-bold text-white">{step.name}</span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 uppercase">{step.status}</span>
                      </div>

                      {step.details && (
                        <p className="text-[11px] text-slate-400 mt-2 pl-7 font-mono border-t border-slate-800/60 pt-1.5">
                          {step.details}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Live Provisioned Credentials if Available */}
              {selectedJob.cpanelUsername && (
                <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
                  <span className="text-[10px] font-black uppercase text-cyan-400 tracking-wider block">
                    Provisioned Control Panel Access
                  </span>
                  <div className="text-xs space-y-1 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Username:</span>
                      <strong className="text-white">{selectedJob.cpanelUsername}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">cPanel URL:</span>
                      <a href={selectedJob.cpanelUrl} target="_blank" rel="noreferrer" className="text-cyan-400 hover:underline flex items-center gap-1">
                        Open <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              )}

              {/* Nameservers */}
              {selectedJob.nameservers && selectedJob.nameservers.length > 0 && (
                <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-1.5">
                  <span className="text-[10px] font-black uppercase text-indigo-400 tracking-wider block">
                    Assigned Nameservers ({selectedJob.nameserverMode})
                  </span>
                  <ul className="space-y-1 text-xs font-mono text-slate-300">
                    {selectedJob.nameservers.map((ns, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <span className="text-indigo-400">NS{i + 1}:</span>
                        <span>{ns}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Action Button */}
              {selectedJob.status === 'failed' && (
                <button
                  onClick={() => handleRetry(selectedJob.id)}
                  disabled={retryingId === selectedJob.id}
                  className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all"
                >
                  <RotateCcw className={`w-4 h-4 ${retryingId === selectedJob.id ? 'animate-spin' : ''}`} />
                  <span>Retry Provisioning Pipeline</span>
                </button>
              )}
            </>
          ) : (
            <div className="text-center py-16 text-slate-500">
              <Zap className="w-8 h-8 mx-auto mb-2 opacity-30 text-purple-400" />
              <p className="text-xs font-bold text-slate-400">Select a job to inspect pipeline</p>
              <p className="text-[11px] text-slate-500 mt-1">Live status of WHM, registrar API & emails</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
