import React, { useState, useEffect } from 'react';
import {
  Server,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  HardDrive,
  Zap,
  Database,
  Mail,
  DollarSign,
  Globe,
  Layers,
  Settings,
  RefreshCw,
  Search,
  ShieldCheck,
  Cpu,
  Activity,
  X,
  Copy,
  Tag,
  ArrowUpDown,
  Sparkles,
  Lock,
  FolderArchive,
  Terminal,
  Download,
  Headset,
  Calculator,
  ChevronDown,
  ChevronUp,
  Percent,
  Check,
  Eye,
  EyeOff,
  Archive,
  ArrowRight
} from 'lucide-react';
import {
  HostingCategory,
  HostingFeature,
  HostingPlan,
  HostingServer,
  HostingPromotion,
  HostingBillingCycle,
  HostingFeatureGroup,
  HostingPlanStatus,
  HostingCategoryStatus,
  Currency,
  WhmcsHostingPackage
} from '../types';
import { systemDatabase } from '../services/systemDatabase';
import { formatPrice } from '../utils/domainSearchEngine';

interface AdminHostingPackagesManagerProps {
  hostingPackages?: WhmcsHostingPackage[];
  onAddPackage?: (pkg: WhmcsHostingPackage) => void;
  onUpdatePackage?: (pkg: WhmcsHostingPackage) => void;
  onDeletePackage?: (id: string) => void;
  currency?: Currency;
}

const AVAILABLE_ICONS = [
  'Globe', 'Zap', 'Server', 'Cpu', 'HardDrive', 'Mail', 'ShieldCheck',
  'Layers', 'Sparkles', 'Lock', 'FolderArchive', 'Terminal', 'Download',
  'Database', 'Activity', 'Headset', 'Settings', 'Copy'
];

export const AdminHostingPackagesManager: React.FC<AdminHostingPackagesManagerProps> = ({
  currency = 'USD'
}) => {
  // Database States
  const [categories, setCategories] = useState<HostingCategory[]>([]);
  const [plans, setPlans] = useState<HostingPlan[]>([]);
  const [features, setFeatures] = useState<HostingFeature[]>([]);
  const [servers, setServers] = useState<HostingServer[]>([]);
  const [promotions, setPromotions] = useState<HostingPromotion[]>([]);

  // Navigation & Filter States
  const [activeTab, setActiveTab] = useState<'plans' | 'categories' | 'features' | 'servers' | 'promotions' | 'calculator'>('plans');
  const [planSearch, setPlanSearch] = useState('');
  const [selectedCatFilter, setSelectedCatFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Modal States
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<HostingPlan | null>(null);

  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<HostingCategory | null>(null);

  const [isFeatureModalOpen, setIsFeatureModalOpen] = useState(false);
  const [editingFeature, setEditingFeature] = useState<HostingFeature | null>(null);

  const [isServerModalOpen, setIsServerModalOpen] = useState(false);
  const [editingServer, setEditingServer] = useState<HostingServer | null>(null);

  const [isPromotionModalOpen, setIsPromotionModalOpen] = useState(false);
  const [editingPromotion, setEditingPromotion] = useState<HostingPromotion | null>(null);

  // Upgrade Calculator Simulator States
  const [calcCurrentPlanId, setCalcCurrentPlanId] = useState<string>('');
  const [calcTargetPlanId, setCalcTargetPlanId] = useState<string>('');
  const [calcCurrentCycle, setCalcCurrentCycle] = useState<HostingBillingCycle>('annual');
  const [calcTargetCycle, setCalcTargetCycle] = useState<HostingBillingCycle>('annual');
  const [calcDaysRemaining, setCalcDaysRemaining] = useState<number>(200);

  // Load database state
  const reloadData = () => {
    setCategories(systemDatabase.getHostingCategories(true));
    setPlans(systemDatabase.getHostingPlans({ includeAll: true, status: 'all' }));
    setFeatures(systemDatabase.getHostingFeatures('all'));
    setServers(systemDatabase.getHostingServers());
    setPromotions(systemDatabase.getHostingPromotions(false));
  };

  useEffect(() => {
    reloadData();
    const unsub = systemDatabase.subscribe(() => {
      reloadData();
    });
    return () => unsub();
  }, []);

  const showNotification = (msg: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message: msg, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // ==========================================
  // PLAN FORM HANDLERS
  // ==========================================
  const [planForm, setPlanForm] = useState<Partial<HostingPlan>>({
    name: '',
    slug: '',
    categoryId: '',
    shortDescription: '',
    fullDescription: '',
    icon: 'Globe',
    badge: 'Popular',
    featured: false,
    displayOrder: 1,
    status: 'active',
    pricing: {
      monthly: 7.99,
      quarterly: 22.50,
      semiAnnual: 43.15,
      annual: 79.90,
      biennial: 143.80,
      triennial: 191.70,
      setupFee: 0,
      discountPercent: 20,
      enabledCycles: ['monthly', 'quarterly', 'semiAnnual', 'annual', 'biennial', 'triennial'],
      currency: 'USD',
    },
    resources: {
      storageGb: 25,
      storageType: 'NVMe SSD',
      bandwidthGb: 'unlimited',
      websites: 3,
      domains: 3,
      subdomains: 10,
      emailAccounts: 'unlimited',
      databases: 10,
      ftpAccounts: 5,
      cpuCores: 2,
      ramGb: 2,
      inodes: 350000,
      processes: 50,
      backups: 'Daily Automated',
      ssl: 'Free Let’s Encrypt Wildcard',
      dedicatedIp: false,
    },
    featureIds: [],
    customFeatureValues: {},
    controlPanels: ['cpanel', 'directadmin'],
    serverNodeIds: ['srv-gh-01', 'srv-uk-01', 'srv-de-01', 'srv-us-01'],
    freeDomainEligible: true,
    freeDomainTlds: ['.com', '.online', '.org', '.com.gh'],
  });

  const handleOpenPlanModal = (plan?: HostingPlan) => {
    if (plan) {
      setEditingPlan(plan);
      setPlanForm({ ...plan });
    } else {
      setEditingPlan(null);
      const firstCatId = categories[0]?.id || 'cat-shared';
      const defaultFeatures = features.filter((f) => f.highlight).map((f) => f.id);
      setPlanForm({
        id: `plan-${Date.now().toString(36)}`,
        name: '',
        slug: '',
        categoryId: firstCatId,
        shortDescription: '',
        fullDescription: '',
        icon: 'Globe',
        badge: '',
        featured: false,
        displayOrder: plans.length + 1,
        status: 'active',
        pricing: {
          monthly: 7.99,
          quarterly: 22.50,
          semiAnnual: 43.15,
          annual: 79.90,
          biennial: 143.80,
          triennial: 191.70,
          setupFee: 0,
          discountPercent: 20,
          enabledCycles: ['monthly', 'quarterly', 'semiAnnual', 'annual', 'biennial', 'triennial'],
          currency: 'USD',
        },
        resources: {
          storageGb: 25,
          storageType: 'NVMe SSD',
          bandwidthGb: 'unlimited',
          websites: 3,
          domains: 3,
          subdomains: 10,
          emailAccounts: 'unlimited',
          databases: 10,
          ftpAccounts: 5,
          cpuCores: 2,
          ramGb: 2,
          inodes: 350000,
          processes: 50,
          backups: 'Daily Automated',
          ssl: 'Free Let’s Encrypt Wildcard',
          dedicatedIp: false,
        },
        featureIds: defaultFeatures,
        customFeatureValues: {},
        controlPanels: ['cpanel', 'directadmin'],
        serverNodeIds: servers.map((s) => s.id),
        freeDomainEligible: true,
        freeDomainTlds: ['.com', '.online', '.org', '.com.gh'],
      });
    }
    setIsPlanModalOpen(true);
  };

  const handleSavePlan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!planForm.name || !planForm.categoryId) {
      showNotification('Please provide Plan Name and Category.', 'error');
      return;
    }

    const slug = planForm.slug?.trim() || planForm.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const planToSave: HostingPlan = {
      id: editingPlan?.id || `plan-${Date.now().toString(36)}`,
      name: planForm.name,
      slug,
      categoryId: planForm.categoryId,
      shortDescription: planForm.shortDescription || 'High-performance web hosting.',
      fullDescription: planForm.fullDescription || planForm.shortDescription || '',
      icon: planForm.icon || 'Globe',
      badge: planForm.badge?.trim() || undefined,
      featured: Boolean(planForm.featured),
      displayOrder: Number(planForm.displayOrder) || 1,
      status: (planForm.status as HostingPlanStatus) || 'active',
      pricing: planForm.pricing || {
        monthly: 7.99,
        annual: 79.90,
        setupFee: 0,
        enabledCycles: ['monthly', 'annual'],
        currency: 'USD',
      },
      resources: planForm.resources || {
        storageGb: 25,
        storageType: 'NVMe SSD',
        bandwidthGb: 'unlimited',
        websites: 1,
        domains: 1,
        subdomains: 10,
        emailAccounts: 'unlimited',
        databases: 5,
        ftpAccounts: 5,
        cpuCores: 2,
        ramGb: 2,
        inodes: 350000,
        processes: 50,
        backups: 'Daily Automated',
        ssl: 'Free SSL',
        dedicatedIp: false,
      },
      featureIds: planForm.featureIds || [],
      customFeatureValues: planForm.customFeatureValues || {},
      controlPanels: planForm.controlPanels || ['cpanel'],
      serverNodeIds: planForm.serverNodeIds || [],
      freeDomainEligible: Boolean(planForm.freeDomainEligible),
      freeDomainTlds: planForm.freeDomainTlds || ['.com', '.online', '.org'],
      createdAt: editingPlan?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    systemDatabase.saveHostingPlan(planToSave);
    setIsPlanModalOpen(false);
    showNotification(`Hosting plan "${planToSave.name}" saved successfully!`);
  };

  const handleDuplicatePlan = (id: string) => {
    const cloned = systemDatabase.duplicateHostingPlan(id);
    if (cloned) {
      showNotification(`Cloned plan as "${cloned.name}" (Draft status)`);
    }
  };

  const handleDeletePlan = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to permanently delete plan "${name}"?`)) {
      systemDatabase.deleteHostingPlan(id);
      showNotification(`Plan "${name}" removed from catalogue.`);
    }
  };

  const handleTogglePlanStatus = (plan: HostingPlan) => {
    const nextStatus: HostingPlanStatus = plan.status === 'active' ? 'draft' : 'active';
    systemDatabase.saveHostingPlan({
      ...plan,
      status: nextStatus,
    });
    showNotification(`Plan "${plan.name}" marked as ${nextStatus.toUpperCase()}`);
  };

  // Reorder plans
  const handleMovePlan = (index: number, direction: 'up' | 'down') => {
    const filteredList = plans.filter((p) => selectedCatFilter === 'all' || p.categoryId === selectedCatFilter);
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= filteredList.length) return;

    const listCopy = [...filteredList];
    const temp = listCopy[index];
    listCopy[index] = listCopy[targetIdx];
    listCopy[targetIdx] = temp;

    systemDatabase.reorderHostingPlans(listCopy.map((p) => p.id));
    showNotification('Plan order updated.');
  };

  // ==========================================
  // CATEGORY FORM HANDLERS
  // ==========================================
  const [categoryForm, setCategoryForm] = useState<Partial<HostingCategory>>({
    name: '',
    slug: '',
    shortDescription: '',
    fullDescription: '',
    icon: 'Globe',
    badge: '',
    displayOrder: 1,
    status: 'active',
    featured: true,
    commonFeatures: [],
  });
  const [commonFeatureInput, setCommonFeatureInput] = useState('');

  const handleOpenCategoryModal = (cat?: HostingCategory) => {
    if (cat) {
      setEditingCategory(cat);
      setCategoryForm({ ...cat });
    } else {
      setEditingCategory(null);
      setCategoryForm({
        id: `cat-${Date.now().toString(36)}`,
        name: '',
        slug: '',
        shortDescription: '',
        fullDescription: '',
        icon: 'Globe',
        badge: '',
        displayOrder: categories.length + 1,
        status: 'active',
        featured: true,
        commonFeatures: [
          'Pure PCIe NVMe SSD Storage',
          'Free Wildcard SSL Certificate',
          'cPanel / DirectAdmin Access',
          'Automated Daily Offsite Backups',
          '24/7 Expert Tier-3 Technical Support'
        ],
      });
    }
    setIsCategoryModalOpen(true);
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!categoryForm.name) {
      showNotification('Please enter a Category Name', 'error');
      return;
    }
    const slug = categoryForm.slug?.trim() || categoryForm.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const catToSave: HostingCategory = {
      id: editingCategory?.id || `cat-${Date.now().toString(36)}`,
      name: categoryForm.name,
      slug,
      shortDescription: categoryForm.shortDescription || '',
      fullDescription: categoryForm.fullDescription || categoryForm.shortDescription || '',
      icon: categoryForm.icon || 'Globe',
      badge: categoryForm.badge?.trim() || undefined,
      displayOrder: Number(categoryForm.displayOrder) || 1,
      status: (categoryForm.status as HostingCategoryStatus) || 'active',
      featured: Boolean(categoryForm.featured),
      commonFeatures: categoryForm.commonFeatures || [],
      seoTitle: categoryForm.seoTitle || `${categoryForm.name} Hosting | ApexDomain`,
      seoDescription: categoryForm.seoDescription || categoryForm.shortDescription,
      createdAt: editingCategory?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    systemDatabase.saveHostingCategory(catToSave);
    setIsCategoryModalOpen(false);
    showNotification(`Category "${catToSave.name}" saved!`);
  };

  const handleDeleteCategory = (id: string, name: string) => {
    const plansInCat = plans.filter((p) => p.categoryId === id);
    if (plansInCat.length > 0) {
      if (!window.confirm(`Warning: There are ${plansInCat.length} plan(s) assigned to "${name}". Deleting the category will unlink these plans. Proceed?`)) {
        return;
      }
    } else {
      if (!window.confirm(`Delete category "${name}"?`)) return;
    }
    systemDatabase.deleteHostingCategory(id);
    showNotification(`Category "${name}" deleted.`);
  };

  // ==========================================
  // FEATURE LIBRARY HANDLERS
  // ==========================================
  const [featureForm, setFeatureForm] = useState<Partial<HostingFeature>>({
    name: '',
    group: 'resources',
    icon: 'HardDrive',
    description: '',
    tooltip: '',
    highlight: true,
    displayOrder: 1,
  });

  const handleOpenFeatureModal = (feat?: HostingFeature) => {
    if (feat) {
      setEditingFeature(feat);
      setFeatureForm({ ...feat });
    } else {
      setEditingFeature(null);
      setFeatureForm({
        id: `feat-${Date.now().toString(36)}`,
        name: '',
        group: 'resources',
        icon: 'HardDrive',
        description: '',
        tooltip: '',
        highlight: true,
        displayOrder: features.length + 1,
      });
    }
    setIsFeatureModalOpen(true);
  };

  const handleSaveFeature = (e: React.FormEvent) => {
    e.preventDefault();
    if (!featureForm.name) {
      showNotification('Feature name is required.', 'error');
      return;
    }
    const featToSave: HostingFeature = {
      id: editingFeature?.id || `feat-${Date.now().toString(36)}`,
      name: featureForm.name,
      group: (featureForm.group as HostingFeatureGroup) || 'resources',
      icon: featureForm.icon || 'HardDrive',
      description: featureForm.description || '',
      tooltip: featureForm.tooltip || undefined,
      highlight: Boolean(featureForm.highlight),
      displayOrder: Number(featureForm.displayOrder) || 1,
    };
    systemDatabase.saveHostingFeature(featToSave);
    setIsFeatureModalOpen(false);
    showNotification(`Feature "${featToSave.name}" saved in library.`);
  };

  const handleDeleteFeature = (id: string, name: string) => {
    if (window.confirm(`Delete feature "${name}" from the reusable library?`)) {
      systemDatabase.deleteHostingFeature(id);
      showNotification(`Feature "${name}" deleted.`);
    }
  };

  // ==========================================
  // SERVER CLUSTER HANDLERS
  // ==========================================
  const [serverForm, setServerForm] = useState<Partial<HostingServer>>({
    name: '',
    hostname: '',
    ipAddress: '',
    location: 'Accra, Ghana 🇬🇭',
    locationCode: 'GH',
    provider: 'MDXi Tier-3 Datacenter',
    controlPanel: 'cpanel',
    apiEndpoint: '',
    apiCredentialsConfigured: true,
    maxCapacityAccounts: 500,
    activeAccounts: 0,
    status: 'online',
    cpuLoad: 20,
    ramUsage: 35,
    diskUsage: 30,
    pingMs: 15,
  });

  const handleOpenServerModal = (srv?: HostingServer) => {
    if (srv) {
      setEditingServer(srv);
      setServerForm({ ...srv });
    } else {
      setEditingServer(null);
      setServerForm({
        id: `srv-${Date.now().toString(36)}`,
        name: '',
        hostname: '',
        ipAddress: '',
        location: 'Accra, Ghana 🇬🇭',
        locationCode: 'GH',
        provider: 'MDXi / MainOne Datacenter',
        controlPanel: 'cpanel',
        apiEndpoint: '',
        apiCredentialsConfigured: true,
        maxCapacityAccounts: 500,
        activeAccounts: 0,
        status: 'online',
        cpuLoad: 15,
        ramUsage: 25,
        diskUsage: 20,
        pingMs: 18,
      });
    }
    setIsServerModalOpen(true);
  };

  const handleSaveServer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serverForm.name || !serverForm.hostname || !serverForm.ipAddress) {
      showNotification('Please provide Server Name, Hostname, and IP Address.', 'error');
      return;
    }
    const srvToSave: HostingServer = {
      id: editingServer?.id || `srv-${Date.now().toString(36)}`,
      name: serverForm.name,
      hostname: serverForm.hostname,
      ipAddress: serverForm.ipAddress,
      location: serverForm.location || 'Accra, Ghana 🇬🇭',
      locationCode: serverForm.locationCode || 'GH',
      provider: serverForm.provider || 'Datacenter',
      controlPanel: serverForm.controlPanel || 'cpanel',
      apiEndpoint: serverForm.apiEndpoint || `https://${serverForm.hostname}:2087/json-api/`,
      apiCredentialsConfigured: Boolean(serverForm.apiCredentialsConfigured),
      maxCapacityAccounts: Number(serverForm.maxCapacityAccounts) || 500,
      activeAccounts: Number(serverForm.activeAccounts) || 0,
      status: serverForm.status || 'online',
      cpuLoad: Number(serverForm.cpuLoad) || 20,
      ramUsage: Number(serverForm.ramUsage) || 35,
      diskUsage: Number(serverForm.diskUsage) || 30,
      pingMs: Number(serverForm.pingMs) || 20,
    };
    systemDatabase.saveHostingServer(srvToSave);
    setIsServerModalOpen(false);
    showNotification(`Server node "${srvToSave.name}" registered!`);
  };

  const handleDeleteServer = (id: string, name: string) => {
    if (window.confirm(`Delete server node "${name}"?`)) {
      systemDatabase.deleteHostingServer(id);
      showNotification(`Server node "${name}" removed.`);
    }
  };

  // ==========================================
  // PROMOTIONS & COUPONS HANDLERS
  // ==========================================
  const [promotionForm, setPromotionForm] = useState<Partial<HostingPromotion>>({
    code: '',
    title: '',
    description: '',
    discountPercent: 20,
    discountType: 'percent',
    applicableCategoryIds: [],
    applicablePlanIds: [],
    minBillingCycle: 'monthly',
    startDate: new Date().toISOString().slice(0, 10),
    endDate: '2028-12-31',
    maxUses: 500,
    usedCount: 0,
    isActive: true,
  });

  const handleOpenPromotionModal = (promo?: HostingPromotion) => {
    if (promo) {
      setEditingPromotion(promo);
      setPromotionForm({ ...promo });
    } else {
      setEditingPromotion(null);
      setPromotionForm({
        id: `promo-${Date.now().toString(36)}`,
        code: '',
        title: '',
        description: '',
        discountPercent: 20,
        discountType: 'percent',
        applicableCategoryIds: [],
        applicablePlanIds: [],
        minBillingCycle: 'monthly',
        startDate: new Date().toISOString().slice(0, 10),
        endDate: '2028-12-31',
        maxUses: 500,
        usedCount: 0,
        isActive: true,
      });
    }
    setIsPromotionModalOpen(true);
  };

  const handleSavePromotion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promotionForm.code || !promotionForm.discountPercent) {
      showNotification('Please enter coupon code and discount percentage.', 'error');
      return;
    }
    const promoToSave: HostingPromotion = {
      id: editingPromotion?.id || `promo-${Date.now().toString(36)}`,
      code: promotionForm.code.trim().toUpperCase(),
      title: promotionForm.title || `${promotionForm.discountPercent}% Off Coupon`,
      description: promotionForm.description || '',
      discountPercent: Number(promotionForm.discountPercent) || 10,
      discountType: promotionForm.discountType || 'percent',
      applicableCategoryIds: promotionForm.applicableCategoryIds || [],
      applicablePlanIds: promotionForm.applicablePlanIds || [],
      minBillingCycle: promotionForm.minBillingCycle,
      startDate: promotionForm.startDate || new Date().toISOString().slice(0, 10),
      endDate: promotionForm.endDate || '2028-12-31',
      maxUses: Number(promotionForm.maxUses) || 500,
      usedCount: Number(promotionForm.usedCount) || 0,
      isActive: Boolean(promotionForm.isActive),
    };
    systemDatabase.saveHostingPromotion(promoToSave);
    setIsPromotionModalOpen(false);
    showNotification(`Coupon "${promoToSave.code}" saved!`);
  };

  const handleDeletePromotion = (id: string, code: string) => {
    if (window.confirm(`Delete promotion code "${code}"?`)) {
      systemDatabase.deleteHostingPromotion(id);
      showNotification(`Coupon "${code}" deleted.`);
    }
  };

  // Filtered Plans List
  const filteredPlans = plans.filter((plan) => {
    const matchesSearch =
      plan.name.toLowerCase().includes(planSearch.toLowerCase()) ||
      plan.shortDescription.toLowerCase().includes(planSearch.toLowerCase()) ||
      plan.slug.toLowerCase().includes(planSearch.toLowerCase());
    const matchesCategory = selectedCatFilter === 'all' || plan.categoryId === selectedCatFilter;
    const matchesStatus = statusFilter === 'all' || plan.status === statusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Calculate Upgrade Proration for Admin Simulator
  const upgradeSimulationResult = (calcCurrentPlanId && calcTargetPlanId)
    ? systemDatabase.calculateHostingUpgrade(
        calcCurrentPlanId,
        calcTargetPlanId,
        calcCurrentCycle,
        calcTargetCycle,
        calcDaysRemaining,
        365
      )
    : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 rounded-3xl p-6 sm:p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-cyan-300 text-xs font-black uppercase tracking-wider border border-blue-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              Master Hosting Catalogue Engine
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Database-Driven Hosting Architecture
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl">
              Manage unlimited hosting categories, configure multi-cycle pricing, customize resource quotas, link features from the central library, and oversee server nodes.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => handleOpenPlanModal()}
              className="px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black text-xs rounded-xl shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition-all hover:scale-105"
            >
              <Plus className="w-4 h-4" />
              <span>Create Hosting Plan</span>
            </button>
            <button
              onClick={() => handleOpenCategoryModal()}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 hover:border-slate-500 flex items-center gap-2 transition-all"
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>New Category</span>
            </button>
          </div>
        </div>

        {/* Global Summary Metric Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-800/50 backdrop-blur rounded-xl p-3 border border-slate-700/50">
            <div className="text-xs text-slate-400 font-bold">Active Plans</div>
            <div className="text-xl font-black text-cyan-400">{plans.filter((p) => p.status === 'active').length}</div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur rounded-xl p-3 border border-slate-700/50">
            <div className="text-xs text-slate-400 font-bold">Categories</div>
            <div className="text-xl font-black text-blue-400">{categories.length}</div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur rounded-xl p-3 border border-slate-700/50">
            <div className="text-xs text-slate-400 font-bold">Feature Library</div>
            <div className="text-xl font-black text-emerald-400">{features.length}</div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur rounded-xl p-3 border border-slate-700/50">
            <div className="text-xs text-slate-400 font-bold">Server Nodes</div>
            <div className="text-xl font-black text-purple-400">{servers.length}</div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur rounded-xl p-3 border border-slate-700/50 col-span-2 sm:col-span-1">
            <div className="text-xs text-slate-400 font-bold">Active Coupons</div>
            <div className="text-xl font-black text-amber-400">{promotions.filter((p) => p.isActive).length}</div>
          </div>
        </div>
      </div>

      {/* Notification Banner */}
      {notification && (
        <div className={`p-4 rounded-2xl border flex items-center justify-between text-sm font-bold animate-in slide-in-from-top-2 ${
          notification.type === 'error'
            ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
            : notification.type === 'info'
            ? 'bg-blue-500/10 border-blue-500/30 text-blue-300'
            : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
        }`}>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            <span>{notification.message}</span>
          </div>
          <button onClick={() => setNotification(null)} className="p-1 hover:bg-white/10 rounded-lg">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Tab Navigation Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setActiveTab('plans')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'plans'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>Plans & Packages ({plans.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('categories')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'categories'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Categories ({categories.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('features')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'features'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Feature Library ({features.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('servers')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'servers'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Server Cluster ({servers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('promotions')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'promotions'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>Coupons & Promos ({promotions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('calculator')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 whitespace-nowrap transition-all ${
            activeTab === 'calculator'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>Proration Simulator</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: HOSTING PLANS & PACKAGES */}
      {/* ========================================================================= */}
      {activeTab === 'plans' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row gap-4 items-center justify-between shadow-sm">
            <div className="flex flex-1 items-center gap-3 w-full sm:w-auto">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search plan name, slug, features..."
                  value={planSearch}
                  onChange={(e) => setPlanSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
                />
              </div>

              <select
                value={selectedCatFilter}
                onChange={(e) => setSelectedCatFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 dark:text-slate-100"
              >
                <option value="all">All Categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 dark:text-slate-100"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active Only</option>
                <option value="draft">Drafts Only</option>
                <option value="archived">Archived Only</option>
              </select>
            </div>

            <div className="text-xs font-bold text-slate-500 whitespace-nowrap">
              Showing {filteredPlans.length} of {plans.length} plans
            </div>
          </div>

          {/* Plans Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPlans.map((plan, index) => {
              const category = categories.find((c) => c.id === plan.categoryId);
              const monthlyPrice = plan.pricing.monthly || (plan.pricing.annual ? plan.pricing.annual / 12 : 7.99);
              const annualPrice = plan.pricing.annual || 79.90;

              return (
                <div
                  key={plan.id}
                  className={`bg-white dark:bg-slate-900 rounded-2xl border transition-all duration-200 hover:shadow-xl flex flex-col justify-between overflow-hidden relative ${
                    plan.status === 'draft'
                      ? 'border-dashed border-amber-400/60 dark:border-amber-500/40 opacity-90'
                      : plan.status === 'archived'
                      ? 'border-slate-300 dark:border-slate-800 opacity-60'
                      : plan.featured
                      ? 'border-blue-500 shadow-md shadow-blue-500/10'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  {/* Top Bar with Badge and Status */}
                  <div className="p-5 pb-3 border-b border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-extrabold text-blue-600 dark:text-cyan-400 uppercase tracking-wider">
                            {category?.name || 'Hosting Plan'}
                          </span>
                          {plan.badge && (
                            <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-[10px] font-black border border-blue-200 dark:border-blue-700">
                              {plan.badge}
                            </span>
                          )}
                        </div>
                        <h3 className="text-lg font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
                          <span>{plan.name}</span>
                          {plan.featured && (
                            <Sparkles className="w-4 h-4 text-amber-500" />
                          )}
                        </h3>
                        <div className="text-[11px] font-mono text-slate-400">/{plan.slug}</div>
                      </div>

                      <div className="flex items-center gap-1">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          plan.status === 'active'
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            : plan.status === 'draft'
                            ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                        }`}>
                          {plan.status}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-2">
                      {plan.shortDescription}
                    </p>
                  </div>

                  {/* Pricing Matrix Preview */}
                  <div className="p-5 bg-slate-50/50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-baseline justify-between">
                      <div>
                        <div className="text-2xl font-black text-slate-900 dark:text-white">
                          {formatPrice(monthlyPrice, currency)}
                          <span className="text-xs font-bold text-slate-400">/mo</span>
                        </div>
                        <div className="text-xs font-semibold text-slate-500">
                          {formatPrice(annualPrice, currency)} billed annually
                        </div>
                      </div>

                      {plan.pricing.discountPercent ? (
                        <div className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-black">
                          Save {plan.pricing.discountPercent}%
                        </div>
                      ) : null}
                    </div>

                    {/* Resources Summary Grid */}
                    <div className="grid grid-cols-2 gap-2 mt-4 text-xs font-medium text-slate-600 dark:text-slate-300">
                      <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800/80 p-2 rounded-lg border border-slate-200/60 dark:border-slate-700/60">
                        <HardDrive className="w-3.5 h-3.5 text-blue-500" />
                        <span className="truncate">
                          {plan.resources.storageGb === 'unlimited' ? 'Unlimited' : `${plan.resources.storageGb} GB`} {plan.resources.storageType}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800/80 p-2 rounded-lg border border-slate-200/60 dark:border-slate-700/60">
                        <Globe className="w-3.5 h-3.5 text-cyan-500" />
                        <span className="truncate">
                          {plan.resources.websites === 'unlimited' ? 'Unlimited Sites' : `${plan.resources.websites} Website(s)`}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800/80 p-2 rounded-lg border border-slate-200/60 dark:border-slate-700/60">
                        <Cpu className="w-3.5 h-3.5 text-purple-500" />
                        <span className="truncate">{plan.resources.cpuCores} Core(s) / {plan.resources.ramGb} GB RAM</span>
                      </div>
                      <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800/80 p-2 rounded-lg border border-slate-200/60 dark:border-slate-700/60">
                        <Mail className="w-3.5 h-3.5 text-amber-500" />
                        <span className="truncate">
                          {plan.resources.emailAccounts === 'unlimited' ? 'Unlimited Email' : `${plan.resources.emailAccounts} Mailboxes`}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="p-4 bg-white dark:bg-slate-900 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleMovePlan(index, 'up')}
                        disabled={index === 0}
                        title="Move Up in Display Order"
                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 disabled:opacity-30"
                      >
                        <ChevronUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleMovePlan(index, 'down')}
                        disabled={index === filteredPlans.length - 1}
                        title="Move Down in Display Order"
                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 disabled:opacity-30"
                      >
                        <ChevronDown className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleTogglePlanStatus(plan)}
                        title={plan.status === 'active' ? 'Set as Draft' : 'Publish to Frontend'}
                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300"
                      >
                        {plan.status === 'active' ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-emerald-500" />}
                      </button>

                      <button
                        onClick={() => handleDuplicatePlan(plan.id)}
                        title="Duplicate Plan"
                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-900/30 text-slate-600 dark:text-slate-300 hover:text-blue-600"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleOpenPlanModal(plan)}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 shadow-sm"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>

                      <button
                        onClick={() => handleDeletePlan(plan.id, plan.name)}
                        className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 dark:text-rose-400"
                        title="Delete Plan"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: CATEGORIES CATALOGUE */}
      {/* ========================================================================= */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-slate-900 dark:text-white">
              Hosting Categories ({categories.length})
            </h2>
            <button
              onClick={() => handleOpenCategoryModal()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Add Category</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => {
              const plansInCat = plans.filter((p) => p.categoryId === category.id);
              return (
                <div
                  key={category.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between shadow-sm hover:shadow-lg transition-all"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-cyan-400 border border-blue-200 dark:border-blue-800">
                          <Globe className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-base font-black text-slate-900 dark:text-white">
                            {category.name}
                          </h3>
                          <div className="text-xs font-mono text-slate-400">/{category.slug}</div>
                        </div>
                      </div>

                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        category.status === 'active'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}>
                        {category.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {category.shortDescription}
                    </p>

                    {category.commonFeatures && category.commonFeatures.length > 0 && (
                      <div className="space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                        <div className="text-[11px] font-bold text-slate-400 uppercase">Included in all plans:</div>
                        {category.commonFeatures.slice(0, 3).map((feat, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                            <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                            <span className="truncate">{feat}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500">
                      {plansInCat.length} plan(s) assigned
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleOpenCategoryModal(category)}
                        className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-bold flex items-center gap-1"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(category.id, category.name)}
                        className="p-1.5 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: FEATURE LIBRARY */}
      {/* ========================================================================= */}
      {activeTab === 'features' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white">
                Reusable Feature Library ({features.length})
              </h2>
              <p className="text-xs text-slate-500">
                Define reusable technical features that can be attached to any plan with customized limit values.
              </p>
            </div>
            <button
              onClick={() => handleOpenFeatureModal()}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Feature</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((feat) => (
              <div
                key={feat.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex items-start justify-between gap-3 shadow-sm hover:shadow-md transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-cyan-400 shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">{feat.name}</h4>
                      {feat.highlight && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-600 text-[10px] font-bold">
                          Highlight
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{feat.description}</p>
                    <span className="inline-block mt-2 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase">
                      {feat.group}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleOpenFeatureModal(feat)}
                    className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeleteFeature(feat.id, feat.name)}
                    className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: SERVER CLUSTER NODES */}
      {/* ========================================================================= */}
      {activeTab === 'servers' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white">
                Server Cluster & Datacenter Nodes ({servers.length})
              </h2>
              <p className="text-xs text-slate-500">
                Live monitoring and provisioning target nodes for cPanel, DirectAdmin, and Plesk installations.
              </p>
            </div>
            <button
              onClick={() => handleOpenServerModal()}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Register Node</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {servers.map((srv) => (
              <div
                key={srv.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800">
                      <Server className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-black text-slate-900 dark:text-white">
                        {srv.name}
                      </h3>
                      <div className="text-xs font-mono text-slate-400">
                        {srv.hostname} ({srv.ipAddress})
                      </div>
                    </div>
                  </div>

                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase ${
                    srv.status === 'online'
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                      : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                  }`}>
                    ● {srv.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-center">
                  <div>
                    <div className="text-[11px] font-bold text-slate-400">CPU Load</div>
                    <div className="text-sm font-black text-slate-800 dark:text-slate-200">{srv.cpuLoad}%</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-bold text-slate-400">RAM Usage</div>
                    <div className="text-sm font-black text-slate-800 dark:text-slate-200">{srv.ramUsage}%</div>
                  </div>
                  <div>
                    <div className="text-[11px] font-bold text-slate-400">Ping Latency</div>
                    <div className="text-sm font-black text-emerald-500">{srv.pingMs} ms</div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Location: <strong className="text-slate-700 dark:text-slate-300">{srv.location}</strong></span>
                  <span>Accounts: <strong className="text-slate-700 dark:text-slate-300">{srv.activeAccounts} / {srv.maxCapacityAccounts}</strong></span>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                  <button
                    onClick={() => handleOpenServerModal(srv)}
                    className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-bold"
                  >
                    Edit Node
                  </button>
                  <button
                    onClick={() => handleDeleteServer(srv.id, srv.name)}
                    className="p-1.5 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: PROMOTIONS & COUPONS */}
      {/* ========================================================================= */}
      {activeTab === 'promotions' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white">
                Promotional Coupons ({promotions.length})
              </h2>
              <p className="text-xs text-slate-500">
                Create and manage discount codes for hosting storefront checkouts.
              </p>
            </div>
            <button
              onClick={() => handleOpenPromotionModal()}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Create Coupon</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {promotions.map((promo) => (
              <div
                key={promo.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 font-mono font-black text-sm rounded-lg">
                    {promo.code}
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                    promo.isActive ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {promo.isActive ? 'Active' : 'Disabled'}
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">{promo.title}</h4>
                  <p className="text-xs text-slate-500 mt-1">{promo.description}</p>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1 text-xs">
                  <div className="flex justify-between text-slate-600 dark:text-slate-300">
                    <span>Discount:</span>
                    <strong className="text-emerald-500 font-black">{promo.discountPercent}% OFF</strong>
                  </div>
                  <div className="flex justify-between text-slate-600 dark:text-slate-300">
                    <span>Usage:</span>
                    <strong>{promo.usedCount} / {promo.maxUses} times</strong>
                  </div>
                  <div className="flex justify-between text-slate-600 dark:text-slate-300">
                    <span>Valid Until:</span>
                    <strong>{promo.endDate}</strong>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                  <button
                    onClick={() => handleOpenPromotionModal(promo)}
                    className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-bold"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeletePromotion(promo.id, promo.code)}
                    className="p-1.5 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: PLAN UPGRADE PRORATION SIMULATOR */}
      {/* ========================================================================= */}
      {activeTab === 'calculator' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Calculator className="w-5 h-5 text-blue-600" />
              Hosting Upgrade & Proration Simulator
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Simulate exact mid-cycle upgrade proration calculations when a customer switches between plans.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                Current Active Plan
              </label>
              <select
                value={calcCurrentPlanId}
                onChange={(e) => setCalcCurrentPlanId(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold"
              >
                <option value="">Select Plan...</option>
                {plans.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({formatPrice(p.pricing.annual || 79.9, currency)}/yr)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                Target Upgrade Plan
              </label>
              <select
                value={calcTargetPlanId}
                onChange={(e) => setCalcTargetPlanId(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold"
              >
                <option value="">Select Target Plan...</option>
                {plans.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({formatPrice(p.pricing.annual || 149.9, currency)}/yr)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                Days Remaining in Current Cycle (out of 365)
              </label>
              <input
                type="number"
                min={1}
                max={365}
                value={calcDaysRemaining}
                onChange={(e) => setCalcDaysRemaining(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold"
              />
            </div>
          </div>

          {upgradeSimulationResult ? (
            <div className="p-6 bg-gradient-to-r from-blue-900/20 via-cyan-900/20 to-slate-900/40 rounded-2xl border border-blue-500/30 space-y-4">
              <h3 className="text-sm font-black text-cyan-400 uppercase tracking-wider">
                Proration Calculation Result
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-xs text-slate-400">Current Plan Credit</div>
                  <div className="text-lg font-black text-slate-700 dark:text-slate-200">
                    {formatPrice(upgradeSimulationResult.proratedCreditCurrentPlan, currency)}
                  </div>
                  <div className="text-[10px] text-slate-400">For {upgradeSimulationResult.daysRemaining} days left</div>
                </div>

                <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="text-xs text-slate-400">Target Plan Cost</div>
                  <div className="text-lg font-black text-slate-700 dark:text-slate-200">
                    {formatPrice(upgradeSimulationResult.proratedCostTargetPlan, currency)}
                  </div>
                  <div className="text-[10px] text-slate-400">For {upgradeSimulationResult.daysRemaining} days</div>
                </div>

                <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/30 col-span-2">
                  <div className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">Payable Difference Today</div>
                  <div className="text-2xl font-black text-emerald-500">
                    {formatPrice(upgradeSimulationResult.payableDifference, currency)}
                  </div>
                  <div className="text-xs text-slate-500">
                    Customer immediately upgraded with new limits; renewal date remains unchanged.
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-6 text-xs text-slate-400">
              Select both a current plan and a target plan to calculate proration.
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE / EDIT HOSTING PLAN */}
      {/* ========================================================================= */}
      {isPlanModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-4xl w-full p-6 sm:p-8 max-h-[90vh] overflow-y-auto space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  {editingPlan ? `Edit Hosting Plan: ${editingPlan.name}` : 'Create New Hosting Plan'}
                </h3>
                <p className="text-xs text-slate-500">
                  Configure multi-cycle pricing, storage quotas, compute bounds, and feature badges.
                </p>
              </div>
              <button
                onClick={() => setIsPlanModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePlan} className="space-y-6">
              {/* Section 1: Basic Metadata */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Plan Name *</label>
                  <input
                    type="text"
                    required
                    value={planForm.name || ''}
                    onChange={(e) => setPlanForm({ ...planForm, name: e.target.value })}
                    placeholder="e.g. Business Pro NVMe"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Category *</label>
                  <select
                    required
                    value={planForm.categoryId || ''}
                    onChange={(e) => setPlanForm({ ...planForm, categoryId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">URL Slug</label>
                  <input
                    type="text"
                    value={planForm.slug || ''}
                    onChange={(e) => setPlanForm({ ...planForm, slug: e.target.value })}
                    placeholder="e.g. business-pro-nvme"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Short Description</label>
                  <input
                    type="text"
                    value={planForm.shortDescription || ''}
                    onChange={(e) => setPlanForm({ ...planForm, shortDescription: e.target.value })}
                    placeholder="e.g. Perfect for launching multiple websites with generous NVMe space."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Badge Text</label>
                  <input
                    type="text"
                    value={planForm.badge || ''}
                    onChange={(e) => setPlanForm({ ...planForm, badge: e.target.value })}
                    placeholder="e.g. Most Popular / Best Value"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                  />
                </div>
              </div>

              {/* Section 2: Multi-Cycle Pricing Engine */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl space-y-4 border border-slate-200 dark:border-slate-700">
                <h4 className="text-xs font-black text-blue-600 dark:text-cyan-400 uppercase tracking-wider">
                  Multi-Cycle Pricing Matrix (USD)
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Monthly ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={planForm.pricing?.monthly ?? 7.99}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          pricing: { ...planForm.pricing!, monthly: Number(e.target.value) },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Quarterly ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={planForm.pricing?.quarterly ?? 22.50}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          pricing: { ...planForm.pricing!, quarterly: Number(e.target.value) },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Semi-Annual ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={planForm.pricing?.semiAnnual ?? 43.15}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          pricing: { ...planForm.pricing!, semiAnnual: Number(e.target.value) },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Annual ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={planForm.pricing?.annual ?? 79.90}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          pricing: { ...planForm.pricing!, annual: Number(e.target.value) },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">2-Year ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={planForm.pricing?.biennial ?? 143.80}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          pricing: { ...planForm.pricing!, biennial: Number(e.target.value) },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">3-Year ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={planForm.pricing?.triennial ?? 191.70}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          pricing: { ...planForm.pricing!, triennial: Number(e.target.value) },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-4 pt-2">
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={planForm.freeDomainEligible}
                      onChange={(e) => setPlanForm({ ...planForm, freeDomainEligible: e.target.checked })}
                      className="rounded text-blue-600"
                    />
                    <span>Free Domain Name Eligible on Annual Plans</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={planForm.featured}
                      onChange={(e) => setPlanForm({ ...planForm, featured: e.target.checked })}
                      className="rounded text-blue-600"
                    />
                    <span>Highlight as Featured Plan</span>
                  </label>
                </div>
              </div>

              {/* Section 3: Quotas & Resource Allocation */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl space-y-4 border border-slate-200 dark:border-slate-700">
                <h4 className="text-xs font-black text-purple-600 dark:text-purple-400 uppercase tracking-wider">
                  Hardware & Resource Allocations
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Storage Quota (GB)</label>
                    <input
                      type="text"
                      value={planForm.resources?.storageGb ?? 25}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          resources: { ...planForm.resources!, storageGb: e.target.value === 'unlimited' ? 'unlimited' : Number(e.target.value) || 25 },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Storage Drive Tech</label>
                    <select
                      value={planForm.resources?.storageType || 'NVMe SSD'}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          resources: { ...planForm.resources!, storageType: e.target.value as any },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    >
                      <option value="NVMe SSD">Pure NVMe SSD</option>
                      <option value="SATA SSD">Enterprise SATA SSD</option>
                      <option value="Enterprise SSD">Enterprise SSD Array</option>
                      <option value="Cloud Block Storage">Cloud Block Storage</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Websites Hosted</label>
                    <input
                      type="text"
                      value={planForm.resources?.websites ?? 3}
                      onChange={(e) =>
                        setPlanForm({
                          ...planForm,
                          resources: { ...planForm.resources!, websites: e.target.value === 'unlimited' ? 'unlimited' : Number(e.target.value) || 1 },
                        })
                      }
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">CPU Cores & RAM</label>
                    <div className="flex gap-1">
                      <input
                        type="number"
                        placeholder="vCPUs"
                        value={planForm.resources?.cpuCores ?? 2}
                        onChange={(e) =>
                          setPlanForm({
                            ...planForm,
                            resources: { ...planForm.resources!, cpuCores: Number(e.target.value) || 1 },
                          })
                        }
                        className="w-1/2 px-2 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                      />
                      <input
                        type="number"
                        placeholder="RAM GB"
                        value={planForm.resources?.ramGb ?? 2}
                        onChange={(e) =>
                          setPlanForm({
                            ...planForm,
                            resources: { ...planForm.resources!, ramGb: Number(e.target.value) || 1 },
                          })
                        }
                        className="w-1/2 px-2 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 4: Features Selection from Central Library */}
              <div className="space-y-3">
                <h4 className="text-xs font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                  Attached Features from Reusable Library
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 border border-slate-200 dark:border-slate-800 rounded-xl">
                  {features.map((feat) => {
                    const isSelected = planForm.featureIds?.includes(feat.id);
                    return (
                      <label
                        key={feat.id}
                        className={`flex items-center gap-2 p-2 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-500/40 text-emerald-800 dark:text-emerald-200'
                            : 'bg-slate-50 dark:bg-slate-800 border border-transparent text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) => {
                            const cur = planForm.featureIds || [];
                            if (e.target.checked) {
                              setPlanForm({ ...planForm, featureIds: [...cur, feat.id] });
                            } else {
                              setPlanForm({ ...planForm, featureIds: cur.filter((id) => id !== feat.id) });
                            }
                          }}
                          className="rounded text-emerald-600"
                        />
                        <span className="truncate">{feat.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Modal Buttons */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsPlanModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs rounded-xl shadow-lg shadow-blue-600/30"
                >
                  {editingPlan ? 'Update Plan' : 'Create Plan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE / EDIT CATEGORY */}
      {/* ========================================================================= */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                {editingCategory ? `Edit Category: ${editingCategory.name}` : 'New Hosting Category'}
              </h3>
              <button onClick={() => setIsCategoryModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Category Name *</label>
                <input
                  type="text"
                  required
                  value={categoryForm.name || ''}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  placeholder="e.g. Shared Web Hosting"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">URL Slug</label>
                <input
                  type="text"
                  value={categoryForm.slug || ''}
                  onChange={(e) => setCategoryForm({ ...categoryForm, slug: e.target.value })}
                  placeholder="e.g. shared"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Short Description</label>
                <textarea
                  rows={2}
                  value={categoryForm.shortDescription || ''}
                  onChange={(e) => setCategoryForm({ ...categoryForm, shortDescription: e.target.value })}
                  placeholder="High-speed, reliable NVMe hosting for all web applications."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Badge Text</label>
                <input
                  type="text"
                  value={categoryForm.badge || ''}
                  onChange={(e) => setCategoryForm({ ...categoryForm, badge: e.target.value })}
                  placeholder="e.g. Most Popular"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCategoryModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 rounded-xl font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-xs"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE / EDIT FEATURE */}
      {/* ========================================================================= */}
      {isFeatureModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                {editingFeature ? 'Edit Feature' : 'Add Feature to Library'}
              </h3>
              <button onClick={() => setIsFeatureModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveFeature} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Feature Name *</label>
                <input
                  type="text"
                  required
                  value={featureForm.name || ''}
                  onChange={(e) => setFeatureForm({ ...featureForm, name: e.target.value })}
                  placeholder="e.g. Free Wildcard SSL"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Feature Group</label>
                <select
                  value={featureForm.group || 'resources'}
                  onChange={(e) => setFeatureForm({ ...featureForm, group: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold"
                >
                  <option value="resources">Resources & Storage</option>
                  <option value="security">Security & Defense</option>
                  <option value="email">Email & Delivery</option>
                  <option value="tools">Tools & Control Panel</option>
                  <option value="performance">Speed & Performance</option>
                  <option value="support">Support & SLA</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Short Description</label>
                <input
                  type="text"
                  value={featureForm.description || ''}
                  onChange={(e) => setFeatureForm({ ...featureForm, description: e.target.value })}
                  placeholder="Auto-renewing Let’s Encrypt certificates."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFeatureModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 rounded-xl font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-black text-xs"
                >
                  Save Feature
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE / EDIT SERVER NODE */}
      {/* ========================================================================= */}
      {isServerModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                {editingServer ? 'Edit Server Node' : 'Register Datacenter Node'}
              </h3>
              <button onClick={() => setIsServerModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveServer} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Server Name *</label>
                <input
                  type="text"
                  required
                  value={serverForm.name || ''}
                  onChange={(e) => setServerForm({ ...serverForm, name: e.target.value })}
                  placeholder="e.g. Accra MDXi Tier-3 Node (GH-01)"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Hostname *</label>
                  <input
                    type="text"
                    required
                    value={serverForm.hostname || ''}
                    onChange={(e) => setServerForm({ ...serverForm, hostname: e.target.value })}
                    placeholder="gh-node1.celoxahost.net"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">IP Address *</label>
                  <input
                    type="text"
                    required
                    value={serverForm.ipAddress || ''}
                    onChange={(e) => setServerForm({ ...serverForm, ipAddress: e.target.value })}
                    placeholder="154.160.18.22"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Location & Flag</label>
                  <input
                    type="text"
                    value={serverForm.location || 'Accra, Ghana 🇬🇭'}
                    onChange={(e) => setServerForm({ ...serverForm, location: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Control Panel</label>
                  <select
                    value={serverForm.controlPanel || 'cpanel'}
                    onChange={(e) => setServerForm({ ...serverForm, controlPanel: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold"
                  >
                    <option value="cpanel">cPanel / WHM</option>
                    <option value="directadmin">DirectAdmin</option>
                    <option value="plesk">Plesk Obsidian</option>
                    <option value="cyberpanel">CyberPanel</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsServerModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 rounded-xl font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-black text-xs"
                >
                  Save Node
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CREATE / EDIT PROMOTION */}
      {/* ========================================================================= */}
      {isPromotionModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                {editingPromotion ? 'Edit Coupon' : 'Create Promotional Code'}
              </h3>
              <button onClick={() => setIsPromotionModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePromotion} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Coupon Code *</label>
                <input
                  type="text"
                  required
                  value={promotionForm.code || ''}
                  onChange={(e) => setPromotionForm({ ...promotionForm, code: e.target.value.toUpperCase() })}
                  placeholder="e.g. WELCOME20"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-black uppercase"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Discount % *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    max={100}
                    value={promotionForm.discountPercent || 20}
                    onChange={(e) => setPromotionForm({ ...promotionForm, discountPercent: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Max Uses</label>
                  <input
                    type="number"
                    value={promotionForm.maxUses || 500}
                    onChange={(e) => setPromotionForm({ ...promotionForm, maxUses: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Description</label>
                <input
                  type="text"
                  value={promotionForm.description || ''}
                  onChange={(e) => setPromotionForm({ ...promotionForm, description: e.target.value })}
                  placeholder="Instant 20% discount on first hosting order."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPromotionModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 rounded-xl font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-black text-xs"
                >
                  Save Coupon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
