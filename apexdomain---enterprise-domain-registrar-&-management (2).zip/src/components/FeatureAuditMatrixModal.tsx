import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Clock, 
  HelpCircle, 
  Search, 
  ShieldCheck, 
  DollarSign, 
  Server, 
  Globe, 
  Layers, 
  LifeBuoy, 
  FileText, 
  X, 
  Filter,
  Sparkles,
  Info,
  Sliders,
  ExternalLink
} from 'lucide-react';

export interface FeatureAuditItem {
  id: string;
  category: string;
  feature: string;
  status: 'available' | 'planned' | 'under_consideration';
  notes: string;
}

export const FEATURE_AUDIT_DATA: FeatureAuditItem[] = [
  // Currency Support
  { id: 'fam-curr-1', category: 'Currency Support', feature: 'Multi-currency', status: 'available', notes: 'Some formatting limitations. Improvements planned.' },
  { id: 'fam-curr-2', category: 'Currency Support', feature: 'Auto exchange rate sync', status: 'available', notes: 'Supports ExchangeRate-API, Currency Data API, and currencylayer. Enabled by default for new installs.' },

  // Security & Anti-Spam
  { id: 'fam-sec-1', category: 'Security & Anti-Spam', feature: 'IP blocking', status: 'available', notes: 'Block problematic IPs' },
  { id: 'fam-sec-2', category: 'Security & Anti-Spam', feature: 'CAPTCHA', status: 'available', notes: 'reCAPTCHA v2, reCAPTCHA v3 (score-based), Cloudflare Turnstile and hCaptcha supported.' },
  { id: 'fam-sec-3', category: 'Security & Anti-Spam', feature: 'Stop Forum Spam', status: 'available', notes: 'Community-driven spam prevention' },
  { id: 'fam-sec-4', category: 'Security & Anti-Spam', feature: 'Disposable email blocking', status: 'available', notes: 'Uses FakeFilter' },
  { id: 'fam-sec-5', category: 'Security & Anti-Spam', feature: 'MFA/2FA', status: 'planned', notes: 'Planned before 1.0 release' },
  { id: 'fam-sec-6', category: 'Security & Anti-Spam', feature: 'Activity logs', status: 'available', notes: 'Track what\'s happening' },
  { id: 'fam-sec-7', category: 'Security & Anti-Spam', feature: 'Session protection', status: 'available', notes: 'Hijacking prevention and session limits' },
  { id: 'fam-sec-8', category: 'Security & Anti-Spam', feature: 'IP restrictions for staff', status: 'available', notes: 'Restrict admin access by IP (note: incorrect configuration may lock you out)' },
  { id: 'fam-sec-9', category: 'Security & Anti-Spam', feature: 'Security alerts', status: 'available', notes: 'Checks our Central Alerts API for vulnerabilities' },
  { id: 'fam-sec-10', category: 'Security & Anti-Spam', feature: 'CSRF protection', status: 'available', notes: 'Enabled by default. Browser API calls are handled by the bundled wrapper' },
  { id: 'fam-sec-11', category: 'Security & Anti-Spam', feature: 'Staff permissions', status: 'available', notes: 'Role-based access control' },
  { id: 'fam-sec-12', category: 'Security & Anti-Spam', feature: 'AbuseIPDB', status: 'planned', notes: 'Planned' },

  // Hosting
  { id: 'fam-host-1', category: 'Hosting', feature: 'Auto provisioning', status: 'available', notes: 'Accounts created automatically on order' },
  { id: 'fam-host-2', category: 'Hosting', feature: 'Suspend/cancel', status: 'available', notes: 'Cancellation reasons not sent to control panel (FOSSBilling only)' },
  { id: 'fam-host-3', category: 'Hosting', feature: '1-click client login', status: 'available', notes: 'Depends on server manager support' },
  { id: 'fam-host-4', category: 'Hosting', feature: 'Custom domains', status: 'available', notes: 'Via nameserver updates' },
  { id: 'fam-host-5', category: 'Hosting', feature: 'Domain + hosting orders', status: 'available', notes: 'Register domains alongside hosting' },
  { id: 'fam-host-6', category: 'Hosting', feature: 'Free subdomains', status: 'available', notes: 'Offer subdomains on a base domain you control, with duplicate protection' },

  // Domains
  { id: 'fam-dom-1', category: 'Domains', feature: 'Registration', status: 'available', notes: 'Instant domain registration via EPDP / ICANN EPP module' },
  { id: 'fam-dom-2', category: 'Domains', feature: 'Renewal', status: 'available', notes: 'Auto-renewals and manual renewals with grace period handling' },
  { id: 'fam-dom-3', category: 'Domains', feature: 'Per-domain pricing', status: 'planned', notes: 'Currently per-TLD only' },
  { id: 'fam-dom-4', category: 'Domains', feature: 'Nameserver changes', status: 'available', notes: 'Real-time custom glue records & NS updates' },
  { id: 'fam-dom-5', category: 'Domains', feature: 'Contact updates', status: 'available', notes: 'Registrant, Admin, Tech, and Billing WHOIS contact editor' },
  { id: 'fam-dom-6', category: 'Domains', feature: 'Transfers', status: 'available', notes: 'Inbound & outbound domain transfer with EPP authorization codes' },
  { id: 'fam-dom-7', category: 'Domains', feature: 'Domain locking', status: 'available', notes: 'Registrar Lock (clientTransferProhibited)' },
  { id: 'fam-dom-8', category: 'Domains', feature: 'Privacy controls', status: 'available', notes: 'WHOIS ID Protection mask' },
  { id: 'fam-dom-9', category: 'Domains', feature: 'Per-TLD requirements', status: 'planned', notes: 'Some TLDs need extra info. May be unregistrable in edge cases.' },
  { id: 'fam-dom-10', category: 'Domains', feature: 'DNS management', status: 'under_consideration', notes: 'Under consideration' },

  // Core Features
  { id: 'fam-core-1', category: 'Core Features', feature: 'Network interface selection', status: 'available', notes: 'Modules must respect this. FOSSBilling official ones do.' },
  { id: 'fam-core-2', category: 'Core Features', feature: 'Theming', status: 'available', notes: 'Custom themes supported' },
  { id: 'fam-core-3', category: 'Core Features', feature: 'Widget system', status: 'available', notes: 'New in 0.8.0 — modules can register renderable dashboard widgets' },
  { id: 'fam-core-4', category: 'Core Features', feature: 'Email', status: 'available', notes: 'One outgoing address only' },
  { id: 'fam-core-5', category: 'Core Features', feature: 'Invoicing', status: 'available', notes: 'Automated invoice generation and tax calculations' },
  { id: 'fam-core-6', category: 'Core Features', feature: 'Usage-based pricing', status: 'planned', notes: 'Planned' },
  { id: 'fam-core-7', category: 'Core Features', feature: 'One-time pricing', status: 'available', notes: 'Lifetime / single pay options' },
  { id: 'fam-core-8', category: 'Core Features', feature: 'Recurring pricing', status: 'available', notes: 'Monthly, Quarterly, Annually, Triennially billing cycles' },
  { id: 'fam-core-9', category: 'Core Features', feature: 'Promo codes', status: 'available', notes: 'Basic functionality. More advanced options planned.' },
  { id: 'fam-core-10', category: 'Core Features', feature: 'Translations', status: 'available', notes: 'i18n translation strings' },
  { id: 'fam-core-11', category: 'Core Features', feature: 'Timezone support', status: 'available', notes: 'System-wide only. Per-client timezones planned.' },
  { id: 'fam-core-12', category: 'Core Features', feature: 'File attachments', status: 'planned', notes: 'Planned' },
  { id: 'fam-core-13', category: 'Core Features', feature: 'Virus scanning', status: 'planned', notes: 'Planned' },
  { id: 'fam-core-14', category: 'Core Features', feature: 'Backups/exports', status: 'planned', notes: 'Planned' },
  { id: 'fam-core-15', category: 'Core Features', feature: 'Restore/imports', status: 'planned', notes: 'Planned' },
  { id: 'fam-core-16', category: 'Core Features', feature: 'Custom email templates', status: 'available', notes: 'HTML & Plain-text transactional template editor' },
  { id: 'fam-core-17', category: 'Core Features', feature: 'Auto-updates', status: 'planned', notes: 'Manual updates supported. Auto-update planned.' },
  { id: 'fam-core-18', category: 'Core Features', feature: 'Modular architecture', status: 'available', notes: 'Unofficial themes, modules, gateways, server managers supported' },
  { id: 'fam-core-19', category: 'Core Features', feature: 'Date/time localization', status: 'available', notes: 'Locale-aware formatting' },
  { id: 'fam-core-20', category: 'Core Features', feature: 'Bulk email', status: 'available', notes: 'Via "Massmailer" module' },
  { id: 'fam-core-21', category: 'Core Features', feature: 'Referral system', status: 'planned', notes: 'Planned' },
  { id: 'fam-core-22', category: 'Core Features', feature: 'Auto language detection', status: 'available', notes: 'Uses Accept-Language header' },
  { id: 'fam-core-23', category: 'Core Features', feature: 'Email attachments', status: 'planned', notes: 'Planned' },

  // Tickets & Helpdesk
  { id: 'fam-tkt-1', category: 'Tickets & Helpdesk', feature: 'Client tickets', status: 'available', notes: 'Full support ticket management for authenticated clients' },
  { id: 'fam-tkt-2', category: 'Tickets & Helpdesk', feature: 'Guest tickets', status: 'available', notes: 'Public sales & presales inquiry ticket submitting' },
  { id: 'fam-tkt-3', category: 'Tickets & Helpdesk', feature: 'Email notifications', status: 'available', notes: 'Instant client & staff alert notifications on ticket update' },
  { id: 'fam-tkt-4', category: 'Tickets & Helpdesk', feature: 'Auto ticket closure', status: 'available', notes: 'Inactivity cron auto-close for answered tickets' },
  { id: 'fam-tkt-5', category: 'Tickets & Helpdesk', feature: 'Email-to-ticket', status: 'under_consideration', notes: 'FOSSBilling can\'t read mailboxes currently. Under consideration.' },
  { id: 'fam-tkt-6', category: 'Tickets & Helpdesk', feature: 'Ticket attachments', status: 'planned', notes: 'Planned' },

  // Invoices & PDFs
  { id: 'fam-pdf-1', category: 'Invoices & PDFs', feature: 'PDF generation', status: 'available', notes: 'Uses Dompdf' },
  { id: 'fam-pdf-2', category: 'Invoices & PDFs', feature: 'PDF customization', status: 'available', notes: 'Limited CSS support (Dompdf constraint)' },
  { id: 'fam-pdf-3', category: 'Invoices & PDFs', feature: 'PDF translations', status: 'available', notes: 'Generated in current language' },
];

interface FeatureAuditMatrixModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FeatureAuditMatrixModal: React.FC<FeatureAuditMatrixModalProps> = ({ isOpen, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  const categories = ['All', 'Currency Support', 'Security & Anti-Spam', 'Hosting', 'Domains', 'Core Features', 'Tickets & Helpdesk', 'Invoices & PDFs'];

  const filteredItems = FEATURE_AUDIT_DATA.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesStatus = 
      selectedStatus === 'All' || 
      (selectedStatus === 'Available' && item.status === 'available') ||
      (selectedStatus === 'Planned' && item.status === 'planned') ||
      (selectedStatus === 'Consideration' && item.status === 'under_consideration');

    const matchesSearch = 
      item.feature.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.notes.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesStatus && matchesSearch;
  });

  const availableCount = FEATURE_AUDIT_DATA.filter(i => i.status === 'available').length;
  const plannedCount = FEATURE_AUDIT_DATA.filter(i => i.status === 'planned').length;
  const considerationCount = FEATURE_AUDIT_DATA.filter(i => i.status === 'under_consideration').length;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* HEADER */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-lg tracking-tight text-white">System Feature Capability Matrix</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Audit v0.8.0
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Complete breakdown of Currency, Security, Hosting, Domains, Core Engine, Tickets & PDF capabilities.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SUMMARY STATS & LEGEND */}
        <div className="bg-slate-50 dark:bg-slate-950/70 border-b border-slate-200 dark:border-slate-800 p-4 shrink-0 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            
            {/* Available Now */}
            <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 p-3 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <div>
                  <span className="font-extrabold text-emerald-900 dark:text-emerald-200 block">Available Now (✅)</span>
                  <span className="text-[10px] text-emerald-700 dark:text-emerald-400">Production ready & active</span>
                </div>
              </div>
              <span className="text-lg font-black text-emerald-700 dark:text-emerald-300 font-mono">
                {availableCount}
              </span>
            </div>

            {/* Planned / In Progress */}
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 p-3 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
                <div>
                  <span className="font-extrabold text-amber-900 dark:text-amber-200 block">Planned / In Progress (🚧)</span>
                  <span className="text-[10px] text-amber-700 dark:text-amber-400">Roadmap release scheduled</span>
                </div>
              </div>
              <span className="text-lg font-black text-amber-700 dark:text-amber-300 font-mono">
                {plannedCount}
              </span>
            </div>

            {/* Under Consideration */}
            <div className="bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 p-3 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                <div>
                  <span className="font-extrabold text-indigo-900 dark:text-indigo-200 block">Under Consideration (❓)</span>
                  <span className="text-[10px] text-indigo-700 dark:text-indigo-400">Feedback evaluating</span>
                </div>
              </div>
              <span className="text-lg font-black text-indigo-700 dark:text-indigo-300 font-mono">
                {considerationCount}
              </span>
            </div>

          </div>

          {/* CONTROLS & FILTER ROW */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            
            {/* Search Input */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search features, modules, or notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 sm:pb-0 scrollbar-none">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mr-1 hidden sm:inline">Category:</span>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all whitespace-nowrap ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-1 rounded-xl text-xs font-bold shrink-0">
              <button
                onClick={() => setSelectedStatus('All')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  selectedStatus === 'All' ? 'bg-indigo-600 text-white' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                All Status
              </button>
              <button
                onClick={() => setSelectedStatus('Available')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  selectedStatus === 'Available' ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                ✅ Active
              </button>
              <button
                onClick={() => setSelectedStatus('Planned')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  selectedStatus === 'Planned' ? 'bg-amber-600 text-white' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                🚧 Roadmap
              </button>
            </div>

          </div>
        </div>

        {/* TABLE LIST BODY */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900 shadow-sm">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 sticky top-0 z-10">
                <tr>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Feature Name</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4">Implementation Details / Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-slate-800 dark:text-slate-200 font-medium">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-12 text-center text-slate-500 dark:text-slate-400 space-y-2">
                      <Info className="w-8 h-8 mx-auto text-slate-400" />
                      <p className="font-bold text-sm">No feature matches your search filter.</p>
                      <p className="text-xs">Try clearing search terms or selecting "All Categories".</p>
                    </td>
                  </tr>
                ) : (
                  filteredItems.map((item) => (
                    <tr 
                      key={item.id}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                    >
                      {/* Category Badge */}
                      <td className="py-3 px-4 font-bold shrink-0">
                        <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-bold inline-block border border-slate-200 dark:border-slate-700">
                          {item.category}
                        </span>
                      </td>

                      {/* Feature Name */}
                      <td className="py-3 px-4 font-extrabold text-slate-900 dark:text-white text-xs">
                        {item.feature}
                      </td>

                      {/* Status Symbol Badge */}
                      <td className="py-3 px-4 text-center shrink-0">
                        {item.status === 'available' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                            Available (✅)
                          </span>
                        )}
                        {item.status === 'planned' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                            <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                            Planned (🚧)
                          </span>
                        )}
                        {item.status === 'under_consideration' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-indigo-100 dark:bg-indigo-950/80 text-indigo-800 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
                            <HelpCircle className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                            Evaluating (❓)
                          </span>
                        )}
                      </td>

                      {/* Notes & Description */}
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-300 text-xs leading-relaxed">
                        {item.notes}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* FOOTER */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
            <Info className="w-4 h-4 text-indigo-500" />
            <span>Showing <strong className="text-slate-900 dark:text-white font-mono">{filteredItems.length}</strong> of <strong className="text-slate-900 dark:text-white font-mono">{FEATURE_AUDIT_DATA.length}</strong> system specs</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl shadow transition-colors"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
