import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Key, 
  Headphones, 
  Mail, 
  ArrowRight, 
  X, 
  AlertTriangle, 
  CheckCircle2, 
  Layers, 
  Eye, 
  EyeOff,
  Server,
  RefreshCw
} from 'lucide-react';
import { 
  systemDatabase, 
  SystemUser, 
  DEFAULT_SUPER_ADMIN_PERMISSIONS, 
  DEFAULT_SUPPORT_STAFF_PERMISSIONS 
} from '../services/systemDatabase';
import { Currency } from '../types';

interface PrivilegedPortalGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetPortal?: 'staff' | 'admin' | 'auto';
  onSuccessfulAuth: (user: SystemUser, targetPortal: 'staff' | 'admin') => void;
  currency?: Currency;
}

export const PrivilegedPortalGatewayModal: React.FC<PrivilegedPortalGatewayModalProps> = ({
  isOpen,
  onClose,
  targetPortal = 'auto',
  onSuccessfulAuth,
  currency = 'USD'
}) => {
  const [authMode, setAuthMode] = useState<'credentials' | 'google' | 'mfa_verify' | 'recovery'>('credentials');
  const [portalType, setPortalType] = useState<'staff' | 'admin'>(targetPortal === 'auto' ? 'admin' : targetPortal);
  const [email, setEmail] = useState(portalType === 'admin' ? 'baffourgideon05@gmail.com' : 'support@celoxaghana.online');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [mfaCode, setMfaCode] = useState('');
  const [tempUser, setTempUser] = useState<SystemUser | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [recoveryEmailSent, setRecoveryEmailSent] = useState(false);

  if (!isOpen) return null;

  const handleCredentialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      // In this demo environment, verify against systemDatabase or admin accounts
      const user = systemDatabase.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase());

      // If user is Google Super Admin (baffourgideon05@gmail.com) or demo staff
      const isSuperAdminEmail = email.toLowerCase() === 'baffourgideon05@gmail.com';
      const isDemoStaff = email.toLowerCase().includes('staff') || email.toLowerCase().includes('support') || email.toLowerCase().includes('admin');

      if (!user && !isSuperAdminEmail && !isDemoStaff) {
        setErrorMessage('Privileged Account Not Found. Only authorized internal staff & administrators may authenticate here.');
        systemDatabase.addAuditLog({
          actor: email,
          action: 'PRIVILEGED_LOGIN_FAILED',
          target: `${portalType.toUpperCase()}_GATEWAY`,
          details: `Non-existent account attempted privileged access.`,
          ipAddress: '127.0.0.1',
          status: 'warning'
        });
        return;
      }

      const activeUser: SystemUser = user || {
        id: isSuperAdminEmail ? 'usr-admin-google-001' : 'usr-staff-auto-1',
        fullName: isSuperAdminEmail ? 'Gideon Baffour' : 'Staff Engineer',
        email: email,
        role: isSuperAdminEmail ? 'super_admin' : (portalType === 'admin' ? 'administrator' : 'staff'),
        platformRole: isSuperAdminEmail ? 'super_admin' : (portalType === 'admin' ? 'administrator' : 'staff'),
        accountStatus: 'active',
        isEmailVerified: true,
        department: isSuperAdminEmail ? 'Executive Leadership' : 'Cloud Support',
        staffTitle: isSuperAdminEmail ? 'Head of Infrastructure' : 'Systems Operations',
        avatarUrl: isSuperAdminEmail 
          ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop'
          : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop',
        walletBalanceGhs: isSuperAdminEmail ? 25000 : 800,
        walletBalanceUsd: isSuperAdminEmail ? 1850 : 60,
        twoFactorEnabled: true,
        mfaEnabled: true,
        permissions: (isSuperAdminEmail || portalType === 'admin') 
          ? DEFAULT_SUPER_ADMIN_PERMISSIONS 
          : DEFAULT_SUPPORT_STAFF_PERMISSIONS,
        createdAt: new Date().toISOString()
      };

      // Check role permissions
      const isPrivileged = ['super_admin', 'administrator', 'admin', 'staff'].includes(activeUser.role);
      if (!isPrivileged) {
        setErrorMessage('Access Denied: Your account role (Client) does not have privileged staff/admin authorization.');
        systemDatabase.addAuditLog({
          actor: email,
          action: 'UNAUTHORIZED_PRIVILEGED_ACCESS_ATTEMPT',
          target: `${portalType.toUpperCase()}_GATEWAY`,
          details: `Client account attempted privileged entry. Access rejected.`,
          ipAddress: '127.0.0.1',
          status: 'error'
        });
        return;
      }

      // If MFA enabled, step to MFA verification
      setTempUser(activeUser);
      setAuthMode('mfa_verify');
    }, 450);
  };

  const handleMfaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (mfaCode.length < 6) {
      setErrorMessage('Please enter the 6-digit TOTP / Authenticator code (or use 123456 for test validation).');
      return;
    }

    if (!tempUser) return;

    systemDatabase.setCurrentUser(tempUser);
    systemDatabase.addAuditLog({
      actor: tempUser.email,
      action: 'PRIVILEGED_LOGIN_SUCCESS',
      target: `${portalType.toUpperCase()}_GATEWAY`,
      details: `Multi-factor authentication passed. Session granted for ${tempUser.role.toUpperCase()}.`,
      ipAddress: '127.0.0.1',
      status: 'success'
    });

    onSuccessfulAuth(tempUser, portalType);
    onClose();
  };

  const handleGooglePrivilegedAuth = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const googleUser = systemDatabase.loginOrRegisterWithGoogle({
        fullName: 'Gideon Baffour',
        email: 'baffourgideon05@gmail.com',
        avatarUrl: 'https://lh3.googleusercontent.com/a/default-user=s96-c'
      });

      systemDatabase.addAuditLog({
        actor: 'baffourgideon05@gmail.com',
        action: 'PRIVILEGED_GOOGLE_SSO_SUCCESS',
        target: 'ADMIN_GATEWAY',
        details: 'Google Workspace Single Sign-On verified with Super Admin privileges.',
        ipAddress: '127.0.0.1',
        status: 'success'
      });

      onSuccessfulAuth(googleUser, 'admin');
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden relative text-slate-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Ribbon */}
        <div className="p-6 sm:p-8 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border-b border-slate-800/80 space-y-3">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              Restricted Operations Gateway
            </span>
            <span className="text-[11px] font-mono text-slate-500">Zone 3 Privileged</span>
          </div>

          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black text-white">
              {portalType === 'admin' ? 'Administrator Control Access' : 'Staff Operations Portal'}
            </h2>
          </div>

          <p className="text-xs text-slate-400">
            This entry point is restricted to accredited personnel. All session events and modifications are permanently logged to the tamper-resistant audit trail.
          </p>

          {/* Portal Switcher Tabs */}
          <div className="grid grid-cols-2 p-1 bg-slate-950 border border-slate-800 rounded-xl gap-1 pt-1">
            <button
              onClick={() => {
                setPortalType('admin');
                setEmail('baffourgideon05@gmail.com');
                setErrorMessage(null);
              }}
              className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                portalType === 'admin'
                  ? 'bg-rose-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              <span>Admin Access</span>
            </button>

            <button
              onClick={() => {
                setPortalType('staff');
                setEmail('support@celoxaghana.online');
                setErrorMessage(null);
              }}
              className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                portalType === 'staff'
                  ? 'bg-purple-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Headphones className="w-3.5 h-3.5" />
              <span>Staff Portal</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {errorMessage && (
            <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <span className="font-bold">Authentication Exception</span>
                <p className="text-[11px] text-rose-300/90">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* MODE 1: CREDENTIALS */}
          {authMode === 'credentials' && (
            <form onSubmit={handleCredentialSubmit} className="space-y-4">
              
              {/* Google Workspace Admin SSO Button */}
              <button
                type="button"
                onClick={handleGooglePrivilegedAuth}
                disabled={isLoading}
                className="w-full py-3 px-4 bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2.5 active:scale-[0.99]"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Authenticate with Google Admin Identity</span>
              </button>

              <div className="flex items-center gap-3 my-3">
                <div className="h-px bg-slate-800 flex-1" />
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Or Privileged Credentials</span>
                <div className="h-px bg-slate-800 flex-1" />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Authorized Personnel Email</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@celoxaghana.online"
                    className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300">Privileged Master Password</label>
                  <button
                    type="button"
                    onClick={() => setAuthMode('recovery')}
                    className="text-[11px] font-medium text-rose-400 hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>Verify Credentials & Proceed to 2FA</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

            </form>
          )}

          {/* MODE 2: MFA VERIFICATION */}
          {authMode === 'mfa_verify' && (
            <form onSubmit={handleMfaSubmit} className="space-y-4">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 text-purple-400 flex items-center justify-center mx-auto">
                  <Key className="w-6 h-6" />
                </div>
                <h3 className="font-black text-white text-base">Two-Factor Authentication (2FA)</h3>
                <p className="text-xs text-slate-400">
                  Enter the 6-digit TOTP code from your Google Authenticator or hardware security token for <span className="text-white font-semibold">{tempUser?.email}</span>.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 text-center block">6-Digit Security Token</label>
                <input
                  type="text"
                  maxLength={6}
                  autoFocus
                  value={mfaCode}
                  onChange={(e) => setMfaCode(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="123456"
                  className="w-full text-center py-3 bg-slate-950 border border-purple-500/40 rounded-xl text-lg font-mono tracking-widest text-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-500 font-bold"
                />
                <span className="text-[10px] text-slate-500 text-center block">Testing demo passcode: 123456 or any 6 digits</span>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setAuthMode('credentials')}
                  className="w-1/3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Authenticate & Launch Portal</span>
                </button>
              </div>
            </form>
          )}

          {/* MODE 3: RECOVERY */}
          {authMode === 'recovery' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h3 className="font-black text-white text-base">Secure Privileged Recovery</h3>
                <p className="text-xs text-slate-400">
                  Password reset for staff and admin accounts requires identity verification with Chief Security Lead.
                </p>
              </div>

              {recoveryEmailSent ? (
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs space-y-2 text-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <span className="font-bold block">Authorization Request Dispatched</span>
                  <p className="text-[11px] text-slate-300">
                    A cryptographic security link has been sent to the designated secondary administrator email for verification.
                  </p>
                  <button
                    onClick={() => {
                      setRecoveryEmailSent(false);
                      setAuthMode('credentials');
                    }}
                    className="mt-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl"
                  >
                    Return to Login
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300">Staff Account Email</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setAuthMode('credentials')}
                      className="w-1/3 py-2.5 bg-slate-800 text-slate-300 font-bold text-xs rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        setRecoveryEmailSent(true);
                        systemDatabase.addAuditLog({
                          actor: email,
                          action: 'PRIVILEGED_PASSWORD_RECOVERY_REQUESTED',
                          target: `${portalType.toUpperCase()}_GATEWAY`,
                          details: `Recovery challenge sent for ${email}.`,
                          ipAddress: '127.0.0.1',
                          status: 'info'
                        });
                      }}
                      className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl"
                    >
                      Send Verification Challenge
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer Security Badge */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 text-slate-400" />
            <span>Encrypted Node: SSL 256-Bit</span>
          </div>
          <span className="font-mono">Zone 3 Privileged Boundary</span>
        </div>

      </div>
    </div>
  );
};
