import React, { useState, useEffect } from 'react';
import { 
  Mail, 
  Settings, 
  Send, 
  Eye, 
  Check, 
  X, 
  Edit3, 
  FileText, 
  Layers, 
  Sparkles, 
  RefreshCw,
  ExternalLink,
  Code,
  Palette,
  CheckCircle2
} from 'lucide-react';
import { EmailTemplate, EmailBrandingConfig, EmailOutboxRecord, EmailTemplateId } from '../types';
import { emailTemplateEngine, DEFAULT_TEMPLATES } from '../services/emailTemplateEngine';

export const AdminEmailTemplatesManager: React.FC = () => {
  const [templates, setTemplates] = useState<EmailTemplate[]>(() => emailTemplateEngine.getTemplates());
  const [branding, setBranding] = useState<EmailBrandingConfig>(() => emailTemplateEngine.getBranding());
  const [outbox, setOutbox] = useState<EmailOutboxRecord[]>(() => emailTemplateEngine.getOutbox());
  
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate | null>(templates[0] || null);
  const [activeTab, setActiveTab] = useState<'templates' | 'branding' | 'outbox'>('templates');
  const [isEditing, setIsEditing] = useState(false);
  const [editSubject, setEditSubject] = useState('');
  const [editBody, setEditBody] = useState('');
  const [previewVars, setPreviewVars] = useState<Record<string, string>>({
    customerName: 'Kwame Mensah',
    invoiceNumber: 'INV-100239',
    orderId: 'ORD-100239',
    amount: '18.50',
    currency: 'GH₵',
    domain: 'enterpriseghana.com',
    packageName: 'NVMe Starter Cloud Hosting',
    cpanelUser: 'enterpris',
    cpanelPassword: 'Pass#Celoxa2026!',
    cpanelUrl: 'https://whm01.accra.celoxaghana.online:2083',
    serverIp: '154.160.10.45',
    serverHostname: 'whm01.accra.celoxaghana.online',
    nameserver1: 'ns1.celoxaghana.online',
    nameserver2: 'ns2.celoxaghana.online',
    phpVersion: 'PHP 8.3',
    paymentMethod: 'Custom Mobile Money (MTN MoMo)',
    approvedBy: 'Gideon Baffour (Admin)',
    date: new Date().toLocaleDateString(),
    dueDate: new Date(Date.now() + 7 * 86400000).toLocaleDateString(),
    viewInvoiceUrl: '#',
    years: '1',
    registrarName: 'Celoxa Ghana Internal Registry',
    nameservers: 'ns1.celoxaghana.online, ns2.celoxaghana.online',
    manageDnsUrl: '#',
    paymentInstructions: 'Transfer to MTN MoMo 0244123456 (Celoxa Cloud Ltd). Reference: INV-100239',
  });

  const [testEmailRecipient, setTestEmailRecipient] = useState('admin@celoxaghana.online');
  const [sendSuccess, setSendSuccess] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    const unsub = emailTemplateEngine.subscribe(() => {
      setTemplates(emailTemplateEngine.getTemplates());
      setBranding(emailTemplateEngine.getBranding());
      setOutbox(emailTemplateEngine.getOutbox());
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (selectedTemplate) {
      setEditSubject(selectedTemplate.subjectTemplate);
      setEditBody(selectedTemplate.bodyTemplate);
    }
  }, [selectedTemplate]);

  const handleSaveTemplate = () => {
    if (!selectedTemplate) return;
    emailTemplateEngine.saveTemplate({
      ...selectedTemplate,
      subjectTemplate: editSubject,
      bodyTemplate: editBody,
    });
    setSaveSuccess(true);
    setIsEditing(false);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    emailTemplateEngine.saveBrandingConfig(branding);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleSendTestEmail = () => {
    if (!selectedTemplate) return;
    emailTemplateEngine.dispatchEmail({
      templateId: selectedTemplate.id,
      recipientEmail: testEmailRecipient,
      recipientName: previewVars.customerName || 'Test Customer',
      variables: previewVars,
      relatedOrderId: 'TEST-ORD-001',
    });
    setSendSuccess(true);
    setTimeout(() => setSendSuccess(false), 3000);
  };

  const renderedPreview = selectedTemplate
    ? emailTemplateEngine.renderEmail(selectedTemplate.id, previewVars)
    : { subject: '', html: '' };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-rose-950/30 to-slate-900 border border-slate-800 rounded-3xl p-6 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Mail className="w-4 h-4" />
              <span>Branded Email Notifications & Delivery System</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">Email Template Studio & Outbox Dispatcher</h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Customize transactional templates sent to customers when invoices are paid, cPanel hosting is created, domain registrations complete, or custom payments need review.
            </p>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => setActiveTab('templates')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'templates' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Templates ({templates.length})
            </button>
            <button
              onClick={() => setActiveTab('branding')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'branding' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Brand Theme
            </button>
            <button
              onClick={() => setActiveTab('outbox')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'outbox' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Outbox Logs ({outbox.length})
            </button>
          </div>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-2xl text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Email template and brand settings saved successfully!</span>
        </div>
      )}

      {/* Tab 1: Templates Manager */}
      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Template List */}
          <div className="lg:col-span-1 space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block px-1">
              Available Templates
            </span>
            {templates.map((tpl) => {
              const isSelected = selectedTemplate?.id === tpl.id;
              return (
                <div
                  key={tpl.id}
                  onClick={() => {
                    setSelectedTemplate(tpl);
                    setIsEditing(false);
                  }}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 border-rose-500 shadow-md shadow-rose-500/10'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-white">{tpl.name}</span>
                    <span
                      className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                        tpl.category === 'hosting'
                          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                          : tpl.category === 'domain'
                          ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/30'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {tpl.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{tpl.description}</p>
                </div>
              );
            })}
          </div>

          {/* Right: Template Editor / Live Responsive Preview */}
          <div className="lg:col-span-2 space-y-6">
            {selectedTemplate && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div>
                    <h2 className="text-base font-black text-white">{selectedTemplate.name}</h2>
                    <span className="text-xs font-mono text-slate-400">ID: {selectedTemplate.id}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsEditing(!isEditing)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      {isEditing ? 'View Live Preview' : 'Edit Markup & Variables'}
                    </button>
                    {isEditing && (
                      <button
                        onClick={handleSaveTemplate}
                        className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-black shadow-lg shadow-rose-600/30 transition-all"
                      >
                        Save Template
                      </button>
                    )}
                  </div>
                </div>

                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Subject Line Template</label>
                      <input
                        type="text"
                        value={editSubject}
                        onChange={(e) => setEditSubject(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none focus:border-rose-500"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-xs font-bold text-slate-300">HTML Body Markup</label>
                        <span className="text-[11px] text-slate-500">Insert variables with {'{variableName}'}</span>
                      </div>
                      <textarea
                        rows={12}
                        value={editBody}
                        onChange={(e) => setEditBody(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 font-mono outline-none focus:border-rose-500 leading-relaxed"
                      />
                    </div>

                    {/* Supported Variables Badges */}
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                        Supported Tokens in this Template
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedTemplate.variables.map((v) => (
                          <button
                            key={v}
                            type="button"
                            onClick={() => setEditBody((prev) => `${prev} {${v}}`)}
                            className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-lg text-[11px] font-mono transition-all"
                          >
                            +{'{'}{v}{'}'}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Rendered Subject */}
                    <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Subject:</span>
                      <span className="text-xs font-bold text-white mt-0.5 block">{renderedPreview.subject}</span>
                    </div>

                    {/* HTML Preview Sandbox */}
                    <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden p-2 sm:p-4">
                      <div
                        className="email-preview-container max-w-full overflow-x-auto"
                        dangerouslySetInnerHTML={{ __html: renderedPreview.html }}
                      />
                    </div>

                    {/* Test Send Dispatcher */}
                    <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <span className="text-xs font-bold text-white block">Send Live Test Email</span>
                        <span className="text-[11px] text-slate-400">Dispatches simulated preview to outbox and logs</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="email"
                          value={testEmailRecipient}
                          onChange={(e) => setTestEmailRecipient(e.target.value)}
                          placeholder="your@email.com"
                          className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white outline-none focus:border-rose-500 w-48"
                        />
                        <button
                          onClick={handleSendTestEmail}
                          className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Send Test</span>
                        </button>
                      </div>
                    </div>

                    {sendSuccess && (
                      <p className="text-xs text-emerald-400 font-bold text-right">
                        ✓ Test email dispatched to outbox!
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Branding Settings */}
      {activeTab === 'branding' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-3xl space-y-6">
          <div>
            <h2 className="text-base font-black text-white">Global Email Brand Envelope Settings</h2>
            <p className="text-xs text-slate-400 mt-0.5">Applied across all automated invoices, cPanel login welcome notices, and receipts.</p>
          </div>

          <form onSubmit={handleSaveBranding} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Company Display Name</label>
                <input
                  type="text"
                  value={branding.companyName}
                  onChange={(e) => setBranding({ ...branding, companyName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Sender Email Address</label>
                <input
                  type="email"
                  value={branding.senderEmail}
                  onChange={(e) => setBranding({ ...branding, senderEmail: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Support Email</label>
                <input
                  type="email"
                  value={branding.supportEmail}
                  onChange={(e) => setBranding({ ...branding, supportEmail: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Support Phone</label>
                <input
                  type="text"
                  value={branding.supportPhone || ''}
                  onChange={(e) => setBranding({ ...branding, supportPhone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1">Footer Legal & Registration Text</label>
                <textarea
                  rows={2}
                  value={branding.footerText}
                  onChange={(e) => setBranding({ ...branding, footerText: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-800">
              <button
                type="submit"
                className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-black shadow-lg shadow-rose-600/30 transition-all"
              >
                Save Brand Theme
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 3: Outbox Logs */}
      {activeTab === 'outbox' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-sm font-black text-white">Dispatched Email Outbox Records</h3>
            <span className="text-xs text-slate-400">{outbox.length} records</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase font-extrabold tracking-wider bg-slate-950/40">
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Recipient</th>
                  <th className="py-3 px-4">Subject</th>
                  <th className="py-3 px-4">Template</th>
                  <th className="py-3 px-4 text-right">Delivery Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {outbox.map((mail) => (
                  <tr key={mail.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                      {new Date(mail.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-white block">{mail.recipientName}</span>
                      <span className="text-[10px] text-slate-500">{mail.recipientEmail}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-300 font-medium">{mail.subject}</td>
                    <td className="py-3 px-4 font-mono text-[10px] text-indigo-400">{mail.templateId}</td>
                    <td className="py-3 px-4 text-right">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        <Check className="w-2.5 h-2.5" /> Sent
                      </span>
                    </td>
                  </tr>
                ))}
                {outbox.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-10 text-slate-500">
                      No sent email records in outbox.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
