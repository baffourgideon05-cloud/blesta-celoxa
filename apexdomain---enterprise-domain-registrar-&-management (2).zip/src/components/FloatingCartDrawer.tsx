import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Tag, Check, ArrowRightLeft, Server, Globe, Lock, User, Sparkles } from 'lucide-react';
import { CartItem, Currency, Coupon } from '../types';
import { formatPrice, calculateTaxBreakdown } from '../utils/domainSearchEngine';
import { VALID_COUPONS } from '../data/coupons';
import { systemDatabase, SystemUser } from '../services/systemDatabase';

interface FloatingCartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onRemoveItem: (id: string) => void;
  onUpdateYears: (id: string, years: number) => void;
  onStartWizard: () => void;
  currency: Currency;
  currentUser?: SystemUser | null;
  onOpenAuthModal?: () => void;
}

export const FloatingCartDrawer: React.FC<FloatingCartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onRemoveItem,
  onUpdateYears,
  onStartWizard,
  currency,
  currentUser,
  onOpenAuthModal,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');

  if (!isOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const found = VALID_COUPONS.find((c) => c.code.toUpperCase() === couponCode.trim().toUpperCase());
    if (found) {
      setAppliedCoupon(found);
      setCouponError('');
    } else {
      setCouponError('Invalid promo code. Try WELCOME20 or DOMAINS50.');
    }
  };

  const subtotal = cartItems.reduce((acc, item) => {
    if (item.itemType === 'hosting') {
      return acc + item.registrationPrice;
    }
    return acc + item.registrationPrice * item.years;
  }, 0);

  const totalIcann = cartItems.reduce((acc, item) => {
    if (item.itemType === 'hosting') return acc;
    return acc + item.icannFee * item.years;
  }, 0);

  const discountAmount = appliedCoupon ? (subtotal * appliedCoupon.discountPercent) / 100 : 0;
  const sysTaxRate = systemDatabase.getSettings()?.billing?.defaultTaxRate ?? 15;
  const taxBreakdown = calculateTaxBreakdown({
    subtotalUsd: subtotal,
    currency,
    taxRatePercent: sysTaxRate,
    discountUsd: discountAmount,
    icannFeeUsd: totalIcann,
  });

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/40">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h2 className="font-extrabold text-base text-slate-900 dark:text-white">Your Shopping Cart</h2>
              {currentUser ? (
                <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-bold">
                  {cartItems.length}
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 text-[10px] font-bold flex items-center gap-1">
                  <Lock className="w-2.5 h-2.5" />
                  Sign In Required
                </span>
              )}
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Content: Only visible after login */}
          {!currentUser ? (
            <div className="flex-1 p-6 flex flex-col justify-between overflow-y-auto">
              <div className="space-y-6 my-auto text-center">
                <div className="relative mx-auto w-16 h-16 rounded-3xl bg-gradient-to-tr from-blue-600/20 via-indigo-600/20 to-cyan-500/20 border border-blue-500/30 flex items-center justify-center text-blue-600 dark:text-cyan-400 shadow-xl">
                  <Lock className="w-8 h-8" />
                  <span className="absolute -top-1 -right-1 p-1 rounded-full bg-blue-600 text-white">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </span>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">
                    Sign In to View Cart Items
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 max-w-xs mx-auto leading-relaxed">
                    For privacy and session security, shopping cart items and active hosting reservations are bound to your verified client account.
                  </p>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-700/80 text-left space-y-2.5">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    Protected Cart Features
                  </div>
                  <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300 font-medium">
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span><strong>Scoped Persistence:</strong> Retain your domain reservations and cart across all sessions.</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span><strong>Automated DNS & cPanel:</strong> Instant setup tied directly to your profile.</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span><strong>Direct Invoicing:</strong> Fast Paystack and Mobile Money fulfillment.</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 space-y-2">
                  <button
                    onClick={() => {
                      if (onOpenAuthModal) onOpenAuthModal();
                      onClose();
                    }}
                    className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs sm:text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99]"
                  >
                    <User className="w-4 h-4" />
                    <span>Sign In to Access Cart</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  
                  <p className="text-[11px] text-slate-400">
                    Signing in takes less than a minute with Google or Email.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Cart Content Items */}
              <div className="flex-1 p-5 overflow-y-auto space-y-4">
                {cartItems.length === 0 ? (
                  <div className="py-16 text-center space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
                      <ShoppingBag className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-slate-800 dark:text-slate-200">Your Cart is Empty</h3>
                    <p className="text-xs text-slate-500 max-w-xs mx-auto">
                      Search for domain names or browse hosting packages to add items to your cart.
                    </p>
                  </div>
                ) : (
                  cartItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          {item.itemType === 'hosting' ? (
                            <div>
                              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold uppercase mb-1">
                                <Server className="w-3 h-3 text-indigo-500" />
                                <span>Hosting Package</span>
                              </div>
                              <div className="font-extrabold text-sm text-slate-900 dark:text-white">
                                {item.packageName || 'Web Hosting'}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                                Bound to: <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold">{item.domain}</span>
                              </div>
                            </div>
                          ) : (
                            <div>
                              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 text-[10px] font-bold uppercase mb-1">
                                <Globe className="w-3 h-3 text-blue-500" />
                                <span>Domain Registration</span>
                              </div>
                              <div className="font-extrabold text-sm text-slate-900 dark:text-white">{item.domain}</div>
                              <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1 mt-0.5">
                                <ShieldCheck className="w-3 h-3" /> Free Privacy Protection
                              </div>
                            </div>
                          )}
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-slate-400 hover:text-red-500 p-1 transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400">Term:</span>
                          {item.itemType === 'hosting' ? (
                            <span className="font-bold text-slate-800 dark:text-white uppercase bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded text-[10px]">
                              {item.billingCycle || 'annually'}
                            </span>
                          ) : (
                            <select
                              value={item.years}
                              onChange={(e) => onUpdateYears(item.id, Number(e.target.value))}
                              className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-white"
                            >
                              {[1, 2, 3, 5, 10].map((yr) => (
                                <option key={yr} value={yr}>
                                  {yr} Year{yr > 1 ? 's' : ''}
                                </option>
                              ))}
                            </select>
                          )}
                        </div>

                        <div className="text-right">
                          <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                            {formatPrice(item.itemType === 'hosting' ? item.registrationPrice : item.registrationPrice * item.years, currency)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Cart Footer Summary */}
              {cartItems.length > 0 && (
                <div className="p-5 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-4">
                  
                  {/* Promo Coupon Input */}
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        placeholder="Coupon code (e.g. WELCOME20)..."
                        className="w-full pl-8 pr-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs uppercase font-bold"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-3 py-1.5 bg-slate-900 dark:bg-slate-700 text-white font-bold text-xs rounded-lg hover:bg-slate-800"
                    >
                      Apply
                    </button>
                  </form>

                  {appliedCoupon && (
                    <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex items-center justify-between">
                      <span>Promo {appliedCoupon.code} applied!</span>
                      <span>-{appliedCoupon.discountPercent}% Off</span>
                    </div>
                  )}

                  {couponError && <div className="text-xs text-red-500 font-bold">{couponError}</div>}

                  {/* Price Breakdown */}
                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span className="font-bold">{formatPrice(subtotal, currency)}</span>
                    </div>
                    {appliedCoupon && (
                      <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                        <span>Discount ({appliedCoupon.discountPercent}%):</span>
                        <span>-{formatPrice(discountAmount, currency)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-slate-400">
                      <span>ICANN Registry Fees ($0.18 / yr):</span>
                      <span>{formatPrice(totalIcann, currency)}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Estimated Taxes & Levies ({taxBreakdown.taxRatePercent}%):</span>
                      <span>{taxBreakdown.taxAmountFormatted}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between text-base font-black text-slate-900 dark:text-white">
                      <span>Total Due:</span>
                      <span className="text-blue-600 dark:text-blue-400">{taxBreakdown.grandTotalFormatted}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onClose();
                      onStartWizard();
                    }}
                    className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.01]"
                  >
                    <span>Proceed to Checkout Wizard</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                </div>
              )}
            </>
          )}

        </div>
      </div>
    </div>
  );
};
