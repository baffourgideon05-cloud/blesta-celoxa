import React, { useState } from 'react';
import { 
  ShieldCheck, 
  User, 
  Users, 
  Server, 
  Globe, 
  CreditCard, 
  FileText, 
  Activity, 
  Lock, 
  CheckCircle2, 
  AlertTriangle, 
  Search, 
  Clock, 
  RefreshCw, 
  Eye, 
  Key, 
  Building2, 
  Smartphone, 
  LogOut,
  Sliders,
  Filter,
  Check,
  XCircle,
  HelpCircle,
  LifeBuoy,
  Send,
  MessageSquare,
  Paperclip,
  Tag,
  ChevronRight,
  AlertCircle,
  ShoppingBag,
  Mail
} from 'lucide-react';
import { systemDatabase, SystemUser } from '../services/systemDatabase';
import { ModulePermissions, PlatformRole, PaymentMethodSettings, PaymentSubmission, Currency, SupportTicket } from '../types';
import { AdminPaymentSettings } from './AdminPaymentSettings';
import { AdminOrderOnBehalfModal } from './AdminOrderOnBehalfModal';
import { AdminEmailTemplatesManager } from './AdminEmailTemplatesManager';
import { DEFAULT_PAYMENT_SETTINGS } from '../data/paymentSettings';
import { MOCK_SUPPORT_TICKETS, CANNED_RESPONSE_TEMPLATES } from '../data/mockCustomerServices';

interface StaffPortalViewProps {
  currentUser: SystemUser;
  onNavigateToView?: (view: string) => void;
  onTriggerImpersonation?: (customerName: string, customerEmail: string) => void;
  paymentSettings?: PaymentMethodSettings;
  onUpdatePaymentSettings?: (newSettings: PaymentMethodSettings) => void;
  paymentSubmissions?: PaymentSubmission[];
  onApproveSubmission?: (submissionId: string) => void;
  onRejectSubmission?: (submissionId: string) => void;
  currency?: Currency;
}

export const StaffPortalView: React.FC<StaffPortalViewProps> = ({
  currentUser,
  onNavigateToView,
  onTriggerImpersonation,
  paymentSettings = DEFAULT_PAYMENT_SETTINGS,
  onUpdatePaymentSettings = () => {},
  paymentSubmissions = [],
  onApproveSubmission = () => {},
  onRejectSubmission = () => {},
  currency = 'GHS',
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'customers' | 'services' | 'billing' | 'tickets' | 'emails' | 'audit' | 'profile'>('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showOrderOnBehalfModal, setShowOrderOnBehalfModal] = useState(false);

  // Support Tickets State
  const [staffTickets, setStaffTickets] = useState<SupportTicket[]>(MOCK_SUPPORT_TICKETS);
  const [selectedTicketId, setSelectedTicketId] = useState<string>(MOCK_SUPPORT_TICKETS[0]?.id || '');
  const [ticketReplyText, setTicketReplyText] = useState('');
  const [ticketIsInternal, setTicketIsInternal] = useState(false);
  const [ticketQueue, setTicketQueue] = useState<'all' | 'unassigned' | 'assigned_to_me' | 'open' | 'closed'>('all');
  const [ticketDeptFilter, setTicketDeptFilter] = useState('all');

  const selectedTicket = staffTickets.find(t => t.id === selectedTicketId) || staffTickets[0];

  const handleSendStaffReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketReplyText.trim() || !selectedTicket) return;

    const newMsg = {
      id: `msg-${Date.now()}`,
      senderName: currentUser.fullName,
      senderEmail: currentUser.email,
      isStaff: true,
      isInternalNote: ticketIsInternal,
      content: ticketReplyText.trim(),
      timestamp: new Date().toLocaleString(),
    };

    setStaffTickets(prev => prev.map(t => {
      if (t.id === selectedTicket.id) {
        return {
          ...t,
          status: ticketIsInternal ? t.status : 'answered',
          updatedAt: new Date().toLocaleString(),
          messages: [...t.messages, newMsg],
        };
      }
      return t;
    }));

    setTicketReplyText('');
    setStatusMessage({
      type: 'success',
      text: ticketIsInternal ? 'Internal staff note added to ticket' : 'Public reply sent to customer',
    });
  };

  const handleUpdateTicketStatus = (ticketId: string, status: any) => {
    setStaffTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status, updatedAt: new Date().toLocaleString() } : t));
    setStatusMessage({ type: 'success', text: `Ticket status updated to ${status}` });
  };

  const handleAssignToMe = (ticketId: string) => {
    setStaffTickets(prev => prev.map(t => t.id === ticketId ? { ...t, assignedAgent: `${currentUser.fullName} (${currentUser.staffTitle || 'Engineer'})` } : t));
    setStatusMessage({ type: 'success', text: 'Ticket assigned to your queue' });
  };

  const permissions: ModulePermissions = currentUser.permissions || {
    customers: { view: true, create: false, edit: true, suspend: false, delete: false },
    domains: { view: true, register: true, transfer: true, editDns: true, delete: false },
    hosting: { view: true, provision: true, suspend: true, unsuspend: true, terminate: false },
    billing: { viewInvoices: true, createInvoice: false, refundPayment: false, managePaymentSettings: false },
    servers: { view: true, manage: false, restart: false },
    staff: { view: false, create: false, edit: false, suspend: false, manageRoles: false },
    systemSettings: { view: false, edit: false },
    auditLogs: { view: true, export: false },
  };

  const allUsers = systemDatabase.getUsers();
  const clientUsers = allUsers.filter(u => u.role === 'client' || u.role === 'customer');
  const auditLogs = systemDatabase.getAuditLogs();
  const provisionAccounts = systemDatabase.getProvisionedAccounts();
  const activeSessions = systemDatabase.getUserSessions(currentUser.id);
  const loginActivity = systemDatabase.getLoginActivityRecords(currentUser.id);

  const filteredClients = clientUsers.filter(u => 
    u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.companyName && u.companyName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleLogout = () => {
    systemDatabase.logoutUser();
    if (onNavigateToView) onNavigateToView('home');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans p-4 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
            <div className="flex items-center gap-4">
              <img 
                src={currentUser.avatarUrl || "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop"} 
                alt={currentUser.fullName} 
                className="w-16 h-16 rounded-2xl object-cover ring-4 ring-indigo-500/30 border border-indigo-400/30 shadow-xl"
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-black uppercase tracking-wider rounded-full flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                    Celoxa Staff Member
                  </span>
                  <span className="px-2.5 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold rounded-md">
                    {currentUser.department || 'Technical Operations'}
                  </span>
                </div>
                <h1 className="text-2xl lg:text-3xl font-black text-white tracking-tight mt-1">
                  {currentUser.fullName}
                </h1>
                <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                  <span>{currentUser.staffTitle || 'Support Lead'}</span>
                  <span>•</span>
                  <span>{currentUser.email}</span>
                  <span>•</span>
                  <span className="text-slate-500">ID: {currentUser.id}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              <button
                onClick={() => setShowOrderOnBehalfModal(true)}
                className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/25 border border-indigo-400/30 transition-all flex items-center gap-2"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>+ Order On Behalf</span>
              </button>

              {onNavigateToView && (
                <button 
                  onClick={() => onNavigateToView('home')}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition-all"
                >
                  Public Website
                </button>
              )}
              <button 
                onClick={handleLogout}
                className="px-4 py-2.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 text-xs font-bold rounded-xl border border-rose-500/30 transition-all flex items-center gap-2"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            </div>
          </div>
        </div>

        {/* Permission Overview Notification */}
        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3 text-slate-300">
            <Lock className="w-4 h-4 text-indigo-400 shrink-0" />
            <span>
              <strong>RBAC Permission Engine:</strong> Active scope enforced. Module actions are restricted based on your assigned staff role matrix.
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.customers.view ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Clients</span>
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.hosting.view ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Hosting</span>
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.billing.viewInvoices ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Billing</span>
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.auditLogs.view ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Audit Logs</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'overview'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Activity className="w-4 h-4" />
            Shift Overview
          </button>

          {permissions.customers.view && (
            <button
              onClick={() => setActiveTab('customers')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'customers'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              Client Directory ({clientUsers.length})
            </button>
          )}

          {permissions.hosting.view && (
            <button
              onClick={() => setActiveTab('services')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'services'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Server className="w-4 h-4" />
              Provisioning Queue ({provisionAccounts.length})
            </button>
          )}

          {permissions.billing.viewInvoices && (
            <button
              onClick={() => setActiveTab('billing')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'billing'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              Billing & Transactions
            </button>
          )}

          <button
            onClick={() => setActiveTab('tickets')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'tickets'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <LifeBuoy className="w-4 h-4" />
            Support Desk & SLAs ({staffTickets.filter(t => t.status !== 'closed').length})
          </button>

          <button
            onClick={() => setActiveTab('emails')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'emails'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Mail className="w-4 h-4" />
            Email Studio & Outbox
          </button>

          {permissions.auditLogs.view && (
            <button
              onClick={() => setActiveTab('audit')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'audit'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              Platform Audit Logs
            </button>
          )}

          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'profile'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <User className="w-4 h-4" />
            Staff Security Profile
          </button>
        </div>

        {/* STATUS ALERT */}
        {statusMessage && (
          <div className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between border ${
            statusMessage.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
          }`}>
            <span>{statusMessage.text}</span>
            <button onClick={() => setStatusMessage(null)} className="text-slate-400 hover:text-white">✕</button>
          </div>
        )}

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Assigned Department</span>
                  <Building2 className="w-4 h-4 text-indigo-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{currentUser.department || 'Operations'}</p>
                <p className="text-[11px] text-slate-500 mt-1">Role: {currentUser.staffTitle}</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Total Managed Clients</span>
                  <Users className="w-4 h-4 text-emerald-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{clientUsers.length} Active Accounts</p>
                <p className="text-[11px] text-emerald-400 mt-1">GH₵ and USD Wallets verified</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Provisioning Tasks</span>
                  <Server className="w-4 h-4 text-cyan-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{provisionAccounts.length} Clusters</p>
                <p className="text-[11px] text-slate-400 mt-1">cPanel & Plesk automated nodes</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Audit Trail Log Entries</span>
                  <Activity className="w-4 h-4 text-amber-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{auditLogs.length} Events Logged</p>
                <p className="text-[11px] text-slate-400 mt-1">Real-time system events</p>
              </div>
            </div>

            {/* Shift Activity & Task Queue */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Staff Operations Matrix
                </h2>
                <p className="text-xs text-slate-400">
                  Welcome to the Celoxa Staff Workspace. Based on your assigned department permissions, you can manage client billing, monitor automated provisioning queues, and view system audit records.
                </p>
                <div className="space-y-2 pt-2">
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs flex items-center justify-between">
                    <span className="text-slate-300">Customer Account Access</span>
                    <span className={`font-bold ${permissions.customers.view ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {permissions.customers.view ? 'READ / WRITE' : 'RESTRICTED'}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs flex items-center justify-between">
                    <span className="text-slate-300">Hosting Provisioning & Suspend</span>
                    <span className={`font-bold ${permissions.hosting.provision ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {permissions.hosting.provision ? 'FULL PROVISIONING' : 'READ ONLY'}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs flex items-center justify-between">
                    <span className="text-slate-300">Staff & Role Management</span>
                    <span className="font-bold text-rose-400">SUPER ADMIN ONLY</span>
                  </div>
                </div>
              </div>

              {/* Recent Audit Entries */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <Clock className="w-4 h-4 text-indigo-400" />
                  Recent System Events
                </h2>
                <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                  {auditLogs.slice(0, 5).map(log => (
                    <div key={log.id} className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-indigo-300">{log.action}</span>
                        <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                      </div>
                      <p className="text-slate-400 text-[11px]">{log.details}</p>
                      <div className="text-[10px] text-slate-500 flex items-center justify-between">
                        <span>Actor: {log.actor}</span>
                        <span>IP: {log.ipAddress}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: CUSTOMERS */}
        {activeTab === 'customers' && permissions.customers.view && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="relative w-full sm:w-96">
                <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Search client by name, email, or company..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <span className="text-xs text-slate-400 font-bold">
                Showing {filteredClients.length} client accounts
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                      <th className="p-4 font-extrabold uppercase">Client Name</th>
                      <th className="p-4 font-extrabold uppercase">Company / Phone</th>
                      <th className="p-4 font-extrabold uppercase">Status</th>
                      <th className="p-4 font-extrabold uppercase">Wallet Balances</th>
                      <th className="p-4 font-extrabold uppercase text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredClients.map(client => (
                      <tr key={client.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img 
                              src={client.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop"} 
                              alt="" 
                              className="w-9 h-9 rounded-xl object-cover"
                            />
                            <div>
                              <p className="font-extrabold text-white">{client.fullName}</p>
                              <p className="text-[11px] text-slate-400">{client.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="font-bold text-slate-200">{client.companyName || 'Individual'}</p>
                          <p className="text-[11px] text-slate-400">{client.phone || 'N/A'}</p>
                        </td>
                        <td className="p-4">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            client.accountStatus === 'active' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' :
                            client.accountStatus === 'suspended' ? 'bg-rose-500/10 border border-rose-500/30 text-rose-400' :
                            'bg-amber-500/10 border border-amber-500/30 text-amber-400'
                          }`}>
                            {client.accountStatus || 'ACTIVE'}
                          </span>
                        </td>
                        <td className="p-4 font-mono font-bold">
                          <p className="text-emerald-400">GH₵ {(client.walletBalanceGhs || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                          <p className="text-slate-400 text-[11px]">$ {(client.walletBalanceUsd || 0).toFixed(2)} USD</p>
                        </td>
                        <td className="p-4 text-right">
                          <button 
                            onClick={() => {
                              systemDatabase.topUpUserWallet(client.id, 100, 7);
                              setStatusMessage({ type: 'success', text: `Credited GH₵100 wallet adjustment to ${client.fullName}` });
                            }}
                            className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 font-bold text-[11px] rounded-lg border border-indigo-500/30 transition-all"
                          >
                            + GH₵100 Adjustment
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SERVICES / PROVISIONING QUEUE */}
        {activeTab === 'services' && permissions.hosting.view && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
              <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Server className="w-4 h-4 text-indigo-400" />
                Active Hosting Provisioning Tasks
              </h2>
              <div className="space-y-3">
                {provisionAccounts.map((task, idx) => (
                  <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
                    <div>
                      <p className="font-extrabold text-white text-sm">{task.domain}</p>
                      <p className="text-slate-400 text-[11px]">Server: {task.serverNodeName} • Package: {task.packageName}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold rounded-lg">
                        {task.status || 'ACTIVE_PROVISIONED'}
                      </span>
                      <button 
                        onClick={() => setStatusMessage({ type: 'success', text: `Provisioning ping sent for ${task.domain}` })}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] rounded-lg border border-slate-700"
                      >
                        Ping Node
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: BILLING & PAYMENT GATEWAY CONTROL */}
        {activeTab === 'billing' && permissions.billing.viewInvoices && (
          <div className="space-y-6">
            <AdminPaymentSettings
              settings={paymentSettings}
              onUpdateSettings={onUpdatePaymentSettings}
              submissions={paymentSubmissions}
              onApproveSubmission={onApproveSubmission}
              onRejectSubmission={onRejectSubmission}
              currency={currency}
            />
          </div>
        )}

        {/* TAB: SUPPORT DESK & SLA WORKBENCH */}
        {activeTab === 'tickets' && (
          <div className="space-y-6">
            {/* Header with Queue Counters */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-3xl">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  <LifeBuoy className="w-5 h-5 text-emerald-400" />
                  Engineering & Billing Support Queues
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Active SLA response target tracking, customer 360 context, and internal staff notes.
                </p>
              </div>

              {/* Queue Filters */}
              <div className="flex items-center gap-2 flex-wrap text-xs">
                <button
                  onClick={() => setTicketQueue('all')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                    ticketQueue === 'all' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  All ({staffTickets.length})
                </button>
                <button
                  onClick={() => setTicketQueue('open')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                    ticketQueue === 'open' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Open / In Progress ({staffTickets.filter(t => t.status === 'open' || t.status === 'in_progress').length})
                </button>
                <button
                  onClick={() => setTicketQueue('unassigned')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                    ticketQueue === 'unassigned' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Unassigned ({staffTickets.filter(t => !t.assignedAgent).length})
                </button>
                <button
                  onClick={() => setTicketQueue('closed')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                    ticketQueue === 'closed' ? 'bg-slate-700 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Closed ({staffTickets.filter(t => t.status === 'closed').length})
                </button>
              </div>
            </div>

            {/* Department Filter & Search Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400">Department:</span>
                <select
                  value={ticketDeptFilter}
                  onChange={(e) => setTicketDeptFilter(e.target.value)}
                  className="p-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">All Departments</option>
                  <option value="Domains">Domains</option>
                  <option value="Hosting">Hosting</option>
                  <option value="Billing">Billing</option>
                  <option value="Technical">Technical</option>
                </select>
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Filter by ticket #, customer, subject..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Main Workbench Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: Ticket List */}
              <div className="space-y-3">
                {staffTickets
                  .filter(t => {
                    if (ticketQueue === 'open' && (t.status === 'closed' || t.status === 'resolved')) return false;
                    if (ticketQueue === 'unassigned' && t.assignedAgent) return false;
                    if (ticketQueue === 'closed' && t.status !== 'closed' && t.status !== 'resolved') return false;
                    if (ticketDeptFilter !== 'all' && t.department !== ticketDeptFilter) return false;
                    if (searchTerm) {
                      const q = searchTerm.toLowerCase();
                      return (
                        t.ticketNumber.toLowerCase().includes(q) ||
                        t.subject.toLowerCase().includes(q) ||
                        t.department.toLowerCase().includes(q) ||
                        (t.customerName && t.customerName.toLowerCase().includes(q))
                      );
                    }
                    return true;
                  })
                  .map(ticket => (
                    <div
                      key={ticket.id}
                      onClick={() => setSelectedTicketId(ticket.id)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all space-y-2 ${
                        selectedTicket?.id === ticket.id
                          ? 'bg-slate-900 border-indigo-500 shadow-lg shadow-indigo-600/10 ring-1 ring-indigo-500'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-black text-indigo-400">{ticket.ticketNumber}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          ticket.priority === 'urgent' || ticket.priority === 'high'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : 'bg-slate-800 text-slate-300'
                        }`}>
                          {ticket.priority}
                        </span>
                      </div>

                      <h4 className="font-bold text-white text-xs line-clamp-2">{ticket.subject}</h4>

                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                        <span className="flex items-center gap-1">
                          <Tag className="w-3 h-3 text-indigo-400" />
                          {ticket.department}
                        </span>
                        <span className={`font-bold ${
                          ticket.status === 'open' ? 'text-amber-400' : ticket.status === 'in_progress' ? 'text-blue-400' : 'text-emerald-400'
                        }`}>
                          {ticket.status.toUpperCase()}
                        </span>
                      </div>

                      {ticket.serviceRelated && (
                        <div className="text-[10px] text-slate-500 font-mono">
                          Linked Service: {ticket.serviceRelated}
                        </div>
                      )}
                    </div>
                  ))}
              </div>

              {/* Right Column: Ticket Detail, Customer 360 & Reply Form */}
              {selectedTicket && (
                <div className="lg:col-span-2 space-y-4">
                  <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
                    {/* Header & Quick Action Buttons */}
                    <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-800">
                      <div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-sm font-black text-indigo-400">{selectedTicket.ticketNumber}</span>
                          <span className="px-2.5 py-0.5 rounded-lg text-xs font-extrabold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                            Dept: {selectedTicket.department}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-lg text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                            SLA Target: {selectedTicket.slaTargetHours || 4}h
                          </span>
                        </div>
                        <h3 className="text-lg font-black text-white mt-1">{selectedTicket.subject}</h3>
                        <p className="text-xs text-slate-400 mt-0.5">
                          Assigned Staff: <span className="text-slate-200 font-bold">{selectedTicket.assignedAgent || 'Unassigned Queue'}</span>
                        </p>
                      </div>

                      {/* Quick Assign / Status Controls */}
                      <div className="flex items-center gap-2">
                        {!selectedTicket.assignedAgent?.includes(currentUser.fullName) && (
                          <button
                            onClick={() => handleAssignToMe(selectedTicket.id)}
                            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow transition-all"
                          >
                            Assign to Me
                          </button>
                        )}
                        <select
                          value={selectedTicket.status}
                          onChange={(e) => handleUpdateTicketStatus(selectedTicket.id, e.target.value)}
                          className="p-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-bold"
                        >
                          <option value="open">Status: Open</option>
                          <option value="in_progress">Status: In Progress</option>
                          <option value="answered">Status: Answered</option>
                          <option value="customer_reply">Status: Customer Reply</option>
                          <option value="closed">Status: Closed</option>
                        </select>
                      </div>
                    </div>

                    {/* Customer 360 Context Summary Card */}
                    <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-4 text-xs">
                      <div>
                        <span className="text-slate-400">Customer Identity: </span>
                        <strong className="text-slate-200">{selectedTicket.customerName || 'Gideon Baffour'}</strong>
                        <span className="text-slate-500 text-[11px] font-mono ml-2">({selectedTicket.customerEmail || 'gideon@celoxaghana.online'})</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[11px] text-slate-400">Service: <span className="font-bold text-indigo-300">{selectedTicket.serviceRelated || 'Domain & DNS'}</span></span>
                        {onTriggerImpersonation && (
                          <button
                            onClick={() => onTriggerImpersonation(selectedTicket.customerName || 'Gideon Baffour', selectedTicket.customerEmail || 'gideon@celoxaghana.online')}
                            className="px-2 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-[10px] font-extrabold rounded-lg border border-amber-500/30"
                          >
                            Diagnostic Impersonation
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Discussion History */}
                    <div className="space-y-3 max-h-[380px] overflow-y-auto pr-2">
                      {selectedTicket.messages.map((m) => (
                        <div
                          key={m.id}
                          className={`p-4 rounded-2xl border text-xs space-y-1.5 ${
                            m.isInternalNote
                              ? 'bg-amber-950/30 border-amber-700/50 text-amber-100 ring-1 ring-amber-600/30'
                              : m.isStaff
                              ? 'bg-slate-950 border-slate-800 text-slate-200'
                              : 'bg-indigo-950/30 border-indigo-800/40 text-indigo-100'
                          }`}
                        >
                          <div className="flex items-center justify-between font-bold">
                            <span className="flex items-center gap-2">
                              {m.senderName}
                              {m.isInternalNote && (
                                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 text-[10px] font-black rounded uppercase">
                                  Internal Staff Note (Customer Cannot See)
                                </span>
                              )}
                              {m.isStaff && !m.isInternalNote && (
                                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-black rounded uppercase">
                                  Staff
                                </span>
                              )}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">{m.timestamp}</span>
                          </div>

                          <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>

                          {m.attachments && m.attachments.length > 0 && (
                            <div className="pt-2 border-t border-slate-800/60 flex items-center gap-2">
                              <Paperclip className="w-3.5 h-3.5 text-indigo-400" />
                              {m.attachments.map((att, idx) => (
                                <span key={idx} className="text-[11px] text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
                                  {att.name} ({att.sizeKb} KB)
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Staff Reply & Internal Note Form */}
                    <form onSubmit={handleSendStaffReply} className="pt-4 border-t border-slate-800 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <label className="flex items-center gap-2 text-xs font-extrabold cursor-pointer">
                          <input
                            type="checkbox"
                            checked={ticketIsInternal}
                            onChange={(e) => setTicketIsInternal(e.target.checked)}
                            className="accent-amber-500 rounded"
                          />
                          <span className={ticketIsInternal ? 'text-amber-400' : 'text-slate-400'}>
                            Post as Internal Note (Visible to Staff Only)
                          </span>
                        </label>

                        {/* Canned Response Template Selector */}
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Quick Snippet:</span>
                          <select
                            onChange={(e) => {
                              const tmpl = CANNED_RESPONSE_TEMPLATES.find(t => t.id === e.target.value);
                              if (tmpl) {
                                setTicketReplyText(tmpl.content.replace('{customer_name}', selectedTicket.customerName || 'Customer'));
                              }
                              e.target.value = '';
                            }}
                            defaultValue=""
                            className="bg-slate-950 border border-slate-700 text-slate-300 text-[11px] rounded-lg px-2 py-1 font-medium focus:outline-none focus:border-indigo-500"
                          >
                            <option value="" disabled>Insert Canned Template...</option>
                            {CANNED_RESPONSE_TEMPLATES.map((tmpl) => (
                              <option key={tmpl.id} value={tmpl.id}>
                                [{tmpl.category}] {tmpl.title}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <textarea
                        value={ticketReplyText}
                        onChange={(e) => setTicketReplyText(e.target.value)}
                        placeholder={ticketIsInternal ? 'Type internal note for other staff members...' : 'Type public reply to the customer...'}
                        rows={4}
                        className={`w-full p-3.5 rounded-2xl text-xs text-white focus:outline-none transition-all ${
                          ticketIsInternal
                            ? 'bg-amber-950/20 border border-amber-600/40 focus:border-amber-500'
                            : 'bg-slate-950 border border-slate-800 focus:border-indigo-500'
                        }`}
                      />

                      <div className="flex justify-end gap-3">
                        <button
                          type="submit"
                          className={`px-5 py-2.5 rounded-xl font-black text-xs shadow-lg flex items-center gap-2 transition-all ${
                            ticketIsInternal
                              ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/20'
                              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20'
                          }`}
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>{ticketIsInternal ? 'Save Internal Note' : 'Send Public Reply'}</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 5: EMAIL TEMPLATES STUDIO & OUTBOX */}
        {activeTab === 'emails' && (
          <div className="space-y-6">
            <AdminEmailTemplatesManager />
          </div>
        )}

        {/* TAB 6: AUDIT LOGS */}
        {activeTab === 'audit' && permissions.auditLogs.view && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              Platform Audit Logs
            </h2>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {auditLogs.map(log => (
                <div key={log.id} className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-300">{log.action}</span>
                    <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                  </div>
                  <p className="text-slate-300 font-mono text-[11px]">{log.target}: {log.details}</p>
                  <div className="text-[10px] text-slate-500 flex items-center justify-between">
                    <span>Actor: {log.actor}</span>
                    <span>IP: {log.ipAddress}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 7: SECURITY PROFILE */}
        {activeTab === 'profile' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
            <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Key className="w-4 h-4 text-indigo-400" />
              Staff Security & Session Management
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <h3 className="font-extrabold text-xs text-slate-200 uppercase">Multi-Factor Authentication</h3>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Status:</span>
                  <span className="font-bold text-emerald-400">ENABLED (TOTP Authenticator)</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Staff accounts require 2FA enforcement for all sensitive administrative operations.
                </p>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <h3 className="font-extrabold text-xs text-slate-200 uppercase">Active Web Sessions ({activeSessions.length})</h3>
                <div className="space-y-2">
                  {activeSessions.map(sess => (
                    <div key={sess.id} className="p-2 bg-slate-900 rounded-lg text-[11px] flex items-center justify-between">
                      <div>
                        <p className="font-bold text-slate-200">{sess.device}</p>
                        <p className="text-[10px] text-slate-500">{sess.ip} • {sess.location}</p>
                      </div>
                      {sess.isCurrent ? (
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold text-[10px] rounded">Current</span>
                      ) : (
                        <button 
                          onClick={() => {
                            systemDatabase.revokeSession(sess.id);
                            setStatusMessage({ type: 'success', text: 'Revoked staff web session' });
                          }}
                          className="text-rose-400 hover:underline font-bold text-[10px]"
                        >
                          Revoke
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Admin Order On Behalf Modal */}
      <AdminOrderOnBehalfModal
        isOpen={showOrderOnBehalfModal}
        onClose={() => setShowOrderOnBehalfModal(false)}
        onSuccess={() => {
          setStatusMessage({ type: 'success', text: 'Order on behalf executed successfully!' });
        }}
      />
    </div>
  );
};
