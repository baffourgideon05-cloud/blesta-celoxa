import React, { useState, useMemo } from 'react';
import { 
  Server, 
  HardDrive, 
  Globe, 
  Activity, 
  ShieldCheck, 
  CheckCircle2, 
  ExternalLink, 
  Key, 
  TrendingUp, 
  Lock, 
  Mail, 
  ArrowUpRight, 
  Plus, 
  Search, 
  LayoutGrid, 
  List, 
  Copy, 
  Check, 
  Clock, 
  Sparkles, 
  RefreshCw, 
  AlertCircle, 
  Zap, 
  ArrowRight,
  Shield,
  Layers,
  ChevronRight
} from 'lucide-react';
import { HostingService, Currency, WhmcsHostingPackage, ServiceTimelineEvent } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';
import { hostingControlPanelManager } from '../services/hostingControlPanelManager';
import { systemDatabase } from '../services/systemDatabase';
import { MOCK_WHMCS_PACKAGES } from '../data/mockWhmcsData';

interface VikalinkWebHostingServicesViewProps {
  hostingList: HostingService[];
  currency: Currency;
  onManageControlPanel: (service: HostingService) => void;
  onOrderNewHosting: () => void;
  onServiceUpdated?: (updated: HostingService) => void;
  onViewTimeline?: (title: string, timeline: ServiceTimelineEvent[]) => void;
}

export const VikalinkWebHostingServicesView: React.FC<VikalinkWebHostingServicesViewProps> = ({
  hostingList,
  currency,
  onManageControlPanel,
  onOrderNewHosting,
  onServiceUpdated,
  onViewTimeline,
}) => {
  // Filter & Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'pending' | 'suspended'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // SSO Session Modal
  const [ssoExecuting, setSsoExecuting] = useState<string | null>(null);
  const [ssoSessionData, setSsoSessionData] = useState<{
    target: string;
    url: string;
    token: string;
    expiresIn: number;
    serverHost: string;
    domain: string;
  } | null>(null);

  // Change Password Modal
  const [passwordModalService, setPasswordModalService] = useState<HostingService | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Upgrade/Downgrade Modal
  const [upgradeModalService, setUpgradeModalService] = useState<HostingService | null>(null);
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [upgradeStatus, setUpgradeStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isUpgrading, setIsUpgrading] = useState(false);

  // Toast Notification
  const [toastNotice, setToastNotice] = useState<{ title: string; desc: string; type?: 'success' | 'info' } | null>(null);

  const currentUser = systemDatabase.getCurrentUser();
  const isStaffOrAdmin = ['admin', 'super_admin', 'administrator', 'staff'].includes(currentUser?.role || '');

  // Filtered List
  const filteredHosting = useMemo(() => {
    return hostingList.filter((item) => {
      const matchesSearch = 
        item.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.planName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.cpanelUser.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.ipAddress.includes(searchQuery);

      const matchesStatus = statusFilter === 'all' || item.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [hostingList, searchQuery, statusFilter]);

  // Aggregate Metrics for Top Banner
  const totalActive = hostingList.filter(h => h.status === 'active').length;
  const totalStorageAllocatedGb = hostingList.reduce((acc, curr) => acc + (curr.diskLimitMb || 0), 0) / 1024;
  const totalMonthlySpend = hostingList.reduce((acc, curr) => acc + (curr.price || 0), 0);

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Launch SSO Session
  const handleLaunchSso = async (service: HostingService, target: 'cpanel' | 'whm' | 'webmail' | 'phpmyadmin' | 'filemanager', label: string) => {
    setSsoExecuting(`${service.id}-${target}`);
    try {
      const res = await hostingControlPanelManager.generateSsoSession({
        target,
        username: service.cpanelUser,
        domain: service.domain,
        serverId: service.hostingServerId,
      });

      if (res.success) {
        setSsoSessionData({
          target: label,
          url: res.ssoUrl,
          token: res.token,
          expiresIn: res.expiresInSeconds,
          serverHost: res.serverHostname,
          domain: service.domain,
        });
      }
    } catch (err: any) {
      alert(`SSO Session Error: ${err.message || 'Failed to authenticate with control panel.'}`);
    } finally {
      setSsoExecuting(null);
    }
  };

  // Submit Password Change
  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordModalService) return;
    setPasswordStatus(null);

    if (newPassword.length < 8) {
      setPasswordStatus({ type: 'error', message: 'Password must be at least 8 characters.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordStatus({ type: 'error', message: 'Passwords do not match.' });
      return;
    }

    setIsChangingPassword(true);
    try {
      const res = await hostingControlPanelManager.changeAccountPassword({
        username: passwordModalService.cpanelUser,
        newPassword,
        domain: passwordModalService.domain,
        serverId: passwordModalService.hostingServerId,
      });

      if (res.success) {
        setPasswordStatus({ type: 'success', message: res.message });
        setToastNotice({
          title: 'Password Synchronized',
          desc: `Updated cPanel, FTP, and Webmail password for ${passwordModalService.cpanelUser}.`,
          type: 'success',
        });
        setTimeout(() => {
          setPasswordModalService(null);
          setNewPassword('');
          setConfirmPassword('');
          setPasswordStatus(null);
        }, 1500);
      }
    } catch (err: any) {
      setPasswordStatus({ type: 'error', message: err.message || 'Failed to update remote credentials.' });
    } finally {
      setIsChangingPassword(false);
    }
  };

  // Submit Upgrade/Downgrade
  const handleUpgradeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!upgradeModalService) return;
    setUpgradeStatus(null);

    const targetPkg = MOCK_WHMCS_PACKAGES.find(p => p.id === selectedPackageId);
    if (!targetPkg) return;

    if (targetPkg.name === upgradeModalService.planName) {
      setUpgradeStatus({ type: 'error', message: 'This service is already on the selected plan tier.' });
      return;
    }

    setIsUpgrading(true);
    try {
      const res = await hostingControlPanelManager.changeAccountPackage({
        username: upgradeModalService.cpanelUser,
        newPackageName: targetPkg.name,
        domain: upgradeModalService.domain,
        serverId: upgradeModalService.hostingServerId,
      });

      if (res.success) {
        const updated: HostingService = {
          ...upgradeModalService,
          planName: targetPkg.name,
          diskLimitMb: res.newQuotaMb,
          bandwidthLimitGb: res.newBwGb,
          price: targetPkg.priceMonthly * 15,
        };

        if (onServiceUpdated) {
          onServiceUpdated(updated);
        }

        setUpgradeStatus({
          type: 'success',
          message: `Package migrated to '${targetPkg.name}'. New quotas: ${res.newQuotaMb}MB Storage, ${res.newBwGb}GB Bandwidth.`
        });

        setToastNotice({
          title: 'Hosting Package Upgraded',
          desc: `${upgradeModalService.domain} scaled to ${targetPkg.name} without downtime.`,
          type: 'success',
        });

        setTimeout(() => {
          setUpgradeModalService(null);
          setUpgradeStatus(null);
        }, 1500);
      }
    } catch (err: any) {
      setUpgradeStatus({ type: 'error', message: err.message || 'Failed to apply package modification.' });
    } finally {
      setIsUpgrading(false);
    }
  };

  const calculateDaysRemaining = (expiryDateStr: string) => {
    try {
      const exp = new Date(expiryDateStr);
      const now = new Date();
      const diffTime = exp.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    } catch {
      return 30;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in" id="vikalink-hosting-dashboard">
      {/* Toast Notification */}
      {toastNotice && (
        <div className="p-4 bg-emerald-950/90 border border-emerald-500/50 rounded-2xl text-white shadow-2xl flex items-start justify-between gap-3 animate-in slide-in-from-top-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-extrabold text-sm text-emerald-300">{toastNotice.title}</h4>
              <p className="text-xs text-slate-200 mt-0.5">{toastNotice.desc}</p>
            </div>
          </div>
          <button 
            onClick={() => setToastNotice(null)}
            className="text-slate-400 hover:text-white text-xs font-bold px-2 py-1 bg-slate-900/60 rounded-lg"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* VIKALINK HOSTING DASHBOARD HEADER & FLEET METRICS */}
      <div className="p-6 bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/70 rounded-3xl border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                Vikalink Cloud Services
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-700/60 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                99.99% SLA UPTIME
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-black text-white flex items-center gap-2.5">
              <Server className="w-7 h-7 text-indigo-400" />
              <span>Web Hosting & Cloud Subscriptions</span>
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl">
              High-performance NVMe cPanel & Cloud VPS instances backed by Vikalink Anycast DDoS Protection, automated Daily Backups, and 1-Click Softaculous auto-installers.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOrderNewHosting}
              className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-900/30 flex items-center gap-2 transition-all transform hover:-translate-y-0.5"
            >
              <Plus className="w-4 h-4" />
              <span>Deploy New Hosting</span>
            </button>
          </div>
        </div>

        {/* Fleet Performance & Allocation Stat Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800/80">
          <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <Server className="w-3.5 h-3.5 text-indigo-400" /> Active Instances
            </span>
            <div className="text-xl font-black text-white">
              {totalActive} <span className="text-xs text-slate-400 font-normal">/ {hostingList.length} total</span>
            </div>
          </div>

          <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <HardDrive className="w-3.5 h-3.5 text-sky-400" /> NVMe Storage
            </span>
            <div className="text-xl font-black text-white font-mono">
              {totalStorageAllocatedGb.toFixed(0)} <span className="text-xs text-slate-400 font-sans">GB Allocated</span>
            </div>
          </div>

          <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5 text-emerald-400" /> Monthly Spend
            </span>
            <div className="text-xl font-black text-emerald-400">
              {formatPrice(totalMonthlySpend, currency)}
            </div>
          </div>

          <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> Security Shield
            </span>
            <div className="text-xs font-bold text-slate-200 mt-1 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              AutoSSL & DDoS Active
            </div>
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH BAR */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
        {/* Search Input */}
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search domain, package, cPanel user, IP..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 font-medium"
          />
        </div>

        {/* Status Filter Tabs & Layout Switcher */}
        <div className="flex items-center justify-between w-full md:w-auto gap-3">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold">
            {(['all', 'active', 'pending', 'suspended'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg capitalize transition-all ${
                  statusFilter === st
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'grid' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'list' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* HOSTING SERVICES CONTENT (GRID OR LIST) */}
      {filteredHosting.length === 0 ? (
        /* Empty State */
        <div className="p-10 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-6 shadow-sm">
          <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800/80 rounded-2xl flex items-center justify-center mx-auto text-indigo-600 dark:text-indigo-400">
            <Server className="w-8 h-8" />
          </div>
          <div className="space-y-2 max-w-md mx-auto">
            <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
              {searchQuery ? 'No Matching Hosting Services Found' : 'No Web Hosting Subscriptions Yet'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {searchQuery 
                ? `No service matches "${searchQuery}". Clear your search filter or try searching by domain name.`
                : 'Deploy ultra-fast NVMe cPanel Web Hosting with free SSL, automated daily backups, and 24/7 technical support.'}
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={onOrderNewHosting}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center gap-2 mx-auto"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Browse Web Hosting Packages</span>
            </button>
          </div>
        </div>
      ) : viewMode === 'grid' ? (
        /* GRID VIEW (VIKALINK HIGH-PERFORMANCE CARD STYLE) */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredHosting.map((service) => {
            const daysRemaining = calculateDaysRemaining(service.expiryDate);
            const isExpiringSoon = daysRemaining <= 15;

            return (
              <div 
                key={service.id}
                className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800/90 shadow-sm hover:shadow-md hover:border-indigo-500/50 transition-all flex flex-col justify-between space-y-5 group"
              >
                {/* Card Top: Plan & Status */}
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-black uppercase text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800/60 px-2.5 py-0.5 rounded-full">
                          {service.planName}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-950 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-800">
                          {service.serverNodeName || 'Node #gh1-accra'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 mt-2">
                        <h3 className="font-black text-slate-900 dark:text-white text-lg group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                          {service.domain}
                        </h3>
                        <a 
                          href={`https://${service.domain}`} 
                          target="_blank" 
                          rel="noreferrer"
                          className="text-slate-400 hover:text-indigo-500 transition-colors p-1"
                          title="Open website in new tab"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${
                        service.status === 'active'
                          ? 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/70'
                          : 'bg-amber-50 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800/70'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${service.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`}></span>
                        {service.status}
                      </span>
                    </div>
                  </div>

                  {/* Account Specification Grid */}
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-950/80 rounded-2xl border border-slate-200 dark:border-slate-800/80 text-xs grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-slate-500 text-[10px] block font-bold uppercase">cPanel Username</span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold text-[13px]">{service.cpanelUser}</span>
                        <button
                          onClick={() => handleCopyText(service.cpanelUser, `user-${service.id}`)}
                          className="text-slate-400 hover:text-slate-200 p-0.5"
                          title="Copy username"
                        >
                          {copiedId === `user-${service.id}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block font-bold uppercase">Dedicated / Shared IP</span>
                      <span className="font-mono text-slate-900 dark:text-white font-bold block mt-0.5">{service.ipAddress}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block font-bold uppercase">Billing Cycle & Cost</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300 capitalize block mt-0.5">
                        {service.billingCycle} • <strong className="text-slate-900 dark:text-white">{formatPrice(service.price, currency)}</strong>
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block font-bold uppercase">Next Renewal Date</span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono text-slate-700 dark:text-slate-300 font-bold">{service.expiryDate}</span>
                        {isExpiringSoon && (
                          <span className="text-[9px] font-bold text-amber-500 bg-amber-500/10 px-1.5 py-0.2 rounded">
                            {daysRemaining}d left
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Bottom: VIKALINK ONE-CLICK ACTIONS SUITE */}
                <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                  {/* Primary Direct SSO Action Buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    {/* Log in to cPanel */}
                    <button
                      onClick={() => handleLaunchSso(service, 'cpanel', 'cPanel Dashboard')}
                      disabled={ssoExecuting !== null}
                      className="py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center justify-center gap-1.5 transition-all group"
                      title="Direct One-Click SSO to cPanel"
                    >
                      <Zap className="w-3.5 h-3.5 text-indigo-200" />
                      <span>Log in to cPanel</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-indigo-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </button>

                    {/* Log in to Webmail */}
                    <button
                      onClick={() => handleLaunchSso(service, 'webmail', 'Webmail Inbox')}
                      disabled={ssoExecuting !== null}
                      className="py-2.5 px-3 bg-sky-950/60 hover:bg-sky-900/60 text-sky-300 border border-sky-800/60 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all"
                      title="Direct SSO to Webmail (Roundcube)"
                    >
                      <Mail className="w-3.5 h-3.5 text-sky-400" />
                      <span>Webmail</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-sky-400/80" />
                    </button>
                  </div>

                  {/* Secondary Quick Action Links (Password, Upgrade, Timeline, Manage) */}
                  <div className="flex items-center justify-between text-xs pt-1 flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setPasswordModalService(service);
                          setPasswordStatus(null);
                        }}
                        className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-amber-500 dark:hover:text-amber-400 font-bold flex items-center gap-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="Change cPanel & FTP Password"
                      >
                        <Key className="w-3.5 h-3.5 text-amber-500" />
                        <span>Change Password</span>
                      </button>

                      <button
                        onClick={() => {
                          setUpgradeModalService(service);
                          setSelectedPackageId(MOCK_WHMCS_PACKAGES.find(p => p.name === service.planName)?.id || MOCK_WHMCS_PACKAGES[0].id);
                          setUpgradeStatus(null);
                        }}
                        className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 font-bold flex items-center gap-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="Upgrade or Downgrade Plan Tier"
                      >
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Upgrade</span>
                      </button>

                      {onViewTimeline && (
                        <button
                          onClick={() => onViewTimeline(`${service.name} (${service.domain})`, service.timeline)}
                          className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-bold flex items-center gap-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          title="View Service Lifecycle Timeline"
                        >
                          <Clock className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Timeline</span>
                        </button>
                      )}
                    </div>

                    {/* Manage Full Control Panel Suite */}
                    <button
                      onClick={() => onManageControlPanel(service)}
                      className="px-3 py-1.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-1 border border-slate-700/80 shadow-sm transition-all"
                    >
                      <span>Manage Service</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* LIST / TABLE VIEW (VIKALINK MODERN COMPACT ROW STYLE) */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 text-[10px] font-black uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                <tr>
                  <th className="p-4">Domain & Service</th>
                  <th className="p-4">Package & Node</th>
                  <th className="p-4">cPanel User / IP</th>
                  <th className="p-4">Billing & Due Date</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Quick Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
                {filteredHosting.map((service) => (
                  <tr key={service.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="p-4">
                      <div className="font-extrabold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                        <span>{service.domain}</span>
                        <a href={`https://${service.domain}`} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-indigo-500">
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">{service.name}</div>
                    </td>

                    <td className="p-4">
                      <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/80 px-2 py-0.5 rounded border border-indigo-200 dark:border-indigo-800/60">
                        {service.planName}
                      </span>
                      <div className="text-[10px] text-slate-400 font-mono mt-1">{service.serverNodeName || 'Node #gh1'}</div>
                    </td>

                    <td className="p-4">
                      <div className="font-mono text-indigo-600 dark:text-indigo-400 font-bold">{service.cpanelUser}</div>
                      <div className="font-mono text-slate-500 dark:text-slate-400 text-[11px]">{service.ipAddress}</div>
                    </td>

                    <td className="p-4">
                      <div className="font-bold text-slate-900 dark:text-white">{formatPrice(service.price, currency)} <span className="text-[10px] text-slate-400 font-normal">/{service.billingCycle}</span></div>
                      <div className="font-mono text-slate-500 dark:text-slate-400 text-[10px]">Due: {service.expiryDate}</div>
                    </td>

                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        service.status === 'active'
                          ? 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                          : 'bg-amber-50 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800'
                      }`}>
                        ● {service.status}
                      </span>
                    </td>

                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleLaunchSso(service, 'cpanel', 'cPanel Dashboard')}
                          className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-[11px] rounded-lg shadow-sm flex items-center gap-1"
                          title="Log in to cPanel"
                        >
                          <Zap className="w-3 h-3 text-indigo-200" />
                          <span>cPanel</span>
                        </button>

                        <button
                          onClick={() => handleLaunchSso(service, 'webmail', 'Webmail Inbox')}
                          className="px-2.5 py-1.5 bg-sky-950/80 hover:bg-sky-900 text-sky-300 font-extrabold text-[11px] rounded-lg border border-sky-800/80 flex items-center gap-1"
                          title="Log in to Webmail"
                        >
                          <Mail className="w-3 h-3 text-sky-400" />
                          <span>Webmail</span>
                        </button>

                        <button
                          onClick={() => onManageControlPanel(service)}
                          className="px-3 py-1.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-extrabold text-[11px] rounded-lg border border-slate-700 flex items-center gap-1"
                        >
                          <span>Manage</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: ONE-CLICK SSO SESSION LAUNCHER */}
      {ssoSessionData && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/30 rounded-xl text-indigo-400">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">SSO Session Handshake</h3>
                  <p className="text-xs text-slate-400 font-mono">{ssoSessionData.domain}</p>
                </div>
              </div>
              <button 
                onClick={() => setSsoSessionData(null)}
                className="text-slate-400 hover:text-white text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Target Gateway</span>
                <span className="font-bold text-indigo-300 text-sm">{ssoSessionData.target}</span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Remote Server Node</span>
                <span className="font-mono text-slate-200">{ssoSessionData.serverHost}</span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Session Security Token</span>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] text-emerald-400 truncate mr-2">{ssoSessionData.token}</span>
                  <button
                    onClick={() => handleCopyText(ssoSessionData.token, 'sso-token')}
                    className="text-slate-400 hover:text-white"
                  >
                    {copiedId === 'sso-token' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-[11px] text-emerald-300 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Token generated with 3600-second automatic expiration.</span>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setSsoSessionData(null)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
              >
                Close
              </button>

              <a
                href={ssoSessionData.url}
                target="_blank"
                rel="noreferrer"
                onClick={() => setSsoSessionData(null)}
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5"
              >
                <span>Launch Panel</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: CHANGE CONTROL PANEL PASSWORD */}
      {passwordModalService && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-400">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">Change Password</h3>
                  <p className="text-xs text-slate-400 font-mono">{passwordModalService.domain}</p>
                </div>
              </div>
              <button 
                onClick={() => setPasswordModalService(null)}
                className="text-slate-400 hover:text-white text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            {passwordStatus && (
              <div className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2 ${
                passwordStatus.type === 'success' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800' : 'bg-rose-950/80 text-rose-300 border border-rose-800'
              }`}>
                {passwordStatus.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                <span>{passwordStatus.message}</span>
              </div>
            )}

            <form onSubmit={handleChangePasswordSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">New Account Password</label>
                <input
                  type="password"
                  required
                  placeholder="Min 8 characters"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1.5">Confirm New Password</label>
                <input
                  type="password"
                  required
                  placeholder="Re-enter password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={() => {
                    const gen = `Vika#${Math.random().toString(36).substring(2, 8)}!${Math.floor(1000 + Math.random() * 9000)}`;
                    setNewPassword(gen);
                    setConfirmPassword(gen);
                  }}
                  className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate Password</span>
                </button>
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setPasswordModalService(null)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isChangingPassword}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  {isChangingPassword ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  <span>{isChangingPassword ? 'Updating...' : 'Update Password'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: UPGRADE / DOWNGRADE PACKAGE */}
      {upgradeModalService && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-xl w-full shadow-2xl space-y-5 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">Upgrade / Scale Hosting Plan</h3>
                  <p className="text-xs text-slate-400 font-mono">{upgradeModalService.domain}</p>
                </div>
              </div>
              <button 
                onClick={() => setUpgradeModalService(null)}
                className="text-slate-400 hover:text-white text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            {upgradeStatus && (
              <div className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2 ${
                upgradeStatus.type === 'success' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800' : 'bg-rose-950/80 text-rose-300 border border-rose-800'
              }`}>
                {upgradeStatus.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                <span>{upgradeStatus.message}</span>
              </div>
            )}

            <form onSubmit={handleUpgradeSubmit} className="space-y-4">
              <div className="space-y-3">
                {MOCK_WHMCS_PACKAGES.filter(p => p.category.includes('Hosting') || p.category.includes('WordPress')).map((pkg) => {
                  const isSelected = selectedPackageId === pkg.id;
                  const isCurrent = pkg.name === upgradeModalService.planName;

                  return (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedPackageId(pkg.id)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-indigo-950/50 border-indigo-500 ring-2 ring-indigo-500/30'
                          : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-white text-sm">{pkg.name}</span>
                          {isCurrent && (
                            <span className="text-[10px] font-bold text-amber-300 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                              Current Plan
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400">
                          {pkg.diskLimitMb / 1024} GB NVMe SSD • {pkg.bandwidthLimitGb} GB Bandwidth • {pkg.maxDatabases === 0 ? 'Unlimited' : pkg.maxDatabases} Databases
                        </p>
                      </div>

                      <div className="text-right">
                        <div className="font-black text-white text-sm">
                          GH₵ {(pkg.priceMonthly * 15).toFixed(2)}<span className="text-xs text-slate-400 font-normal">/mo</span>
                        </div>
                        <div className={`w-4 h-4 rounded-full border ml-auto mt-1 flex items-center justify-center ${
                          isSelected ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-slate-700'
                        }`}>
                          {isSelected && <Check className="w-2.5 h-2.5" />}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setUpgradeModalService(null)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isUpgrading}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  {isUpgrading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <TrendingUp className="w-3.5 h-3.5" />}
                  <span>{isUpgrading ? 'Applying Upgrade...' : 'Confirm Package Scale'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
