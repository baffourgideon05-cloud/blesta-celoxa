import React, { useState, useEffect, useRef } from 'react';
import { 
  Database, 
  Download, 
  Upload, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  FileJson, 
  FileText, 
  RotateCcw, 
  Trash2, 
  Play, 
  Check, 
  Copy, 
  Layers, 
  Clock, 
  Activity, 
  Sliders, 
  HardDrive, 
  Table, 
  Search, 
  ChevronRight, 
  Sparkles, 
  Info, 
  Lock, 
  Terminal, 
  X,
  FileCode,
  ArrowRight
} from 'lucide-react';
import { 
  databaseBackupService, 
  DatabaseSnapshot, 
  ValidationReport, 
  IntegrityCheckResult 
} from '../services/databaseBackupService';
import { systemDatabase } from '../services/systemDatabase';

interface DatabaseBackupRestoreHubProps {
  onClose?: () => void;
  isModal?: boolean;
}

export const DatabaseBackupRestoreHub: React.FC<DatabaseBackupRestoreHubProps> = ({
  onClose,
  isModal = false,
}) => {
  const [activeTab, setActiveTab] = useState<'backup' | 'restore' | 'snapshots' | 'integrity' | 'sql'>('backup');
  const [dbState, setDbState] = useState(systemDatabase.getState());
  const [snapshots, setSnapshots] = useState<DatabaseSnapshot[]>(databaseBackupService.getSnapshots());
  
  // Backup Tab State
  const [backupFormat, setBackupFormat] = useState<'json' | 'sql'>('json');
  const [selectedBackupModules, setSelectedBackupModules] = useState<string[]>([
    'users', 'domains', 'hosting', 'billing', 'settings', 'audit'
  ]);
  const [isExporting, setIsExporting] = useState(false);
  const [generatedSqlPreview, setGeneratedSqlPreview] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState(false);

  // Restore Tab State
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [rawRestoreText, setRawRestoreText] = useState<string>('');
  const [validationReport, setValidationReport] = useState<ValidationReport | null>(null);
  const [restoreMode, setRestoreMode] = useState<'full_replace' | 'merge_upsert' | 'selective'>('full_replace');
  const [selectedRestoreTables, setSelectedRestoreTables] = useState<string[]>([
    'users', 'hostingPackages', 'tlds', 'domainOwnership', 'paymentSubmissions', 'settings'
  ]);
  const [createSafetySnapshot, setCreateSafetySnapshot] = useState(true);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreSuccessMessage, setRestoreSuccessMessage] = useState<string | null>(null);
  const [restoreErrorMessage, setRestoreErrorMessage] = useState<string | null>(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);

  // Snapshot State
  const [newSnapshotName, setNewSnapshotName] = useState('');
  const [snapshotLoadingId, setSnapshotLoadingId] = useState<string | null>(null);

  // Integrity State
  const [integrityResult, setIntegrityResult] = useState<IntegrityCheckResult | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [repairSuccessMsg, setRepairSuccessMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const dropzoneRef = useRef<HTMLDivElement | null>(null);

  // Refresh local state when systemDatabase changes
  useEffect(() => {
    const unsub = systemDatabase.subscribe((state) => {
      setDbState(state);
      setSnapshots(databaseBackupService.getSnapshots());
    });
    // Run initial integrity check
    setIntegrityResult(databaseBackupService.runRelationalIntegrityCheck());
    return () => unsub();
  }, []);

  // Handle Drag and Drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const processSelectedFile = (file: File) => {
    setUploadedFile(file);
    setRestoreSuccessMessage(null);
    setRestoreErrorMessage(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setRawRestoreText(content);
      const report = databaseBackupService.validateBackupPayload(content);
      setValidationReport(report);
    };
    reader.onerror = () => {
      setRestoreErrorMessage('Failed to read uploaded database file.');
    };
    reader.readAsText(file);
  };

  // Handle Manual File Input Change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processSelectedFile(e.target.files[0]);
    }
  };

  // Handle Raw Text Change
  const handleRawTextChange = (text: string) => {
    setRawRestoreText(text);
    setRestoreSuccessMessage(null);
    setRestoreErrorMessage(null);
    if (text.trim().length > 10) {
      const report = databaseBackupService.validateBackupPayload(text);
      setValidationReport(report);
    } else {
      setValidationReport(null);
    }
  };

  // Download Backup
  const handleDownloadBackup = (format: 'json' | 'sql') => {
    setIsExporting(true);
    try {
      if (format === 'json') {
        const backup = databaseBackupService.generateFullJsonBackup('Admin Backup Studio');
        const jsonStr = JSON.stringify(backup, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `vikalink-database-backup-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } else {
        const sql = databaseBackupService.generatePostgresSqlDump();
        const blob = new Blob([sql], { type: 'application/sql' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `vikalink-postgres-dump-${new Date().toISOString().slice(0, 10)}.sql`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } finally {
      setTimeout(() => setIsExporting(false), 500);
    }
  };

  // Generate SQL Preview
  const handleGenerateSqlPreview = () => {
    const sql = databaseBackupService.generatePostgresSqlDump();
    setGeneratedSqlPreview(sql);
    setActiveTab('sql');
  };

  // Execute Restore
  const handleExecuteRestore = () => {
    if (!validationReport || !validationReport.canRestore) return;
    setIsRestoring(true);
    setRestoreSuccessMessage(null);
    setRestoreErrorMessage(null);

    try {
      const result = databaseBackupService.executeRestore(rawRestoreText, {
        mode: restoreMode,
        selectedTables: selectedRestoreTables,
        createSafetySnapshot,
        actorEmail: 'Super Administrator',
      });

      setRestoreSuccessMessage(result.message);
      setSnapshots(databaseBackupService.getSnapshots());
      setConfirmModalOpen(false);
      setUploadedFile(null);
      setRawRestoreText('');
      setValidationReport(null);
    } catch (err: any) {
      setRestoreErrorMessage(err.message || 'An unexpected error occurred during database restoration.');
      setConfirmModalOpen(false);
    } finally {
      setIsRestoring(false);
    }
  };

  // Create Manual Snapshot
  const handleCreateSnapshot = () => {
    const name = newSnapshotName.trim() || `Manual Checkpoint (${new Date().toLocaleTimeString()})`;
    databaseBackupService.createSafetySnapshot(name, 'Manually saved system snapshot checkpoint', 'manual');
    setSnapshots(databaseBackupService.getSnapshots());
    setNewSnapshotName('');
  };

  // Restore Snapshot
  const handleRestoreSnapshot = (id: string) => {
    setSnapshotLoadingId(id);
    try {
      const res = databaseBackupService.restoreSnapshotById(id);
      setRestoreSuccessMessage(res.message);
      setSnapshots(databaseBackupService.getSnapshots());
    } catch (err: any) {
      setRestoreErrorMessage(err.message);
    } finally {
      setSnapshotLoadingId(null);
    }
  };

  // Delete Snapshot
  const handleDeleteSnapshot = (id: string) => {
    databaseBackupService.deleteSnapshot(id);
    setSnapshots(databaseBackupService.getSnapshots());
  };

  // Run Integrity Scan
  const handleRunIntegrityScan = () => {
    setIsScanning(true);
    setRepairSuccessMsg(null);
    setTimeout(() => {
      const result = databaseBackupService.runRelationalIntegrityCheck();
      setIntegrityResult(result);
      setIsScanning(false);
    }, 400);
  };

  // Auto Repair
  const handleAutoRepair = () => {
    const res = databaseBackupService.autoRepairIntegrityIssues();
    setRepairSuccessMsg(res.message);
    setIntegrityResult(databaseBackupService.runRelationalIntegrityCheck());
  };

  const totalRowsInDb = 
    1 + 
    (dbState.users?.length || 0) + 
    (dbState.hostingPackages?.length || 0) + 
    (dbState.tlds?.length || 0) + 
    (dbState.domainOwnership?.length || 0) + 
    (dbState.paymentSubmissions?.length || 0) + 
    (dbState.auditLogs?.length || 0);

  return (
    <div className={`space-y-6 text-slate-800 dark:text-slate-200 ${isModal ? 'p-2' : ''}`}>
      
      {/* HEADER BAR & SYSTEM STATS */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 rounded-2xl">
                <Database className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-black text-white">Database Backup & Restore Hub</h2>
                  <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-extrabold rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    LIVE DUAL PERSISTENCE
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Automated backups, PostgreSQL SQL dumps, point-in-time snapshots & safe zero-data-loss restoration.
                </p>
              </div>
            </div>

            {isModal && onClose && (
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3.5 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Database Engine</span>
              <div className="text-sm font-black text-cyan-300 truncate">PostgreSQL + LocalDB</div>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-bold">
                <ShieldCheck className="w-3 h-3" /> Auto-Synced
              </span>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3.5 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Stored Records</span>
              <div className="text-sm font-black text-white">{totalRowsInDb} Rows</div>
              <span className="text-[10px] text-slate-400 font-mono">18 System Tables</span>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3.5 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Safety Snapshots</span>
              <div className="text-sm font-black text-amber-300">{snapshots.length} Points</div>
              <span className="text-[10px] text-slate-400">1-Click Rollback</span>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3.5 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Integrity Health</span>
              <div className="text-sm font-black text-emerald-400">{integrityResult?.score || 100}% Optimal</div>
              <span className="text-[10px] text-emerald-400/80">0 Foreign Key Conflicts</span>
            </div>
          </div>
        </div>
      </div>

      {/* NAVIGATION TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'backup', label: 'Export & Backup Studio', icon: Download },
          { id: 'restore', label: 'Upload & Restore Engine', icon: Upload },
          { id: 'snapshots', label: 'Snapshot Vault', icon: Clock, badge: snapshots.length },
          { id: 'integrity', label: 'Integrity Doctor', icon: Activity },
          { id: 'sql', label: 'Live SQL Script Viewer', icon: Terminal },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 text-xs font-black rounded-t-2xl transition-all flex items-center gap-2 whitespace-nowrap border-b-2 ${
                isActive
                  ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400 bg-cyan-500/10'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span className="px-1.5 py-0.2 text-[10px] bg-slate-200 dark:bg-slate-800 rounded-full font-mono font-bold">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: EXPORT & BACKUP STUDIO */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-cyan-500" />
                <span>Export System Database Backup</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Download an immediate full snapshot of your Vikalink application data. Backups contain all registered domains, user credentials, hosting packages, and invoices.
              </p>
            </div>

            {/* FORMAT SELECTOR */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div
                onClick={() => setBackupFormat('json')}
                className={`p-5 rounded-2xl border-2 cursor-pointer transition-all space-y-2 ${
                  backupFormat === 'json'
                    ? 'border-cyan-500 bg-cyan-500/5 dark:bg-cyan-500/10'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileJson className="w-5 h-5 text-cyan-500" />
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">Full JSON State Snapshot</span>
                  </div>
                  <input
                    type="radio"
                    checked={backupFormat === 'json'}
                    onChange={() => setBackupFormat('json')}
                    className="text-cyan-600 focus:ring-cyan-500"
                  />
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Recommended for instant restore, multi-environment synchronization, and seamless client portal migration.
                </p>
                <span className="inline-block text-[10px] font-mono font-bold text-cyan-600 dark:text-cyan-400">
                  Format: .json (Full Metadata + Checksum)
                </span>
              </div>

              <div
                onClick={() => setBackupFormat('sql')}
                className={`p-5 rounded-2xl border-2 cursor-pointer transition-all space-y-2 ${
                  backupFormat === 'sql'
                    ? 'border-indigo-500 bg-indigo-500/5 dark:bg-indigo-500/10'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileCode className="w-5 h-5 text-indigo-500" />
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">PostgreSQL SQL Dump (.sql)</span>
                  </div>
                  <input
                    type="radio"
                    checked={backupFormat === 'sql'}
                    onChange={() => setBackupFormat('sql')}
                    className="text-indigo-600 focus:ring-indigo-500"
                  />
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Formatted for direct execution in Netlify Postgres, Neon DB, Google Cloud SQL, Supabase, and AWS RDS.
                </p>
                <span className="inline-block text-[10px] font-mono font-bold text-indigo-600 dark:text-indigo-400">
                  Format: .sql (DDL + INSERT Statements)
                </span>
              </div>
            </div>

            {/* MODULES INCLUDED */}
            <div className="space-y-3 pt-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Included Data Modules ({selectedBackupModules.length} selected):
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                {[
                  { id: 'users', label: 'Users & Customers', count: dbState.users?.length || 0 },
                  { id: 'domains', label: 'Registered Domains & DNS', count: dbState.domainOwnership?.length || 0 },
                  { id: 'hosting', label: 'Hosting Blueprints & Nodes', count: dbState.hostingPackages?.length || 0 },
                  { id: 'tlds', label: 'TLD Pricing Catalog', count: dbState.tlds?.length || 0 },
                  { id: 'billing', label: 'Payments & Submissions', count: dbState.paymentSubmissions?.length || 0 },
                  { id: 'settings', label: 'System Configuration', count: '1 Configuration' },
                ].map((mod) => (
                  <div
                    key={mod.id}
                    className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block">{mod.label}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{mod.count} records</span>
                    </div>
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  </div>
                ))}
              </div>
            </div>

            {/* ACTION BUTTONS */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleGenerateSqlPreview}
                  className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition-all flex items-center gap-2"
                >
                  <Terminal className="w-4 h-4 text-indigo-400" />
                  <span>Inspect SQL Script</span>
                </button>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleDownloadBackup(backupFormat)}
                  disabled={isExporting}
                  className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2"
                >
                  {isExporting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Generating Backup...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>Download {backupFormat.toUpperCase()} Backup</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: UPLOAD & RESTORE ENGINE */}
      {activeTab === 'restore' && (
        <div className="space-y-6">
          
          {/* Notifications */}
          {restoreSuccessMessage && (
            <div className="p-4 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 rounded-2xl text-xs flex items-center gap-3 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <span className="font-bold block">Database Restored Successfully</span>
                <span>{restoreSuccessMessage}</span>
              </div>
            </div>
          )}

          {restoreErrorMessage && (
            <div className="p-4 bg-rose-500/15 border border-rose-500/30 text-rose-300 rounded-2xl text-xs flex items-center gap-3 animate-in fade-in">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
              <div>
                <span className="font-bold block">Restore Operation Blocked</span>
                <span>{restoreErrorMessage}</span>
              </div>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-indigo-500" />
                <span>Upload & Restore Database</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Upload a verified JSON database backup file or paste raw snapshot data. All restores are preceded by an automated rollback safety checkpoint.
              </p>
            </div>

            {/* DRAG AND DROP ZONE */}
            <div
              ref={dropzoneRef}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 dark:hover:border-indigo-500 rounded-3xl p-8 text-center cursor-pointer transition-all bg-slate-50/50 dark:bg-slate-950/50 space-y-3"
            >
              <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
                <Upload className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-extrabold text-slate-900 dark:text-white">
                  {uploadedFile ? uploadedFile.name : 'Click to select or drag and drop your database backup (.json)'}
                </p>
                <p className="text-xs text-slate-500">
                  Supports Vikalink Enterprise database snapshots (.json) with checksum verification
                </p>
              </div>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileInputChange}
                accept=".json,.sql"
                className="hidden"
              />
            </div>

            {/* RAW TEXT INPUT TOGGLE */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span>Or Paste Raw JSON / SQL Payload:</span>
                {rawRestoreText && (
                  <button
                    onClick={() => {
                      setRawRestoreText('');
                      setValidationReport(null);
                      setUploadedFile(null);
                    }}
                    className="text-[11px] text-rose-500 hover:underline"
                  >
                    Clear Text
                  </button>
                )}
              </label>
              <textarea
                rows={4}
                value={rawRestoreText}
                onChange={(e) => handleRawTextChange(e.target.value)}
                placeholder='Paste database payload JSON e.g. { "metadata": { "version": "1.0.0" }, "data": { ... } }'
                className="w-full p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-2xl font-mono text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* PRE-RESTORE VALIDATION REPORT */}
            {validationReport && (
              <div className={`p-5 rounded-2xl border space-y-4 ${
                validationReport.canRestore
                  ? 'bg-emerald-950/20 border-emerald-500/30'
                  : 'bg-rose-950/20 border-rose-500/30'
              }`}>
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    {validationReport.canRestore ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-rose-400" />
                    )}
                    <div>
                      <h4 className="font-extrabold text-xs text-slate-900 dark:text-white">
                        Pre-Restore Schema Analysis & Integrity Report
                      </h4>
                      <span className="text-[10px] text-slate-400">
                        Checksum: <span className="font-mono text-cyan-400">{validationReport.checksum}</span>
                      </span>
                    </div>
                  </div>

                  <span className={`px-2.5 py-1 text-[10px] font-bold rounded-full ${
                    validationReport.canRestore
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}>
                    {validationReport.canRestore ? 'READY TO RESTORE' : 'INTEGRITY ERRORS'}
                  </span>
                </div>

                {/* Table breakdown pills */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-xs">
                  <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Users</span>
                    <span className="font-mono font-bold text-white">{validationReport.previewItems.usersCount}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Domains</span>
                    <span className="font-mono font-bold text-cyan-400">{validationReport.previewItems.domainsCount}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Hosting</span>
                    <span className="font-mono font-bold text-indigo-400">{validationReport.previewItems.hostingCount}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">TLDs</span>
                    <span className="font-mono font-bold text-amber-400">{validationReport.previewItems.tldsCount}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Payments</span>
                    <span className="font-mono font-bold text-emerald-400">{validationReport.previewItems.paymentsCount}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Total Rows</span>
                    <span className="font-mono font-bold text-purple-400">{validationReport.totalRecords}</span>
                  </div>
                </div>

                {/* Warnings / Errors */}
                {validationReport.errors.length > 0 && (
                  <div className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl text-rose-300 text-xs space-y-1">
                    {validationReport.errors.map((err, i) => (
                      <div key={i} className="flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                        <span>{err}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* RESTORE MODES & OPTIONS */}
            {validationReport && validationReport.canRestore && (
              <div className="space-y-4 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Select Restoration Strategy:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div
                    onClick={() => setRestoreMode('full_replace')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all space-y-1 ${
                      restoreMode === 'full_replace'
                        ? 'border-indigo-500 bg-indigo-500/10'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'
                    }`}
                  >
                    <div className="font-black text-xs text-slate-900 dark:text-white">Full Replace</div>
                    <p className="text-[11px] text-slate-500">Completely overwrites all existing tables with backup state.</p>
                  </div>

                  <div
                    onClick={() => setRestoreMode('merge_upsert')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all space-y-1 ${
                      restoreMode === 'merge_upsert'
                        ? 'border-emerald-500 bg-emerald-500/10'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'
                    }`}
                  >
                    <div className="font-black text-xs text-slate-900 dark:text-white">Smart Merge (Upsert)</div>
                    <p className="text-[11px] text-slate-500">Imports records without deleting unmentioned existing users/domains.</p>
                  </div>

                  <div
                    onClick={() => setRestoreMode('selective')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all space-y-1 ${
                      restoreMode === 'selective'
                        ? 'border-cyan-500 bg-cyan-500/10'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'
                    }`}
                  >
                    <div className="font-black text-xs text-slate-900 dark:text-white">Selective Tables</div>
                    <p className="text-[11px] text-slate-500">Choose specific tables to restore while keeping others untouched.</p>
                  </div>
                </div>

                {/* Safety Checkpoint Toggle */}
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <ShieldCheck className="w-5 h-5 text-emerald-500" />
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block">
                        Create Automated Pre-Restore Safety Checkpoint
                      </span>
                      <span className="text-slate-500 text-[11px]">
                        Guarantees 1-click instant rollback if you ever need to undo this restore operation.
                      </span>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={createSafetySnapshot}
                    onChange={(e) => setCreateSafetySnapshot(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                  />
                </div>

                {/* EXECUTE BUTTON */}
                <div className="flex justify-end pt-2">
                  <button
                    onClick={() => setConfirmModalOpen(true)}
                    className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Proceed to Database Restore</span>
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* TAB 3: SNAPSHOT VAULT & POINT-IN-TIME CHECKPOINTS */}
      {activeTab === 'snapshots' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-500" />
                  <span>Point-in-Time Snapshot Vault</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Rollback checkpoints and safety snapshots stored in isolated local and cloud storage.
                </p>
              </div>

              {/* Create Snapshot Form */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Checkpoint label..."
                  value={newSnapshotName}
                  onChange={(e) => setNewSnapshotName(e.target.value)}
                  className="px-3.5 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none"
                />
                <button
                  onClick={handleCreateSnapshot}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 shrink-0"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Take Checkpoint</span>
                </button>
              </div>
            </div>

            {/* SNAPSHOTS LIST */}
            <div className="space-y-3">
              {snapshots.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  No snapshots recorded yet. Click "Take Checkpoint" to create one.
                </div>
              ) : (
                snapshots.map((snap) => (
                  <div
                    key={snap.id}
                    className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-4 text-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2.5 rounded-xl ${
                        snap.type === 'pre_restore_safety'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : snap.type === 'auto_scheduled'
                          ? 'bg-purple-500/10 text-purple-400'
                          : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        <Database className="w-4 h-4" />
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900 dark:text-white">{snap.name}</span>
                          <span className="px-2 py-0.2 text-[9px] bg-slate-200 dark:bg-slate-800 rounded-full font-mono uppercase font-bold text-slate-500">
                            {snap.type.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {snap.description} • <span className="font-mono text-slate-400">{new Date(snap.timestamp).toLocaleString()}</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right font-mono text-[11px] text-slate-400 hidden sm:block">
                        <div>{snap.totalRecords} Records</div>
                        <div>{(snap.sizeBytes / 1024).toFixed(1)} KB</div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleRestoreSnapshot(snap.id)}
                          disabled={snapshotLoadingId === snap.id}
                          className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1 transition-all"
                        >
                          {snapshotLoadingId === snap.id ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <RotateCcw className="w-3.5 h-3.5" />
                          )}
                          <span>Rollback</span>
                        </button>

                        <button
                          onClick={() => handleDeleteSnapshot(snap.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: INTEGRITY DOCTOR */}
      {activeTab === 'integrity' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-emerald-500" />
                  <span>Database Relational Integrity Doctor</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Deep scans detect orphaned records, foreign key discrepancies, and pricing anomalies across all 18 tables.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunIntegrityScan}
                  disabled={isScanning}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 flex items-center gap-1.5 transition-all"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                  <span>Run Deep Scan</span>
                </button>

                {integrityResult && integrityResult.issues.length > 0 && (
                  <button
                    onClick={handleAutoRepair}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1.5 transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-Repair Anomalies</span>
                  </button>
                )}
              </div>
            </div>

            {repairSuccessMsg && (
              <div className="p-4 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 rounded-2xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{repairSuccessMsg}</span>
              </div>
            )}

            {/* Score Card */}
            {integrityResult && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Health Score</span>
                  <div className="text-2xl font-black text-emerald-500">{integrityResult.score} / 100</div>
                  <p className="text-[11px] text-slate-500">{integrityResult.passedChecks} of {integrityResult.totalChecks} checks passed</p>
                </div>

                <div className="p-5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Anomalies Detected</span>
                  <div className="text-2xl font-black text-slate-900 dark:text-white">
                    {integrityResult.issues.length}
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {integrityResult.issues.filter(i => i.severity === 'critical').length} Critical, {integrityResult.issues.filter(i => i.severity === 'warning').length} Warnings
                  </p>
                </div>

                <div className="p-5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Last Diagnostic Run</span>
                  <div className="text-sm font-black text-slate-900 dark:text-white truncate">
                    {new Date(integrityResult.checkedAt).toLocaleTimeString()}
                  </div>
                  <p className="text-[11px] text-emerald-400">All foreign keys verified</p>
                </div>
              </div>
            )}

            {/* Issues List */}
            {integrityResult && integrityResult.issues.length > 0 ? (
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Detailed Diagnostic Findings:</label>
                {integrityResult.issues.map((iss, i) => (
                  <div
                    key={i}
                    className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs gap-3"
                  >
                    <div className="flex items-center gap-2.5">
                      <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white font-mono">[{iss.table}]</span>{' '}
                        <span className="text-slate-600 dark:text-slate-300">{iss.description}</span>
                      </div>
                    </div>
                    {iss.repairAction && (
                      <span className="text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-1 rounded-md font-mono shrink-0">
                        {iss.repairAction}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-center text-xs text-emerald-400 space-y-1">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400" />
                <p className="font-extrabold text-sm text-emerald-300">Zero Database Relational Defects Found</p>
                <p className="text-[11px] text-emerald-400/80">All user accounts, domain ownership handles, hosting nodes, and invoices pass schema verification.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: LIVE SQL VIEWER */}
      {activeTab === 'sql' && (
        <div className="space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-4 shadow-sm text-slate-200">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-black text-cyan-400 flex items-center gap-2">
                  <Terminal className="w-5 h-5" />
                  <span>Production PostgreSQL DDL & DML Script</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Direct SQL dump ready for Netlify Database, Neon, Cloud SQL, Supabase, or AWS RDS.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedSqlPreview || databaseBackupService.generatePostgresSqlDump());
                    setCopiedCode(true);
                    setTimeout(() => setCopiedCode(false), 2000);
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied SQL!' : 'Copy SQL'}</span>
                </button>

                <button
                  onClick={() => handleDownloadBackup('sql')}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .sql File</span>
                </button>
              </div>
            </div>

            <pre className="font-mono text-[11px] text-cyan-300 bg-slate-900/80 p-4 rounded-2xl border border-slate-800 overflow-x-auto max-h-96 whitespace-pre leading-relaxed">
              {generatedSqlPreview || databaseBackupService.generatePostgresSqlDump()}
            </pre>
          </div>
        </div>
      )}

      {/* CONFIRMATION SAFETY MODAL */}
      {confirmModalOpen && validationReport && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-xl">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Confirm Database Restore</h3>
                  <p className="text-xs text-slate-500">Verify restore settings before applying changes</p>
                </div>
              </div>
              <button
                onClick={() => setConfirmModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-xl space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  Important System Notice
                </span>
                <p className="text-[11px] text-amber-200/80 leading-relaxed">
                  Executing this restore will update your current database state to the uploaded snapshot ({validationReport.totalRecords} records across {Object.keys(validationReport.tableCounts).length} tables).
                </p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">Restore Mode:</span>
                  <span className="font-bold text-indigo-400">{restoreMode.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Safety Checkpoint:</span>
                  <span className="font-bold text-emerald-400">{createSafetySnapshot ? 'ENABLED' : 'DISABLED'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Target Records:</span>
                  <span className="font-bold text-white">{validationReport.totalRecords}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setConfirmModalOpen(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteRestore}
                disabled={isRestoring}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
              >
                {isRestoring ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Applying Changes...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Confirm & Execute Restore</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
