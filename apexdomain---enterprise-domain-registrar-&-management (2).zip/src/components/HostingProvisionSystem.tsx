import React, { useState, useEffect } from 'react';
import { 
  Server, 
  Cpu, 
  HardDrive, 
  Terminal, 
  Play, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  RefreshCw, 
  Plus, 
  Database, 
  Mail, 
  Lock, 
  Globe, 
  ShieldCheck, 
  Zap, 
  Sliders, 
  ExternalLink, 
  Key, 
  Trash2, 
  Search, 
  AlertTriangle,
  FolderArchive,
  Layers,
  Code,
  User,
  Sparkles,
  Info,
  Settings,
  Link2,
  Edit3,
  SlidersHorizontal,
  Radio,
  FileText,
  Check,
  Activity,
  Power,
  Globe2,
  ArrowUpRight,
  Wrench,
  ChevronRight
} from 'lucide-react';
import { Currency } from '../types';
import { systemDatabase } from '../services/systemDatabase';

export interface ProvisionTask {
  id: string;
  domain: string;
  customerName: string;
  customerEmail: string;
  packageName: string;
  serverNodeName: string;
  serverIp: string;
  status: 'completed' | 'suspended' | 'provisioning' | 'failed';
  currentStage: string;
  progressPercent: number;
  logs: string[];
  createdAt: string;
  username: string;
  cpanelUrl: string;
  phpVersion: string;
  diskUsageMb: number;
  bandwidthUsageGb: number;
  dnsRecords: DnsRecord[];
}

export interface DnsRecord {
  id: string;
  type: 'A' | 'AAAA' | 'CNAME' | 'MX' | 'TXT';
  name: string;
  value: string;
  ttl: number;
}

export interface ServerClusterNode {
  id: string;
  name: string;
  managerType: 'whmcs' | 'cpanel' | 'directadmin' | 'plesk' | 'cyberpanel';
  ip: string;
  location: string;
  status: 'online' | 'degraded' | 'offline';
  cpuUsage: number;
  ramUsage: number;
  diskUsage: number;
  activeAccounts: number;
  maxAccounts: number;
  pingMs: number;
}

export interface HostingPackageBlueprint {
  id: string;
  name: string;
  category: 'Shared Hosting' | 'WordPress Cloud' | 'NVMe VPS' | 'Reseller Hosting' | 'Dedicated Server';
  controlPanelType: 'cpanel' | 'whmcs' | 'directadmin' | 'plesk' | 'cyberpanel';
  diskQuotaMb: number;
  bandwidthQuotaGb: number;
  bandwidthQuotaMb?: number;
  maxDatabases: number;
  maxEmails: number;
  maxSubdomains: number;
  ramMb: number;
  cpuCores: number;
  priceMonthly: number;
  priceMonthlyGhs: number;
  priceAnnualGhs?: number;
  cpanelPackageName?: string;
  popular?: boolean;
  features?: string[];
  maxWebsites?: number;
  preinstalledCms: string;
  autoSsl: boolean;
  redisCache: boolean;
  dailyBackups: boolean;
}

export interface ControlPanelGateway {
  id: string;
  name: string;
  type: 'cpanel' | 'whmcs' | 'directadmin' | 'plesk' | 'cyberpanel';
  hostname: string;
  port: number;
  username: string;
  apiKeyOrToken: string;
  sslEnabled: boolean;
  status: 'connected' | 'error' | 'maintenance';
  lastTested: string;
  apiVersion: string;
  activeServerGroup: string;
}

export const INITIAL_GATEWAYS: ControlPanelGateway[] = [
  {
    id: 'gw-1',
    name: 'WHM Master Central API',
    type: 'cpanel',
    hostname: 'whm.celoxahost.net',
    port: 2087,
    username: 'root',
    apiKeyOrToken: 'whm_tok_99184918290192019481a8c90',
    sslEnabled: true,
    status: 'connected',
    lastTested: '2026-08-09 10:20',
    apiVersion: 'cPanel/WHM v118.0.12',
    activeServerGroup: 'US East Primary Cluster',
  },
  {
    id: 'gw-2',
    name: 'Celoxa Cloud Storefront API',
    type: 'whmcs',
    hostname: 'billing.celoxahost.net',
    port: 443,
    username: 'api_admin_user',
    apiKeyOrToken: 'whmcs_sec_01920491029481a20',
    sslEnabled: true,
    status: 'connected',
    lastTested: '2026-08-09 09:45',
    apiVersion: 'Cloud v8.10.1 System API',
    activeServerGroup: 'Global Reseller Gateway',
  },
  {
    id: 'gw-3',
    name: 'DirectAdmin High Speed NVMe Gateway',
    type: 'directadmin',
    hostname: 'da.eu-central.celoxahost.net',
    port: 2222,
    username: 'admin',
    apiKeyOrToken: 'da_key_881920491029',
    sslEnabled: true,
    status: 'connected',
    lastTested: '2026-08-09 08:30',
    apiVersion: 'DirectAdmin v1.65.2 API',
    activeServerGroup: 'Europe Frankfurt Cluster',
  },
  {
    id: 'gw-4',
    name: 'Plesk Obsidian Web Host Gateway',
    type: 'plesk',
    hostname: 'plesk.us-west.celoxahost.net',
    port: 8443,
    username: 'admin',
    apiKeyOrToken: 'plesk_sec_1920491029',
    sslEnabled: true,
    status: 'connected',
    lastTested: '2026-08-09 07:12',
    apiVersion: 'Plesk Obsidian v18.0.59',
    activeServerGroup: 'US West Cloud Cluster',
  },
];

export const INITIAL_NODES: ServerClusterNode[] = [
  {
    id: 'node-1',
    name: 'US-EAST-GH1 (Cluster Master)',
    managerType: 'whmcs',
    ip: '198.51.100.42',
    location: 'Accra / N. Virginia Data Center',
    status: 'online',
    cpuUsage: 18,
    ramUsage: 42,
    diskUsage: 38,
    activeAccounts: 384,
    maxAccounts: 1000,
    pingMs: 12,
  },
  {
    id: 'node-2',
    name: 'UK-LON-02 (cPanel WHM Cloud)',
    managerType: 'cpanel',
    ip: '185.199.108.153',
    location: 'London Docklands DC',
    status: 'online',
    cpuUsage: 28,
    ramUsage: 58,
    diskUsage: 64,
    activeAccounts: 512,
    maxAccounts: 800,
    pingMs: 24,
  },
  {
    id: 'node-3',
    name: 'DE-FRA-03 (DirectAdmin NVMe)',
    managerType: 'directadmin',
    ip: '194.12.221.80',
    location: 'Frankfurt Equinix',
    status: 'online',
    cpuUsage: 14,
    ramUsage: 31,
    diskUsage: 22,
    activeAccounts: 180,
    maxAccounts: 600,
    pingMs: 19,
  },
];

export const INITIAL_BLUEPRINTS: HostingPackageBlueprint[] = [
  {
    id: 'plan-1',
    name: 'Starter Cloud cPanel',
    category: 'Shared Hosting',
    controlPanelType: 'cpanel',
    diskQuotaMb: 10240, // 10 GB
    bandwidthQuotaGb: 100,
    maxDatabases: 5,
    maxEmails: 10,
    maxSubdomains: 5,
    ramMb: 1024,
    cpuCores: 1,
    priceMonthly: 4.99,
    priceMonthlyGhs: 75.00,
    preinstalledCms: 'None',
    autoSsl: true,
    redisCache: false,
    dailyBackups: true,
  },
  {
    id: 'plan-2',
    name: 'Business Enterprise NVMe',
    category: 'Shared Hosting',
    controlPanelType: 'cpanel',
    diskQuotaMb: 51200, // 50 GB
    bandwidthQuotaGb: 1000,
    maxDatabases: 25,
    maxEmails: 100,
    maxSubdomains: 25,
    ramMb: 2048,
    cpuCores: 2,
    priceMonthly: 12.99,
    priceMonthlyGhs: 195.00,
    preinstalledCms: 'WordPress Pro',
    autoSsl: true,
    redisCache: true,
    dailyBackups: true,
  },
  {
    id: 'plan-3',
    name: 'Managed WordPress Pro',
    category: 'WordPress Cloud',
    controlPanelType: 'cpanel',
    diskQuotaMb: 30720, // 30 GB
    bandwidthQuotaGb: 500,
    maxDatabases: 10,
    maxEmails: 25,
    maxSubdomains: 10,
    ramMb: 4096,
    cpuCores: 2,
    priceMonthly: 18.99,
    priceMonthlyGhs: 285.00,
    preinstalledCms: 'WordPress 6.4 + Redis Cache',
    autoSsl: true,
    redisCache: true,
    dailyBackups: true,
  },
  {
    id: 'plan-4',
    name: 'DirectAdmin Turbo Speed',
    category: 'Shared Hosting',
    controlPanelType: 'directadmin',
    diskQuotaMb: 20480, // 20 GB
    bandwidthQuotaGb: 300,
    maxDatabases: 15,
    maxEmails: 50,
    maxSubdomains: 15,
    ramMb: 2048,
    cpuCores: 2,
    priceMonthly: 7.99,
    priceMonthlyGhs: 120.00,
    preinstalledCms: 'Softaculous Suite',
    autoSsl: true,
    redisCache: true,
    dailyBackups: true,
  },
  {
    id: 'plan-5',
    name: 'Plesk Reseller Master Node',
    category: 'Reseller Hosting',
    controlPanelType: 'plesk',
    diskQuotaMb: 102400, // 100 GB
    bandwidthQuotaGb: 2500,
    maxDatabases: 100,
    maxEmails: 500,
    maxSubdomains: 100,
    ramMb: 8192,
    cpuCores: 4,
    priceMonthly: 39.99,
    priceMonthlyGhs: 600.00,
    preinstalledCms: 'Multi-Tenant Reseller',
    autoSsl: true,
    redisCache: true,
    dailyBackups: true,
  },
];

export const INITIAL_PROVISION_TASKS: ProvisionTask[] = [
  {
    id: 'task-101',
    domain: 'celoxaghana.online',
    customerName: 'Kwame Mensah',
    customerEmail: 'kwame@celoxaghana.online',
    packageName: 'Business Enterprise NVMe',
    serverNodeName: 'US-EAST-GH1 (Cluster Master)',
    serverIp: '198.51.100.42',
    status: 'completed',
    currentStage: 'Active & Operating',
    progressPercent: 100,
    logs: [
      '[14:20:01] Order payment verified via Paystack GHS...',
      '[14:20:02] Initiating Cloud cPanel API call on US-EAST-GH1...',
      '[14:20:03] Created user account celox_admin with quota 50GB...',
      '[14:20:04] Provisioned MySQL DB celox_wpdb and DB user...',
      '[14:20:05] AutoSSL certificate issued successfully (DigiCert 4096-bit)...',
      '[14:20:06] Welcome credentials email dispatched to kwame@celoxaghana.online.',
    ],
    createdAt: '2026-08-08 14:20',
    username: 'celox_admin',
    cpanelUrl: 'https://198.51.100.42:2083',
    phpVersion: 'PHP 8.2 FPM',
    diskUsageMb: 4280,
    bandwidthUsageGb: 45,
    dnsRecords: [
      { id: 'dns-1', type: 'A', name: '@', value: '198.51.100.42', ttl: 3600 },
      { id: 'dns-2', type: 'CNAME', name: 'www', value: 'celoxaghana.online.', ttl: 3600 },
      { id: 'dns-3', type: 'MX', name: '@', value: 'mail.celoxaghana.online (Priority 10)', ttl: 3600 },
      { id: 'dns-4', type: 'TXT', name: '@', value: 'v=spf1 mx a ip4:198.51.100.42 ~all', ttl: 3600 },
    ],
  },
  {
    id: 'task-102',
    domain: 'africabusinessHub.com',
    customerName: 'Amina Bello',
    customerEmail: 'amina@africabusiness.com',
    packageName: 'Managed WordPress Pro',
    serverNodeName: 'UK-LON-02 (cPanel WHM Cloud)',
    serverIp: '185.199.108.153',
    status: 'completed',
    currentStage: 'Active & Operating',
    progressPercent: 100,
    logs: [
      '[12:10:00] Order received from Cloud storefront...',
      '[12:10:01] Softaculous WordPress automated installer triggered...',
      '[12:10:03] WordPress 6.4 core files installed with Redis Object Cache...',
      '[12:10:04] Account setup verified on UK-LON-02 node.',
    ],
    createdAt: '2026-08-07 12:10',
    username: 'africabiz',
    cpanelUrl: 'https://185.199.108.153:2083',
    phpVersion: 'PHP 8.3 FPM',
    diskUsageMb: 8900,
    bandwidthUsageGb: 120,
    dnsRecords: [
      { id: 'dns-10', type: 'A', name: '@', value: '185.199.108.153', ttl: 3600 },
      { id: 'dns-11', type: 'CNAME', name: 'www', value: 'africabusinessHub.com.', ttl: 3600 },
      { id: 'dns-12', type: 'TXT', name: '@', value: 'v=spf1 mx a ip4:185.199.108.153 ~all', ttl: 3600 },
    ],
  },
];

interface HostingProvisionSystemProps {
  currency?: Currency;
  onNavigateToSettings?: () => void;
}

export const HostingProvisionSystem: React.FC<HostingProvisionSystemProps> = ({
  currency = 'USD',
  onNavigateToSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'provision_tool' | 'connections' | 'blueprints' | 'server_cluster' | 'accounts' | 'queue'>('provision_tool');
  const [tasks, setTasks] = useState<ProvisionTask[]>(() => systemDatabase.getProvisionedAccounts());
  const [nodes, setNodes] = useState<ServerClusterNode[]>(() => systemDatabase.getServerNodes());
  const [blueprints, setBlueprints] = useState<HostingPackageBlueprint[]>(() => systemDatabase.getHostingPackages());
  const [gateways, setGateways] = useState<ControlPanelGateway[]>(() => systemDatabase.getControlPanelGateways());

  useEffect(() => {
    const unsubscribe = systemDatabase.subscribe((db) => {
      setTasks(db.provisionedAccounts);
      setNodes(db.serverClusterNodes);
      setBlueprints(db.hostingPackages);
      setGateways(db.controlPanelGateways);
    });
    return () => unsubscribe();
  }, []);

  // Form State for 1-Click Provisioning Tool
  const [newDomain, setNewDomain] = useState('newappghana.com');
  const [newCustomerName, setNewCustomerName] = useState('Abena Osei');
  const [newCustomerEmail, setNewCustomerEmail] = useState('abena@gmail.com');
  const [selectedBlueprintId, setSelectedBlueprintId] = useState(blueprints[0]?.id || 'plan-1');
  const [selectedNodeId, setSelectedNodeId] = useState(nodes[0]?.id || 'node-1');
  const [installCms, setInstallCms] = useState('WordPress');
  const [issueAutoSsl, setIssueAutoSsl] = useState(true);

  // Live Simulation Logs State
  const [isSimulating, setIsSimulating] = useState(false);
  const [simLogs, setSimLogs] = useState<string[]>([]);
  const [simProgress, setSimProgress] = useState(0);
  const [simStage, setSimStage] = useState('Idle');
  const [lastProvisionedTask, setLastProvisionedTask] = useState<ProvisionTask | null>(null);

  // Account Modals State
  const [selectedAccountModal, setSelectedAccountModal] = useState<ProvisionTask | null>(null);
  const [selectedDnsModal, setSelectedDnsModal] = useState<ProvisionTask | null>(null);
  const [selectedPhpModal, setSelectedPhpModal] = useState<ProvisionTask | null>(null);
  const [selectedUpgradeModal, setSelectedUpgradeModal] = useState<ProvisionTask | null>(null);

  // New Gateway / Connection Modal State
  const [showCreateGatewayModal, setShowCreateGatewayModal] = useState(false);
  const [newGwName, setNewGwName] = useState('');
  const [newGwType, setNewGwType] = useState<'cpanel' | 'whmcs' | 'directadmin' | 'plesk' | 'cyberpanel'>('cpanel');
  const [newGwHost, setNewGwHost] = useState('');
  const [newGwPort, setNewGwPort] = useState(2087);
  const [newGwUsername, setNewGwUsername] = useState('root');
  const [newGwApiKey, setNewGwApiKey] = useState('');

  // Gateway Testing Diagnostics State
  const [testingGateway, setTestingGateway] = useState<ControlPanelGateway | null>(null);
  const [testLog, setTestLog] = useState<string[]>([]);
  const [isTesting, setIsTesting] = useState(false);

  // New Plan / Blueprint Modal State
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<HostingPackageBlueprint | null>(null);
  const [planFormName, setPlanFormName] = useState('');
  const [planFormCat, setPlanFormCat] = useState<'Shared Hosting' | 'WordPress Cloud' | 'NVMe VPS' | 'Reseller Hosting' | 'Dedicated Server'>('Shared Hosting');
  const [planFormPanel, setPlanFormPanel] = useState<'cpanel' | 'whmcs' | 'directadmin' | 'plesk' | 'cyberpanel'>('cpanel');
  const [planFormDiskGb, setPlanFormDiskGb] = useState(20);
  const [planFormBwGb, setPlanFormBwGb] = useState(200);
  const [planFormDb, setPlanFormDb] = useState(10);
  const [planFormMail, setPlanFormMail] = useState(20);
  const [planFormPriceUsd, setPlanFormPriceUsd] = useState(9.99);
  const [planFormCms, setPlanFormCms] = useState('WordPress 6.4');

  // New Server Node Modal State
  const [showNodeModal, setShowNodeModal] = useState(false);
  const [nodeFormName, setNodeFormName] = useState('');
  const [nodeFormIp, setNodeFormIp] = useState('');
  const [nodeFormLocation, setNodeFormLocation] = useState('Accra Data Center');
  const [nodeFormManager, setNodeFormManager] = useState<'whmcs' | 'cpanel' | 'directadmin' | 'plesk' | 'cyberpanel'>('cpanel');

  // Search Filter
  const [searchQuery, setSearchQuery] = useState('');

  // RUN PROVISIONING ENGINE SIMULATION
  const handleRunProvisioningSimulation = () => {
    setIsSimulating(true);
    setSimLogs([]);
    setSimProgress(10);
    setSimStage('1. Validating Order Payload');

    const targetNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];
    const targetBlueprint = blueprints.find((b) => b.id === selectedBlueprintId) || blueprints[0];
    const generatedUsername = newDomain.split('.')[0].replace(/[^a-z0-9]/gi, '').slice(0, 8) + '_usr';

    const timestamp = new Date().toLocaleTimeString();

    setTimeout(() => {
      setSimProgress(30);
      setSimStage('2. Allocating Control Panel Account on Node');
      setSimLogs((prev) => [...prev, `[${timestamp}] Connecting to ${targetNode.name} (${targetNode.ip}) via Control Panel API...`]);
      setSimLogs((prev) => [...prev, `[${timestamp}] Provisioning account "${generatedUsername}" with ${targetBlueprint.diskQuotaMb / 1024}GB disk quota...`]);
    }, 700);

    setTimeout(() => {
      setSimProgress(60);
      setSimStage('3. Setting up MySQL & CMS');
      setSimLogs((prev) => [...prev, `[${timestamp}] Provisioning MySQL Database "${generatedUsername}_db" & granting privileges...`]);
      if (installCms !== 'None') {
        setSimLogs((prev) => [...prev, `[${timestamp}] Softaculous Auto-Installer executing for ${installCms}...`]);
      }
    }, 1500);

    setTimeout(() => {
      setSimProgress(85);
      setSimStage('4. Issuing AutoSSL & Nameservers');
      if (issueAutoSsl) {
        setSimLogs((prev) => [...prev, `[${timestamp}] AutoSSL DigiCert 4096-bit certificate issued for ${newDomain} & www.${newDomain}.`]);
      }
      setSimLogs((prev) => [...prev, `[${timestamp}] Assigned Cluster Nameservers: ns1.celoxahost.net, ns2.celoxahost.net`]);
    }, 2200);

    setTimeout(() => {
      setSimProgress(100);
      setSimStage('Provision Completed');
      const newTask: ProvisionTask = {
        id: `task-${Date.now().toString().slice(-4)}`,
        domain: newDomain,
        customerName: newCustomerName,
        customerEmail: newCustomerEmail,
        packageName: targetBlueprint.name,
        serverNodeName: targetNode.name,
        serverIp: targetNode.ip,
        status: 'completed',
        currentStage: 'Active & Operating',
        progressPercent: 100,
        logs: [
          `[${timestamp}] Order verified for ${newDomain}...`,
          `[${timestamp}] Account ${generatedUsername} created on ${targetNode.name}...`,
          `[${timestamp}] AutoSSL active and credentials sent to ${newCustomerEmail}.`,
        ],
        createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
        username: generatedUsername,
        cpanelUrl: `https://${targetNode.ip}:2083`,
        phpVersion: 'PHP 8.2 FPM',
        diskUsageMb: 120,
        bandwidthUsageGb: 1,
        dnsRecords: [
          { id: `dns-${Date.now()}-1`, type: 'A', name: '@', value: targetNode.ip, ttl: 3600 },
          { id: `dns-${Date.now()}-2`, type: 'CNAME', name: 'www', value: `${newDomain}.`, ttl: 3600 },
          { id: `dns-${Date.now()}-3`, type: 'MX', name: '@', value: `mail.${newDomain} (Priority 10)`, ttl: 3600 },
          { id: `dns-${Date.now()}-4`, type: 'TXT', name: '@', value: `v=spf1 mx a ip4:${targetNode.ip} ~all`, ttl: 3600 },
        ]
      };

      setTasks((prev) => [newTask, ...prev]);
      systemDatabase.saveProvisionedAccount(newTask);
      setLastProvisionedTask(newTask);
      setIsSimulating(false);

      // Increment active accounts count on the node
      setNodes((prev) => prev.map((node) => node.id === targetNode.id ? { ...node, activeAccounts: node.activeAccounts + 1 } : node));
    }, 3000);
  };

  // TEST GATEWAY HANDSHAKE
  const handleTestGateway = (gw: ControlPanelGateway) => {
    setTestingGateway(gw);
    setIsTesting(true);
    setTestLog([`Initializing API ping handshake to ${gw.hostname}:${gw.port}...`]);

    setTimeout(() => {
      setTestLog((prev) => [...prev, `HTTP/1.1 TLS 1.3 Handshake successful.`]);
      setTestLog((prev) => [...prev, `Authenticating header credentials [User: ${gw.username}]...`]);
    }, 600);

    setTimeout(() => {
      setTestLog((prev) => [...prev, `Status 200 OK — ${gw.apiVersion} responding.`]);
      setTestLog((prev) => [...prev, `Server Health: 0.14 Load Avg | Active License Valid.`]);
    }, 1400);

    setTimeout(() => {
      setIsTesting(false);
      setGateways((prev) => prev.map((g) => g.id === gw.id ? { ...g, status: 'connected', lastTested: new Date().toISOString().replace('T', ' ').slice(0, 16) } : g));
    }, 2000);
  };

  // ADD NEW GATEWAY
  const handleSaveGateway = () => {
    if (!newGwName || !newGwHost) return;
    const newGw: ControlPanelGateway = {
      id: `gw-${Date.now()}`,
      name: newGwName,
      type: newGwType,
      hostname: newGwHost,
      port: newGwPort,
      username: newGwUsername,
      apiKeyOrToken: newGwApiKey || 'sec_key_demo_auto_gen',
      sslEnabled: true,
      status: 'connected',
      lastTested: new Date().toISOString().replace('T', ' ').slice(0, 16),
      apiVersion: `${newGwType.toUpperCase()} Gateway v2.4`,
      activeServerGroup: 'Primary Global Group',
    };
    setGateways((prev) => [newGw, ...prev]);
    systemDatabase.saveControlPanelGateway(newGw);
    setShowCreateGatewayModal(false);
    setNewGwName('');
    setNewGwHost('');
  };

  // SAVE HOSTING PLAN / BLUEPRINT
  const handleSavePlan = () => {
    if (!planFormName) return;
    let savedBp: HostingPackageBlueprint;
    if (editingPlan) {
      savedBp = {
        ...editingPlan,
        name: planFormName,
        category: planFormCat,
        controlPanelType: planFormPanel,
        diskQuotaMb: planFormDiskGb * 1024,
        bandwidthQuotaGb: planFormBwGb,
        maxDatabases: planFormDb,
        maxEmails: planFormMail,
        priceMonthly: planFormPriceUsd,
        priceMonthlyGhs: planFormPriceUsd * 15,
        preinstalledCms: planFormCms,
      };
      setBlueprints((prev) => prev.map((p) => p.id === editingPlan.id ? savedBp : p));
    } else {
      savedBp = {
        id: `plan-${Date.now()}`,
        name: planFormName,
        category: planFormCat,
        controlPanelType: planFormPanel,
        diskQuotaMb: planFormDiskGb * 1024,
        bandwidthQuotaGb: planFormBwGb,
        maxDatabases: planFormDb,
        maxEmails: planFormMail,
        maxSubdomains: planFormDb,
        ramMb: 2048,
        cpuCores: 2,
        priceMonthly: planFormPriceUsd,
        priceMonthlyGhs: planFormPriceUsd * 15,
        preinstalledCms: planFormCms,
        autoSsl: true,
        redisCache: true,
        dailyBackups: true,
      };
      setBlueprints((prev) => [...prev, savedBp]);
    }
    systemDatabase.saveHostingPackage(savedBp);
    setShowPlanModal(false);
    setEditingPlan(null);
  };

  // SAVE SERVER NODE
  const handleSaveNode = () => {
    if (!nodeFormName || !nodeFormIp) return;
    const newNode: ServerClusterNode = {
      id: `node-${Date.now()}`,
      name: nodeFormName,
      managerType: nodeFormManager,
      ip: nodeFormIp,
      location: nodeFormLocation,
      status: 'online',
      cpuUsage: Math.floor(Math.random() * 20) + 10,
      ramUsage: Math.floor(Math.random() * 30) + 20,
      diskUsage: Math.floor(Math.random() * 25) + 15,
      activeAccounts: 0,
      maxAccounts: 500,
      pingMs: Math.floor(Math.random() * 20) + 10,
    };
    setNodes((prev) => [...prev, newNode]);
    systemDatabase.saveServerNode(newNode);
    setShowNodeModal(false);
    setNodeFormName('');
    setNodeFormIp('');
  };

  // TOGGLE ACCOUNT SUSPEND/UNSUSPEND
  const handleToggleAccountSuspend = (taskId: string) => {
    setTasks((prev) => prev.map((t) => {
      if (t.id === taskId) {
        const isSuspended = t.status === 'suspended';
        const updated: ProvisionTask = {
          ...t,
          status: isSuspended ? 'completed' : 'suspended',
          currentStage: isSuspended ? 'Active & Operating' : 'Suspended by Admin',
        };
        systemDatabase.saveProvisionedAccount(updated);
        return updated;
      }
      return t;
    }));
  };

  // DELETE ACCOUNT
  const handleDeleteAccount = (taskId: string) => {
    if (confirm('Are you sure you want to terminate this hosting account from the server cluster?')) {
      setTasks((prev) => prev.filter((t) => t.id !== taskId));
      systemDatabase.deleteProvisionedAccount(taskId);
      setSelectedAccountModal(null);
    }
  };

  // UPDATE PHP VERSION
  const handleUpdatePhpVersion = (taskId: string, newPhp: string) => {
    setTasks((prev) => prev.map((t) => t.id === taskId ? { ...t, phpVersion: newPhp } : t));
    setSelectedPhpModal(null);
  };

  // ADD NEW DNS RECORD
  const [newDnsType, setNewDnsType] = useState<'A' | 'CNAME' | 'MX' | 'TXT'>('A');
  const [newDnsName, setNewDnsName] = useState('subdomain');
  const [newDnsValue, setNewDnsValue] = useState('198.51.100.42');

  const handleAddDnsRecord = (taskId: string) => {
    setTasks((prev) => prev.map((t) => {
      if (t.id === taskId) {
        const newRec: DnsRecord = {
          id: `dns-${Date.now()}`,
          type: newDnsType,
          name: newDnsName,
          value: newDnsValue,
          ttl: 3600,
        };
        return { ...t, dnsRecords: [...t.dnsRecords, newRec] };
      }
      return t;
    }));
  };

  const handleRemoveDnsRecord = (taskId: string, recordId: string) => {
    setTasks((prev) => prev.map((t) => {
      if (t.id === taskId) {
        return { ...t, dnsRecords: t.dnsRecords.filter((r) => r.id !== recordId) };
      }
      return t;
    }));
  };

  const filteredTasks = tasks.filter((t) => 
    t.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.customerEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      
      {/* HEADER BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shadow-lg">
            <Server className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black tracking-tight text-white">Hosting Auto-Provisioning & Control Panel Suite</h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                cPanel • DirectAdmin • Plesk • CyberPanel
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Connect control panel APIs, customize hosting packages & resource limits, run 1-click provisioning, and manage live accounts.
            </p>
          </div>
        </div>

        {/* TOP STATS BADGES */}
        <div className="flex flex-wrap items-center gap-3 text-xs font-bold">
          <div className="bg-slate-800/80 border border-slate-700/80 px-3.5 py-2 rounded-2xl flex items-center gap-2">
            <Link2 className="w-4 h-4 text-indigo-400" />
            <div>
              <span className="text-[10px] text-slate-400 block">Connected Gateways</span>
              <span className="text-white font-mono font-black">{gateways.filter(g => g.status === 'connected').length} Active APIs</span>
            </div>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 px-3.5 py-2 rounded-2xl flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <div>
              <span className="text-[10px] text-slate-400 block">Hosting Packages</span>
              <span className="text-white font-mono font-black">{blueprints.length} Plans</span>
            </div>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 px-3.5 py-2 rounded-2xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="text-[10px] text-slate-400 block">Active Accounts</span>
              <span className="text-emerald-400 font-mono font-black">{tasks.length} Provisioned</span>
            </div>
          </div>
        </div>
      </div>

      {/* TAB NAVIGATION HEADER */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-2 shadow-sm flex items-center gap-1 overflow-x-auto scrollbar-none">
        {[
          { id: 'provision_tool', label: '1-Click Provision Build', icon: Zap, color: 'text-emerald-500' },
          { id: 'connections', label: 'Control Panel API Gateways', icon: Link2, color: 'text-indigo-500' },
          { id: 'blueprints', label: 'Hosting Plans & Packages', icon: Layers, color: 'text-blue-500' },
          { id: 'server_cluster', label: 'Server Cluster Nodes', icon: Server, color: 'text-amber-500' },
          { id: 'accounts', label: 'Provisioned Accounts Explorer', icon: Globe, color: 'text-teal-500' },
          { id: 'queue', label: 'Execution Log & Queue', icon: Terminal, color: 'text-purple-500' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: 1-CLICK PROVISION TOOL & LIVE TERMINAL */}
      {activeTab === 'provision_tool' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT FORM: PROVISIONING PARAMETERS (7 COLS) */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-emerald-500" />
                <span>Instant Hosting Account Provisioning</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Trigger manual or automated cPanel/Cloud account build with instant credentials generation.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              
              {/* Domain Name */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="font-bold text-slate-700 dark:text-slate-300">Target Domain Name</label>
                <div className="relative">
                  <Globe className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={newDomain}
                    onChange={(e) => setNewDomain(e.target.value)}
                    placeholder="e.g. celoxaghana.online"
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Customer Name */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">Customer Name</label>
                <input
                  type="text"
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              {/* Customer Email */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">Customer Email Address</label>
                <input
                  type="email"
                  value={newCustomerEmail}
                  onChange={(e) => setNewCustomerEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              {/* Package Blueprint */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">Select Hosting Package Plan</label>
                <select
                  value={selectedBlueprintId}
                  onChange={(e) => setSelectedBlueprintId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-indigo-600 dark:text-indigo-400 focus:outline-none"
                >
                  {blueprints.map((bp) => (
                    <option key={bp.id} value={bp.id}>
                      {bp.name} ({bp.diskQuotaMb / 1024}GB Disk • ${bp.priceMonthly}/mo)
                    </option>
                  ))}
                </select>
              </div>

              {/* Target Server Node */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">Target Server Node</label>
                <select
                  value={selectedNodeId}
                  onChange={(e) => setSelectedNodeId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-amber-600 dark:text-amber-400 focus:outline-none"
                >
                  {nodes.map((node) => (
                    <option key={node.id} value={node.id}>
                      {node.name} ({node.ip})
                    </option>
                  ))}
                </select>
              </div>

              {/* Auto Install CMS */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">Softaculous Pre-Install CMS</label>
                <select
                  value={installCms}
                  onChange={(e) => setInstallCms(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-teal-600 dark:text-teal-400 focus:outline-none"
                >
                  <option value="WordPress">WordPress 6.4 (Recommended)</option>
                  <option value="WooCommerce">WooCommerce Online Store</option>
                  <option value="Laravel">Laravel 11 Framework</option>
                  <option value="Joomla">Joomla CMS</option>
                  <option value="None">Blank Web Directory (cPanel Default)</option>
                </select>
              </div>

              {/* Issue AutoSSL */}
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Issue Free AutoSSL</span>
                  <span className="text-[10px] text-slate-500">4096-bit DigiCert SSL</span>
                </div>
                <input
                  type="checkbox"
                  checked={issueAutoSsl}
                  onChange={(e) => setIssueAutoSsl(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded"
                />
              </div>

            </div>

            <button
              onClick={handleRunProvisioningSimulation}
              disabled={isSimulating}
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
            >
              {isSimulating ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Executing Provisioning Sequence...</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  <span>Run 1-Click Provision Build</span>
                </>
              )}
            </button>

          </div>

          {/* RIGHT TERMINAL CONSOLE & LOGS (5 COLS) */}
          <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between space-y-4 shadow-2xl font-mono text-xs">
            
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-white">Cloud Server / cPanel API Log Stream</span>
                </div>
                <span className="text-[10px] text-slate-500 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  {isSimulating ? 'STATUS: RUNNING' : 'STATUS: IDLE'}
                </span>
              </div>

              {/* Progress Bar */}
              {isSimulating && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>{simStage}</span>
                    <span className="font-bold text-emerald-400">{simProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-emerald-500 to-indigo-500 transition-all duration-300" 
                      style={{ width: `${simProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Logs Box */}
              <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800/80 min-h-[220px] max-h-[300px] overflow-y-auto space-y-2 text-[11px] text-slate-300 leading-relaxed font-mono">
                {simLogs.length === 0 ? (
                  <div className="text-slate-600 text-center py-12 italic">
                    Press "Run 1-Click Provision Build" to simulate live cPanel account creation logs...
                  </div>
                ) : (
                  simLogs.map((log, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-400 font-bold shrink-0">&gt;</span>
                      <span>{log}</span>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* LAST PROVISIONED RESULT CARD */}
            {lastProvisionedTask && (
              <div className="bg-indigo-950/60 border border-indigo-800/80 rounded-2xl p-4 text-xs space-y-2 animate-in zoom-in-95">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    Account Built Successfully!
                  </span>
                  <span className="text-[10px] text-slate-400">{lastProvisionedTask.createdAt}</span>
                </div>

                <div className="text-slate-300 text-[11px] space-y-1 font-sans">
                  <p>Domain: <strong className="text-white">{lastProvisionedTask.domain}</strong></p>
                  <p>Username: <code className="bg-indigo-900/60 px-1.5 py-0.5 rounded text-amber-300 font-mono">{lastProvisionedTask.username}</code></p>
                  <p>Control Panel: <a href={lastProvisionedTask.cpanelUrl} target="_blank" rel="noopener noreferrer" className="text-indigo-400 underline">{lastProvisionedTask.cpanelUrl}</a></p>
                </div>

                <button
                  onClick={() => setSelectedAccountModal(lastProvisionedTask)}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 mt-2"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>1-Click Client Login Simulation</span>
                </button>
              </div>
            )}

          </div>

        </div>
      )}

      {/* TAB 2: CONTROL PANEL GATEWAYS & API CONNECTIONS */}
      {activeTab === 'connections' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Link2 className="w-5 h-5 text-indigo-500" />
                <span>Control Panel API Gateways & Integrations</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Manage live authentication tokens, hostname ports, and roundtrip API handshakes for cPanel/WHM, DirectAdmin, Plesk, and CyberPanel.
              </p>
            </div>

            <button
              onClick={() => setShowCreateGatewayModal(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Connect New Control Panel API</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {gateways.map((gw) => (
              <div 
                key={gw.id}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] uppercase">
                      {gw.type.toUpperCase()}
                    </span>
                    <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" />
                      {gw.status}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-black text-slate-900 dark:text-white text-base">{gw.name}</h4>
                    <p className="font-mono text-xs text-indigo-600 dark:text-indigo-400 font-bold mt-0.5">
                      https://{gw.hostname}:{gw.port}
                    </p>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs text-slate-600 dark:text-slate-300 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-400">API Username:</span>
                      <strong className="text-slate-900 dark:text-white">{gw.username}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">API Key / Token:</span>
                      <strong className="text-amber-500">{gw.apiKeyOrToken.slice(0, 10)}•••••</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">API Runtime:</span>
                      <strong className="text-emerald-500">{gw.apiVersion}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Cluster Group:</span>
                      <span className="text-slate-700 dark:text-slate-300 font-sans">{gw.activeServerGroup}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => handleTestGateway(gw)}
                    className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Test API Connection</span>
                  </button>

                  <button
                    onClick={() => setGateways((prev) => prev.filter((g) => g.id !== gw.id))}
                    className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-xl border border-rose-200 dark:border-rose-900/50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* TAB 3: HOSTING PLANS & PACKAGES MANAGEMENT */}
      {activeTab === 'blueprints' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-500" />
                <span>Hosting Package Blueprints & Resource Quotas</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Define and configure disk space, monthly bandwidth, databases, email mailboxes, and pricing per package.
              </p>
            </div>

            <button
              onClick={() => {
                setEditingPlan(null);
                setPlanFormName('');
                setPlanFormDiskGb(20);
                setPlanFormBwGb(200);
                setPlanFormPriceUsd(9.99);
                setShowPlanModal(true);
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create Custom Hosting Package</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {blueprints.map((bp) => (
              <div 
                key={bp.id}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] uppercase">
                      {bp.category}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono text-[10px] uppercase font-bold">
                      {bp.controlPanelType}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-black text-slate-900 dark:text-white text-base">{bp.name}</h4>
                    <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">
                      ${bp.priceMonthly} <span className="text-xs text-slate-500 font-normal">/ mo (GH₵{bp.priceMonthlyGhs})</span>
                    </div>
                  </div>
                </div>

                <div className="text-xs space-y-2 border-t border-b border-slate-200 dark:border-slate-800 py-3 text-slate-600 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span>Disk Storage:</span>
                    <strong className="text-slate-900 dark:text-white">{bp.diskQuotaMb / 1024} GB NVMe</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Bandwidth:</span>
                    <strong className="text-slate-900 dark:text-white">{bp.bandwidthQuotaGb} GB / mo</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Databases:</span>
                    <strong className="text-slate-900 dark:text-white">{bp.maxDatabases} MySQL</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Email Mailboxes:</span>
                    <strong className="text-slate-900 dark:text-white">{bp.maxEmails} Mailboxes</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>RAM / CPU:</span>
                    <strong className="text-slate-900 dark:text-white">{bp.ramMb}MB RAM • {bp.cpuCores} vCPU</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Pre-installed CMS:</span>
                    <strong className="text-emerald-600 dark:text-emerald-400">{bp.preinstalledCms}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSelectedBlueprintId(bp.id);
                      setActiveTab('provision_tool');
                    }}
                    className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl transition-colors shadow"
                  >
                    Use in 1-Click Provision
                  </button>

                  <button
                    onClick={() => {
                      setEditingPlan(bp);
                      setPlanFormName(bp.name);
                      setPlanFormCat(bp.category);
                      setPlanFormPanel(bp.controlPanelType);
                      setPlanFormDiskGb(bp.diskQuotaMb / 1024);
                      setPlanFormBwGb(bp.bandwidthQuotaGb);
                      setPlanFormDb(bp.maxDatabases);
                      setPlanFormMail(bp.maxEmails);
                      setPlanFormPriceUsd(bp.priceMonthly);
                      setPlanFormCms(bp.preinstalledCms);
                      setShowPlanModal(true);
                    }}
                    className="p-2 text-slate-500 hover:text-indigo-600 bg-slate-200 dark:bg-slate-800 rounded-xl"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setBlueprints((prev) => prev.filter((p) => p.id !== bp.id))}
                    className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-xl border border-rose-200 dark:border-rose-900/50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* TAB 4: SERVER CLUSTER NODES */}
      {activeTab === 'server_cluster' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Server className="w-5 h-5 text-amber-500" />
                <span>Connected Server Cluster Nodes</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Real-time hardware resource capacity (CPU, RAM, NVMe Disk) and ping latency across global datacenters.
              </p>
            </div>

            <button
              onClick={() => setShowNodeModal(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Connect New Server Node</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {nodes.map((node) => (
              <div 
                key={node.id}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm"
              >
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <div>
                    <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">{node.name}</h4>
                    <span className="font-mono text-xs text-indigo-600 dark:text-indigo-400 font-bold">{node.ip}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                    {node.status} ({node.pingMs}ms)
                  </span>
                </div>

                <div className="text-xs text-slate-500 space-y-1">
                  <p>Location: <strong className="text-slate-800 dark:text-slate-200">{node.location}</strong></p>
                  <p>Active Accounts: <strong className="text-slate-800 dark:text-slate-200">{node.activeAccounts} / {node.maxAccounts}</strong></p>
                </div>

                {/* Resource Gauges */}
                <div className="space-y-2 text-xs pt-1">
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-0.5">
                      <span>CPU Load</span>
                      <span className="font-bold text-indigo-500">{node.cpuUsage}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: `${node.cpuUsage}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-0.5">
                      <span>RAM Allocation</span>
                      <span className="font-bold text-amber-500">{node.ramUsage}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500" style={{ width: `${node.ramUsage}%` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-0.5">
                      <span>NVMe Storage</span>
                      <span className="font-bold text-teal-500">{node.diskUsage}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-teal-500" style={{ width: `${node.diskUsage}%` }} />
                    </div>
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      )}

      {/* TAB 5: ACTIVE PROVISIONED ACCOUNTS EXPLORER */}
      {activeTab === 'accounts' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Globe className="w-5 h-5 text-teal-500" />
                <span>Active Provisioned Hosting Accounts Explorer</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Manage client hosting accounts, trigger 1-click SSO logins, change PHP runtimes, edit DNS zone records, and suspend/unsuspend.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search domain or customer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-500 dark:text-slate-400 font-bold uppercase text-[10px] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Domain Name</th>
                  <th className="py-3 px-4">cPanel Username</th>
                  <th className="py-3 px-4">Package</th>
                  <th className="py-3 px-4">PHP Runtime</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions & Management</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {filteredTasks.map((acc) => (
                  <tr key={acc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-4">
                      <div className="font-black text-slate-900 dark:text-white text-xs">{acc.domain}</div>
                      <div className="text-[11px] text-slate-400">{acc.customerEmail}</div>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-indigo-600 dark:text-indigo-400">{acc.username}</td>
                    <td className="py-3 px-4 font-medium text-slate-700 dark:text-slate-300">{acc.packageName}</td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => setSelectedPhpModal(acc)}
                        className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-100 dark:hover:bg-indigo-950 text-slate-800 dark:text-slate-200 font-mono text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1"
                      >
                        <Code className="w-3 h-3 text-indigo-500" />
                        <span>{acc.phpVersion}</span>
                      </button>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase ${
                        acc.status === 'completed'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                          : 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-800'
                      }`}>
                        {acc.status === 'completed' ? 'Active' : 'Suspended'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1">
                      <button
                        onClick={() => setSelectedAccountModal(acc)}
                        className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow inline-flex items-center gap-1"
                      >
                        <Key className="w-3 h-3" />
                        <span>SSO</span>
                      </button>

                      <button
                        onClick={() => setSelectedDnsModal(acc)}
                        className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow inline-flex items-center gap-1"
                      >
                        <Globe2 className="w-3 h-3" />
                        <span>DNS</span>
                      </button>

                      <button
                        onClick={() => handleToggleAccountSuspend(acc.id)}
                        className={`px-2.5 py-1.5 text-xs font-bold rounded-xl shadow inline-flex items-center gap-1 ${
                          acc.status === 'completed'
                            ? 'bg-amber-600 hover:bg-amber-500 text-white'
                            : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        }`}
                      >
                        <Power className="w-3 h-3" />
                        <span>{acc.status === 'completed' ? 'Suspend' : 'Unsuspend'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* TAB 6: PROVISIONING QUEUE */}
      {activeTab === 'queue' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-500" />
                <span>Execution Queue & Cron Audit Log</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Track pending, executing, and historical server account provisioning tasks.
              </p>
            </div>
          </div>

          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-500 dark:text-slate-400 font-bold uppercase text-[10px] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Task ID</th>
                  <th className="py-3 px-4">Domain & Customer</th>
                  <th className="py-3 px-4">Package</th>
                  <th className="py-3 px-4">Node Allocation</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {filteredTasks.map((task) => (
                  <tr key={task.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-400">{task.id}</td>
                    <td className="py-3 px-4">
                      <div className="font-extrabold text-slate-900 dark:text-white">{task.domain}</div>
                      <div className="text-[11px] text-slate-400">{task.customerName} ({task.customerEmail})</div>
                    </td>
                    <td className="py-3 px-4 font-medium text-indigo-600 dark:text-indigo-400">{task.packageName}</td>
                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">{task.serverNodeName}</td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                        <CheckCircle2 className="w-3 h-3" />
                        {task.currentStage}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedAccountModal(task)}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* MODAL 1: 1-CLICK CLIENT CPANEL LOGIN MODAL SIMULATOR */}
      {selectedAccountModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 text-white space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-white">cPanel Single Sign-On (SSO) Session</h3>
                  <p className="text-xs text-slate-400">Domain: {selectedAccountModal.domain}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedAccountModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">cPanel Username:</span>
                <span className="text-emerald-400 font-bold">{selectedAccountModal.username}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Server Node:</span>
                <span className="text-white">{selectedAccountModal.serverNodeName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">PHP Version:</span>
                <span className="text-indigo-400">{selectedAccountModal.phpVersion}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SSO Session Token:</span>
                <span className="text-amber-400 truncate max-w-[180px]">token_sso_{Date.now()}</span>
              </div>
            </div>

            {/* QUICK CONTROL PANEL TOOL SHORTCUTS */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold text-slate-400 block uppercase">Control Panel Quick Launch Tools</span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <a
                  href={selectedAccountModal.cpanelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 flex items-center gap-2 font-bold"
                >
                  <FolderArchive className="w-4 h-4 text-amber-400" />
                  <span>File Manager</span>
                </a>
                <a
                  href={selectedAccountModal.cpanelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 flex items-center gap-2 font-bold"
                >
                  <Database className="w-4 h-4 text-indigo-400" />
                  <span>phpMyAdmin</span>
                </a>
                <a
                  href={selectedAccountModal.cpanelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 flex items-center gap-2 font-bold"
                >
                  <Mail className="w-4 h-4 text-emerald-400" />
                  <span>Email Accounts</span>
                </a>
                <a
                  href={selectedAccountModal.cpanelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 flex items-center gap-2 font-bold"
                >
                  <Lock className="w-4 h-4 text-teal-400" />
                  <span>SSL/TLS Status</span>
                </a>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-2">
              <a
                href={selectedAccountModal.cpanelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center justify-center gap-2"
              >
                <span>Launch Full Control Panel Dashboard</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              <button
                onClick={() => handleDeleteAccount(selectedAccountModal.id)}
                className="p-3 bg-rose-950/60 hover:bg-rose-900 border border-rose-800 text-rose-400 rounded-xl"
                title="Terminate Account"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: DNS ZONE EDITOR MODAL */}
      {selectedDnsModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 text-white space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
                  <Globe2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-white">DNS Zone File Manager</h3>
                  <p className="text-xs text-slate-400">Domain: {selectedDnsModal.domain}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedDnsModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {/* ADD RECORD FORM */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <span className="text-xs font-bold text-indigo-400 block">Add New DNS Zone Record</span>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                <select
                  value={newDnsType}
                  onChange={(e) => setNewDnsType(e.target.value as any)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-2 font-bold text-white"
                >
                  <option value="A">A Record</option>
                  <option value="CNAME">CNAME</option>
                  <option value="MX">MX Record</option>
                  <option value="TXT">TXT Record</option>
                </select>
                <input
                  type="text"
                  placeholder="Host / Subdomain"
                  value={newDnsName}
                  onChange={(e) => setNewDnsName(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-2 text-white"
                />
                <input
                  type="text"
                  placeholder="Value / Destination IP"
                  value={newDnsValue}
                  onChange={(e) => setNewDnsValue(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-2 text-white"
                />
                <button
                  onClick={() => handleAddDnsRecord(selectedDnsModal.id)}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl px-3 py-2 flex items-center justify-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add</span>
                </button>
              </div>
            </div>

            {/* DNS RECORDS LIST */}
            <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950 text-xs">
              <table className="w-full text-left font-mono">
                <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Name</th>
                    <th className="py-2.5 px-3">Value</th>
                    <th className="py-2.5 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {selectedDnsModal.dnsRecords.map((r) => (
                    <tr key={r.id}>
                      <td className="py-2.5 px-3 font-bold text-emerald-400">{r.type}</td>
                      <td className="py-2.5 px-3 text-white">{r.name}</td>
                      <td className="py-2.5 px-3 truncate max-w-[200px] text-slate-400">{r.value}</td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => handleRemoveDnsRecord(selectedDnsModal.id, r.id)}
                          className="text-rose-400 hover:text-rose-300 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button
              onClick={() => setSelectedDnsModal(null)}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl"
            >
              Done Editing Zone File
            </button>
          </div>
        </div>
      )}

      {/* MODAL 3: PHP VERSION SELECTOR */}
      {selectedPhpModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 text-white space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <Code className="w-5 h-5 text-indigo-400" />
                <h3 className="font-extrabold text-base text-white">PHP Runtime Switcher</h3>
              </div>
              <button onClick={() => setSelectedPhpModal(null)} className="p-1 text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-2">
              {['PHP 8.3 FPM', 'PHP 8.2 FPM', 'PHP 8.1 FPM', 'PHP 8.0 FPM', 'PHP 7.4 Legacy'].map((php) => (
                <button
                  key={php}
                  onClick={() => handleUpdatePhpVersion(selectedPhpModal.id, php)}
                  className={`w-full p-3 rounded-xl border text-left font-mono text-xs font-bold transition-all flex items-center justify-between ${
                    selectedPhpModal.phpVersion === php
                      ? 'bg-indigo-600/30 border-indigo-500 text-emerald-400'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>{php}</span>
                  {selectedPhpModal.phpVersion === php && <Check className="w-4 h-4 text-emerald-400" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: GATEWAY DIAGNOSTIC TEST MODAL */}
      {testingGateway && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 text-white space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <Activity className="w-5 h-5 text-emerald-400 animate-pulse" />
                <div>
                  <h3 className="font-extrabold text-base text-white">API Diagnostic Handshake</h3>
                  <p className="text-xs text-slate-400">{testingGateway.name}</p>
                </div>
              </div>
              <button onClick={() => setTestingGateway(null)} className="p-1 text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 min-h-[160px] space-y-2 font-mono text-xs text-slate-300">
              {testLog.map((l, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">&gt;</span>
                  <span>{l}</span>
                </div>
              ))}
            </div>

            <button
              disabled={isTesting}
              onClick={() => setTestingGateway(null)}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow"
            >
              {isTesting ? 'Running Diagnostic Ping...' : 'Close Diagnostics'}
            </button>
          </div>
        </div>
      )}

      {/* MODAL 5: CONNECT NEW CONTROL PANEL GATEWAY MODAL */}
      {showCreateGatewayModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-base text-white">Connect Control Panel API</h3>
              <button onClick={() => setShowCreateGatewayModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Connection Name</label>
                <input
                  type="text"
                  placeholder="e.g. WHM Secondary Node API"
                  value={newGwName}
                  onChange={(e) => setNewGwName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Control Panel Type</label>
                <select
                  value={newGwType}
                  onChange={(e) => {
                    const t = e.target.value as any;
                    setNewGwType(t);
                    if (t === 'cpanel') setNewGwPort(2087);
                    else if (t === 'whmcs') setNewGwPort(443);
                    else if (t === 'directadmin') setNewGwPort(2222);
                    else if (t === 'plesk') setNewGwPort(8443);
                    else if (t === 'cyberpanel') setNewGwPort(8090);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-indigo-400"
                >
                  <option value="cpanel">cPanel / WHM API v2</option>
                  <option value="whmcs">Cloud Storefront API</option>
                  <option value="directadmin">DirectAdmin CMD_API</option>
                  <option value="plesk">Plesk Obsidian XML API</option>
                  <option value="cyberpanel">CyberPanel LiteSpeed API</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="font-bold text-slate-300 block mb-1">Hostname / Domain</label>
                  <input
                    type="text"
                    placeholder="whm.mydomain.com"
                    value={newGwHost}
                    onChange={(e) => setNewGwHost(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Port</label>
                  <input
                    type="number"
                    value={newGwPort}
                    onChange={(e) => setNewGwPort(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">API Key / Token</label>
                <input
                  type="password"
                  placeholder="whm_token_••••••••••••"
                  value={newGwApiKey}
                  onChange={(e) => setNewGwApiKey(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono"
                />
              </div>
            </div>

            <button
              onClick={handleSaveGateway}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow"
            >
              Save Gateway Connection
            </button>
          </div>
        </div>
      )}

      {/* MODAL 6: CREATE / EDIT HOSTING PACKAGE BLUEPRINT */}
      {showPlanModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-base text-white">
                {editingPlan ? 'Edit Hosting Package' : 'Create Custom Hosting Package'}
              </h3>
              <button onClick={() => setShowPlanModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="col-span-2">
                <label className="font-bold text-slate-300 block mb-1">Package Name</label>
                <input
                  type="text"
                  placeholder="e.g. Ultra NVMe Pro Cloud"
                  value={planFormName}
                  onChange={(e) => setPlanFormName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Category</label>
                <select
                  value={planFormCat}
                  onChange={(e) => setPlanFormCat(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-indigo-400"
                >
                  <option value="Shared Hosting">Shared Hosting</option>
                  <option value="WordPress Cloud">WordPress Cloud</option>
                  <option value="NVMe VPS">NVMe VPS</option>
                  <option value="Reseller Hosting">Reseller Hosting</option>
                  <option value="Dedicated Server">Dedicated Server</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Control Panel</label>
                <select
                  value={planFormPanel}
                  onChange={(e) => setPlanFormPanel(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-amber-400"
                >
                  <option value="cpanel">cPanel / WHM</option>
                  <option value="whmcs">Cloud Panel</option>
                  <option value="directadmin">DirectAdmin</option>
                  <option value="plesk">Plesk</option>
                  <option value="cyberpanel">CyberPanel</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Disk Quota (GB)</label>
                <input
                  type="number"
                  value={planFormDiskGb}
                  onChange={(e) => setPlanFormDiskGb(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Bandwidth (GB/mo)</label>
                <input
                  type="number"
                  value={planFormBwGb}
                  onChange={(e) => setPlanFormBwGb(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">MySQL DB Limit</label>
                <input
                  type="number"
                  value={planFormDb}
                  onChange={(e) => setPlanFormDb(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Monthly Price ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={planFormPriceUsd}
                  onChange={(e) => setPlanFormPriceUsd(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-emerald-400 font-bold font-mono"
                />
              </div>
            </div>

            <button
              onClick={handleSavePlan}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow"
            >
              Save Hosting Package
            </button>
          </div>
        </div>
      )}

      {/* MODAL 7: CONNECT NEW SERVER NODE */}
      {showNodeModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-base text-white">Connect New Server Node</h3>
              <button onClick={() => setShowNodeModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Node Identifier Name</label>
                <input
                  type="text"
                  placeholder="e.g. US-WEST-04 (Plesk Obsidian)"
                  value={nodeFormName}
                  onChange={(e) => setNodeFormName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-bold text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Server IP Address</label>
                <input
                  type="text"
                  placeholder="198.51.100.99"
                  value={nodeFormIp}
                  onChange={(e) => setNodeFormIp(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Datacenter Location</label>
                <input
                  type="text"
                  placeholder="Accra / Frankfurt / Virginia"
                  value={nodeFormLocation}
                  onChange={(e) => setNodeFormLocation(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>
            </div>

            <button
              onClick={handleSaveNode}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow"
            >
              Add Server Node to Cluster
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
