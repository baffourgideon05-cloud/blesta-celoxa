import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Server, 
  Key, 
  ShieldCheck, 
  Sliders, 
  FileText, 
  ExternalLink, 
  Clock, 
  Check, 
  X, 
  Search, 
  DollarSign, 
  Zap, 
  Activity,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';
import { RegistrarConfig, RegistrarApiLog, RegistrarProviderType } from '../types';
import { registrarManager } from '../services/registrarManager';
import { formatCurrencyAmount } from '../utils/domainSearchEngine';

export const AdminRegistrarIntegrationHub: React.FC = () => {
  const [registrars, setRegistrars] = useState<RegistrarConfig[]>(() => registrarManager.getRegistrars());
  const [logs, setLogs] = useState<RegistrarApiLog[]>(() => registrarManager.getLogs());
  const [selectedRegistrar, setSelectedRegistrar] = useState<RegistrarConfig | null>(() => registrarManager.getDefaultRegistrar());
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; success: boolean; message: string; latencyMs: number } | null>(null);
  const [logFilter, setLogFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<RegistrarConfig>>({});
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const unsub = registrarManager.subscribe(() => {
      setRegistrars(registrarManager.getRegistrars());
      setLogs(registrarManager.getLogs());
    });
    return unsub;
  }, []);

  const handleTestConnection = async (id: string) => {
    setTestingId(id);
    setTestResult(null);
    try {
      const res = await registrarManager.testConnection(id);
      setTestResult({ id, success: res.success, message: res.message, latencyMs: res.latencyMs });
      setStatusMessage({ type: res.success ? 'success' : 'error', text: res.message });
    } catch (e: any) {
      setTestResult({ id, success: false, message: e.message || 'Connection failed', latencyMs: 0 });
    } finally {
      setTestingId(null);
    }
  };

  const handleSetDefault = (id: string) => {
    registrarManager.setDefaultRegistrar(id);
    setStatusMessage({ type: 'success', text: 'Default domain registrar provider updated.' });
  };

  const handleStartEdit = (reg: RegistrarConfig) => {
    setSelectedRegistrar(reg);
    setEditForm({ ...reg });
    setIsEditing(true);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.id || !editForm.name) return;

    registrarManager.saveRegistrar(editForm as RegistrarConfig);
    setIsEditing(false);
    setStatusMessage({ type: 'success', text: `Saved settings for ${editForm.name}` });
  };

  const filteredLogs = logs.filter((l) => {
    if (logFilter !== 'all' && l.provider !== logFilter) return false;
    if (searchTerm) {
      const s = searchTerm.toLowerCase();
      return (
        l.registrarName.toLowerCase().includes(s) ||
        l.action.toLowerCase().includes(s) ||
        (l.domain && l.domain.toLowerCase().includes(s))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-3xl p-6 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Globe className="w-4 h-4" />
              <span>Domain Registrar Integration Manager</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">Provider Adapters & Live Gateway Controls</h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Configure and test domain registrar connections (Internal Authoritative Registry, ResellerClub, GoDaddy, eNom, Namecheap). The system automatically routes registrations and nameserver updates through active adapters.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                const def = registrarManager.getDefaultRegistrar();
                if (def) handleTestConnection(def.id);
              }}
              disabled={!!testingId}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg shadow-indigo-600/30 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${testingId ? 'animate-spin' : ''}`} />
              <span>Test Active Gateway</span>
            </button>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between border ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
          }`}
        >
          <span>{statusMessage.text}</span>
          <button onClick={() => setStatusMessage(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Main Grid: Registrars Cards + Selected Details/Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: List of Adapters */}
        <div className="lg:col-span-1 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400 px-1">
            <span>Configured Registrars ({registrars.length})</span>
            <span className="text-[11px] text-indigo-400">Adapter Pattern</span>
          </div>

          {registrars.map((reg) => {
            const isSelected = selectedRegistrar?.id === reg.id;
            const isDefault = reg.isDefault;
            return (
              <div
                key={reg.id}
                onClick={() => {
                  setSelectedRegistrar(reg);
                  setIsEditing(false);
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-900 border-indigo-500 shadow-lg shadow-indigo-500/10'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-white">{reg.name}</span>
                      {isDefault && (
                        <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 rounded-full text-[10px] font-black uppercase">
                          Default
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                      Provider: {reg.provider.toUpperCase()} {reg.testMode ? '• Sandbox' : '• Production'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        reg.status === 'connected'
                          ? 'bg-emerald-400 shadow-sm shadow-emerald-400/50'
                          : reg.status === 'error'
                          ? 'bg-rose-400'
                          : 'bg-amber-400'
                      }`}
                    />
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">
                    Balance: <strong className="text-slate-200">{reg.accountBalance ? `$${reg.accountBalance.amount.toFixed(2)}` : 'N/A'}</strong>
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTestConnection(reg.id);
                      }}
                      disabled={testingId === reg.id}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
                    >
                      <RefreshCw className={`w-3 h-3 ${testingId === reg.id ? 'animate-spin' : ''}`} />
                      Test
                    </button>
                    {!isDefault && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSetDefault(reg.id);
                        }}
                        className="px-2.5 py-1 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white rounded-lg text-[10px] font-bold transition-all"
                      >
                        Set Default
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Selected Registrar Configuration & Live API Logs */}
        <div className="lg:col-span-2 space-y-6">
          {selectedRegistrar && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-3">
                    <h2 className="text-lg font-black text-white">{selectedRegistrar.name}</h2>
                    <span
                      className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold flex items-center gap-1.5 ${
                        selectedRegistrar.status === 'connected'
                          ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
                          : 'bg-rose-500/10 border border-rose-500/30 text-rose-400'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      {selectedRegistrar.status === 'connected' ? 'Connected & Healthy' : 'Action Required'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{selectedRegistrar.statusMessage || 'API configuration online'}</p>
                </div>

                <div className="flex items-center gap-2">
                  {isEditing ? (
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all"
                    >
                      Cancel
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStartEdit(selectedRegistrar)}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-lg shadow-indigo-600/20"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      Configure API
                    </button>
                  )}
                </div>
              </div>

              {/* Edit Mode vs View Mode */}
              {isEditing ? (
                <form onSubmit={handleSaveEdit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Display Name</label>
                      <input
                        type="text"
                        value={editForm.name || ''}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Environment Mode</label>
                      <select
                        value={editForm.testMode ? 'sandbox' : 'production'}
                        onChange={(e) => setEditForm({ ...editForm, testMode: e.target.value === 'sandbox' })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                      >
                        <option value="sandbox">Sandbox / OTE Test Mode</option>
                        <option value="production">Live Production API</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">API Key / User ID</label>
                      <input
                        type="text"
                        value={editForm.apiKey || editForm.username || ''}
                        onChange={(e) => setEditForm({ ...editForm, apiKey: e.target.value, username: e.target.value })}
                        placeholder="e.g. rc_live_key_..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">API Secret / Password</label>
                      <input
                        type="password"
                        value={editForm.apiSecret || editForm.password || ''}
                        onChange={(e) => setEditForm({ ...editForm, apiSecret: e.target.value, password: e.target.value })}
                        placeholder="••••••••••••"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none font-mono"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">API Endpoint URL</label>
                      <input
                        type="text"
                        value={editForm.endpointUrl || ''}
                        onChange={(e) => setEditForm({ ...editForm, endpointUrl: e.target.value })}
                        placeholder="https://api.registrar.com/v1/"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none font-mono"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">Default Nameservers (1 per line)</label>
                      <textarea
                        rows={3}
                        value={(editForm.defaultNameservers || []).join('\n')}
                        onChange={(e) => {
                          const lines = e.target.value.split('\n').filter(Boolean);
                          setEditForm({
                            ...editForm,
                            defaultNameservers: [
                              lines[0] || 'ns1.celoxaghana.online',
                              lines[1] || 'ns2.celoxaghana.online',
                              lines[2] || 'ns3.celoxaghana.online',
                              lines[3] || 'ns4.celoxaghana.online',
                            ],
                          });
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold hover:bg-slate-700"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-extrabold hover:bg-indigo-500 shadow-lg shadow-indigo-600/30"
                    >
                      Save Configuration
                    </button>
                  </div>
                </form>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Adapter Specifications</span>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Provider Type</span>
                      <span className="font-mono font-bold text-slate-200">{selectedRegistrar.provider.toUpperCase()}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Environment</span>
                      <span className={`font-bold ${selectedRegistrar.testMode ? 'text-amber-400' : 'text-emerald-400'}`}>
                        {selectedRegistrar.testMode ? 'Sandbox (OTE Test)' : 'Production (Live)'}
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Auto-Renew Engine</span>
                      <span className="text-emerald-400 font-bold">Supported</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-400">DNS & WHOIS Privacy</span>
                      <span className="text-emerald-400 font-bold">Supported</span>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Default Nameserver Cluster</span>
                    <ul className="space-y-1.5 font-mono text-[11px] text-slate-300">
                      {selectedRegistrar.defaultNameservers.map((ns, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <span className="text-indigo-400 font-bold">NS{idx + 1}:</span>
                          <span>{ns}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Registrar API Logs */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-black text-white">Registrar API Communication Logs</h3>
                <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded-full text-[10px] font-bold">
                  {filteredLogs.length} events
                </span>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search logs..."
                    className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:border-indigo-500 outline-none w-36 sm:w-48"
                  />
                </div>
                <select
                  value={logFilter}
                  onChange={(e) => setLogFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:border-indigo-500 outline-none"
                >
                  <option value="all">All Providers</option>
                  <option value="internal">Internal</option>
                  <option value="resellerclub">ResellerClub</option>
                  <option value="godaddy">GoDaddy</option>
                  <option value="enom">eNom</option>
                  <option value="namecheap">Namecheap</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase font-extrabold tracking-wider">
                    <th className="pb-3 px-3">Timestamp</th>
                    <th className="pb-3 px-3">Registrar / Provider</th>
                    <th className="pb-3 px-3">Action</th>
                    <th className="pb-3 px-3">Target Domain</th>
                    <th className="pb-3 px-3">Latency</th>
                    <th className="pb-3 px-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-white block">{log.registrarName}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{log.provider.toUpperCase()}</span>
                      </td>
                      <td className="py-3 px-3 font-mono text-indigo-300">
                        {log.action}
                      </td>
                      <td className="py-3 px-3 text-slate-200">
                        {log.domain || '—'}
                      </td>
                      <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">
                        {log.executionTimeMs} ms
                      </td>
                      <td className="py-3 px-3 text-right">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                            log.status === 'success'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {log.status === 'success' ? <Check className="w-2.5 h-2.5" /> : <X className="w-2.5 h-2.5" />}
                          {log.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filteredLogs.length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-slate-500">
                        No registrar API log entries found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
