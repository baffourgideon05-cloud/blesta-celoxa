import React, { useState } from 'react';
import { 
  Building2, 
  Server, 
  Lock, 
  Unlock, 
  RefreshCw, 
  ShieldCheck, 
  Check, 
  AlertTriangle,
  FileText,
  Clock,
  ExternalLink,
  Globe,
  ArrowRight,
  ChevronRight,
  CreditCard,
  Layers,
  HelpCircle,
  Settings,
  CheckCircle2,
  Calendar,
  DollarSign,
  Receipt,
  UserCheck,
  Zap,
  Info,
  Shield,
  Activity,
  ArrowUpRight,
  Database,
  Cpu,
  Key,
  Copy,
  Terminal,
  Send,
  AlertCircle,
  X
} from 'lucide-react';
import { 
  RegisteredDomain, 
  Currency,
  PaystackConfig
} from '../types';
import { CURRENCY_RATES, formatCurrencyAmount } from '../utils/domainSearchEngine';
import { PaystackCheckoutModal } from './PaystackCheckoutModal';
import { systemDatabase } from '../services/systemDatabase';

interface DomainManagementHubProps {
  domains: RegisteredDomain[];
  setDomains: React.Dispatch<React.SetStateAction<RegisteredDomain[]>>;
  currency?: Currency;
  onNavigateToHosting?: (domainName?: string) => void;
  onOpenSupportTicket?: (domainName?: string) => void;
}

export const DomainManagementHub: React.FC<DomainManagementHubProps> = ({ 
  domains, 
  setDomains,
  currency = 'GHS',
  onNavigateToHosting,
  onOpenSupportTicket
}) => {
  const [selectedDomainId, setSelectedDomainId] = useState<string>(domains[0]?.id || '');
  const [viewMode, setViewMode] = useState<'customer' | 'admin'>('customer');
  
  // Modals & Drawers
  const [showRenewModal, setShowRenewModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showAuthCodeAdmin, setShowAuthCodeAdmin] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  // Selected Domain Object
  const selectedDomain = domains.find((d) => d.id === selectedDomainId) || domains[0];

  // Nameserver Edit State
  const [nsMode, setNsMode] = useState<'system_default' | 'custom'>(
    selectedDomain?.nameserverMode || 'system_default'
  );
  const [ns1, setNs1] = useState(selectedDomain?.customNameservers?.[0] || selectedDomain?.nameservers?.[0] || 'ns1.apexdomain.com');
  const [ns2, setNs2] = useState(selectedDomain?.customNameservers?.[1] || selectedDomain?.nameservers?.[1] || 'ns2.apexdomain.com');
  const [ns3, setNs3] = useState(selectedDomain?.customNameservers?.[2] || '');
  const [ns4, setNs4] = useState(selectedDomain?.customNameservers?.[3] || '');

  // Contact Info State
  const [contactName, setContactName] = useState(selectedDomain?.contactInfo?.registrantName || selectedDomain?.customerName || 'Gideon Baffour');
  const [contactEmail, setContactEmail] = useState(selectedDomain?.contactInfo?.registrantEmail || selectedDomain?.customerEmail || 'baffourgideon05@gmail.com');
  const [contactPhone, setContactPhone] = useState(selectedDomain?.contactInfo?.registrantPhone || '+233 24 000 0000');
  const [contactOrg, setContactOrg] = useState(selectedDomain?.contactInfo?.organization || 'Celoxa Ghana');
  const [contactCountry, setContactCountry] = useState(selectedDomain?.contactInfo?.country || 'Ghana (GH)');

  // Sync state with selected domain switch
  const handleSelectDomain = (dom: RegisteredDomain) => {
    setSelectedDomainId(dom.id);
    setNsMode(dom.nameserverMode || 'system_default');
    setNs1(dom.customNameservers?.[0] || dom.nameservers?.[0] || 'ns1.apexdomain.com');
    setNs2(dom.customNameservers?.[1] || dom.nameservers?.[1] || 'ns2.apexdomain.com');
    setNs3(dom.customNameservers?.[2] || '');
    setNs4(dom.customNameservers?.[3] || '');
    setContactName(dom.contactInfo?.registrantName || dom.customerName || 'Gideon Baffour');
    setContactEmail(dom.contactInfo?.registrantEmail || dom.customerEmail || 'baffourgideon05@gmail.com');
    setContactPhone(dom.contactInfo?.registrantPhone || '+233 24 000 0000');
    setContactOrg(dom.contactInfo?.organization || 'Celoxa Ghana');
    setContactCountry(dom.contactInfo?.country || 'Ghana (GH)');
    setShowAuthCodeAdmin(false);
    setSaveFeedback(null);
    setSyncFeedback(null);
  };

  // Pricing format helper
  const regPrice = selectedDomain?.registrationPrice || 120;
  const renPrice = selectedDomain?.renewalPrice || 120;
  const curr = selectedDomain?.currency || currency || 'GHS';

  // Toggle Auto-Renew
  const handleToggleAutoRenew = (id: string) => {
    setDomains((prev) =>
      prev.map((d) => {
        if (d.id === id) {
          const nextVal = !d.autoRenew;
          const newActivity = [
            ...(d.activityTimeline || []),
            {
              id: `act-${Date.now()}`,
              title: `Auto-Renewal ${nextVal ? 'Enabled' : 'Disabled'}`,
              description: `Automatic renewal was turned ${nextVal ? 'ON' : 'OFF'} by customer.`,
              date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
              type: 'renewal' as const
            }
          ];
          return { ...d, autoRenew: nextVal, activityTimeline: newActivity };
        }
        return d;
      })
    );
    setSaveFeedback('Auto-renewal preference updated successfully.');
    setTimeout(() => setSaveFeedback(null), 3000);
  };

  // Save Nameserver Configuration
  const handleSaveNameservers = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDomain) return;

    let targetNameservers: string[] = [];
    if (nsMode === 'system_default') {
      targetNameservers = ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'];
    } else {
      targetNameservers = [ns1.trim(), ns2.trim(), ns3.trim(), ns4.trim()].filter(Boolean);
      if (targetNameservers.length < 2) {
        alert('Please provide at least 2 valid nameservers (NS1 and NS2).');
        return;
      }
    }

    const todayStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

    setDomains((prev) =>
      prev.map((d) => {
        if (d.id === selectedDomain.id) {
          const newActivity = [
            ...(d.activityTimeline || []),
            {
              id: `act-${Date.now()}`,
              title: nsMode === 'system_default' ? 'Default Nameservers Configured' : 'Custom Nameservers Saved',
              description: `Nameservers updated to: ${targetNameservers.join(', ')}`,
              date: todayStr,
              type: 'nameserver' as const
            }
          ];
          return {
            ...d,
            nameserverMode: nsMode,
            nameservers: targetNameservers,
            customNameservers: [ns1, ns2, ns3, ns4],
            nameserverUpdatedDate: todayStr,
            nameserverUpdatedBy: 'Customer',
            activityTimeline: newActivity
          };
        }
        return d;
      })
    );

    setSaveFeedback('Nameserver changes saved successfully and propagated to authoritative registry.');
    setTimeout(() => setSaveFeedback(null), 4000);
  };

  // Save Contact Information
  const handleSaveContactInfo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDomain) return;

    setDomains((prev) =>
      prev.map((d) => {
        if (d.id === selectedDomain.id) {
          return {
            ...d,
            contactInfo: {
              registrantName: contactName,
              registrantEmail: contactEmail,
              registrantPhone: contactPhone,
              organization: contactOrg,
              country: contactCountry
            }
          };
        }
        return d;
      })
    );

    setShowContactModal(false);
    setSaveFeedback('Domain contact details saved successfully.');
    setTimeout(() => setSaveFeedback(null), 3000);
  };

  // Admin Force Synchronization with Registrar
  const handleForceSyncRegistrar = () => {
    setIsSyncing(true);
    setSyncFeedback(null);
    setTimeout(() => {
      setIsSyncing(false);
      const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC';
      setDomains((prev) =>
        prev.map((d) => (d.id === selectedDomain?.id ? { ...d, lastSyncDate: nowStr, syncStatus: 'synced' } : d))
      );
      setSyncFeedback(`Successfully synchronized with ${selectedDomain?.registrarProvider || 'Registrar API'}. Registry state is up-to-date.`);
      setTimeout(() => setSyncFeedback(null), 5000);
    }, 1200);
  };

  // Paystack Config for Renewal
  const paystackConfig: PaystackConfig = {
    enabled: true,
    testMode: false,
    environment: 'live',
    publicKey: 'pk_live_93621f2292fc2f1396ddc18fea182881a6f55e1b',
    merchantName: 'ApexDomain & Celoxa Ghana',
    allowedChannels: ['card', 'mobile_money', 'bank_transfer', 'ussd'],
    currencyPreference: 'GHS',
    healthStatus: 'healthy',
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* TOP HEADER & VIEW MODE SELECTOR */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5" />
              Domain Management
            </span>
            <span className="text-xs text-slate-400 font-bold">•</span>
            <span className="text-xs text-slate-500 font-semibold">Registered Domains ({domains.length})</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            {viewMode === 'customer' ? 'My Domain Management' : 'Admin Domain Infrastructure'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            {viewMode === 'customer' 
              ? 'Manage your domain registration, renewal status, nameservers, and billing information.'
              : 'Inspect registrar provider APIs, provisioning states, EPP transfer authorization keys, and technical audit logs.'}
          </p>
        </div>

        {/* View Switcher: Customer vs Admin (Clean Separation) */}
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800/80 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700/80 self-start sm:self-auto shadow-sm">
          <button
            onClick={() => setViewMode('customer')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'customer'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm font-black'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Customer View</span>
          </button>

          <button
            onClick={() => setViewMode('admin')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'admin'
                ? 'bg-slate-900 dark:bg-slate-950 text-amber-400 shadow-sm font-black border border-amber-500/30'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-amber-500" />
            <span>Admin / Registrar View</span>
          </button>
        </div>
      </div>

      {/* FEEDBACK TOASTS */}
      {saveFeedback && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800/80 rounded-2xl text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{saveFeedback}</span>
          </div>
          <button onClick={() => setSaveFeedback(null)} className="text-emerald-600 hover:text-emerald-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {syncFeedback && (
        <div className="p-3.5 bg-blue-50 dark:bg-blue-950/40 border border-blue-300 dark:border-blue-800/80 rounded-2xl text-blue-800 dark:text-blue-300 text-xs font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
            <span>{syncFeedback}</span>
          </div>
          <button onClick={() => setSyncFeedback(null)} className="text-blue-600 hover:text-blue-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* MAIN TWO-COLUMN CONTAINER */}
      {domains.length > 0 && selectedDomain && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* LEFT SIDEBAR: DOMAIN SELECTOR */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm space-y-2.5">
              <div className="flex items-center justify-between px-2 pb-1">
                <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">
                  Select Domain ({domains.length})
                </span>
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                  Active Services
                </span>
              </div>

              <div className="space-y-1.5">
                {domains.map((dom) => {
                  const isSelected = selectedDomain.id === dom.id;
                  return (
                    <button
                      key={dom.id}
                      onClick={() => handleSelectDomain(dom)}
                      className={`w-full text-left p-3.5 rounded-2xl transition-all border ${
                        isSelected
                          ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 dark:border-emerald-600 shadow-md shadow-emerald-600/10'
                          : 'bg-slate-50/50 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`font-black text-sm truncate ${isSelected ? 'text-emerald-950 dark:text-white' : 'text-slate-800 dark:text-slate-200'}`}>
                          {dom.domain}
                        </span>
                        <span className={`w-2 h-2 rounded-full ${dom.status === 'active' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                        <span>Expires: {dom.expiryDate}</span>
                        <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                          {formatCurrencyAmount(dom.renewalPrice || 120, dom.currency || currency)}/yr
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* QUICK STATS WIDGET */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-3xl p-5 border border-slate-800 shadow-lg space-y-3">
              <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> Ownership Protection
                </span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold">100% SECURE</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">WHOIS Privacy</div>
                  <div className="font-black text-emerald-400 mt-0.5 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Enabled
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Registry Lock</div>
                  <div className="font-black text-emerald-400 mt-0.5 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Active
                  </div>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed">
                Your domain registration is guarded with ICANN WHOIS data redaction and automated transfer protection.
              </p>
            </div>

          </div>

          {/* RIGHT COLUMN: DETAILED DOMAIN MANAGEMENT CONTENT */}
          <div className="lg:col-span-8 space-y-6">

            {/* ========================================================= */}
            {/* VIEW MODE 1: CLEAN CUSTOMER-SIDE DOMAIN MANAGEMENT        */}
            {/* ========================================================= */}
            {viewMode === 'customer' && (
              <div className="space-y-6 animate-in fade-in">
                
                {/* SECTION 1: DOMAIN OVERVIEW CARD */}
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5">
                  
                  {/* Title & Status */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-xs font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                          {selectedDomain.status === 'active' ? 'Active' : 'Expiring Soon'}
                        </span>
                        <span className="text-xs text-slate-400">•</span>
                        <span className="text-xs font-mono text-slate-500 font-bold">
                          Service ID: {selectedDomain.serviceId || `#DOM-${selectedDomain.id.slice(-5)}`}
                        </span>
                      </div>
                      <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                        {selectedDomain.domain}
                      </h2>
                    </div>

                    <div className="flex items-center gap-2">
                      <a
                        href={`https://${selectedDomain.domain}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-all"
                      >
                        <Globe className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Visit Website</span>
                        <ExternalLink className="w-3 h-3 opacity-60" />
                      </a>
                    </div>
                  </div>

                  {/* Clean Specification Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Registration Date</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-1">{selectedDomain.registeredDate}</div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Expiry Date</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-1">{selectedDomain.expiryDate}</div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Domain Status</div>
                      <div className="font-bold text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Active
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Auto-Renewal</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-1 flex items-center justify-between">
                        <span>{selectedDomain.autoRenew ? 'ON' : 'OFF'}</span>
                        <button
                          onClick={() => handleToggleAutoRenew(selectedDomain.id)}
                          className="text-[10px] text-emerald-600 dark:text-emerald-400 hover:underline font-bold"
                        >
                          Toggle
                        </button>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Registrar</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-1">
                        Managed by System
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Billing Cycle</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-1">{selectedDomain.billingCycle || '1 Year'}</div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50">
                      <div className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold uppercase">Domain Price</div>
                      <div className="font-mono font-black text-emerald-800 dark:text-emerald-300 mt-1">
                        {formatCurrencyAmount(regPrice, curr)}/year
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50">
                      <div className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold uppercase">Renewal Price</div>
                      <div className="font-mono font-black text-emerald-800 dark:text-emerald-300 mt-1">
                        {formatCurrencyAmount(renPrice, curr)}/year
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Next Renewal Date</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-1">{selectedDomain.expiryDate}</div>
                    </div>
                  </div>

                  {/* SECTION 2: MAIN ACTION BUTTONS */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={() => setShowRenewModal(true)}
                      className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 transition-all hover:scale-[1.02]"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Renew Domain ({formatCurrencyAmount(renPrice, curr)})</span>
                    </button>

                    <button
                      onClick={() => handleToggleAutoRenew(selectedDomain.id)}
                      className={`px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                        selectedDomain.autoRenew
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                          : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-500" />
                      <span>Auto-Renew: {selectedDomain.autoRenew ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      onClick={() => setShowContactModal(true)}
                      className="px-3.5 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5"
                    >
                      <UserCheck className="w-3.5 h-3.5 text-blue-500" />
                      <span>Contact Details</span>
                    </button>

                    <button
                      onClick={() => setShowInvoiceModal(true)}
                      className="px-3.5 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5"
                    >
                      <Receipt className="w-3.5 h-3.5 text-purple-500" />
                      <span>View Invoice</span>
                    </button>

                    {onOpenSupportTicket && (
                      <button
                        onClick={() => onOpenSupportTicket(selectedDomain.domain)}
                        className="px-3.5 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5"
                      >
                        <HelpCircle className="w-3.5 h-3.5 text-amber-500" />
                        <span>Support Request</span>
                      </button>
                    )}
                  </div>

                </div>

                {/* SECTION 3: NAMESERVER SETTINGS */}
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div>
                      <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                        <Server className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                        <span>Nameserver Configuration</span>
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Choose whether to use our global Anycast DNS nameservers or custom third-party nameservers.
                      </p>
                    </div>

                    <span className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-mono font-bold text-slate-600 dark:text-slate-300">
                      Mode: {nsMode === 'system_default' ? 'System Default' : 'Custom'}
                    </span>
                  </div>

                  <form onSubmit={handleSaveNameservers} className="space-y-4">
                    
                    {/* Radio Options */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <label 
                        className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                          nsMode === 'system_default'
                            ? 'bg-emerald-50/60 dark:bg-emerald-950/40 border-emerald-500 dark:border-emerald-600 text-emerald-950 dark:text-white'
                            : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <input
                          type="radio"
                          name="nsMode"
                          value="system_default"
                          checked={nsMode === 'system_default'}
                          onChange={() => setNsMode('system_default')}
                          className="mt-1 text-emerald-600 focus:ring-emerald-500"
                        />
                        <div>
                          <div className="font-black text-xs">Use System Default Nameservers</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                            Recommended. Automatically managed by our high-speed global Anycast DNS network.
                          </div>
                        </div>
                      </label>

                      <label 
                        className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                          nsMode === 'custom'
                            ? 'bg-emerald-50/60 dark:bg-emerald-950/40 border-emerald-500 dark:border-emerald-600 text-emerald-950 dark:text-white'
                            : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <input
                          type="radio"
                          name="nsMode"
                          value="custom"
                          checked={nsMode === 'custom'}
                          onChange={() => setNsMode('custom')}
                          className="mt-1 text-emerald-600 focus:ring-emerald-500"
                        />
                        <div>
                          <div className="font-black text-xs">Use Custom Nameservers</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                            Point your domain to external hosts such as Cloudflare, AWS Route53, or cPanel.
                          </div>
                        </div>
                      </label>
                    </div>

                    {/* Default Nameservers Display */}
                    {nsMode === 'system_default' && (
                      <div className="p-4 rounded-2xl bg-slate-900 text-slate-200 font-mono text-xs space-y-2 border border-slate-800">
                        <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider pb-1 border-b border-slate-800">
                          Active System Default Nameservers
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold">NS1:</span> ns1.apexdomain.com
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold">NS2:</span> ns2.apexdomain.com
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold">NS3:</span> ns3.apexdomain.com
                        </div>
                      </div>
                    )}

                    {/* Custom Nameservers Inputs */}
                    {nsMode === 'custom' && (
                      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3 animate-in fade-in">
                        <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                          Enter Custom Nameserver Hostnames:
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="text-[10px] font-bold text-slate-400 uppercase">Nameserver 1 (Required)</label>
                            <input
                              type="text"
                              required
                              value={ns1}
                              onChange={(e) => setNs1(e.target.value)}
                              placeholder="ns1.examplehost.com"
                              className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-slate-400 uppercase">Nameserver 2 (Required)</label>
                            <input
                              type="text"
                              required
                              value={ns2}
                              onChange={(e) => setNs2(e.target.value)}
                              placeholder="ns2.examplehost.com"
                              className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-slate-400 uppercase">Nameserver 3 (Optional)</label>
                            <input
                              type="text"
                              value={ns3}
                              onChange={(e) => setNs3(e.target.value)}
                              placeholder="ns3.examplehost.com"
                              className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-slate-400 uppercase">Nameserver 4 (Optional)</label>
                            <input
                              type="text"
                              value={ns4}
                              onChange={(e) => setNs4(e.target.value)}
                              placeholder="ns4.examplehost.com"
                              className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-900 dark:text-white"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2">
                      <p className="text-[11px] text-slate-400">
                        DNS changes may take up to 24–48 hours to fully propagate worldwide.
                      </p>
                      <button
                        type="submit"
                        className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all hover:scale-[1.02]"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Save Nameserver Changes</span>
                      </button>
                    </div>

                  </form>
                </div>

                {/* SECTION 4: DNS ZONE MANAGEMENT NOTICE (CLEAN BOUNDARY) */}
                <div className="bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-black text-slate-800 dark:text-slate-200">
                        <Layers className="w-4 h-4 text-indigo-500" />
                        <span>DNS Zone & Record Management</span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xl leading-relaxed">
                        DNS records (A, AAAA, CNAME, MX, TXT, SRV, CAA) are managed directly through your active hosting and cloud DNS service.
                      </p>
                    </div>

                    {onNavigateToHosting && (
                      <button
                        type="button"
                        onClick={() => onNavigateToHosting(selectedDomain.domain)}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow shrink-0 flex items-center gap-1.5"
                      >
                        <span>Manage DNS via Hosting</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* SECTION 5: ORDER & BILLING TRANSPARENCY */}
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                      <Receipt className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span>Order & Billing Details</span>
                    </h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 text-[10px] font-black uppercase">
                      Payment: {selectedDomain.paymentStatus || 'Paid'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Order ID</div>
                      <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5">#{selectedDomain.orderId || 'ORD-10482'}</div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Invoice ID</div>
                      <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5">#{selectedDomain.invoiceId || 'INV-10482'}</div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Amount Paid</div>
                      <div className="font-mono font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                        {formatCurrencyAmount(regPrice, curr)}
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Registration Term</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{selectedDomain.billingCycle || '1 Year'}</div>
                    </div>
                  </div>
                </div>

                {/* SECTION 6: DOMAIN ACTIVITY TIMELINE (CUSTOMER-FRIENDLY) */}
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-emerald-500" />
                      <span>Domain Activity Timeline</span>
                    </h3>
                    <span className="text-[11px] text-slate-400 font-medium">Logged Milestones</span>
                  </div>

                  <div className="space-y-3">
                    {(selectedDomain.activityTimeline && selectedDomain.activityTimeline.length > 0) ? (
                      selectedDomain.activityTimeline.map((item) => (
                        <div key={item.id} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/30 border border-slate-200/60 dark:border-slate-800 flex items-start gap-3">
                          <div className="w-7 h-7 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                          <div className="flex-1 space-y-0.5">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900 dark:text-white">{item.title}</span>
                              <span className="text-[10px] font-mono text-slate-400">{item.date}</span>
                            </div>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400">{item.description}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-4 text-xs text-slate-400">
                        No activity records logged yet.
                      </div>
                    )}
                  </div>
                </div>

              </div>
            )}

            {/* ========================================================= */}
            {/* VIEW MODE 2: ADMIN-SIDE DOMAIN INFRASTRUCTURE             */}
            {/* ========================================================= */}
            {viewMode === 'admin' && (
              <div className="space-y-6 animate-in fade-in">
                
                {/* ADMIN OVERVIEW & REGISTRAR DETAILS */}
                <div className="bg-slate-950 text-white rounded-3xl border border-slate-800 p-6 shadow-xl space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-black uppercase">
                          Registrar Infrastructure (Admin Only)
                        </span>
                        <span className="text-slate-500">•</span>
                        <span className="text-xs font-mono text-slate-400">Owner: {selectedDomain.customerName || 'Gideon Baffour'}</span>
                      </div>
                      <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                        <span>{selectedDomain.domain}</span>
                        <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-lg border border-emerald-800">
                          STATUS: ACTIVE
                        </span>
                      </h2>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleForceSyncRegistrar}
                        disabled={isSyncing}
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow flex items-center gap-1.5 transition-all"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                        <span>{isSyncing ? 'Syncing...' : 'Sync Registrar API'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Infrastructure Matrix */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Registrar Provider</div>
                      <div className="font-bold text-amber-400 mt-1 capitalize">
                        {selectedDomain.registrarProvider || 'ResellerClub'}
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Registrar Account</div>
                      <div className="font-bold text-white mt-1">
                        {selectedDomain.registrarAccount || 'Reseller Account #01'}
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Provider Domain ID</div>
                      <div className="font-mono font-bold text-slate-300 mt-1">
                        {selectedDomain.providerDomainId || 'RC-DOM-772910'}
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
                      <div className="text-[10px] text-slate-400 font-bold uppercase">Last Synchronization</div>
                      <div className="font-mono font-bold text-emerald-400 mt-1">
                        {selectedDomain.lastSyncDate || '2026-08-19 14:20 UTC'}
                      </div>
                    </div>
                  </div>

                  {/* EPP / Transfer Authorization Key (Admin Only) */}
                  <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                        <Key className="w-3.5 h-3.5" /> Transfer Authorization (EPP) Code
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">Strictly Internal Access</span>
                    </div>

                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs">
                      {showAuthCodeAdmin ? (
                        <span className="text-amber-300 font-bold tracking-wider">{selectedDomain.authCode}</span>
                      ) : (
                        <span className="text-slate-500 font-bold">••••••••••••••••••••••••</span>
                      )}

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setShowAuthCodeAdmin(!showAuthCodeAdmin)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-slate-300"
                        >
                          {showAuthCodeAdmin ? 'Hide' : 'Reveal'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(selectedDomain.authCode);
                            alert('EPP Code copied to clipboard.');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-slate-300 flex items-center gap-1"
                        >
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Nameserver Technical Audit */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="text-xs font-bold text-slate-300 flex items-center justify-between">
                      <span>Authoritative Delegation Audit</span>
                      <span className="text-[10px] font-mono text-slate-400">
                        Updated By: {selectedDomain.nameserverUpdatedBy || 'System'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                      {selectedDomain.nameservers.map((ns, idx) => (
                        <div key={idx} className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-2">
                          <span className="text-amber-400 font-bold">NS{idx + 1}:</span>
                          <span className="text-slate-200">{ns}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Diagnostic Action Bar */}
                  <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => alert(`Provisioning verified with ${selectedDomain.registrarProvider || 'Registrar'}. Status is Active.`)}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 flex items-center gap-1.5"
                    >
                      <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Retry Provisioning Hook</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => alert('Domain reassignment modal opened in staff admin.')}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 flex items-center gap-1.5"
                    >
                      <UserCheck className="w-3.5 h-3.5 text-blue-400" />
                      <span>Move to Another Customer</span>
                    </button>
                  </div>

                </div>

              </div>
            )}

          </div>

        </div>
      )}

      {/* MODAL 1: PAYSTACK RENEWAL CHECKOUT */}
      {showRenewModal && selectedDomain && (
        <PaystackCheckoutModal
          amount={renPrice}
          currency={curr}
          customerEmail={selectedDomain.customerEmail || 'customer@celoxaghana.online'}
          customerName={selectedDomain.customerName || 'Valued Customer'}
          paystackConfig={paystackConfig}
          orderId={`REN-${selectedDomain.id.slice(-4)}-${Date.now().toString().slice(-4)}`}
          purpose="order"
          description={`Domain 1-Year Renewal: ${selectedDomain.domain}`}
          onSuccess={(ref) => {
            setShowRenewModal(false);
            setDomains((prev) =>
              prev.map((d) => {
                if (d.id === selectedDomain.id) {
                  const currentYear = parseInt(d.expiryDate.split('-')[0]) || 2027;
                  const newExpiry = d.expiryDate.replace(String(currentYear), String(currentYear + 1));
                  const newActivity = [
                    ...(d.activityTimeline || []),
                    {
                      id: `act-${Date.now()}`,
                      title: 'Domain Renewed (1 Year)',
                      description: `Renewed successfully via Paystack (Ref: ${ref}). Next expiry: ${newExpiry}.`,
                      date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
                      type: 'renewal' as const
                    }
                  ];
                  return { ...d, expiryDate: newExpiry, status: 'active', activityTimeline: newActivity };
                }
                return d;
              })
            );
            setSaveFeedback(`Domain ${selectedDomain.domain} renewed successfully for 1 year!`);
          }}
          onClose={() => setShowRenewModal(false)}
        />
      )}

      {/* MODAL 2: DOMAIN CONTACT DETAILS */}
      {showContactModal && selectedDomain && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-slate-900 to-slate-950 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="font-black text-base">Registrant Contact Information</h3>
              </div>
              <button onClick={() => setShowContactModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveContactInfo} className="p-6 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Registrant Full Name</label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Phone Number</label>
                  <input
                    type="text"
                    required
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Country</label>
                  <input
                    type="text"
                    required
                    value={contactCountry}
                    onChange={(e) => setContactCountry(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Organization / Business</label>
                <input
                  type="text"
                  value={contactOrg}
                  onChange={(e) => setContactOrg(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-800 dark:text-emerald-300 font-medium flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                <span>WHOIS Privacy is Active. Contact details are masked from public registries.</span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowContactModal(false)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow"
                >
                  Save Contact Information
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: INVOICE DETAILS */}
      {showInvoiceModal && selectedDomain && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-purple-900 to-slate-950 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-purple-400" />
                <h3 className="font-black text-base">Invoice #{selectedDomain.invoiceId || 'INV-10482'}</h3>
              </div>
              <button onClick={() => setShowInvoiceModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 space-y-2">
                <div className="flex justify-between font-medium">
                  <span className="text-slate-500">Service:</span>
                  <span className="font-bold text-slate-900 dark:text-white">{selectedDomain.domain} Registration</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span className="text-slate-500">Order ID:</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">#{selectedDomain.orderId || 'ORD-10482'}</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span className="text-slate-500">Date:</span>
                  <span className="text-slate-900 dark:text-white">{selectedDomain.registeredDate}</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span className="text-slate-500">Status:</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">
                    PAID IN FULL
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex justify-between items-baseline">
                <span className="font-bold text-emerald-900 dark:text-emerald-300">Total Charged:</span>
                <span className="font-mono font-black text-base text-emerald-800 dark:text-emerald-200">
                  {formatCurrencyAmount(regPrice, curr)}
                </span>
              </div>

              <button
                type="button"
                onClick={() => setShowInvoiceModal(false)}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl"
              >
                Close Invoice
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
