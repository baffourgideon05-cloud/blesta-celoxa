import React, { useState, useEffect } from 'react';
import { X, Shield, Globe, Clock, Server, CheckCircle2, AlertCircle, Bell, Mail, Copy, Check, Activity, Lock, Database, Award, ExternalLink, ShieldCheck, ShieldAlert } from 'lucide-react';
import { WhoisData, DomainDetailedStatus } from '../types';
import { systemDatabase } from '../services/systemDatabase';
import { DomainStatusTimeline } from './DomainStatusTimeline';

interface WhoisModalProps {
  domainName: string;
  onClose: () => void;
  onManageDomain?: (domainName: string) => void;
}

export const WhoisModal: React.FC<WhoisModalProps> = ({ domainName, onClose, onManageDomain }) => {
  const [loading, setLoading] = useState(true);
  const [whois, setWhois] = useState<WhoisData | null>(null);
  const [activeTab, setActiveTab] = useState<'structured' | 'timeline' | 'dns' | 'raw'>('structured');
  const [copied, setCopied] = useState(false);
  const [alertEmail, setAlertEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    fetch(`/api/whois/${encodeURIComponent(domainName)}`)
      .then((res) => res.json())
      .then((data) => {
        if (isMounted) {
          const rawWhois = data.whois || {};
          const evalStatus = systemDatabase.evaluateDomainStatus(domainName, undefined, {
            isAvailable: rawWhois.isAvailable,
            isBrandRegistered: rawWhois.isBrandRegistered,
            registrar: rawWhois.registrar,
            status: rawWhois.status,
            creationDate: rawWhois.creationDate,
            expirationDate: rawWhois.expirationDate,
          });

          // Enrich WHOIS with internal authoritative database & privacy protection
          const enriched: WhoisData = {
            ...rawWhois,
            detailedStatus: evalStatus.detailedStatus,
            isOwnedByCurrentUser: evalStatus.isOwnedByYou,
            isBrandRegistered: evalStatus.isOwnedByPlatformCustomer || rawWhois.isBrandRegistered,
            // Mask registrant details if owned by someone else on our platform
            registrantOrganization: evalStatus.isOwnedByYou
              ? (evalStatus.ownership?.ownerName || rawWhois.registrantOrganization || 'Your Account')
              : evalStatus.isOwnedByPlatformCustomer
              ? 'ApexDomain Privacy Protection / Celoxa Registry'
              : rawWhois.registrantOrganization,
            brandAccountEmail: evalStatus.isOwnedByYou ? evalStatus.ownership?.ownerEmail : undefined, // Privacy protected!
          };

          setWhois(enriched);
          setLoading(false);
        }
      })
      .catch(() => {
        if (isMounted) {
          const evalStatus = systemDatabase.evaluateDomainStatus(domainName, undefined, { unableToVerify: true });
          setWhois({
            domainName: domainName.toLowerCase(),
            isAvailable: evalStatus.detailedStatus === 'available',
            detailedStatus: evalStatus.detailedStatus,
            isOwnedByCurrentUser: evalStatus.isOwnedByYou,
            status: evalStatus.statusMessage,
            registrar: 'ApexDomain Verification Engine',
            creationDate: evalStatus.creationDate || 'N/A',
            expirationDate: evalStatus.expiryDate || 'N/A',
            updatedDate: 'N/A',
            nameServers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
            dnssec: 'unsigned',
            registrantOrganization: 'Registry Lookup Timeout',
            registrantCountry: 'Global',
            rawWhoisText: 'Unable to establish authoritative connection with remote registry.'
          });
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [domainName]);

  const handleCopyRaw = () => {
    if (whois?.rawWhoisText) {
      navigator.clipboard.writeText(whois.rawWhoisText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (alertEmail) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setAlertEmail('');
    }
  };

  return (
    <div id="whois-modal-backdrop" className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in">
      <div id="whois-modal-card" className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 dark:text-white">Authoritative WHOIS & RDAP</h2>
                {whois?.isBrandRegistered && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-blue-600 text-white shadow-sm">
                    <Award className="w-3 h-3" /> Brand Registered
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">{domainName}</p>
            </div>
          </div>

          <button
            id="btn-close-whois-modal"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 pt-3 border-b border-slate-200 dark:border-slate-800 flex items-center gap-4 bg-white dark:bg-slate-900 overflow-x-auto">
          <button
            id="tab-whois-structured"
            onClick={() => setActiveTab('structured')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'structured'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Structured Registry Record
          </button>
          <button
            id="tab-whois-timeline"
            onClick={() => setActiveTab('timeline')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'timeline'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Lifecycle Timeline
          </button>
          <button
            id="tab-whois-dns"
            onClick={() => setActiveTab('dns')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'dns'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Live DNS & Server Probe
          </button>
          <button
            id="tab-whois-raw"
            onClick={() => setActiveTab('raw')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'raw'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Raw Verbatim Payload
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {loading ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-9 h-9 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-sm text-slate-700 dark:text-slate-300 font-bold">Querying Global Root Nameservers & RDAP...</p>
              <p className="text-xs text-slate-500">Inspecting ICANN registry records, in-house brand inventory, and live DNS zone.</p>
            </div>
          ) : whois ? (
            activeTab === 'structured' ? (
              <div className="space-y-6">
                
                {/* Brand Registration Highlight Card */}
                {whois.isBrandRegistered && (
                  <div className="p-4 rounded-xl bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-slate-900/40 border border-blue-500/30 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Award className="w-5 h-5 text-blue-400" />
                        <span className="text-sm font-extrabold text-white">In-House Brand Managed Domain</span>
                      </div>
                      <span className="px-2 py-0.5 text-[10px] font-bold rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/40">
                        ApexRegistrar IANA 9942
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      This domain is actively registered and securely managed under the <strong>ApexDomain / Celoxa Technology Group</strong> multi-tier infrastructure.
                    </p>
                    {whois.brandAccountEmail && (
                      <div className="text-[11px] text-blue-200 font-mono flex items-center gap-1.5 pt-1">
                        <Shield className="w-3.5 h-3.5 text-blue-400" />
                        Registered Account: <strong>{whois.brandAccountEmail}</strong>
                      </div>
                    )}
                  </div>
                )}

                {/* Primary Status Banner */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${
                  whois.isAvailable
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                }`}>
                  <div className="flex items-center gap-3">
                    {whois.isAvailable ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <AlertCircle className="w-6 h-6 text-amber-600 dark:text-amber-400 shrink-0" />
                    )}
                    <div>
                      <div className="font-black text-base">{whois.domainName}</div>
                      <div className="text-xs font-semibold opacity-90">{whois.status}</div>
                    </div>
                  </div>

                  <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm">
                    {whois.authoritativeSource || 'LIVE_RDAP_DNS'}
                  </span>
                </div>

                {/* Grid Properties */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium flex items-center gap-1">
                      <Shield className="w-3.5 h-3.5" /> Registrar Organization:
                    </span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.registrar}</div>
                    {whois.registrarIanaId && (
                      <div className="text-[10px] text-slate-400 font-mono">IANA ID: {whois.registrarIanaId}</div>
                    )}
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium flex items-center gap-1">
                      <Globe className="w-3.5 h-3.5" /> Registrant Entity / Country:
                    </span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.registrantOrganization}</div>
                    <div className="text-[10px] text-slate-400">Country: {whois.registrantCountry || 'Global'}</div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" /> Creation Date:
                    </span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.creationDate}</div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5" /> Registry Expiration Date:
                    </span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.expirationDate}</div>
                  </div>
                </div>

                {/* Name Servers */}
                {whois.nameServers && whois.nameServers.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5" /> Authoritative Name Servers ({whois.nameServers.length})
                    </h4>
                    <div className="bg-slate-900 text-slate-200 rounded-xl p-3 font-mono text-xs space-y-1.5 border border-slate-800">
                      {whois.nameServers.map((ns, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <span className="text-blue-400 font-bold">NS{idx + 1}:</span>
                          <span className="text-slate-200">{ns}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Backorder / Drop Alert Form */}
                {!whois.isAvailable && (
                  <div className="p-4 rounded-xl bg-gradient-to-r from-blue-900/30 to-indigo-900/30 border border-blue-500/20 space-y-3">
                    <div className="flex items-center gap-2 text-blue-300 font-bold text-xs">
                      <Bell className="w-4 h-4 text-blue-400" />
                      <span>Get Notified on Expiration or Status Change</span>
                    </div>
                    <form onSubmit={handleSubscribe} className="flex gap-2">
                      <input
                        type="email"
                        required
                        value={alertEmail}
                        onChange={(e) => setAlertEmail(e.target.value)}
                        placeholder="Enter your email address..."
                        className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white border border-slate-300 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg transition-colors shrink-0"
                      >
                        Subscribe
                      </button>
                    </form>
                    {subscribed && (
                      <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Alert active! We will email you when {domainName} status updates.
                      </div>
                    )}
                  </div>
                )}

              </div>
            ) : activeTab === 'timeline' ? (
              <div className="space-y-4">
                <DomainStatusTimeline
                  domain={domainName}
                  detailedStatus={whois.detailedStatus}
                  creationDate={whois.creationDate}
                  expiryDate={whois.expirationDate}
                  registrar={whois.registrar}
                  isOwnedByYou={whois.isOwnedByCurrentUser}
                  onManageDomain={onManageDomain ? () => { onClose(); onManageDomain(domainName); } : undefined}
                />
              </div>
            ) : activeTab === 'dns' ? (
              <div className="space-y-6">
                
                {/* Web Probe Status */}
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-blue-500" /> Live Web Server Probe & Connectivity
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px]">Web Status</span>
                      <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 mt-0.5">
                        <span className={`w-2 h-2 rounded-full ${whois.httpStatus?.isOnline ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                        {whois.httpStatus?.isOnline ? `Online (${whois.httpStatus.statusCode || 200})` : 'Offline / Inactive'}
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px]">Server Engine</span>
                      <div className="font-bold text-slate-800 dark:text-slate-200 truncate mt-0.5">
                        {whois.httpStatus?.serverHeader || 'Apex Anycast Node'}
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px]">Protocol / SSL</span>
                      <div className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                        {whois.httpStatus?.protocol || 'HTTPS (TLS 1.3)'}
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px]">Primary IPv4</span>
                      <div className="font-bold text-slate-800 dark:text-slate-200 font-mono text-[11px] truncate mt-0.5">
                        {whois.httpStatus?.ipAddress || whois.dnsRecords?.find((r) => r.type === 'A')?.value || 'N/A'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* DNS Zone Records Table */}
                <div className="space-y-2">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5 text-indigo-500" /> Active DNS Zone Records
                  </h4>

                  {whois.dnsRecords && whois.dnsRecords.length > 0 ? (
                    <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
                          <tr>
                            <th className="px-3 py-2.5">Type</th>
                            <th className="px-3 py-2.5">Host / Name</th>
                            <th className="px-3 py-2.5">Value / Target</th>
                            <th className="px-3 py-2.5">TTL</th>
                            <th className="px-3 py-2.5">Priority</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-mono text-[11px] bg-white dark:bg-slate-900">
                          {whois.dnsRecords.map((rec, i) => (
                            <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                              <td className="px-3 py-2">
                                <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                                  rec.type === 'A' ? 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300' :
                                  rec.type === 'CNAME' ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' :
                                  rec.type === 'MX' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' :
                                  rec.type === 'TXT' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' :
                                  'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                                }`}>
                                  {rec.type}
                                </span>
                              </td>
                              <td className="px-3 py-2 text-slate-700 dark:text-slate-300">{rec.name}</td>
                              <td className="px-3 py-2 text-slate-900 dark:text-white font-semibold max-w-xs truncate">{rec.value}</td>
                              <td className="px-3 py-2 text-slate-500">{rec.ttl || 3600}s</td>
                              <td className="px-3 py-2 text-slate-500">{rec.priority !== undefined ? rec.priority : '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="p-6 text-center rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 text-xs text-slate-500">
                      No live DNS zone records delegated for this domain name.
                    </div>
                  )}
                </div>

              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">Verbatim Authoritative RDAP / WHOIS Payload</span>
                  <button
                    id="btn-copy-whois-raw"
                    onClick={handleCopyRaw}
                    className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'Copied' : 'Copy Payload'}
                  </button>
                </div>
                <pre className="bg-slate-950 text-emerald-400 p-4 rounded-xl font-mono text-xs overflow-x-auto whitespace-pre-wrap max-h-80 leading-relaxed border border-slate-800">
                  {whois.rawWhoisText}
                </pre>
              </div>
            )
          ) : null}
        </div>

      </div>
    </div>
  );
};

