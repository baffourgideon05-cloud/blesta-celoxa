import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  DollarSign, 
  User, 
  CreditCard, 
  ExternalLink, 
  ShieldCheck, 
  Clock,
  Sparkles
} from 'lucide-react';
import { CommerceInvoice } from '../services/commerceEngine';
import { commerceEngine } from '../services/commerceEngine';
import { systemDatabase } from '../services/systemDatabase';

interface AdminCustomPaymentReviewModalProps {
  invoice: CommerceInvoice | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const AdminCustomPaymentReviewModal: React.FC<AdminCustomPaymentReviewModalProps> = ({
  invoice,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [paymentMethod, setPaymentMethod] = useState('MTN Mobile Money Direct (Ghana)');
  const [transactionRef, setTransactionRef] = useState(`TX-MOMO-${Math.floor(100000 + Math.random() * 900000)}`);
  const [adminNotes, setAdminNotes] = useState('Verified transaction in merchant account');
  const [isProcessing, setIsProcessing] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  if (!isOpen || !invoice) return null;

  const currentUser = systemDatabase.getCurrentUser();

  const handleApprove = async () => {
    setIsProcessing(true);
    try {
      const res = commerceEngine.markInvoiceAsPaid(
        invoice.id,
        currentUser.fullName || 'Gideon Baffour (Admin)',
        paymentMethod
      );

      if (res.success) {
        setActionSuccess('Invoice approved! Automated WHM & registrar provisioning queue started.');
        if (onSuccess) onSuccess();
        setTimeout(() => {
          onClose();
          setActionSuccess(null);
        }, 1800);
      } else {
        alert(res.error || 'Failed to approve invoice');
      }
    } catch (e: any) {
      alert(e?.message || 'Approval error');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-emerald-950/40 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white">Review Custom / Manual Payment</h2>
              <p className="text-xs text-slate-400 font-mono">Invoice #{invoice.invoiceNumber}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {actionSuccess ? (
            <div className="p-6 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-white">Payment Verified & Approved!</h3>
              <p className="text-xs text-slate-300">{actionSuccess}</p>
            </div>
          ) : (
            <>
              {/* Invoice Summary Card */}
              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2 text-xs">
                <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Customer:</span>
                  <strong className="text-white">{invoice.customerName} ({invoice.customerEmail})</strong>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Amount Due:</span>
                  <span className="text-base font-black text-emerald-400">
                    {invoice.currency === 'GHS' ? 'GH₵' : '$'} {invoice.total.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Services in Order:</span>
                  <span className="text-slate-300 font-medium">
                    {invoice.items.map((i) => i.name).join(', ')}
                  </span>
                </div>
              </div>

              {/* Approval Details */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Confirmed Payment Channel</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
                  >
                    <option value="MTN Mobile Money Direct (Ghana)">MTN Mobile Money Direct (Ghana)</option>
                    <option value="Telecel Cash (Vodafone MoMo)">Telecel Cash (Vodafone MoMo)</option>
                    <option value="AT Money (AirtelTigo)">AT Money (AirtelTigo)</option>
                    <option value="Direct Bank Wire / Ecobank Deposit">Direct Bank Wire / Ecobank Deposit</option>
                    <option value="Cash / POS In-Person Deposit">Cash / POS In-Person Deposit</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Transaction Ref / MoMo ID</label>
                  <input
                    type="text"
                    value={transactionRef}
                    onChange={(e) => setTransactionRef(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Audit Verification Notes</label>
                  <input
                    type="text"
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Informational banner */}
              <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-[11px] text-indigo-300 flex items-start gap-2">
                <Sparkles className="w-4 h-4 shrink-0 text-indigo-400 mt-0.5" />
                <span>
                  Approving this invoice will immediately trigger automated cPanel account creation, registrar API delegation, and dispatch the official <strong>Invoice Marked as Paid</strong> branded email to <strong>{invoice.customerEmail}</strong>.
                </span>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleApprove}
                  disabled={isProcessing}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-600/30 flex items-center gap-2 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <span>Approving & Provisioning...</span>
                  ) : (
                    <span>✓ Approve & Mark as Paid</span>
                  )}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
