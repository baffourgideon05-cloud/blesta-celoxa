import React, { useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  ShoppingCart, 
  Heart, 
  ArrowRightLeft, 
  Share2, 
  Copy, 
  Info, 
  Clock, 
  ShieldCheck, 
  ExternalLink,
  Check,
  Zap,
  Lock,
  AlertCircle,
  HelpCircle,
  ShieldAlert,
  Globe,
  Activity,
  ChevronDown,
  ChevronUp,
  Settings
} from 'lucide-react';
import { DomainResult, ViewMode, Currency, DomainDetailedStatus } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';
import { DomainStatusTimeline } from './DomainStatusTimeline';

interface DomainCardProps {
  domain: DomainResult;
  viewMode: ViewMode;
  currency: Currency;
  isInCart: boolean;
  isWishlisted: boolean;
  isCompared: boolean;
  onAddToCart: (domain: DomainResult) => void;
  onCheckoutNow?: (domain: DomainResult) => void;
  onToggleWishlist: (domain: DomainResult) => void;
  onToggleCompare: (domain: DomainResult) => void;
  onOpenWhois: (domainName: string) => void;
  onOpenAppraise?: (domainName: string) => void;
  onManageDomain?: (domainName: string) => void;
}

export const DomainCard: React.FC<DomainCardProps> = ({
  domain,
  viewMode,
  currency,
  isInCart,
  isWishlisted,
  isCompared,
  onAddToCart,
  onCheckoutNow,
  onToggleWishlist,
  onToggleCompare,
  onOpenWhois,
  onOpenAppraise,
  onManageDomain,
}) => {
  const [copied, setCopied] = useState(false);
  const [showTimeline, setShowTimeline] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(domain.domain);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `Domain Status: ${domain.domain}`,
        text: `Check out domain status for ${domain.domain} on ApexDomain!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      handleCopy();
    }
  };

  // Status flags
  const status: DomainDetailedStatus = domain.detailedStatus || (
    domain.isOwnedByCurrentUser ? 'owned_by_you' :
    domain.isBrandRegistered ? 'owned_by_platform_customer' :
    domain.isAvailable ? (domain.isPremium ? 'premium' : 'available') :
    'external_registered'
  );

  const isOwnedByYou = status === 'owned_by_you' || !!domain.isOwnedByCurrentUser;
  const isPlatformOwned = status === 'owned_by_platform_customer';
  const isExternal = status === 'external_registered';
  const isPending = status === 'registration_pending';
  const isPremium = status === 'premium' || !!domain.isPremium;
  const isReserved = status === 'reserved';
  const isUnable = status === 'unable_to_verify';
  const isAvailable = (status === 'available' || status === 'premium') && !isOwnedByYou && !isPlatformOwned && !isExternal && !isPending && !isReserved && !isUnable;

  // Render Status Badge
  const renderStatusBadge = (compact = false) => {
    if (isOwnedByYou) {
      return (
        <span className={`inline-flex items-center gap-1 font-black bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-200 border border-blue-300 dark:border-blue-800 rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
          <ShieldCheck className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
          <span>You Own This Domain</span>
        </span>
      );
    }
    if (isPlatformOwned) {
      return (
        <span className={`inline-flex items-center gap-1 font-bold bg-slate-800 text-slate-100 dark:bg-slate-800 dark:text-slate-200 border border-slate-700 rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
          <Lock className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
          <span>Registered (In-House)</span>
        </span>
      );
    }
    if (isExternal) {
      return (
        <span className={`inline-flex items-center gap-1 font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
          <Globe className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
          <span>Registered</span>
        </span>
      );
    }
    if (isPending) {
      return (
        <span className={`inline-flex items-center gap-1 font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 animate-pulse rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
          <Clock className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
          <span>Processing</span>
        </span>
      );
    }
    if (isReserved) {
      return (
        <span className={`inline-flex items-center gap-1 font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
          <ShieldAlert className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
          <span>Reserved</span>
        </span>
      );
    }
    if (isUnable) {
      return (
        <span className={`inline-flex items-center gap-1 font-bold bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300 rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
          <AlertCircle className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
          <span>Unable to Verify</span>
        </span>
      );
    }
    if (isPremium) {
      return (
        <span className={`inline-flex items-center gap-1 font-extrabold bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 border border-amber-300 dark:border-amber-800 rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
          <Sparkles className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
          <span>★ Premium Available</span>
        </span>
      );
    }
    return (
      <span className={`inline-flex items-center gap-1 font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60 rounded-full ${compact ? 'px-1.5 py-0.5 text-[9px]' : 'px-2.5 py-1 text-xs'}`}>
        <CheckCircle2 className={compact ? "w-2.5 h-2.5" : "w-3.5 h-3.5"} />
        <span>Available</span>
      </span>
    );
  };

  // Render Table Row View
  if (viewMode === 'table') {
    return (
      <>
        <tr className="border-b border-slate-200 dark:border-slate-800 hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors">
          <td className="py-3 px-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-extrabold text-sm text-slate-900 dark:text-white">{domain.domain}</span>
              {renderStatusBadge(true)}
            </div>
          </td>
          <td className="py-3 px-4">
            <button
              onClick={() => setShowTimeline(!showTimeline)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
            >
              <Activity className="w-3 h-3" />
              <span>{showTimeline ? 'Hide Timeline' : 'View Timeline'}</span>
            </button>
          </td>
          <td className="py-3 px-4">
            <div className="text-sm font-extrabold text-slate-900 dark:text-white">
              {formatPrice(domain.registrationPrice, currency)}
              <span className="text-[10px] text-slate-500 font-normal"> /1st yr</span>
            </div>
            <div className="text-[11px] text-slate-400 font-medium">
              Renews: {formatPrice(domain.renewalPrice, currency)}
            </div>
          </td>
          <td className="py-3 px-4 text-xs text-slate-500 font-medium hidden md:table-cell">
            {domain.timeEstimate}
          </td>
          <td className="py-3 px-4 text-right">
            <div className="flex items-center justify-end gap-1.5">
              <button
                onClick={() => onToggleWishlist(domain)}
                className={`p-1.5 rounded-lg border text-xs transition-colors ${
                  isWishlisted 
                    ? 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-rose-900/30 dark:border-rose-800 dark:text-rose-400' 
                    : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-500'
                }`}
                title="Add to Wishlist"
              >
                <Heart className="w-3.5 h-3.5 fill-current" />
              </button>

              <button
                onClick={() => onOpenWhois(domain.domain)}
                className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-semibold text-slate-600 dark:text-slate-300 transition-colors"
              >
                Domain Info
              </button>

              {isOwnedByYou ? (
                <button
                  onClick={() => onManageDomain ? onManageDomain(domain.domain) : onOpenWhois(domain.domain)}
                  className="px-3 py-1.5 rounded-lg text-xs font-black bg-blue-600 hover:bg-blue-700 text-white shadow-sm flex items-center gap-1"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Manage</span>
                </button>
              ) : isAvailable ? (
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => onAddToCart(domain)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                      isInCart
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {isInCart ? <Check className="w-3.5 h-3.5" /> : <ShoppingCart className="w-3.5 h-3.5" />}
                    {isInCart ? 'In Cart' : 'Cart'}
                  </button>

                  {onCheckoutNow && (
                    <button
                      onClick={() => onCheckoutNow(domain)}
                      className="px-3 py-1.5 rounded-lg text-xs font-black bg-blue-600 hover:bg-blue-700 text-white shadow-sm flex items-center gap-1"
                    >
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      <span>Buy</span>
                    </button>
                  )}
                </div>
              ) : isUnable ? (
                <button
                  onClick={() => onOpenWhois(domain.domain)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-orange-100 dark:bg-orange-950/60 text-orange-800 dark:text-orange-200"
                >
                  Retry Probe
                </button>
              ) : (
                <button
                  onClick={() => onOpenWhois(domain.domain)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                >
                  Backorder
                </button>
              )}
            </div>
          </td>
        </tr>
        {showTimeline && (
          <tr className="bg-slate-50/50 dark:bg-slate-900/50">
            <td colSpan={5} className="p-4">
              <DomainStatusTimeline
                domain={domain.domain}
                detailedStatus={status}
                creationDate={domain.creationDate}
                expiryDate={domain.expiryDate}
                registrar={domain.realRegistrarName || domain.brandRegistrar}
                isOwnedByYou={isOwnedByYou}
                onManageDomain={onManageDomain}
                onAddToCart={isAvailable ? () => onAddToCart(domain) : undefined}
              />
            </td>
          </tr>
        )}
      </>
    );
  }

  // Render Compact Mode
  if (viewMode === 'compact') {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-col gap-2 hover:border-blue-500/50 transition-all shadow-sm">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="truncate">
              <div className="flex items-center gap-1.5 truncate">
                <span className="font-extrabold text-sm text-slate-900 dark:text-white truncate block">
                  {domain.domain}
                </span>
                {renderStatusBadge(true)}
              </div>
              <span className="text-[10px] text-slate-400">
                Renews {formatPrice(domain.renewalPrice, currency)} • ICANN ${domain.icannFee}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="font-extrabold text-sm text-slate-900 dark:text-white">
              {formatPrice(domain.registrationPrice, currency)}
            </span>
            {isOwnedByYou ? (
              <button
                onClick={() => onManageDomain ? onManageDomain(domain.domain) : onOpenWhois(domain.domain)}
                className="px-2.5 py-1 rounded-lg text-xs font-black bg-blue-600 text-white flex items-center gap-1 shadow-sm"
              >
                <Settings className="w-3 h-3" />
                <span>Manage</span>
              </button>
            ) : isAvailable ? (
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onAddToCart(domain)}
                  className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                    isInCart ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700'
                  }`}
                >
                  {isInCart ? 'In Cart' : 'Cart'}
                </button>
                {onCheckoutNow && (
                  <button
                    onClick={() => onCheckoutNow(domain)}
                    className="px-2.5 py-1 rounded-lg text-xs font-black bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1 shadow-sm"
                  >
                    <Zap className="w-3 h-3 fill-current" />
                    <span>Buy</span>
                  </button>
                )}
              </div>
            ) : (
              <button
                onClick={() => onOpenWhois(domain.domain)}
                className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
              >
                Info
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Render List View
  if (viewMode === 'list') {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col gap-4 hover:border-blue-500/50 transition-all shadow-sm hover:shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          {/* Main Information */}
          <div className="space-y-1.5 max-w-xl">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-lg font-black tracking-tight text-slate-900 dark:text-white">
                {domain.domain}
              </h3>
              {renderStatusBadge()}
              <span className="px-2 py-0.5 text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-md">
                {domain.category}
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 font-normal">
              {domain.statusMessage || (
                isOwnedByYou 
                  ? 'Managed in your ApexDomain Account • Full DNS and Nameserver Control Included' 
                  : isPlatformOwned 
                  ? 'Registered with ApexDomain / Celoxa Anycast Cluster' 
                  : `${domain.description} • Free Domain Privacy Included`
              )}
            </p>

            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-medium pt-1">
              <span>Renewal: <strong className="text-slate-700 dark:text-slate-200">{formatPrice(domain.renewalPrice, currency)}/yr</strong></span>
              <span>•</span>
              <span>Transfer: <strong className="text-slate-700 dark:text-slate-200">{formatPrice(domain.transferPrice, currency)}</strong></span>
              <span>•</span>
              <button
                onClick={() => setShowTimeline(!showTimeline)}
                className="inline-flex items-center gap-1 font-bold text-blue-600 dark:text-blue-400 hover:underline"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>{showTimeline ? 'Close Timeline' : 'Lifecycle Timeline'}</span>
                {showTimeline ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            </div>
          </div>

          {/* Price & Action Cluster */}
          <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 border-slate-100 dark:border-slate-800 pt-3 sm:pt-0">
            <div className="text-right">
              <div className="text-xl font-black text-slate-900 dark:text-white">
                {formatPrice(domain.registrationPrice, currency)}
              </div>
              <div className="text-[11px] font-medium text-slate-400">1st Year Registration</div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onToggleWishlist(domain)}
                className={`p-2 rounded-xl border text-slate-400 hover:text-rose-500 transition-colors ${
                  isWishlisted ? 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-rose-900/30' : 'border-slate-200 dark:border-slate-700'
                }`}
                title="Wishlist"
              >
                <Heart className="w-4 h-4 fill-current" />
              </button>

              <button
                onClick={() => onOpenWhois(domain.domain)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
              >
                Domain Info
              </button>

              {isOwnedByYou ? (
                <button
                  onClick={() => onManageDomain ? onManageDomain(domain.domain) : onOpenWhois(domain.domain)}
                  className="px-4 py-2 rounded-xl text-xs font-black bg-blue-600 hover:bg-blue-700 text-white shadow-md flex items-center gap-1.5"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Manage Domain</span>
                </button>
              ) : isAvailable ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onAddToCart(domain)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                      isInCart
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {isInCart ? <Check className="w-3.5 h-3.5" /> : <ShoppingCart className="w-3.5 h-3.5" />}
                    {isInCart ? 'In Cart' : 'Add to Cart'}
                  </button>

                  {onCheckoutNow && (
                    <button
                      onClick={() => onCheckoutNow(domain)}
                      className="px-4 py-2 rounded-xl text-xs font-black bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 flex items-center gap-1.5 transition-all hover:scale-105"
                    >
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      <span>Checkout Now</span>
                    </button>
                  )}
                </div>
              ) : isUnable ? (
                <button
                  onClick={() => onOpenWhois(domain.domain)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-orange-100 hover:bg-orange-200 text-orange-800 dark:bg-orange-950 dark:text-orange-200"
                >
                  Probe Status
                </button>
              ) : (
                <button
                  onClick={() => onOpenWhois(domain.domain)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
                >
                  Backorder
                </button>
              )}
            </div>
          </div>
        </div>

        {showTimeline && (
          <DomainStatusTimeline
            domain={domain.domain}
            detailedStatus={status}
            creationDate={domain.creationDate}
            expiryDate={domain.expiryDate}
            registrar={domain.realRegistrarName || domain.brandRegistrar}
            isOwnedByYou={isOwnedByYou}
            onManageDomain={onManageDomain}
            onAddToCart={isAvailable ? () => onAddToCart(domain) : undefined}
          />
        )}
      </div>
    );
  }

  // Default Standard Card View (Grid)
  return (
    <div className={`bg-white dark:bg-slate-900 border rounded-2xl p-5 flex flex-col justify-between transition-all shadow-sm hover:shadow-xl relative group ${
      isOwnedByYou ? 'border-blue-300 dark:border-blue-800 ring-1 ring-blue-500/20' : 'border-slate-200 dark:border-slate-800 hover:border-blue-500/50'
    }`}>
      
      {/* Top Card Bar */}
      <div>
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            {renderStatusBadge()}
          </div>

          {/* Top Quick Tools */}
          <div className="flex items-center gap-1">
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title={copied ? "Copied!" : "Copy Domain"}
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() => onToggleWishlist(domain)}
              className={`p-1.5 rounded-lg transition-colors ${
                isWishlisted 
                  ? 'text-rose-500 fill-current' 
                  : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Add to Wishlist"
            >
              <Heart className="w-3.5 h-3.5 fill-current" />
            </button>

            <button
              onClick={() => onToggleCompare(domain)}
              className={`p-1.5 rounded-lg transition-colors ${
                isCompared 
                  ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30' 
                  : 'text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Compare Side-by-Side"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Domain Name */}
        <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors truncate">
          {domain.domain}
        </h3>

        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-3 font-normal">
          {domain.statusMessage || (isOwnedByYou ? 'Managed securely under your account' : domain.description)}
        </p>

        {/* Specs Pill List */}
        <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-2.5 space-y-1.5 text-xs text-slate-600 dark:text-slate-300 font-medium mb-3 border border-slate-100 dark:border-slate-800">
          <div className="flex justify-between">
            <span className="text-slate-400 font-normal">Renewal Cost:</span>
            <span className="font-semibold">{formatPrice(domain.renewalPrice, currency)} / yr</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400 font-normal">Lifecycle State:</span>
            <span className="font-semibold capitalize text-slate-700 dark:text-slate-200">
              {domain.timelineStep || (isOwnedByYou ? 'Active' : isAvailable ? 'Available' : 'Registered')}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400 font-normal">ID Protection:</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Included Free
            </span>
          </div>
        </div>

        {/* Expand Timeline Button */}
        <button
          onClick={() => setShowTimeline(!showTimeline)}
          className="w-full mb-3 py-1.5 px-2 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 bg-slate-100/70 dark:bg-slate-800/60 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors flex items-center justify-center gap-1.5"
        >
          <Activity className="w-3.5 h-3.5 text-blue-500" />
          <span>{showTimeline ? 'Hide Lifecycle Timeline' : 'View Lifecycle Timeline'}</span>
          {showTimeline ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>

        {showTimeline && (
          <div className="mb-4">
            <DomainStatusTimeline
              domain={domain.domain}
              detailedStatus={status}
              creationDate={domain.creationDate}
              expiryDate={domain.expiryDate}
              registrar={domain.realRegistrarName || domain.brandRegistrar}
              isOwnedByYou={isOwnedByYou}
              onManageDomain={onManageDomain}
              onAddToCart={isAvailable ? () => onAddToCart(domain) : undefined}
            />
          </div>
        )}
      </div>

      {/* Card Footer Price & Buy */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
        <div>
          <span className="text-2xl font-black text-slate-900 dark:text-white">
            {formatPrice(domain.registrationPrice, currency)}
          </span>
          <span className="text-[10px] text-slate-400 font-medium block -mt-1">
            +${domain.icannFee} ICANN Fee
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onOpenWhois(domain.domain)}
            className="px-2 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
            title="View Domain Info"
          >
            Info
          </button>

          {isOwnedByYou ? (
            <button
              onClick={() => onManageDomain ? onManageDomain(domain.domain) : onOpenWhois(domain.domain)}
              className="px-3.5 py-2 rounded-xl text-xs font-black bg-blue-600 hover:bg-blue-700 text-white shadow-md flex items-center gap-1 transition-all"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Manage</span>
            </button>
          ) : isAvailable ? (
            <div className="flex items-center gap-1">
              <button
                onClick={() => onAddToCart(domain)}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 border ${
                  isInCart
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700'
                }`}
                title="Add to Cart"
              >
                {isInCart ? <Check className="w-3.5 h-3.5" /> : <ShoppingCart className="w-3.5 h-3.5" />}
                {isInCart ? 'In Cart' : 'Cart'}
              </button>

              {onCheckoutNow && (
                <button
                  onClick={() => onCheckoutNow(domain)}
                  className="px-3.5 py-2 rounded-xl text-xs font-black bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 flex items-center gap-1 transition-all hover:scale-105"
                  title="Checkout Immediately"
                >
                  <Zap className="w-3.5 h-3.5 fill-current" />
                  <span>Checkout</span>
                </button>
              )}
            </div>
          ) : isUnable ? (
            <button
              onClick={() => onOpenWhois(domain.domain)}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-orange-100 hover:bg-orange-200 text-orange-800 dark:bg-orange-950 dark:text-orange-200"
            >
              Probe Status
            </button>
          ) : (
            <button
              onClick={() => onOpenWhois(domain.domain)}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
            >
              Backorder
            </button>
          )}
        </div>
      </div>

    </div>
  );
};
