import React, { useState, useEffect } from 'react';
import { 
  Server, 
  HardDrive, 
  Activity, 
  Globe, 
  Mail, 
  Database, 
  Download, 
  Terminal, 
  ExternalLink, 
  Key, 
  Settings, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Cpu, 
  Layers, 
  Zap, 
  FolderArchive, 
  ShieldCheck, 
  Lock, 
  Code, 
  RefreshCw,
  Search,
  Check,
  TrendingUp,
  ArrowRight,
  Shield,
  Clock,
  Sparkles,
  ArrowUpRight
} from 'lucide-react';

import { HostingService, WhmcsCpanelEmailAccount, WhmcsCpanelDatabase, WhmcsSoftaculousApp, WhmcsHostingPackage } from '../types';
import { MOCK_CPANEL_EMAILS, MOCK_CPANEL_DATABASES, MOCK_SOFTACULOUS_APPS, MOCK_WHMCS_PACKAGES } from '../data/mockWhmcsData';
import { hostingControlPanelManager } from '../services/hostingControlPanelManager';
import { systemDatabase } from '../services/systemDatabase';

interface Props {
  service: HostingService;
  onBack?: () => void;
  currency?: string;
  onServiceUpdated?: (updated: HostingService) => void;
}

export const WhmcsHostingControlPanel: React.FC<Props> = ({ 
  service: initialService, 
  onBack, 
  currency = 'GHS',
  onServiceUpdated
}) => {
  const [currentService, setCurrentService] = useState<HostingService>(initialService);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'softaculous' | 'databases' | 'emails' | 'php' | 'password' | 'upgrade' | 'whmcs_actions'>('dashboard');

  // Interactive Local State for cPanel elements
  const [emails, setEmails] = useState<WhmcsCpanelEmailAccount[]>(MOCK_CPANEL_EMAILS);
  const [databases, setDatabases] = useState<WhmcsCpanelDatabase[]>(MOCK_CPANEL_DATABASES);
  const [apps, setApps] = useState<WhmcsSoftaculousApp[]>(MOCK_SOFTACULOUS_APPS);

  // PHP Settings State
  const [phpVersion, setPhpVersion] = useState<string>(currentService.phpVersion || '8.2');
  const [memoryLimit, setMemoryLimit] = useState<string>('512M');
  const [redisEnabled, setRedisEnabled] = useState<boolean>(true);
  const [imagickEnabled, setImagickEnabled] = useState<boolean>(true);

  // Form Modals
  const [showAddEmailModal, setShowAddEmailModal] = useState(false);
  const [newEmailPrefix, setNewEmailPrefix] = useState('');
  const [newEmailQuota, setNewEmailQuota] = useState(2048);

  const [showAddDbModal, setShowAddDbModal] = useState(false);
  const [newDbName, setNewDbName] = useState('');

  const [showInstallAppModal, setShowInstallAppModal] = useState(false);
  const [selectedAppName, setSelectedAppName] = useState('WordPress');
  const [installPath, setInstallPath] = useState('');

  // SSO Session Modal & Feedback
  const [ssoExecuting, setSsoExecuting] = useState<string | null>(null);
  const [ssoSessionData, setSsoSessionData] = useState<{
    target: string;
    url: string;
    token: string;
    expiresIn: number;
    serverHost: string;
  } | null>(null);

  // Password Change State
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Upgrade/Downgrade State
  const [selectedPackageId, setSelectedPackageId] = useState<string>(
    MOCK_WHMCS_PACKAGES.find(p => p.name === currentService.planName)?.id || MOCK_WHMCS_PACKAGES[0].id
  );
  const [upgradeStatus, setUpgradeStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isUpgrading, setIsUpgrading] = useState(false);

  // Global Notification
  const [actionNotice, setActionNotice] = useState<{ title: string; desc: string; type?: 'success' | 'info' } | null>(null);

  useEffect(() => {
    if (actionNotice) {
      const t = setTimeout(() => setActionNotice(null), 6000);
      return () => clearTimeout(t);
    }
  }, [actionNotice]);

  // Handlers for cPanel Sub-features
  const handleCreateEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmailPrefix) return;
    const newAcc: WhmcsCpanelEmailAccount = {
      id: `em-${Date.now()}`,
      email: `${newEmailPrefix}@${currentService.domain}`,
      usageMb: 0,
      quotaMb: newEmailQuota,
    };
    setEmails([...emails, newAcc]);
    setShowAddEmailModal(false);
    setNewEmailPrefix('');
    setActionNotice({
      title: 'Email Account Provisioned',
      desc: `Mailbox '${newAcc.email}' created on server ${currentService.ipAddress} with ${newEmailQuota}MB quota.`,
      type: 'success',
    });
  };

  const handleCreateDb = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDbName) return;
    const prefix = currentService.cpanelUser ? currentService.cpanelUser.substring(0, 8) : 'dbuser';
    const newDb: WhmcsCpanelDatabase = {
      id: `db-${Date.now()}`,
      dbName: `${prefix}_${newDbName}`,
      dbUser: `${prefix}_usr`,
      sizeMb: 1,
    };
    setDatabases([...databases, newDb]);
    setShowAddDbModal(false);
    setNewDbName('');
    setActionNotice({
      title: 'MySQL Database Created',
      desc: `Database '${newDb.dbName}' and user '${newDb.dbUser}' provisioned in MySQL engine.`,
      type: 'success',
    });
  };

  const handleInstallApp = (e: React.FormEvent) => {
    e.preventDefault();
    const newApp: WhmcsSoftaculousApp = {
      id: `app-${Date.now()}`,
      name: selectedAppName,
      category: 'CMS',
      version: '6.6.1',
      installedUrl: `https://${currentService.domain}${installPath ? `/${installPath}` : ''}`,
      installedPath: `/public_html${installPath ? `/${installPath}` : ''}`,
      dbName: `${currentService.cpanelUser || 'user'}_wp${Math.floor(Math.random() * 900 + 100)}`,
      installedDate: new Date().toISOString().split('T')[0],
      autoUpdate: true,
    };
    setApps([...apps, newApp]);
    setShowInstallAppModal(false);
    setInstallPath('');
    setActionNotice({
      title: 'Softaculous App Deployed',
      desc: `${selectedAppName} installed at ${newApp.installedUrl} with auto-configured database.`,
      type: 'success',
    });
  };

  // Launch Real Control Panel SSO
  const handleLaunchSsoSession = async (target: 'cpanel' | 'whm' | 'webmail' | 'phpmyadmin' | 'filemanager', label: string) => {
    setSsoExecuting(label);
    try {
      const res = await hostingControlPanelManager.generateSsoSession({
        target,
        username: currentService.cpanelUser,
        domain: currentService.domain,
        serverId: currentService.hostingServerId,
      });

      if (res.success) {
        setSsoSessionData({
          target: label,
          url: res.ssoUrl,
          token: res.token,
          expiresIn: res.expiresInSeconds,
          serverHost: res.serverHostname,
        });
      }
    } catch (err: any) {
      alert(`SSO Session Error: ${err.message || 'Failed to establish control panel handshake.'}`);
    } finally {
      setSsoExecuting(null);
    }
  };

  // Handle Change Password Form
  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordStatus(null);

    if (newPassword.length < 8) {
      setPasswordStatus({ type: 'error', message: 'Password must be at least 8 characters long.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordStatus({ type: 'error', message: 'Passwords do not match. Please re-enter.' });
      return;
    }

    setIsChangingPassword(true);
    try {
      const res = await hostingControlPanelManager.changeAccountPassword({
        username: currentService.cpanelUser,
        newPassword,
        domain: currentService.domain,
        serverId: currentService.hostingServerId,
      });

      if (res.success) {
        setPasswordStatus({ type: 'success', message: res.message });
        setNewPassword('');
        setConfirmPassword('');
        setActionNotice({
          title: 'Password Synchronized',
          desc: `Authentication password updated across cPanel, Webmail, and FTP services for ${currentService.cpanelUser}.`,
          type: 'success',
        });
      }
    } catch (err: any) {
      setPasswordStatus({ type: 'error', message: err.message || 'Failed to update control panel password.' });
    } finally {
      setIsChangingPassword(false);
    }
  };

  // Handle Upgrade/Downgrade Form
  const handleUpgradeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUpgradeStatus(null);

    const targetPkg = MOCK_WHMCS_PACKAGES.find(p => p.id === selectedPackageId);
    if (!targetPkg) return;

    if (targetPkg.name === currentService.planName) {
      setUpgradeStatus({ type: 'error', message: 'This service is already on the selected package.' });
      return;
    }

    setIsUpgrading(true);
    try {
      const res = await hostingControlPanelManager.changeAccountPackage({
        username: currentService.cpanelUser,
        newPackageName: targetPkg.name,
        domain: currentService.domain,
        serverId: currentService.hostingServerId,
      });

      if (res.success) {
        const updated: HostingService = {
          ...currentService,
          planName: targetPkg.name,
          diskLimitMb: res.newQuotaMb,
          bandwidthLimitGb: res.newBwGb,
          price: targetPkg.priceMonthly * 15, // conversion approx
        };
        setCurrentService(updated);
        if (onServiceUpdated) {
          onServiceUpdated(updated);
        }

        setUpgradeStatus({ 
          type: 'success', 
          message: `Package successfully migrated to ${targetPkg.name}. New resources immediately applied.` 
        });

        setActionNotice({
          title: 'Package Tier Updated',
          desc: `Account transitioned to '${targetPkg.name}' with ${res.newQuotaMb}MB disk and ${res.newBwGb}GB bandwidth quota.`,
          type: 'success',
        });
      }
    } catch (err: any) {
      setUpgradeStatus({ type: 'error', message: err.message || 'Failed to apply package change via control panel API.' });
    } finally {
      setIsUpgrading(false);
    }
  };

  const currentUser = systemDatabase.getCurrentUser();
  const isStaffOrAdmin = ['admin', 'super_admin', 'administrator', 'staff'].includes(currentUser?.role || '');

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Toast Notice */}
      {actionNotice && (
        <div className="p-4 bg-emerald-950/90 border border-emerald-600/50 rounded-2xl text-white shadow-xl flex items-start justify-between gap-3 animate-in slide-in-from-top-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-extrabold text-sm text-emerald-300">{actionNotice.title}</h4>
              <p className="text-xs text-slate-200 mt-0.5">{actionNotice.desc}</p>
            </div>
          </div>
          <button 
            onClick={() => setActionNotice(null)}
            className="text-slate-400 hover:text-white text-xs font-bold px-2 py-1 bg-slate-900/60 rounded-lg"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Control Panel Master Banner */}
      <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            {onBack && (
              <button
                onClick={onBack}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition-colors flex items-center gap-1"
              >
                <span>← Back to Services</span>
              </button>
            )}
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500 text-white shadow-sm">
              Control Panel Gateway
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-700/60">
              ● {currentService.status.toUpperCase()}
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono text-slate-400 bg-slate-800 border border-slate-700">
              IP: {currentService.ipAddress}
            </span>
          </div>

          <h2 className="text-2xl md:text-3xl font-black text-white flex items-center gap-3">
            <Globe className="w-7 h-7 text-indigo-400" />
            <span>{currentService.domain}</span>
          </h2>

          <p className="text-xs text-slate-400 font-mono">
            Package: <strong className="text-white">{currentService.planName}</strong> • cPanel Username: <strong className="text-indigo-300">{currentService.cpanelUser}</strong> • PHP: <strong className="text-emerald-400">v{currentService.phpVersion}</strong>
          </p>
        </div>

        {/* PRIMARY CONTROL PANEL ACTIONS BAR */}
        <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800 flex flex-col gap-2">
          <div className="text-[10px] font-black tracking-wider uppercase text-slate-400 px-1 flex items-center justify-between">
            <span>Actions & SSO Gateway</span>
            <span className="text-emerald-400 flex items-center gap-1 text-[9px] font-mono">
              <ShieldCheck className="w-3 h-3" /> Live API Connected
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
            {/* 1. Log in to WHM (Admin / Reseller) */}
            <button
              onClick={() => handleLaunchSsoSession('whm', 'WHM WebHost Manager')}
              disabled={ssoExecuting !== null}
              className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                isStaffOrAdmin 
                  ? 'bg-purple-950/70 hover:bg-purple-900/80 border-purple-800/80 text-purple-200'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-300'
              }`}
              title="Log in to WHM (WebHost Manager root/reseller portal)"
            >
              <div className="flex items-center justify-between">
                <Server className="w-4 h-4 text-purple-400" />
                <ArrowUpRight className="w-3 h-3 text-purple-400/70" />
              </div>
              <div className="mt-1">
                <div className="font-extrabold text-[11px] leading-tight">Log in to WHM</div>
                <div className="text-[9px] text-purple-300/70">{isStaffOrAdmin ? 'Admin Cluster' : 'Reseller'}</div>
              </div>
            </button>

            {/* 2. Log in to cPanel */}
            <button
              onClick={() => handleLaunchSsoSession('cpanel', 'cPanel Dashboard')}
              disabled={ssoExecuting !== null}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl border border-indigo-500/50 text-white text-left flex flex-col justify-between shadow-lg shadow-indigo-900/30 transition-all group"
              title="Log in directly to cPanel with One-Click Single Sign-On"
            >
              <div className="flex items-center justify-between">
                <LayoutDashboardIcon className="w-4 h-4 text-indigo-200" />
                <ArrowUpRight className="w-3 h-3 text-indigo-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
              <div className="mt-1">
                <div className="font-black text-[11px] leading-tight">Log in to cPanel</div>
                <div className="text-[9px] text-indigo-200/80">Direct SSO Token</div>
              </div>
            </button>

            {/* 3. Log in to Webmail */}
            <button
              onClick={() => handleLaunchSsoSession('webmail', 'Webmail Inbox')}
              disabled={ssoExecuting !== null}
              className="p-2.5 bg-sky-950/80 hover:bg-sky-900/80 rounded-xl border border-sky-800/80 text-sky-200 text-left flex flex-col justify-between transition-all"
              title="Log in directly to Webmail (Roundcube / Horde)"
            >
              <div className="flex items-center justify-between">
                <Mail className="w-4 h-4 text-sky-400" />
                <ArrowUpRight className="w-3 h-3 text-sky-400/70" />
              </div>
              <div className="mt-1">
                <div className="font-extrabold text-[11px] leading-tight">Log in to Webmail</div>
                <div className="text-[9px] text-sky-300/70">Port 2096 SSL</div>
              </div>
            </button>

            {/* 4. Change Password Action */}
            <button
              onClick={() => setActiveTab('password')}
              className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                activeTab === 'password'
                  ? 'bg-amber-600 text-white border-amber-500 shadow-md'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-200'
              }`}
              title="Change cPanel and FTP Password"
            >
              <div className="flex items-center justify-between">
                <Key className="w-4 h-4 text-amber-400" />
                <Lock className="w-3 h-3 text-amber-400/70" />
              </div>
              <div className="mt-1">
                <div className="font-extrabold text-[11px] leading-tight">Change Password</div>
                <div className="text-[9px] text-slate-400">cPanel / FTP / SQL</div>
              </div>
            </button>

            {/* 5. Upgrade/Downgrade Action */}
            <button
              onClick={() => setActiveTab('upgrade')}
              className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                activeTab === 'upgrade'
                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-200'
              }`}
              title="Upgrade or Downgrade Hosting Package"
            >
              <div className="flex items-center justify-between">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <ArrowRight className="w-3 h-3 text-emerald-400/70" />
              </div>
              <div className="mt-1">
                <div className="font-extrabold text-[11px] leading-tight">Upgrade/Downgrade</div>
                <div className="text-[9px] text-slate-400">Package Scale</div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Control Panel Tab Navigation */}
      <div className="flex items-center gap-2 bg-slate-900 p-2 rounded-2xl border border-slate-800 text-xs font-extrabold overflow-x-auto shadow-sm">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Control Panel Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('softaculous')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'softaculous' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Zap className="w-4 h-4 text-amber-400" />
          <span>Softaculous Apps ({apps.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('databases')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'databases' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Database className="w-4 h-4 text-emerald-400" />
          <span>MySQL Databases ({databases.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('emails')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'emails' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Mail className="w-4 h-4 text-sky-400" />
          <span>Email Accounts ({emails.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('php')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'php' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Code className="w-4 h-4 text-purple-400" />
          <span>PHP Selector</span>
        </button>

        <button
          onClick={() => setActiveTab('password')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'password' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Key className="w-4 h-4 text-amber-400" />
          <span>Change Password</span>
        </button>

        <button
          onClick={() => setActiveTab('upgrade')}
          className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'upgrade' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <span>Upgrade / Downgrade</span>
        </button>

        {isStaffOrAdmin && (
          <button
            onClick={() => setActiveTab('whmcs_actions')}
            className={`px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'whmcs_actions' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Terminal className="w-4 h-4 text-rose-400" />
            <span>Admin Module Operations</span>
          </button>
        )}
      </div>

      {/* TAB 1: DASHBOARD & CONTROL PANEL LIVE METRICS */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Quick SSO Launch Tiles */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <button
              onClick={() => handleLaunchSsoSession('filemanager', 'cPanel File Manager')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group shadow-sm hover:border-indigo-500/40"
            >
              <FolderArchive className="w-6 h-6 text-indigo-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">File Manager</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Direct /public_html SSO</div>
            </button>

            <button
              onClick={() => handleLaunchSsoSession('phpmyadmin', 'phpMyAdmin SQL Engine')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group shadow-sm hover:border-emerald-500/40"
            >
              <Database className="w-6 h-6 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">phpMyAdmin</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Manage MySQL tables</div>
            </button>

            <button
              onClick={() => handleLaunchSsoSession('webmail', 'Webmail Client')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group shadow-sm hover:border-sky-500/40"
            >
              <Mail className="w-6 h-6 text-sky-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">Webmail SSO</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Roundcube mail client</div>
            </button>

            <button
              onClick={() => handleLaunchSsoSession('cpanel', 'cPanel Backup Wizard')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group shadow-sm hover:border-amber-500/40"
            >
              <Download className="w-6 h-6 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">Backup Wizard</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Download full snapshot</div>
            </button>
          </div>

          {/* Real-time Control Panel Quotas */}
          <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800 space-y-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Activity className="w-5 h-5 text-indigo-400" />
                <span>Control Panel Real-Time Resource Consumption</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                Host Node: <strong className="text-slate-200">{currentService.serverNodeName || 'whm01.accra.celoxaghana.online'}</strong>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* NVMe Disk */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-indigo-400" /> NVMe SSD Storage Quota
                  </span>
                  <span className="font-mono text-white font-bold">
                    {(currentService.diskUsageMb / 1024).toFixed(2)} GB / {(currentService.diskLimitMb / 1024).toFixed(0)} GB ({((currentService.diskUsageMb / currentService.diskLimitMb) * 100).toFixed(1)}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${Math.min(100, (currentService.diskUsageMb / currentService.diskLimitMb) * 100)}%` }}></div>
                </div>
              </div>

              {/* Bandwidth */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-sky-400" /> Monthly Bandwidth Allocation
                  </span>
                  <span className="font-mono text-white font-bold">
                    {currentService.bandwidthUsageGb} GB / {currentService.bandwidthLimitGb} GB ({((currentService.bandwidthUsageGb / currentService.bandwidthLimitGb) * 100).toFixed(1)}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-sky-500 h-full rounded-full" style={{ width: `${Math.min(100, (currentService.bandwidthUsageGb / currentService.bandwidthLimitGb) * 100)}%` }}></div>
                </div>
              </div>

              {/* Inodes */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-amber-400" /> Inode File Count Quota
                  </span>
                  <span className="font-mono text-white font-bold">34,120 / 250,000 (13.6%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '13.6%' }}></div>
                </div>
              </div>

              {/* Physical Memory */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Cpu className="w-4 h-4 text-emerald-400" /> Dedicated Physical RAM
                  </span>
                  <span className="font-mono text-white font-bold">428 MB / 2048 MB (20.9%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: '20.9%' }}></div>
                </div>
              </div>
            </div>

            {/* Quick Connection Credentials Box */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <span className="text-slate-500 text-[10px] block font-bold uppercase">FTP Server / Host</span>
                <span className="font-mono text-white font-bold">ftp.{currentService.domain}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block font-bold uppercase">FTP / cPanel Username</span>
                <span className="font-mono text-indigo-400 font-bold">{currentService.cpanelUser}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block font-bold uppercase">Incoming / Outgoing Mail</span>
                <span className="font-mono text-sky-400 font-bold">mail.{currentService.domain}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block font-bold uppercase">Active Nameservers</span>
                <span className="font-mono text-emerald-400 font-bold">ns1.celoxaghana.online</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: CHANGE PASSWORD (REQUESTED SPECIFIC ACTION) */}
      {activeTab === 'password' && (
        <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800 space-y-6 shadow-xl max-w-2xl">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-amber-400">
              <Key className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-lg">Change Control Panel Password</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Update the authentication credentials for user <strong className="text-white font-mono">{currentService.cpanelUser}</strong>.
              </p>
            </div>
          </div>

          <div className="p-4 bg-amber-950/30 border border-amber-800/40 rounded-2xl text-xs text-amber-200/90 space-y-1">
            <p className="font-bold flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-amber-400" /> Unified Server Credential Sync:
            </p>
            <p className="text-[11px] text-amber-300/80">
              This action immediately updates authentication credentials on the remote server across cPanel Web Interface, FTP accounts, Webmail, and default SSH/SFTP connections.
            </p>
          </div>

          {passwordStatus && (
            <div className={`p-4 rounded-2xl text-xs font-bold flex items-center gap-2 ${
              passwordStatus.type === 'success'
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                : 'bg-rose-950/80 text-rose-300 border border-rose-800'
            }`}>
              {passwordStatus.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{passwordStatus.message}</span>
            </div>
          )}

          <form onSubmit={handleChangePasswordSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">New Account Password</label>
              <input
                type="password"
                required
                placeholder="Enter strong new password (min 8 chars)"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1.5">Confirm New Password</label>
              <input
                type="password"
                required
                placeholder="Re-enter new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="pt-2 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  const gen = `Sec#${Math.random().toString(36).substring(2, 8)}!${Math.floor(1000 + Math.random() * 9000)}`;
                  setNewPassword(gen);
                  setConfirmPassword(gen);
                }}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Generate Strong Password</span>
              </button>

              <button
                type="submit"
                disabled={isChangingPassword}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl shadow-lg flex items-center gap-2 disabled:opacity-50"
              >
                {isChangingPassword ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                <span>{isChangingPassword ? 'Applying via API...' : 'Change Password'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB: UPGRADE / DOWNGRADE (REQUESTED SPECIFIC ACTION) */}
      {activeTab === 'upgrade' && (
        <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-emerald-400">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-lg">Upgrade / Downgrade Hosting Package</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Seamlessly scale resources (disk, bandwidth, database limits) without server migration or downtime.
              </p>
            </div>
          </div>

          {upgradeStatus && (
            <div className={`p-4 rounded-2xl text-xs font-bold flex items-center gap-2 ${
              upgradeStatus.type === 'success'
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                : 'bg-rose-950/80 text-rose-300 border border-rose-800'
            }`}>
              {upgradeStatus.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{upgradeStatus.message}</span>
            </div>
          )}

          <form onSubmit={handleUpgradeSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {MOCK_WHMCS_PACKAGES.filter(p => p.category.includes('Hosting') || p.category.includes('WordPress')).map((pkg) => {
                const isSelected = selectedPackageId === pkg.id;
                const isCurrent = pkg.name === currentService.planName;

                return (
                  <div
                    key={pkg.id}
                    onClick={() => setSelectedPackageId(pkg.id)}
                    className={`p-5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30'
                        : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-indigo-400 bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">
                          {pkg.module.toUpperCase()}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] font-bold text-amber-300 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                            Current Plan
                          </span>
                        )}
                      </div>

                      <h4 className="font-extrabold text-white text-base">{pkg.name}</h4>
                      <p className="text-xs text-slate-400">{pkg.description}</p>

                      <div className="pt-2 border-t border-slate-800/80 space-y-1.5 text-xs">
                        <div className="flex justify-between text-slate-300">
                          <span>NVMe Storage:</span>
                          <strong className="text-white font-mono">{pkg.diskLimitMb / 1024} GB</strong>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Bandwidth:</span>
                          <strong className="text-white font-mono">{pkg.bandwidthLimitGb} GB/mo</strong>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Databases:</span>
                          <strong className="text-white font-mono">{pkg.maxDatabases === 0 ? 'Unlimited' : pkg.maxDatabases}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                      <div className="text-lg font-black text-white">
                        GH₵ {(pkg.priceMonthly * 15).toFixed(2)}<span className="text-xs text-slate-400 font-normal">/mo</span>
                      </div>
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                        isSelected ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-slate-700'
                      }`}>
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between pt-2">
              <p className="text-xs text-slate-400">
                Resource quota changes are applied automatically to the cPanel server cluster.
              </p>
              <button
                type="submit"
                disabled={isUpgrading}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center gap-2 disabled:opacity-50"
              >
                {isUpgrading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
                <span>{isUpgrading ? 'Updating Package via API...' : 'Apply Package Change'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 2: SOFTACULOUS 1-CLICK APPS */}
      {activeTab === 'softaculous' && (
        <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 space-y-5 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                <span>Softaculous Auto-Installer</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Instantly deploy applications onto {currentService.domain} with automated MySQL database configuration.
              </p>
            </div>

            <button
              onClick={() => setShowInstallAppModal(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Install New Application</span>
            </button>
          </div>

          <div className="space-y-3">
            {apps.map((app) => (
              <div key={app.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-white text-sm">{app.name}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-950 text-indigo-300">
                      v{app.version}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono">
                    URL: <a href={app.installedUrl} target="_blank" rel="noreferrer" className="text-sky-400 underline">{app.installedUrl}</a> • Path: {app.installedPath}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`${app.installedUrl}/wp-admin`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl text-xs flex items-center gap-1"
                  >
                    <span>Admin Dashboard</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: MYSQL DATABASES */}
      {activeTab === 'databases' && (
        <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 space-y-5 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <span>MySQL / MariaDB Database Manager</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Manage relational databases and user privileges on your cPanel hosting instance.
              </p>
            </div>

            <button
              onClick={() => setShowAddDbModal(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create MySQL Database</span>
            </button>
          </div>

          <div className="space-y-3">
            {databases.map((db) => (
              <div key={db.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-extrabold text-white text-sm font-mono">{db.dbName}</div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    User: <strong className="text-slate-200">{db.dbUser}</strong> • Size: {db.sizeMb} MB
                  </div>
                </div>

                <button
                  onClick={() => handleLaunchSsoSession('phpmyadmin', `phpMyAdmin (${db.dbName})`)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 font-extrabold rounded-xl text-xs border border-slate-700 flex items-center gap-1"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Launch phpMyAdmin
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: EMAIL ACCOUNTS */}
      {activeTab === 'emails' && (
        <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 space-y-5 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Mail className="w-5 h-5 text-sky-400" />
                <span>cPanel Mailbox Accounts</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Create domain email accounts with POP3/IMAP SSL settings and Webmail direct access.
              </p>
            </div>

            <button
              onClick={() => setShowAddEmailModal(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create Email Account</span>
            </button>
          </div>

          <div className="space-y-3">
            {emails.map((em) => (
              <div key={em.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-extrabold text-white text-sm font-mono">{em.email}</div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Quota: {em.usageMb} MB / {em.quotaMb} MB ({((em.usageMb / em.quotaMb) * 100).toFixed(1)}%)
                  </div>
                </div>

                <button
                  onClick={() => handleLaunchSsoSession('webmail', `Webmail (${em.email})`)}
                  className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5" /> Webmail SSO
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: PHP SELECTOR */}
      {activeTab === 'php' && (
        <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center gap-3">
            <Code className="w-6 h-6 text-purple-400" />
            <div>
              <h3 className="font-extrabold text-white text-base">cPanel PHP Version & Directives</h3>
              <p className="text-xs text-slate-400">
                Switch PHP versions on the fly and toggle extensions for optimized site loading speed.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <label className="font-bold text-slate-300 block">Active PHP Runtime Version</label>
              <select
                value={phpVersion}
                onChange={(e) => setPhpVersion(e.target.value)}
                className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none"
              >
                <option value="8.3">PHP 8.3 (Latest - Recommended)</option>
                <option value="8.2">PHP 8.2 (Stable High Performance)</option>
                <option value="8.1">PHP 8.1</option>
                <option value="8.0">PHP 8.0</option>
                <option value="7.4">PHP 7.4 (Legacy Support)</option>
              </select>

              <div className="pt-2">
                <label className="font-bold text-slate-300 block mb-1">memory_limit Directive</label>
                <select
                  value={memoryLimit}
                  onChange={(e) => setMemoryLimit(e.target.value)}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                >
                  <option value="256M">256M</option>
                  <option value="512M">512M (Recommended for WP)</option>
                  <option value="1024M">1024M (1 GB)</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <label className="font-bold text-slate-300 block">PHP Extensions & Modules</label>
              <div className="space-y-2">
                <label className="flex items-center justify-between p-2 bg-slate-900 rounded-lg cursor-pointer">
                  <span>Redis Object Cache Extension</span>
                  <input
                    type="checkbox"
                    checked={redisEnabled}
                    onChange={(e) => setRedisEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between p-2 bg-slate-900 rounded-lg cursor-pointer">
                  <span>ImageMagick (imagick)</span>
                  <input
                    type="checkbox"
                    checked={imagickEnabled}
                    onChange={(e) => setImagickEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
                  />
                </label>
              </div>

              <button
                onClick={() => {
                  setActionNotice({
                    title: 'PHP Settings Synchronized',
                    desc: `PHP runtime updated to v${phpVersion} with ${memoryLimit} memory limit.`,
                    type: 'success',
                  });
                }}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl shadow"
              >
                Apply PHP Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB: WHMCS ADMIN MODULE ACTIONS */}
      {activeTab === 'whmcs_actions' && isStaffOrAdmin && (
        <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800 space-y-5 shadow-xl">
          <div className="flex items-center gap-3">
            <Terminal className="w-6 h-6 text-rose-400" />
            <div>
              <h3 className="font-extrabold text-white text-base">Server Module Command Operations</h3>
              <p className="text-xs text-slate-400">
                Admin-only API commands executed directly on the cPanel / WHM cluster.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-bold">
            <button
              onClick={() => {
                setActionNotice({
                  title: 'Account Re-Created',
                  desc: `API command executed. Re-allocated user '${currentService.cpanelUser}' on ${currentService.ipAddress}.`,
                  type: 'success',
                });
              }}
              className="p-3.5 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 rounded-xl border border-emerald-800 text-left"
            >
              ▶ Re-Create Account
            </button>

            <button
              onClick={() => {
                setActionNotice({
                  title: 'Account Suspended',
                  desc: `Account '${currentService.domain}' suspended via WHM API.`,
                  type: 'info',
                });
              }}
              className="p-3.5 bg-amber-950/80 hover:bg-amber-900 text-amber-300 rounded-xl border border-amber-800 text-left"
            >
              ⏸ Suspend Account
            </button>

            <button
              onClick={() => {
                setActionNotice({
                  title: 'Account Unsuspended',
                  desc: `Account '${currentService.domain}' unsuspended and web access restored.`,
                  type: 'success',
                });
              }}
              className="p-3.5 bg-sky-950/80 hover:bg-sky-900 text-sky-300 rounded-xl border border-sky-800 text-left"
            >
              ⏯ Unsuspend Account
            </button>

            <button
              onClick={() => {
                setActiveTab('password');
              }}
              className="p-3.5 bg-purple-950/80 hover:bg-purple-900 text-purple-300 rounded-xl border border-purple-800 text-left"
            >
              🔑 Reset Password
            </button>
          </div>
        </div>
      )}

      {/* SSO MODAL VIEWER */}
      {ssoSessionData && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 rounded-3xl border border-slate-800 p-6 space-y-5 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="font-extrabold text-white text-base">SSO Authentication Established</h3>
              </div>
              <button 
                onClick={() => setSsoSessionData(null)} 
                className="text-slate-400 hover:text-white font-bold text-xs px-2 py-1 bg-slate-800 rounded-lg"
              >
                ✕ Close
              </button>
            </div>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 text-xs">
              <div>
                <span className="text-slate-500 text-[10px] block font-bold uppercase">Target System</span>
                <span className="font-extrabold text-white text-sm">{ssoSessionData.target}</span>
              </div>

              <div>
                <span className="text-slate-500 text-[10px] block font-bold uppercase">Server Node</span>
                <span className="font-mono text-slate-300">{ssoSessionData.serverHost}</span>
              </div>

              <div>
                <span className="text-slate-500 text-[10px] block font-bold uppercase">Generated Single Sign-On URL</span>
                <input
                  type="text"
                  readOnly
                  value={ssoSessionData.url}
                  className="w-full p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-emerald-400 font-mono text-[11px] focus:outline-none"
                />
              </div>

              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Security Token: <strong className="font-mono text-slate-300">{ssoSessionData.token.substring(0, 16)}...</strong></span>
                <span>Valid For: <strong className="text-emerald-400">{ssoSessionData.expiresIn / 60} minutes</strong></span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSsoSessionData(null)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs"
              >
                Dismiss
              </button>
              <a
                href={ssoSessionData.url}
                target="_blank"
                rel="noreferrer"
                onClick={() => setSsoSessionData(null)}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl text-xs shadow-lg flex items-center gap-1.5"
              >
                <span>Launch {ssoSessionData.target} in New Tab</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD EMAIL */}
      {showAddEmailModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 rounded-3xl border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-white text-base">Create cPanel Mailbox</h3>
              <button onClick={() => setShowAddEmailModal(false)} className="text-slate-400 hover:text-white font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleCreateEmail} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Email Username</label>
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    required
                    placeholder="e.g. support"
                    value={newEmailPrefix}
                    onChange={(e) => setNewEmailPrefix(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                  />
                  <span className="text-slate-400 font-mono text-xs font-bold">@{currentService.domain}</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Storage Quota (MB)</label>
                <input
                  type="number"
                  value={newEmailQuota}
                  onChange={(e) => setNewEmailQuota(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowAddEmailModal(false)} className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-indigo-600 text-white font-extrabold rounded-xl shadow">Create Mailbox</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD DATABASE */}
      {showAddDbModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 rounded-3xl border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-white text-base">Create MySQL Database</h3>
              <button onClick={() => setShowAddDbModal(false)} className="text-slate-400 hover:text-white font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleCreateDb} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Database Suffix Name</label>
                <div className="flex items-center gap-1">
                  <span className="text-slate-400 font-mono text-xs font-bold">{currentService.cpanelUser || 'user'}_</span>
                  <input
                    type="text"
                    required
                    placeholder="e.g. appdb"
                    value={newDbName}
                    onChange={(e) => setNewDbName(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowAddDbModal(false)} className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-emerald-600 text-white font-extrabold rounded-xl shadow">Create Database</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: INSTALL APP */}
      {showInstallAppModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 rounded-3xl border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-white text-base">Softaculous 1-Click Installer</h3>
              <button onClick={() => setShowInstallAppModal(false)} className="text-slate-400 hover:text-white font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleInstallApp} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Select Software</label>
                <select
                  value={selectedAppName}
                  onChange={(e) => setSelectedAppName(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-bold focus:outline-none"
                >
                  <option value="WordPress">WordPress CMS</option>
                  <option value="WooCommerce">WooCommerce E-Commerce Store</option>
                  <option value="Laravel">Laravel PHP Framework</option>
                  <option value="Joomla">Joomla CMS</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Installation Path (Optional)</label>
                <div className="flex items-center gap-1">
                  <span className="text-slate-400 font-mono text-[11px]">{currentService.domain}/</span>
                  <input
                    type="text"
                    placeholder="e.g. blog or shop (leave blank for root)"
                    value={installPath}
                    onChange={(e) => setInstallPath(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowInstallAppModal(false)} className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-indigo-600 text-white font-extrabold rounded-xl shadow">Install Software Now</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// Internal icon alias for cPanel Layout
const LayoutDashboardIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="7" height="9" x="3" y="3" rx="1" />
    <rect width="7" height="5" x="14" y="3" rx="1" />
    <rect width="7" height="9" x="14" y="12" rx="1" />
    <rect width="7" height="5" x="3" y="16" rx="1" />
  </svg>
);
