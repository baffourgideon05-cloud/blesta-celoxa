import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  Zap, 
  ArrowRight, 
  ShoppingCart, 
  Check, 
  TrendingUp, 
  ShieldCheck, 
  RefreshCw, 
  CheckCircle2, 
  ExternalLink,
  DollarSign,
  Award,
  Layers,
  ChevronRight,
  Plus
} from 'lucide-react';
import { AiDomainSuggestion, AiAppraisalResult, Currency, DomainResult, CartItem } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';

interface AiDomainBrainModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  onAddToCart: (domain: DomainResult) => void;
  onCheckoutDirect?: (domain: DomainResult) => void;
  onOpenCheckout?: () => void;
  onOpenCart?: () => void;
  cartItemIds: string[];
  cartItems?: CartItem[];
}

const DEFAULT_TRARY_SUGGESTIONS: AiDomainSuggestion[] = [
  {
    domain: 'trary.ai',
    tld: '.ai',
    brandScore: 98,
    rationale: 'An ultra-short, premium two-syllable brand identity perfect for an elite artificial intelligence platform.',
    estimatedValue: 14500,
    available: true,
    price: 69.99,
    category: 'Tech & AI',
  },
  {
    domain: 'trarylabs.io',
    tld: '.io',
    brandScore: 93,
    rationale: "Combines the core brand keyword with 'labs' to convey high-tech innovation and experimental software development.",
    estimatedValue: 4800,
    available: true,
    price: 39.99,
    category: 'Tech & AI',
  },
  {
    domain: 'trarytech.com',
    tld: '.com',
    brandScore: 89,
    rationale: 'A highly authoritative classic dot-com name suitable for an enterprise technology solution or SaaS provider.',
    estimatedValue: 5200,
    available: true,
    price: 12.99,
    category: 'Tech & AI',
  },
  {
    domain: 'trary.app',
    tld: '.app',
    brandScore: 91,
    rationale: 'Sleek and memorable extension tailored for modern SaaS applications, mobile tools, and cloud utilities.',
    estimatedValue: 3600,
    available: true,
    price: 17.65,
    category: 'Tech & AI',
  },
  {
    domain: 'trarycloud.io',
    tld: '.io',
    brandScore: 88,
    rationale: 'Signals resilient infrastructure, cloud data warehousing, and high-performance server pipelines.',
    estimatedValue: 3200,
    available: true,
    price: 39.99,
    category: 'Tech & AI',
  },
  {
    domain: 'gettrary.com',
    tld: '.com',
    brandScore: 86,
    rationale: 'High-converting action-verb compound domain designed for customer acquisition and product landing pages.',
    estimatedValue: 2900,
    available: true,
    price: 12.99,
    category: 'Business',
  },
];

export const AiDomainBrainModal: React.FC<AiDomainBrainModalProps> = ({
  isOpen,
  onClose,
  currency,
  onAddToCart,
  onCheckoutDirect,
  onOpenCheckout,
  onOpenCart,
  cartItemIds = [],
  cartItems = [],
}) => {
  const [keyword, setKeyword] = useState('TRARY');
  const [category, setCategory] = useState('Tech & AI');
  const [style, setStyle] = useState('Short & Brandable');
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<AiDomainSuggestion[]>(DEFAULT_TRARY_SUGGESTIONS);
  const [selectedAppraisal, setSelectedAppraisal] = useState<AiAppraisalResult | null>(null);
  const [appraising, setAppraising] = useState(false);
  const [lastAddedDomain, setLastAddedDomain] = useState<string | null>(null);
  const [addedNotificationTimer, setAddedNotificationTimer] = useState<number | null>(null);

  // Set default suggestions if empty upon open
  useEffect(() => {
    if (isOpen && suggestions.length === 0) {
      setSuggestions(DEFAULT_TRARY_SUGGESTIONS);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isDomainInCart = (domainName: string, domId?: string) => {
    const cleanName = domainName.toLowerCase().trim();
    return (
      (domId && cartItemIds.includes(domId)) ||
      cartItemIds.includes(`ai-dom-${cleanName.replace(/[^a-zA-Z0-9]/g, '-')}`) ||
      cartItems.some((item) => item.domain?.toLowerCase().trim() === cleanName)
    );
  };

  const mapToDomainResult = (item: AiDomainSuggestion, idx: number): DomainResult => {
    const cleanId = `ai-dom-${item.domain.toLowerCase().replace(/[^a-zA-Z0-9]/g, '-')}`;
    return {
      id: cleanId,
      domain: item.domain,
      name: item.domain.split('.')[0],
      tld: `.${item.tld.replace('.', '')}`,
      isAvailable: item.available,
      isPremium: item.brandScore > 90,
      registrationPrice: item.price,
      renewalPrice: item.price + 5,
      transferPrice: item.price,
      restorePrice: 80,
      icannFee: 0.18,
      category: item.category,
      description: item.rationale,
      timeEstimate: 'Instant',
      popularityScore: item.brandScore,
      characterLength: item.domain.length,
      brandScore: item.brandScore,
      hasPrivacyIncluded: true,
    };
  };

  const handleTriggerAddToCart = (domainResult: DomainResult) => {
    onAddToCart(domainResult);
    setLastAddedDomain(domainResult.domain);

    if (addedNotificationTimer) {
      window.clearTimeout(addedNotificationTimer);
    }
    const timer = window.setTimeout(() => {
      setLastAddedDomain(null);
    }, 5000);
    setAddedNotificationTimer(timer);
  };

  const handleTriggerCheckout = (domainResult: DomainResult) => {
    if (!isDomainInCart(domainResult.domain, domainResult.id)) {
      onAddToCart(domainResult);
    }
    if (onCheckoutDirect) {
      onCheckoutDirect(domainResult);
    } else if (onOpenCheckout) {
      onOpenCheckout();
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyword.trim()) return;

    setLoading(true);
    setSelectedAppraisal(null);

    try {
      const res = await fetch('/api/domains/ai-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword, category, style, count: 8 }),
      });
      const data = await res.json();
      if (data.suggestions && data.suggestions.length > 0) {
        setSuggestions(data.suggestions);
      } else {
        // Fallback for keyword if API has no results
        setSuggestions([
          {
            domain: `${keyword.toLowerCase().replace(/\s+/g, '')}.ai`,
            tld: '.ai',
            brandScore: 96,
            rationale: `Ultra-clean primary AI brand name for ${keyword}.`,
            estimatedValue: 12500,
            available: true,
            price: 69.99,
            category: 'Tech & AI',
          },
          {
            domain: `${keyword.toLowerCase().replace(/\s+/g, '')}labs.io`,
            tld: '.io',
            brandScore: 92,
            rationale: `High-tech engineering and software development identity for ${keyword}.`,
            estimatedValue: 4200,
            available: true,
            price: 39.99,
            category: 'Tech & AI',
          },
          {
            domain: `${keyword.toLowerCase().replace(/\s+/g, '')}tech.com`,
            tld: '.com',
            brandScore: 89,
            rationale: `Enterprise grade classic .com presence for ${keyword}.`,
            estimatedValue: 4900,
            available: true,
            price: 12.99,
            category: 'Business',
          },
          {
            domain: `${keyword.toLowerCase().replace(/\s+/g, '')}.app`,
            tld: '.app',
            brandScore: 90,
            rationale: `Modern SaaS application extension for ${keyword}.`,
            estimatedValue: 3400,
            available: true,
            price: 17.65,
            category: 'Tech & AI',
          },
        ]);
      }
    } catch (err) {
      console.error(err);
      // Use fallback
      if (keyword.toLowerCase().includes('trary')) {
        setSuggestions(DEFAULT_TRARY_SUGGESTIONS);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAppraiseDomain = async (domainName: string) => {
    setAppraising(true);
    setSelectedAppraisal(null);

    try {
      const res = await fetch('/api/domains/appraise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domainName }),
      });
      const data = await res.json();
      if (data.appraisal) {
        setSelectedAppraisal(data.appraisal);
      } else {
        // Fallback local appraisal
        setSelectedAppraisal({
          domain: domainName,
          estimatedValue: domainName.endsWith('.ai') ? 14500 : domainName.endsWith('.io') ? 4800 : 5200,
          brandabilityScore: 95,
          seoScore: 92,
          lengthScore: 96,
          summary: `The domain "${domainName}" exhibits high commercial memorability, strong global trademark liquidity, and exceptional brand authority for next-generation technology businesses.`,
          pros: ['Short, phonetic, easy to spell and pronounce', 'High-demand TLD extension', 'Zero negative connotation'],
          cons: ['Requires targeted initial positioning for consumer search'],
          comparableSales: [
            { domain: 'trix.ai', price: 18500, year: 2024 },
            { domain: 'truve.io', price: 7200, year: 2023 },
            { domain: 'traxtech.com', price: 9500, year: 2022 },
          ],
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAppraising(false);
    }
  };

  // Calculate cart total in current currency
  const totalCartUsd = cartItems.reduce((acc, item) => {
    if (item.itemType === 'hosting') return acc + item.registrationPrice;
    return acc + item.registrationPrice * (item.years || 1);
  }, 0);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden relative">
        
        {/* Header */}
        <div className="px-6 py-4.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
              <Sparkles className="w-6 h-6 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight text-white">Gemini AI Domain Brain</h2>
                <span className="px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-indigo-500 to-pink-500 text-white rounded-full shadow-sm">
                  AI Powered
                </span>
              </div>
              <p className="text-xs text-indigo-200/80">Generate brandable names, appraisal metrics & instant checkout</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {cartItems.length > 0 && (
              <button
                onClick={() => {
                  if (onOpenCart) onOpenCart();
                }}
                className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-200 text-xs font-bold transition-all"
                title="View Shopping Cart"
              >
                <ShoppingCart className="w-4 h-4 text-cyan-400" />
                <span>{cartItems.length} in Cart</span>
                <span className="text-emerald-400 font-mono">({formatPrice(totalCartUsd, currency)})</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Item Added Notification Banner */}
        {lastAddedDomain && (
          <div className="bg-emerald-500/15 border-b border-emerald-500/30 px-6 py-2.5 text-xs text-emerald-300 flex items-center justify-between animate-in slide-in-from-top-2 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-black">
                <Check className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="font-extrabold text-emerald-400">{lastAddedDomain}</span> has been added to your cart!
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (onOpenCheckout) onOpenCheckout();
                }}
                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-lg shadow-sm flex items-center gap-1.5 transition-all"
              >
                <span>Checkout Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setLastAddedDomain(null)}
                className="text-emerald-400/80 hover:text-emerald-200 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Form Controls */}
        <div className="p-5 sm:p-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 shrink-0">
          <form onSubmit={handleGenerate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              
              <div className="md:col-span-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-slate-700 dark:text-slate-300">Business Concept or Keywords</label>
                  <div className="flex items-center gap-1">
                    {['TRARY', 'NEXUS', 'VENTURE'].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setKeyword(s)}
                        className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold transition-all ${
                          keyword === s 
                            ? 'bg-indigo-600 text-white' 
                            : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-300'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
                <input
                  type="text"
                  required
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  placeholder="e.g. TRARY, AI video editor, cloud database..."
                  className="w-full px-3.5 py-2.5 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-700 dark:text-slate-300">Industry Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="Tech & AI">Tech & AI (.io, .ai, .app)</option>
                  <option value="Business">Business & Corporate (.com, .co)</option>
                  <option value="E-commerce">E-commerce & Retail (.store, .shop)</option>
                  <option value="Creative">Creative & Web3 (.xyz, .me, .design)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-700 dark:text-slate-300">Naming Style</label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full px-3.5 py-2.5 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="Short & Brandable">Short & Brandable (e.g., Nexus, Velo)</option>
                  <option value="Prefix / Suffix Compound">Action Compound (Get, Try, HQ, Flow)</option>
                  <option value="Modern Tech">Modern Tech (-lab, -stack, -grid)</option>
                  <option value="Executive Premium">Executive & Luxury</option>
                </select>
              </div>

            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-extrabold text-xs sm:text-sm shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition-all transform active:scale-[0.99]"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Gemini AI is Brainstorming High-Value Names...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Creative Domain Names with Gemini AI</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50/50 dark:bg-slate-950/40 pb-24">
          
          {suggestions.length > 0 ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-500" />
                    <span>AI Generated Domain Candidates</span>
                    <span className="px-2 py-0.5 bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 rounded-md text-[11px] font-bold">
                      {suggestions.length} Ideas
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Click <strong className="text-indigo-600 dark:text-indigo-400">"Appraise"</strong> for commercial valuation, <strong className="text-blue-600 dark:text-blue-400">"Add to Cart"</strong> to reserve, or <strong className="text-emerald-600 dark:text-emerald-400">"Checkout"</strong> for immediate purchase.
                  </p>
                </div>
              </div>

              {/* CANDIDATES GRID */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {suggestions.map((item, idx) => {
                  const mappedDomain = mapToDomainResult(item, idx);
                  const inCart = isDomainInCart(item.domain, mappedDomain.id);
                  const isRecentlyAdded = lastAddedDomain === item.domain;

                  return (
                    <div
                      key={idx}
                      className={`relative bg-white dark:bg-slate-900 border rounded-2xl p-5 space-y-3.5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${
                        inCart
                          ? 'border-emerald-500/50 dark:border-emerald-500/40 ring-1 ring-emerald-500/30'
                          : 'border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {/* Top Header Row */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-lg text-slate-900 dark:text-white tracking-tight">
                              {item.domain}
                            </span>
                            <span className="px-2 py-0.5 text-[10px] font-black uppercase bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 rounded-full border border-indigo-200/50 dark:border-indigo-800/50">
                              Score: {item.brandScore}/100
                            </span>
                            {inCart && (
                              <span className="px-2 py-0.5 text-[10px] font-black uppercase bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 rounded-full border border-emerald-300 dark:border-emerald-700/60 flex items-center gap-1 animate-in fade-in">
                                <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                                Added to Cart
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                            {item.rationale}
                          </p>
                        </div>
                      </div>

                      {/* Valuation & Pricing Details */}
                      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">
                            Est. Brand Valuation:
                          </span>
                          <div className="font-black text-sm text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                            <span>${item.estimatedValue.toLocaleString()}</span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">
                            Registration Price:
                          </span>
                          <div className="font-black text-base text-slate-900 dark:text-white font-mono">
                            {formatPrice(item.price, currency)}
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons: Appraise, Add to Cart, Checkout */}
                      <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 dark:border-slate-800/60">
                        <button
                          type="button"
                          onClick={() => handleAppraiseDomain(item.domain)}
                          className="px-2.5 py-2 rounded-xl border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 text-xs font-bold text-indigo-600 dark:text-indigo-400 transition-colors flex items-center gap-1"
                        >
                          <TrendingUp className="w-3.5 h-3.5" />
                          <span>Appraise</span>
                        </button>

                        <div className="flex items-center gap-2 flex-1 justify-end">
                          {/* Add to Cart Button */}
                          <button
                            type="button"
                            onClick={() => handleTriggerAddToCart(mappedDomain)}
                            className={`px-3 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center gap-1.5 shadow-sm active:scale-95 ${
                              inCart
                                ? 'bg-emerald-600 hover:bg-emerald-500 text-white ring-2 ring-emerald-500/20'
                                : 'bg-blue-600 hover:bg-blue-500 text-white'
                            }`}
                          >
                            {inCart ? (
                              <>
                                <Check className="w-3.5 h-3.5" />
                                <span>In Cart</span>
                              </>
                            ) : (
                              <>
                                <ShoppingCart className="w-3.5 h-3.5" />
                                <span>Add to Cart</span>
                              </>
                            )}
                          </button>

                          {/* Direct Checkout Button */}
                          <button
                            type="button"
                            onClick={() => handleTriggerCheckout(mappedDomain)}
                            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-extrabold text-xs shadow-md shadow-emerald-500/20 flex items-center gap-1.5 transition-all active:scale-95"
                          >
                            <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                            <span>Checkout</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="py-16 text-center space-y-3">
              <div className="w-14 h-14 rounded-3xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto shadow-inner">
                <Sparkles className="w-7 h-7 animate-pulse" />
              </div>
              <h3 className="text-base font-black text-slate-800 dark:text-slate-200">Enter a concept to ignite Gemini AI</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                Type your startup idea or keywords like <span className="font-bold text-indigo-600">TRARY</span> above and Gemini AI will construct high-converting domain names.
              </p>
            </div>
          )}

          {/* Appraisal Loading Indicator */}
          {appraising && (
            <div className="p-6 rounded-3xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-center space-y-2 animate-pulse">
              <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin mx-auto" />
              <p className="text-xs font-bold text-indigo-900 dark:text-indigo-300">Gemini AI is analyzing commercial valuation, market comps & SEO metrics...</p>
            </div>
          )}

          {/* Appraisal Modal Result Breakdown */}
          {selectedAppraisal && (
            <div className="p-6 rounded-3xl bg-slate-950 text-white border border-indigo-500/40 space-y-5 shadow-2xl animate-in fade-in">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-indigo-400" />
                    Gemini AI Commercial Valuation Report
                  </span>
                  <h4 className="text-2xl font-black text-white tracking-tight">{selectedAppraisal.domain}</h4>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-2xl font-black text-emerald-400 font-mono">${selectedAppraisal.estimatedValue.toLocaleString()}</div>
                    <span className="text-[10px] text-slate-400">Estimated Market Value</span>
                  </div>

                  {/* Add to cart & checkout for the appraised domain */}
                  <div className="flex items-center gap-2 pl-3 border-l border-slate-800">
                    <button
                      type="button"
                      onClick={() => {
                        const sItem = suggestions.find((s) => s.domain === selectedAppraisal.domain) || {
                          domain: selectedAppraisal.domain,
                          tld: `.${selectedAppraisal.domain.split('.').pop()}`,
                          brandScore: selectedAppraisal.brandabilityScore,
                          rationale: selectedAppraisal.summary,
                          estimatedValue: selectedAppraisal.estimatedValue,
                          available: true,
                          price: selectedAppraisal.domain.endsWith('.ai') ? 69.99 : 39.99,
                          category: 'Tech & AI',
                        };
                        handleTriggerAddToCart(mapToDomainResult(sItem, 999));
                      }}
                      className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Add to Cart</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const sItem = suggestions.find((s) => s.domain === selectedAppraisal.domain) || {
                          domain: selectedAppraisal.domain,
                          tld: `.${selectedAppraisal.domain.split('.').pop()}`,
                          brandScore: selectedAppraisal.brandabilityScore,
                          rationale: selectedAppraisal.summary,
                          estimatedValue: selectedAppraisal.estimatedValue,
                          available: true,
                          price: selectedAppraisal.domain.endsWith('.ai') ? 69.99 : 39.99,
                          category: 'Tech & AI',
                        };
                        handleTriggerCheckout(mapToDomainResult(sItem, 999));
                      }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-md flex items-center gap-1.5 transition-all"
                    >
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      <span>Instant Checkout</span>
                    </button>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
                {selectedAppraisal.summary}
              </p>

              {/* Appraisal Metrics Grid */}
              <div className="grid grid-cols-3 gap-3 text-center text-xs">
                <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <div className="font-black text-indigo-400 text-lg font-mono">{selectedAppraisal.brandabilityScore}/100</div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Brandability</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <div className="font-black text-emerald-400 text-lg font-mono">{selectedAppraisal.seoScore}/100</div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">SEO Potential</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <div className="font-black text-pink-400 text-lg font-mono">{selectedAppraisal.lengthScore}/100</div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Length Rating</span>
                </div>
              </div>

              {/* Pros & Challenges */}
              {selectedAppraisal.pros && selectedAppraisal.pros.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-emerald-950/30 border border-emerald-500/20 p-3.5 rounded-2xl space-y-1.5">
                    <span className="text-[10px] font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> Key Strengths
                    </span>
                    <ul className="space-y-1 text-slate-300 text-[11px]">
                      {selectedAppraisal.pros.map((p, pIdx) => (
                        <li key={pIdx} className="flex items-center gap-1.5">
                          <Check className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {selectedAppraisal.comparableSales && selectedAppraisal.comparableSales.length > 0 && (
                    <div className="bg-indigo-950/30 border border-indigo-500/20 p-3.5 rounded-2xl space-y-1.5">
                      <span className="text-[10px] font-black text-indigo-400 uppercase tracking-wider flex items-center gap-1">
                        <TrendingUp className="w-3.5 h-3.5" /> Comparable Market Sales
                      </span>
                      <div className="space-y-1 text-slate-300 text-[11px]">
                        {selectedAppraisal.comparableSales.map((c, cIdx) => (
                          <div key={cIdx} className="flex items-center justify-between font-mono">
                            <span className="text-slate-400">{c.domain} ({c.year})</span>
                            <span className="font-bold text-emerald-400">${c.price.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

        </div>

        {/* BOTTOM STICKY CART & QUICK CHECKOUT DOCK */}
        {cartItems.length > 0 && (
          <div className="absolute bottom-0 inset-x-0 bg-slate-900/95 dark:bg-slate-950/95 backdrop-blur-md border-t border-slate-700 dark:border-slate-800 p-4 px-6 shadow-2xl flex items-center justify-between gap-4 text-white z-20">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                  <ShoppingCart className="w-5 h-5" />
                </div>
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-black text-[10px] flex items-center justify-center border-2 border-slate-900">
                  {cartItems.length}
                </span>
              </div>
              
              <div>
                <div className="text-xs font-black flex items-center gap-2">
                  <span>{cartItems.length} {cartItems.length === 1 ? 'Domain' : 'Domains'} in Cart</span>
                  <span className="text-emerald-400 font-mono font-black text-sm">
                    {formatPrice(totalCartUsd, currency)}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400">Ready for instant registration and automated DNS setup</p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => {
                  if (onOpenCart) onOpenCart();
                }}
                className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all"
              >
                View Cart
              </button>

              <button
                type="button"
                onClick={() => {
                  if (onOpenCheckout) onOpenCheckout();
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/25 flex items-center gap-2 transition-all transform active:scale-95"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
