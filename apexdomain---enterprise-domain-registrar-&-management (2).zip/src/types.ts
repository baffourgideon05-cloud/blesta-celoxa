export type ViewMode = 'card' | 'list' | 'compact' | 'table';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'INR' | 'GHS' | 'CAD' | 'AUD' | 'NGN' | 'ZAR';

export type Language = 'en' | 'es' | 'fr' | 'de' | 'ja';

export interface CustomPaymentConfig {
  enabled: boolean;
  title: string;
  description: string;
  instructions: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  swiftCode?: string;
  momoProvider: string;
  momoNumber: string;
  momoName: string;
  requireProofOfPayment: boolean;
}

export interface PaystackConfig {
  enabled: boolean;
  testMode: boolean;
  environment?: 'test' | 'live';
  publicKey: string;
  secretKey?: string; // Only used when sending replacement key from admin; never exposed in public responses
  isSecretKeyConfigured?: boolean;
  maskedSecretKey?: string;
  merchantName: string;
  allowedChannels: ('card' | 'mobile_money' | 'bank_transfer' | 'ussd')[];
  currencyPreference: 'GHS' | 'USD' | 'NGN';
  callbackUrl?: string;
  webhookUrl?: string;
  lastUpdated?: string;
  healthStatus?: 'healthy' | 'warning' | 'error' | 'unconfigured';
}

export interface PaymentMethodSettings {
  creditCardEnabled?: boolean; // Deprecated: Only Paystack and Custom Payment supported
  customPayment: CustomPaymentConfig;
  paystack: PaystackConfig;
}

export interface PaymentSubmission {
  id: string;
  orderId: string;
  domains: string[];
  amount: number;
  currency: string;
  paymentMethod: 'paystack' | 'custom_manual';
  paystackReference?: string;
  customProofText?: string;
  momoNumberUsed?: string;
  status: 'completed' | 'pending_approval' | 'failed' | 'refunded';
  createdAt: string;
  customerName: string;
  customerEmail: string;
}

export type DomainDetailedStatus = 
  | 'available'
  | 'owned_by_you'
  | 'owned_by_platform_customer'
  | 'external_registered'
  | 'registration_pending'
  | 'premium'
  | 'reserved'
  | 'unable_to_verify';

export interface DomainOwnershipRecord {
  id: string;
  domain: string;
  ownerUserId: string;
  ownerEmail: string;
  ownerName?: string;
  status: 'active' | 'pending_registration' | 'pending_transfer' | 'expired' | 'suspended';
  registeredDate: string;
  expiryDate: string;
  autoRenew: boolean;
  locked: boolean;
  whoisPrivacy: boolean;
  authCode: string;
  nameservers: string[];
  nameserverConfig?: NameserverConfig;
  registrarProvider?: RegistrarProviderType;
  registrarName?: string;
  dnsRecords?: DNSRecord[];
  orderId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface DomainResult {
  id: string;
  domain: string;
  name: string;
  tld: string;
  isAvailable: boolean;
  isPremium: boolean;
  detailedStatus?: DomainDetailedStatus;
  statusMessage?: string;
  isOwnedByCurrentUser?: boolean;
  hasPendingOrder?: boolean;
  ownershipRecordId?: string;
  expiryDate?: string;
  creationDate?: string;
  timelineStep?: 'available' | 'registered' | 'active' | 'grace_period' | 'redemption' | 'pending';
  restrictedReason?: string;
  isBrandRegistered?: boolean;
  brandRegistrar?: string;
  registeredOwnerEmail?: string;
  realRegistrarName?: string;
  registrationPrice: number;
  renewalPrice: number;
  transferPrice: number;
  restorePrice: number;
  icannFee: number;
  category: string;
  description: string;
  timeEstimate: string;
  popularityScore: number;
  characterLength: number;
  brandScore: number;
  hasPrivacyIncluded: boolean;
  isCheckingLive?: boolean;
}

export interface TLDDetail {
  tld: string;
  name: string;
  category: string;
  registrationPrice: number;
  renewalPrice: number;
  transferPrice: number;
  restorePrice: number;
  icannFee: number;
  description: string;
  bestUseCases: string[];
  registrationRules: string[];
  supportedYears: number[];
  popularIn: string;
  faq: { question: string; answer: string }[];
}

export interface CartItem {
  id: string;
  domain: string;
  tld: string;
  registrationPrice: number;
  renewalPrice: number;
  years: number;
  privacyProtection: boolean;
  emailForwarding: boolean;
  dnssecEnabled: boolean;
  hostingAddon: boolean;
  icannFee: number;
  isPremium: boolean;
  itemType?: 'domain' | 'hosting' | 'ssl' | 'email' | 'vps';
  packageName?: string;
  planId?: string;
  billingCycle?: 'monthly' | 'annually' | 'triennially';
  serverRegion?: string;
  diskLimitMb?: number;
  bandwidthLimitGb?: number;
  module?: WhmcsModuleType;
  nameserverConfig?: NameserverConfig;
  registrarProvider?: RegistrarProviderType;
  hostingServerId?: string;
}

export interface DNSRecord {
  id: string;
  type: 'A' | 'AAAA' | 'CNAME' | 'MX' | 'TXT' | 'NS';
  name: string;
  value: string;
  ttl: number;
  priority?: number;
}

export interface EmailForwardRule {
  id: string;
  source: string;
  destination: string;
  active: boolean;
}

export interface RegisteredDomain {
  id: string;
  domain: string;
  registeredDate: string;
  expiryDate: string;
  autoRenew: boolean;
  locked: boolean;
  whoisPrivacy: boolean;
  authCode: string;
  dnsRecords: DNSRecord[];
  nameservers: string[];
  nameserverMode?: 'system_default' | 'custom';
  customNameservers?: string[];
  nameserverUpdatedDate?: string;
  nameserverUpdatedBy?: 'System' | 'Customer' | 'Staff';
  emailForwarding?: EmailForwardRule[];
  status: 'active' | 'expiring_soon' | 'pending_transfer' | 'expired';
  // Financial, Pricing & Billing metadata
  registrationPrice?: number;
  renewalPrice?: number;
  currency?: Currency | string;
  billingCycle?: string;
  orderId?: string;
  invoiceId?: string;
  paymentStatus?: 'Paid' | 'Unpaid' | 'Pending';
  serviceId?: string;
  customerName?: string;
  customerEmail?: string;
  // Admin & Registrar Infrastructure metadata (Admin-only)
  registrarProvider?: RegistrarProviderType | string;
  registrarAccount?: string;
  providerDomainId?: string;
  lastSyncDate?: string;
  syncStatus?: 'synced' | 'pending' | 'failed';
  provisioningState?: 'completed' | 'pending' | 'provisioning' | 'failed';
  contactInfo?: {
    registrantName?: string;
    registrantEmail?: string;
    registrantPhone?: string;
    organization?: string;
    country?: string;
  };
  activityTimeline?: Array<{
    id: string;
    title: string;
    description: string;
    date: string;
    type?: 'registration' | 'payment' | 'nameserver' | 'renewal' | 'system' | 'security';
  }>;
}

export interface Coupon {
  code: string;
  discountPercent: number;
  description: string;
}

export interface SearchFilter {
  availability: 'all' | 'available' | 'registered' | 'premium';
  maxPrice: number;
  minPrice: number;
  category: string;
  maxChars: number;
  tldType: string;
}

export type SortOption = 'price-asc' | 'price-desc' | 'alphabetical' | 'popular' | 'bestselling' | 'recent';

export interface EducationalArticle {
  id: string;
  title: string;
  category: string;
  readTime: string;
  description: string;
  icon: string;
  sections: { title: string; content: string }[];
}

export interface PriceAlertSub {
  id: string;
  domain: string;
  email: string;
  alertType: 'availability' | 'price_drop' | 'backorder';
  createdAt: string;
}

export interface WhoisData {
  domainName: string;
  status: string;
  detailedStatus?: DomainDetailedStatus;
  statusMessage?: string;
  isAvailable?: boolean;
  isBrandRegistered?: boolean;
  isOwnedByCurrentUser?: boolean;
  hasPendingOrder?: boolean;
  ownershipRecord?: DomainOwnershipRecord;
  brandRegistrar?: string;
  brandAccountEmail?: string;
  registrar: string;
  registrarIanaId?: string;
  creationDate: string;
  updatedDate: string;
  expirationDate: string;
  registrantOrganization: string;
  registrantCountry: string;
  nameServers: string[];
  dnssec: string;
  rawWhoisText: string;
  dnsRecords?: { type: string; name: string; value: string; ttl?: number; priority?: number }[];
  httpStatus?: {
    isOnline: boolean;
    statusCode?: number;
    serverHeader?: string;
    ipAddress?: string;
    protocol?: string;
  };
  authoritativeSource?: 'IN_HOUSE_BRAND_DATABASE' | 'LIVE_RDAP_DNS' | 'AUTHORITATIVE_DNS';
}

export interface AiDomainSuggestion {
  domain: string;
  tld: string;
  brandScore: number;
  rationale: string;
  estimatedValue: number;
  available: boolean;
  price: number;
  category: string;
}

export interface AiAppraisalResult {
  domain: string;
  estimatedValue: number;
  brandabilityScore: number;
  seoScore: number;
  lengthScore: number;
  summary: string;
  pros: string[];
  cons: string[];
  comparableSales: { domain: string; price: number; year: number }[];
}

// Service Types (Hosting, SSL, Email, VPS)
export type ServiceType = 'domain' | 'hosting' | 'ssl' | 'email' | 'vps';
export type ServiceStatus = 'active' | 'pending' | 'provisioning' | 'suspended' | 'expiring' | 'expired' | 'cancelled' | 'failed';

export interface HostingService {
  id: string;
  name: string;
  domain: string;
  planName: string;
  diskUsageMb: number;
  diskLimitMb: number;
  bandwidthUsageGb: number;
  bandwidthLimitGb: number;
  ipAddress: string;
  phpVersion: string;
  cpanelUser: string;
  cpanelUrl?: string;
  controlPanelType?: ControlPanelProviderType;
  hostingServerId?: string;
  serverNodeName?: string;
  nameservers?: string[];
  nameserverConfig?: NameserverConfig;
  price: number;
  billingCycle: 'monthly' | 'annually' | 'triennially';
  startDate: string;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  timeline: ServiceTimelineEvent[];
}

export interface SslService {
  id: string;
  domain: string;
  type: 'PositiveSSL' | 'Wildcard SSL' | 'EV SSL' | 'Let\'s Encrypt Free';
  issuer: string;
  issuedDate: string;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  sanDomains: string[];
  timeline: ServiceTimelineEvent[];
}

export interface EmailService {
  id: string;
  domain: string;
  provider: 'Google Workspace' | 'Titan Business Email' | 'Custom cPanel Mail';
  mailboxesCount: number;
  maxMailboxes: number;
  storagePerMailboxGb: number;
  price: number;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  timeline: ServiceTimelineEvent[];
}

export interface VpsService {
  id: string;
  hostname: string;
  os: string;
  vCpus: number;
  ramGb: number;
  ssdGb: number;
  ipAddress: string;
  datacenterRegion: string;
  price: number;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  timeline: ServiceTimelineEvent[];
}

export interface ServiceTimelineEvent {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  type: 'created' | 'provisioned' | 'ssl_installed' | 'upgraded' | 'renewed' | 'suspended' | 'dns_changed';
}

// Customer Account Timeline
export interface CustomerTimelineEvent {
  id: string;
  category: 'service' | 'billing' | 'support' | 'security' | 'domain';
  title: string;
  description: string;
  timestamp: string;
  actor: string;
  statusBadge?: string;
}

// Invoices & Billing
export interface InvoiceItem {
  description: string;
  serviceType: ServiceType;
  amount: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  orderId: string;
  customerName: string;
  customerEmail: string;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  total: number;
  currency: Currency;
  status: 'paid' | 'unpaid' | 'overdue' | 'cancelled';
  issueDate: string;
  dueDate: string;
  paidDate?: string;
  paymentMethod?: string;
}

// Wallet & Credit System
export interface WalletTransaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  currency: Currency;
  description: string;
  reference: string;
  date: string;
  balanceAfter: number;
}

export interface CustomerWallet {
  balance: number;
  currency: Currency;
  transactions: WalletTransaction[];
}

// Team Accounts & Permissions
export type TeamRole = 'Owner' | 'Billing Contact' | 'Technical Contact' | 'Administrative Contact' | 'Support Agent';

export interface TeamMemberPermission {
  viewInvoices: boolean;
  payInvoices: boolean;
  downloadReceipts: boolean;
  manageDomains: boolean;
  manageHosting: boolean;
  cancelHosting: boolean;
  openTickets: boolean;
  manageTeam: boolean;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: TeamRole;
  isPrimaryOwner: boolean;
  status: 'active' | 'invited' | 'disabled';
  addedDate: string;
  permissions: TeamMemberPermission;
}

// Support Tickets, Departments, Knowledge Base & SLAs
export type TicketPriority = 'low' | 'normal' | 'high' | 'urgent' | 'critical';
export type TicketStatus = 
  | 'open' 
  | 'awaiting_admin' 
  | 'admin_replied' 
  | 'in_progress' 
  | 'waiting_customer' 
  | 'resolved' 
  | 'closed' 
  | 'escalated';

export type TicketWaitingFor = 'admin' | 'customer' | 'none';

export interface SupportDepartment {
  id: string;
  name: string;
  description: string;
  email: string;
  assignedStaff: string[];
  autoAssignment: boolean;
  defaultPriority: TicketPriority;
  slaHours: number;
  autoReplyTemplate?: string;
  isActive: boolean;
  ticketsCount?: number;
}

export interface TicketAttachment {
  id?: string;
  name: string;
  sizeKb: number;
  url: string;
  type?: string;
}

export interface TicketSeenRecord {
  seenAt: string;
  staffName?: string;
  staffEmail?: string;
}

export interface TicketMessage {
  id: string;
  ticketId?: string;
  senderName: string;
  senderEmail: string;
  senderRole?: 'customer' | 'support_agent' | 'admin';
  isStaff: boolean;
  isInternalNote: boolean; // Staff only internal notes
  content: string;
  timestamp: string;
  attachments?: TicketAttachment[];
  seenBy?: TicketSeenRecord[];
}

export interface TicketEvent {
  id: string;
  ticketId: string;
  timestamp: string;
  action: string;
  performedBy: string;
  details: string;
  type: 'created' | 'viewed' | 'replied' | 'note_added' | 'status_changed' | 'priority_changed' | 'assigned' | 'resolved' | 'closed' | 'escalated';
}

export interface SupportTicket {
  id: string;
  ticketNumber: string; // e.g. TK-10482
  userId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  subject: string;
  departmentId?: string;
  department: string;
  serviceCategory?: 'Domain' | 'Hosting' | 'Billing' | 'SSL & Security' | 'Email' | 'Technical' | 'General' | 'Other';
  serviceRelated?: string; // e.g. "celoxaghana.online" or "Business Enterprise NVMe"
  relatedDomain?: string;
  relatedHosting?: string;
  relatedInvoice?: string;
  relatedOrderId?: string;
  priority: TicketPriority;
  status: TicketStatus;
  waitingFor: TicketWaitingFor;
  assignedAgent?: string;
  assignedDepartment?: string;
  createdAt: string;
  updatedAt: string;
  lastReplyAt?: string;
  lastReplyBy?: string;
  seenBySupportAt?: string;
  seenBySupportStaff?: string;
  seenByCustomerAt?: string;
  slaTargetHours: number;
  slaDueAt?: string;
  isSlaBreached?: boolean;
  internalNotesCount?: number;
  messages: TicketMessage[];
  events?: TicketEvent[];
  paymentInfo?: {
    invoiceNumber?: string;
    amount?: number;
    currency?: string;
    paymentStatus?: 'paid' | 'pending' | 'failed' | 'unpaid';
    paymentMethod?: string;
    paidAt?: string;
  };
  serviceInfo?: {
    serviceName?: string;
    ipAddress?: string;
    provisioningStatus?: 'active' | 'pending' | 'failed' | 'suspended';
    controlPanelUrl?: string;
  };
  aiSummary?: string;
  aiSuggestedDepartment?: string;
  aiSuggestedPriority?: TicketPriority;
  aiSuggestedReply?: string;
}

export interface KnowledgeBaseArticle {
  id: string;
  title: string;
  slug: string;
  category: 'Domains' | 'Hosting' | 'Billing' | 'cPanel & DNS' | 'Security & SSL' | 'General';
  excerpt: string;
  content: string;
  viewsCount: number;
  helpfulCount: number;
  tags: string[];
  updatedAt: string;
}

export interface SlaRule {
  id: string;
  department: string;
  priority: TicketPriority;
  targetResponseHours: number;
  escalateAfterHours: number;
  enabled: boolean;
}

export interface CannedResponseTemplate {
  id: string;
  title: string;
  category: string;
  content: string;
}

// Renewal Reminder Rules Configurator
export interface RenewalReminderRule {
  id: string;
  days: number;
  timing: 'before_expiry' | 'after_expiry' | 'before_termination';
  enabled: boolean;
  channel: 'email' | 'sms' | 'dashboard_banner';
  subjectTemplate: string;
}

// Global Account Search Result
export interface GlobalSearchResultItem {
  id: string;
  title: string;
  subtitle: string;
  category: 'domain' | 'hosting' | 'invoice' | 'order' | 'ticket' | 'payment' | 'customer';
  status: string;
  linkAction: string;
}

// Impersonation State
export interface ImpersonationState {
  isActive: boolean;
  adminName: string;
  targetCustomerName: string;
  targetCustomerEmail: string;
  reason: string;
  startedAt: string;
}

// ==========================================
// WHMCS HOSTMING SYSTEM EXTENSION TYPES
// ==========================================

export type WhmcsModuleType = 'cpanel' | 'directadmin' | 'plesk' | 'cyberpanel' | 'solusvm' | 'custom_api';

export interface WhmcsServerNode {
  id: string;
  name: string;
  hostname: string;
  ipAddress: string;
  module: WhmcsModuleType;
  serverGroup: string;
  datacenter: string;
  maxAccounts: number;
  activeAccounts: number;
  status: 'online' | 'degraded' | 'maintenance' | 'offline';
  cpuLoadPercentage: number;
  ramUsagePercentage: number;
  diskUsagePercentage: number;
  activeIpPool: string[];
  accessHashConfigured: boolean;
}

export interface WhmcsHostingPackage {
  id: string;
  name: string;
  category: 'Shared Web Hosting' | 'WordPress Cloud' | 'Reseller Hosting' | 'KVM VPS' | 'Dedicated Server';
  module: WhmcsModuleType;
  description: string;
  diskLimitMb: number; // 0 = unlimited
  bandwidthLimitGb: number; // 0 = unlimited
  maxDatabases: number;
  maxSubdomains: number;
  maxMailboxes: number;
  priceMonthly: number;
  priceAnnually: number;
  freeDomainEligible: boolean;
  features: string[];
}

export interface WhmcsProvisioningQueueItem {
  id: string;
  serviceId: string;
  domain: string;
  packageName: string;
  action: 'Create Account' | 'Suspend Account' | 'Unsuspend Account' | 'Terminate Account' | 'Change Package' | 'Reset Password';
  serverId: string;
  serverName: string;
  status: 'queued' | 'processing' | 'success' | 'failed';
  errorMessage?: string;
  queuedAt: string;
  completedAt?: string;
}

export interface WhmcsAutomationCronLog {
  id: string;
  jobName: string;
  category: 'Billing & Invoicing' | 'Domain Sync' | 'Provisioning Queue' | 'Auto-Suspension' | 'SSL Issuance';
  executedAt: string;
  status: 'success' | 'warning' | 'error';
  recordsProcessed: number;
  details: string;
}

export interface WhmcsCpanelEmailAccount {
  id: string;
  email: string;
  usageMb: number;
  quotaMb: number;
  forwardTo?: string;
}

export interface WhmcsCpanelDatabase {
  id: string;
  dbName: string;
  dbUser: string;
  sizeMb: number;
}

export interface WhmcsSoftaculousApp {
  id: string;
  name: string;
  category: 'CMS' | 'E-Commerce' | 'Framework' | 'Forum' | 'Wiki';
  version: string;
  installedUrl: string;
  installedPath: string;
  dbName: string;
  installedDate: string;
  autoUpdate: boolean;
}

export interface SystemSettingsConfig {
  general: {
    siteName: string;
    companyName: string;
    contactEmail: string;
    supportPhone: string;
    logoUrl: string;
    defaultCurrency: Currency;
    defaultLanguage: Language;
    timezone: string;
    maintenanceMode: boolean;
  };
  hostingProvisioning: {
    autoProvisionOnPayment: boolean;
    defaultServerManager: 'whmcs' | 'cpanel' | 'directadmin' | 'plesk';
    defaultNameservers: [string, string, string, string];
    serverNodePool: string;
    autoSslEnabled: boolean;
    cpanelTheme: string;
    phpVersion: string;
  };
  domains: {
    defaultPricingMarkupPercent: number;
    autoRenewGraceDays: number;
    defaultWhoisPrivacy: boolean;
    requireEppForTransfers: boolean;
  };
  securityAntiSpam: {
    captchaProvider: 'recaptcha_v3' | 'recaptcha_v2' | 'turnstile' | 'hcaptcha' | 'none';
    ipRateLimitRequestsPerMin: number;
    stopForumSpamEnabled: boolean;
    disposableEmailFilter: boolean;
    staffIpWhitelist: string[];
    centralSecurityAlerts: boolean;
    staffPortalPath?: string;
    adminPortalPath?: string;
    requireMfaForStaff?: boolean;
    requireMfaForAdmin?: boolean;
    sessionTimeoutMinutes?: number;
  };
  billing: {
    autoExchangeRateSync: boolean;
    rateSyncProvider: 'ExchangeRate-API' | 'CurrencyDataAPI' | 'currencylayer';
    invoicePrefix: string;
    invoiceDueDays: number;
    defaultTaxRate: number;
  };
  notifications: {
    smtpHost: string;
    smtpPort: number;
    smtpUser: string;
    smtpFromEmail: string;
    sendLowDiskAlerts: boolean;
    sendSslExpiryAlerts: boolean;
  };
}

// ==========================================
// IDENTITY & ACCESS MANAGEMENT (IAM) TYPES
// ==========================================

export type PlatformRole = 'super_admin' | 'administrator' | 'staff' | 'client';

export type UserAccountStatus = 'active' | 'pending_verification' | 'suspended' | 'locked' | 'deactivated';

export interface ModulePermissions {
  customers: { view: boolean; create: boolean; edit: boolean; suspend: boolean; delete: boolean };
  domains: { view: boolean; register: boolean; transfer: boolean; editDns: boolean; delete: boolean };
  hosting: { view: boolean; provision: boolean; suspend: boolean; unsuspend: boolean; terminate: boolean };
  billing: { viewInvoices: boolean; createInvoice: boolean; refundPayment: boolean; managePaymentSettings: boolean };
  servers: { view: boolean; manage: boolean; restart: boolean };
  staff: { view: boolean; create: boolean; edit: boolean; suspend: boolean; manageRoles: boolean };
  systemSettings: { view: boolean; edit: boolean };
  auditLogs: { view: boolean; export: boolean };
}

export interface UserSession {
  id: string;
  userId: string;
  device: string;
  ip: string;
  location: string;
  createdAt: string;
  lastActiveAt: string;
  isCurrent: boolean;
}

export interface LoginActivityRecord {
  id: string;
  userId: string;
  userEmail: string;
  timestamp: string;
  device: string;
  ip: string;
  status: 'success' | 'failed';
  failureReason?: string;
}

export interface StaffInvitation {
  id: string;
  email: string;
  fullName: string;
  role: PlatformRole;
  department?: string;
  staffTitle?: string;
  permissions: ModulePermissions;
  token: string;
  expiresAt: string;
  status: 'pending' | 'accepted' | 'expired';
  createdByEmail: string;
  createdAt: string;
}

export interface ClientApiKey {
  id: string;
  userId: string;
  keyName: string;
  keySecret: string;
  scopes: ('domain:read' | 'domain:write' | 'hosting:read' | 'hosting:write' | 'billing:read' | 'tickets:write')[];
  createdAt: string;
  lastUsedAt?: string;
  active: boolean;
}

// ==========================================
// MASTER HOSTING CATALOGUE SYSTEM TYPES
// ==========================================

export type HostingPlanStatus = 'draft' | 'active' | 'hidden' | 'archived';
export type HostingCategoryStatus = 'active' | 'draft' | 'hidden' | 'archived';
export type HostingBillingCycle = 'monthly' | 'quarterly' | 'semiAnnual' | 'annual' | 'biennial' | 'triennial';
export type HostingFeatureGroup = 'resources' | 'security' | 'email' | 'tools' | 'support' | 'performance';

export interface HostingCategory {
  id: string;
  name: string;
  slug: string;
  shortDescription: string;
  fullDescription: string;
  icon: string; // Lucide icon name e.g. "Globe", "Zap", "Server", "Cpu", "HardDrive", "Mail", "ShieldCheck", "Layers", "Sparkles", "Cloud"
  bannerImage?: string;
  categoryImage?: string;
  badge?: string; // e.g. "Most Popular", "Best for Beginners", "Enterprise Grade", "For Agencies"
  displayOrder: number;
  status: HostingCategoryStatus;
  featured: boolean;
  seoTitle?: string;
  seoDescription?: string;
  commonFeatures?: string[]; // "What's included in all plans"
  createdAt?: string;
  updatedAt?: string;
}

export interface HostingFeature {
  id: string;
  name: string;
  group: HostingFeatureGroup;
  icon: string; // Lucide icon name
  description: string;
  tooltip?: string;
  highlight: boolean;
  displayOrder?: number;
}

export interface HostingPlanPricing {
  monthly?: number;
  quarterly?: number;
  semiAnnual?: number;
  annual?: number;
  biennial?: number; // 2-year
  triennial?: number; // 3-year
  setupFee: number;
  discountPercent?: number; // e.g. 20% off annual
  enabledCycles: HostingBillingCycle[];
  currency: Currency;
}

export interface HostingPlanResources {
  storageGb: number | 'unlimited';
  storageType: 'NVMe SSD' | 'SATA SSD' | 'Enterprise SSD' | 'Cloud Block Storage';
  bandwidthGb: number | 'unlimited';
  websites: number | 'unlimited';
  domains: number | 'unlimited';
  subdomains: number | 'unlimited';
  emailAccounts: number | 'unlimited';
  databases: number | 'unlimited';
  ftpAccounts: number | 'unlimited';
  cpuCores: number | string;
  ramGb: number | string;
  inodes: number | string;
  processes: number | string;
  backups: string;
  ssl: string;
  dedicatedIp: boolean;
}

export interface HostingPlan {
  id: string;
  name: string;
  slug: string;
  categoryId: string; // references HostingCategory.id
  shortDescription: string;
  fullDescription: string;
  icon: string;
  badge?: string; // e.g. "Most Popular", "Best Value", "Recommended", "New", "Limited Offer", "Business Choice", "Starter", "Premium"
  featured: boolean;
  displayOrder: number;
  status: HostingPlanStatus;
  pricing: HostingPlanPricing;
  resources: HostingPlanResources;
  featureIds: string[]; // references HostingFeature.id
  customFeatureValues?: Record<string, string>; // featureId -> custom text (e.g. "10 GB NVMe Storage")
  controlPanels: ('cpanel' | 'directadmin' | 'plesk' | 'cyberpanel' | 'custom_api')[];
  serverNodeIds?: string[];
  preinstalledApps?: string[];
  freeDomainEligible: boolean;
  freeDomainTlds?: string[];
  technicalSpecs?: Record<string, string>;
  faq?: { question: string; answer: string }[];
  createdAt?: string;
  updatedAt?: string;
}

export interface HostingServer {
  id: string;
  name: string;
  hostname: string;
  ipAddress: string;
  location: string; // e.g. "Accra, Ghana 🇬🇭", "London, UK 🇬🇧", "Frankfurt, Germany 🇩🇪", "New York, USA 🇺🇸"
  locationCode: string; // "GH", "UK", "DE", "US"
  provider: string; // "MainOne / MDXi Datacenter", "Equinix London", "Hetzner Frankfurt", "AWS US-East"
  controlPanel: 'cpanel' | 'directadmin' | 'plesk' | 'cyberpanel';
  apiEndpoint: string;
  apiCredentialsConfigured: boolean;
  maxCapacityAccounts: number;
  activeAccounts: number;
  status: 'online' | 'degraded' | 'maintenance' | 'offline';
  cpuLoad: number;
  ramUsage: number;
  diskUsage: number;
  pingMs: number;
}

export interface HostingPromotion {
  id: string;
  code: string;
  title: string;
  description: string;
  discountPercent: number;
  discountType: 'percent' | 'fixed';
  applicableCategoryIds: string[]; // empty = all
  applicablePlanIds: string[]; // empty = all
  minBillingCycle?: HostingBillingCycle;
  startDate: string;
  endDate: string;
  maxUses: number;
  usedCount: number;
  isActive: boolean;
}

export interface HostingUpgradeCalculation {
  currentPlan: HostingPlan;
  targetPlan: HostingPlan;
  currentBillingCycle: HostingBillingCycle;
  targetBillingCycle: HostingBillingCycle;
  daysRemaining: number;
  totalCycleDays: number;
  proratedCreditCurrentPlan: number;
  proratedCostTargetPlan: number;
  payableDifference: number;
  currency: Currency;
}

// ==========================================
// REGISTRAR & CONTROL PANEL ADAPTERS & QUEUE
// ==========================================

export type RegistrarProviderType = 'internal' | 'resellerclub' | 'godaddy' | 'enom' | 'namecheap' | 'custom_api';

export interface NameserverConfig {
  mode: 'system_default' | 'custom';
  ns1: string;
  ns2: string;
  ns3?: string;
  ns4?: string;
  lastUpdated: string;
  syncStatus: 'synced' | 'pending' | 'failed';
  syncedRegistrar?: string;
  lastError?: string;
}

export interface RegistrarConfig {
  id: string;
  name: string;
  provider: RegistrarProviderType;
  isDefault: boolean;
  isEnabled: boolean;
  testMode: boolean; // Sandbox / OTE vs Live
  apiKey?: string;
  apiSecret?: string;
  resellerId?: string;
  username?: string;
  password?: string;
  endpointUrl?: string;
  defaultNameservers: [string, string, string, string];
  autoRenewSupport: boolean;
  dnsManagementSupport: boolean;
  privacyProtectionSupport: boolean;
  lastSyncTime?: string;
  status: 'connected' | 'error' | 'untested';
  statusMessage?: string;
  accountBalance?: { amount: number; currency: string };
}

export interface RegistrarApiLog {
  id: string;
  registrarId: string;
  registrarName: string;
  provider: RegistrarProviderType;
  action: 'check_availability' | 'register' | 'renew' | 'transfer' | 'update_nameservers' | 'get_details' | 'test_connection' | 'sync_status';
  domain?: string;
  status: 'success' | 'failed';
  requestPayload?: string;
  responsePayload?: string;
  errorMessage?: string;
  executionTimeMs: number;
  timestamp: string;
}

export type ControlPanelProviderType = 'cpanel' | 'directadmin' | 'plesk' | 'cyberpanel' | 'internal';

export interface HostingControlPanelConfig {
  id: string;
  name: string;
  provider: ControlPanelProviderType;
  hostname: string;
  ipAddress: string;
  apiEndpoint: string;
  apiToken?: string;
  username: string;
  password?: string;
  isDefault: boolean;
  isEnabled: boolean;
  sslAutoInstall: boolean;
  defaultNameservers: [string, string, string, string];
  cpanelTheme?: string;
  maxAccounts: number;
  activeAccounts: number;
  status: 'connected' | 'error' | 'untested';
  statusMessage?: string;
  lastHealthCheck?: string;
}

export interface ControlPanelApiLog {
  id: string;
  panelId: string;
  panelName: string;
  provider: ControlPanelProviderType;
  action: 'test_connection' | 'create_account' | 'suspend_account' | 'unsuspend_account' | 'terminate_account' | 'change_package' | 'reset_password' | 'change_password' | 'sso_login' | 'sync_packages';
  username?: string;
  domain?: string;
  status: 'success' | 'failed';
  requestPayload?: string;
  responsePayload?: string;
  errorMessage?: string;
  executionTimeMs: number;
  timestamp: string;
}

export interface ProvisioningJobStep {
  name: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  timestamp?: string;
  details?: string;
  error?: string;
}

export interface ProvisioningJob {
  id: string;
  orderId: string;
  invoiceId: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  domain?: string;
  packageName?: string;
  planId?: string;
  serviceType: 'domain' | 'hosting' | 'bundle';
  registrarProvider: RegistrarProviderType;
  hostingProvider: ControlPanelProviderType;
  hostingServerId?: string;
  nameserverMode: 'system_default' | 'custom';
  nameservers: string[];
  status: 'queued' | 'provisioning' | 'completed' | 'failed' | 'retrying';
  currentStep: string;
  steps: ProvisioningJobStep[];
  errorDetails?: string;
  retryCount: number;
  maxRetries: number;
  provisionedServiceId?: string;
  cpanelUsername?: string;
  cpanelUrl?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

// ==========================================
// BRANDED EMAIL TEMPLATES SYSTEM
// ==========================================

export type EmailTemplateId = 
  | 'PAYMENT_RECEIVED'
  | 'INVOICE_CREATED'
  | 'INVOICE_MARKED_PAID'
  | 'HOSTING_ACCOUNT_CREATED'
  | 'DOMAIN_REGISTERED'
  | 'DOMAIN_RENEWAL'
  | 'PROVISIONING_FAILED'
  | 'SERVICE_SUSPENDED'
  | 'SERVICE_TERMINATED'
  | 'PASSWORD_RESET';

export interface EmailBrandingConfig {
  companyName: string;
  logoUrl: string;
  senderName: string;
  senderEmail: string;
  supportEmail: string;
  supportPhone?: string;
  websiteUrl: string;
  primaryColor: string;
  accentColor: string;
  footerText: string;
}

export interface EmailTemplate {
  id: EmailTemplateId;
  name: string;
  category: 'billing' | 'hosting' | 'domain' | 'system';
  subjectTemplate: string;
  bodyTemplate: string;
  variables: string[];
  description: string;
  enabled: boolean;
  lastUpdated: string;
}

export interface EmailOutboxRecord {
  id: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  templateId: EmailTemplateId;
  category: string;
  status: 'sent' | 'queued' | 'failed';
  renderedHtml: string;
  sentAt: string;
  relatedOrderId?: string;
  relatedServiceId?: string;
  errorMessage?: string;
}




