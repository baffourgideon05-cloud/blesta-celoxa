import { ModulePermissions, PlatformRole } from '../types';
import { systemDatabase, SystemUser } from './systemDatabase';

export interface NavMenuItem {
  id: string;
  title: string;
  subtitle?: string;
  iconName: string;
  badge?: string;
  viewKey: string;
  requiredPermission?: keyof ModulePermissions;
  requiredSubPermission?: string;
  minRole?: PlatformRole | 'any_staff' | 'authenticated';
  isExternal?: boolean;
}

export interface NavMenuGroup {
  groupId: string;
  groupTitle: string;
  items: NavMenuItem[];
}

/**
 * MASTER ACCESS-CONTROL & ROLE-BASED AUTHORIZATION ENGINE (RBAC)
 * 
 * Ideology:
 * 1. Authentication answers: "Who are you?"
 * 2. Authorization answers: "What are you allowed to access?"
 * 3. Menus are dynamically built according to user identity, role, and permissions.
 * 4. Protected views & data resources are enforced server-side/backend.
 *    Hiding a menu item is a UX convenience, NOT the security boundary.
 */
export class AccessControlEngine {
  
  /**
   * Evaluates if a given user has permission to access a target view/route key.
   */
  public static canAccessView(user: SystemUser | null, viewKey: string): { 
    allowed: boolean; 
    reason?: string; 
    redirectView: string; 
    statusCode: number 
  } {
    // 1. PUBLIC VIEWS (Accessible by anyone, authenticated or anonymous)
    const publicViews = [
      'search',
      'tlds',
      'academy',
      'visitor_analytics',
      'hosting_packages',
      'bulk',
      'about',
      'contact',
      'support_public',
      'pricing',
      'knowledgebase'
    ];

    if (publicViews.includes(viewKey)) {
      return { allowed: true, redirectView: viewKey, statusCode: 200 };
    }

    // 2. UNAUTHENTICATED USER ATTEMPTING PROTECTED ROUTE
    if (!user) {
      return {
        allowed: false,
        reason: 'Authentication required. Please sign in to access your portal.',
        redirectView: 'search',
        statusCode: 401
      };
    }

    // 3. ACCOUNT STATUS CHECK
    if (user.accountStatus === 'suspended') {
      return {
        allowed: false,
        reason: 'ACCOUNT SUSPENDED: Your account has been suspended by an administrator. Access is restricted.',
        redirectView: 'search',
        statusCode: 403
      };
    }

    if (user.accountStatus === 'locked') {
      return {
        allowed: false,
        reason: 'ACCOUNT LOCKED: Security lock active. Please reset your credentials.',
        redirectView: 'search',
        statusCode: 403
      };
    }

    const role = user.platformRole || user.role;

    // 4. CLIENT PORTAL VIEWS
    const clientPortalViews = [
      'client_portal',
      'dashboard',
      'command_center',
      'management',
      'services',
      'billing',
      'wallet',
      'renewals',
      'calendar',
      'team',
      'tickets',
      'timeline',
      'security'
    ];

    if (clientPortalViews.includes(viewKey)) {
      return { allowed: true, redirectView: viewKey, statusCode: 200 };
    }

    // 5. STAFF PORTAL VIEWS
    const staffViews = ['staff_portal'];
    if (staffViews.includes(viewKey)) {
      if (role === 'staff' || role === 'administrator' || role === 'super_admin' || user.role === 'admin') {
        return { allowed: true, redirectView: viewKey, statusCode: 200 };
      }
      return {
        allowed: false,
        reason: '403 FORBIDDEN: Staff or Administrative authorization required to access Staff Operations Portal.',
        redirectView: 'client_portal',
        statusCode: 403
      };
    }

    // 6. ADMIN PORTAL VIEWS
    const adminViews = ['settings', 'hosting_provision', 'admin_iam', 'admin_hosting_packages'];
    if (adminViews.includes(viewKey)) {
      if (role === 'super_admin' || role === 'administrator' || user.role === 'admin' || user.role === 'super_admin') {
        
        if (viewKey === 'admin_iam') {
          const hasStaffPerm = user.permissions?.staff?.view || role === 'super_admin';
          if (!hasStaffPerm) {
            return {
              allowed: false,
              reason: '403 FORBIDDEN: Your account role does not have "staff.view" permissions.',
              redirectView: 'staff_portal',
              statusCode: 403
            };
          }
        }

        if (viewKey === 'settings') {
          const hasSysPerm = user.permissions?.systemSettings?.view || role === 'super_admin' || role === 'administrator';
          if (!hasSysPerm) {
            return {
              allowed: false,
              reason: '403 FORBIDDEN: Your account role does not have "systemSettings.view" permissions.',
              redirectView: 'staff_portal',
              statusCode: 403
            };
          }
        }

        return { allowed: true, redirectView: viewKey, statusCode: 200 };
      }

      return {
        allowed: false,
        reason: '403 FORBIDDEN: Administrator authorization required to access Platform Management System.',
        redirectView: 'client_portal',
        statusCode: 403
      };
    }

    return { allowed: true, redirectView: viewKey, statusCode: 200 };
  }

  /**
   * Enforces data-level ownership check.
   */
  public static checkDataOwnership(user: SystemUser | null, resourceOwnerUserId: string): boolean {
    if (!user) return false;

    const role = user.platformRole || user.role;
    if (role === 'super_admin' || role === 'administrator' || role === 'staff' || user.role === 'admin') {
      return true;
    }

    return user.id === resourceOwnerUserId;
  }

  /**
   * Dynamically constructs the user's authorized navigation menu according to role and permissions.
   */
  public static getDynamicMenu(user: SystemUser | null): NavMenuGroup[] {
    if (!user) {
      return [
        {
          groupId: 'public',
          groupTitle: 'Public Storefront & Services',
          items: [
            { id: 'search', title: 'Domain Search', iconName: 'Search', viewKey: 'search' },
            { id: 'hosting_packages', title: 'Web Hosting Plans', iconName: 'Server', viewKey: 'hosting_packages' },
            { id: 'tlds', title: 'TLD Catalog', iconName: 'FolderGit2', viewKey: 'tlds' },
            { id: 'academy', title: 'Knowledge Base', iconName: 'BookOpen', viewKey: 'academy' },
          ]
        }
      ];
    }

    const role = user.platformRole || user.role;
    const perms = user.permissions;

    if (role === 'client') {
      return [
        {
          groupId: 'client_portal',
          groupTitle: 'Client Account Portal',
          items: [
            { id: 'client_dashboard', title: 'Client Dashboard', subtitle: 'Account Overview, Active Services & Orders', iconName: 'LayoutGrid', viewKey: 'client_portal' },
            { id: 'client_domains', title: 'My Domains', subtitle: 'Manage Registrations, DNS & Renewals', iconName: 'Globe', viewKey: 'management' },
            { id: 'client_hosting', title: 'My Hosting Services', subtitle: 'cPanel Accounts, Bandwidth & SSL', iconName: 'Server', viewKey: 'services' },
            { id: 'client_billing', title: 'Billing & Invoices', subtitle: 'Invoices, Wallet Credit & Receipts', iconName: 'CreditCard', viewKey: 'billing' },
            { id: 'client_support', title: 'Support & Tickets', subtitle: 'Submit Tickets & Technical Assistance', iconName: 'Headphones', viewKey: 'tickets' },
            { id: 'client_security', title: 'Account & Security', subtitle: 'Profile, Passwords, MFA & API Keys', iconName: 'ShieldCheck', viewKey: 'security' },
          ]
        },
        {
          groupId: 'storefront',
          groupTitle: 'Storefront & Products',
          items: [
            { id: 'search', title: 'Domain Search', iconName: 'Search', viewKey: 'search' },
            { id: 'hosting_packages', title: 'Explore Hosting Plans', iconName: 'Zap', viewKey: 'hosting_packages' },
            { id: 'bulk', title: 'Bulk Tools', iconName: 'Layers', viewKey: 'bulk' },
            { id: 'tlds', title: 'TLD Directory', iconName: 'FolderGit2', viewKey: 'tlds' },
          ]
        }
      ];
    }

    if (role === 'staff') {
      const staffItems: NavMenuItem[] = [
        { id: 'staff_dashboard', title: 'Staff Operations Hub', subtitle: 'Internal Service Queue, Tickets & Operations', iconName: 'Server', viewKey: 'staff_portal' },
        { id: 'client_dashboard', title: 'Client Area Preview', subtitle: 'View Platform as Client', iconName: 'LayoutGrid', viewKey: 'client_portal' },
      ];

      if (perms?.customers?.view) {
        staffItems.push({ id: 'staff_customers', title: 'Customer Search & Profiles', iconName: 'User', viewKey: 'staff_portal' });
      }
      if (perms?.hosting?.view || perms?.hosting?.provision) {
        staffItems.push({ id: 'staff_hosting', title: 'Hosting Provisioning & Servers', iconName: 'Server', viewKey: 'staff_portal' });
      }

      return [
        {
          groupId: 'staff_portal',
          groupTitle: 'Staff Internal Portal',
          items: staffItems
        },
        {
          groupId: 'storefront',
          groupTitle: 'Public Website',
          items: [
            { id: 'search', title: 'Domain Search', iconName: 'Search', viewKey: 'search' },
            { id: 'hosting_packages', title: 'Hosting Plans', iconName: 'Zap', viewKey: 'hosting_packages' },
          ]
        }
      ];
    }

    return [
      {
        groupId: 'admin_portal',
        groupTitle: 'Administrator Control Center',
        items: [
          { id: 'admin_iam', title: 'Staff & IAM Management', subtitle: 'Users, Roles, Invitations & Security', iconName: 'ShieldCheck', viewKey: 'admin_iam' },
          { id: 'admin_hosting', title: 'Hosting Plans & Cluster', subtitle: 'Manage Packages, Servers & Gateways', iconName: 'Server', viewKey: 'admin_hosting_packages' },
          { id: 'hosting_provision', title: 'Automated Provisioner', subtitle: 'cPanel/WHM Queue & Infrastructure Tasks', iconName: 'Zap', viewKey: 'hosting_provision' },
          { id: 'settings', title: 'System Settings', subtitle: 'Global Config, Payment Gateways & Mail', iconName: 'Settings', viewKey: 'settings' },
        ]
      },
      {
        groupId: 'portals',
        groupTitle: 'Cross-Portal Views',
        items: [
          { id: 'staff_portal', title: 'Staff Operations Portal', iconName: 'Server', viewKey: 'staff_portal' },
          { id: 'client_portal', title: 'Client Account Portal', iconName: 'LayoutGrid', viewKey: 'client_portal' },
          { id: 'visitor_analytics', title: 'Platform Analytics', iconName: 'TrendingUp', viewKey: 'visitor_analytics' },
          { id: 'search', title: 'Public Storefront', iconName: 'Search', viewKey: 'search' },
        ]
      }
    ];
  }
}
