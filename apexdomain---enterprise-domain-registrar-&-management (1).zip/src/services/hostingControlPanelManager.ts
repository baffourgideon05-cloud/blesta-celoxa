import { HostingControlPanelConfig, ControlPanelApiLog, ControlPanelProviderType } from '../types';
import { systemDatabase } from './systemDatabase';

const STORAGE_SERVERS_KEY = 'CELOXA_HOSTING_SERVERS_CONFIG_V1';
const STORAGE_SERVER_LOGS_KEY = 'CELOXA_HOSTING_SERVER_LOGS_V1';

export const DEFAULT_HOSTING_SERVERS: HostingControlPanelConfig[] = [
  {
    id: 'srv-cpanel-gh1',
    name: 'Ghana Primary Cloud Cluster (cPanel/WHM)',
    provider: 'cpanel',
    hostname: 'whm01.accra.celoxaghana.online',
    ipAddress: '154.160.10.45',
    apiEndpoint: 'https://whm01.accra.celoxaghana.online:2087/json-api/',
    username: 'root',
    apiToken: 'WHM_SEC_TOKEN_9941a8e8b21c',
    isDefault: true,
    isEnabled: true,
    sslAutoInstall: true,
    defaultNameservers: [
      'ns1.celoxaghana.online',
      'ns2.celoxaghana.online',
      'ns3.celoxaghana.online',
      'ns4.celoxaghana.online',
    ],
    cpanelTheme: 'jupiter',
    maxAccounts: 500,
    activeAccounts: 184,
    status: 'connected',
    statusMessage: 'WHM API v1 Authenticated • cPanel v118.0.8 (Accra Tier 3 DC)',
    lastHealthCheck: new Date().toISOString(),
  },
  {
    id: 'srv-cpanel-us1',
    name: 'US-East High Speed NVMe cPanel',
    provider: 'cpanel',
    hostname: 'us-cpanel01.celoxaghana.online',
    ipAddress: '198.51.100.42',
    apiEndpoint: 'https://us-cpanel01.celoxaghana.online:2087/json-api/',
    username: 'root',
    apiToken: 'WHM_TOKEN_US_EAST_8832',
    isDefault: false,
    isEnabled: true,
    sslAutoInstall: true,
    defaultNameservers: [
      'ns1.celoxaghana.online',
      'ns2.celoxaghana.online',
      'ns3.celoxaghana.online',
      'ns4.celoxaghana.online',
    ],
    cpanelTheme: 'jupiter',
    maxAccounts: 300,
    activeAccounts: 142,
    status: 'connected',
    statusMessage: 'cPanel NVMe Node Online (Equinix NY4)',
    lastHealthCheck: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 'srv-da-eu1',
    name: 'Frankfurt DirectAdmin Node',
    provider: 'directadmin',
    hostname: 'da01.fra.celoxaghana.online',
    ipAddress: '198.51.100.88',
    apiEndpoint: 'https://da01.fra.celoxaghana.online:2222/CMD_API_',
    username: 'admin',
    password: '••••••••••••',
    isDefault: false,
    isEnabled: true,
    sslAutoInstall: true,
    defaultNameservers: [
      'ns1.celoxaghana.online',
      'ns2.celoxaghana.online',
      'ns3.celoxaghana.online',
      'ns4.celoxaghana.online',
    ],
    maxAccounts: 200,
    activeAccounts: 88,
    status: 'connected',
    statusMessage: 'DirectAdmin v1.65 Enhanced API Ready (Frankfurt)',
    lastHealthCheck: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: 'srv-plesk-sg1',
    name: 'Singapore Enterprise Plesk Obsidian',
    provider: 'plesk',
    hostname: 'plesk01.sin.celoxaghana.online',
    ipAddress: '203.0.113.105',
    apiEndpoint: 'https://plesk01.sin.celoxaghana.online:8443/api/v2/',
    username: 'admin',
    apiToken: 'PLESK_API_KEY_9921',
    isDefault: false,
    isEnabled: true,
    sslAutoInstall: true,
    defaultNameservers: [
      'ns1.celoxaghana.online',
      'ns2.celoxaghana.online',
      'ns3.celoxaghana.online',
      'ns4.celoxaghana.online',
    ],
    maxAccounts: 150,
    activeAccounts: 45,
    status: 'connected',
    statusMessage: 'Plesk Obsidian REST API Validated (Singapore)',
    lastHealthCheck: new Date(Date.now() - 3600000 * 8).toISOString(),
  },
];

class HostingControlPanelManager {
  private servers: HostingControlPanelConfig[] = [];
  private logs: ControlPanelApiLog[] = [];
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      const raw = localStorage.getItem(STORAGE_SERVERS_KEY);
      if (raw) {
        this.servers = JSON.parse(raw);
      } else {
        this.servers = DEFAULT_HOSTING_SERVERS;
        this.saveServers();
      }

      const rawLogs = localStorage.getItem(STORAGE_SERVER_LOGS_KEY);
      if (rawLogs) {
        this.logs = JSON.parse(rawLogs);
      } else {
        this.logs = this.getInitialLogs();
        this.saveLogs();
      }
    } catch (e) {
      console.error('[HostingControlPanelManager] Storage error:', e);
      this.servers = DEFAULT_HOSTING_SERVERS;
      this.logs = this.getInitialLogs();
    }
  }

  private saveServers() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_SERVERS_KEY, JSON.stringify(this.servers));
    } catch (e) {
      console.error('[HostingControlPanelManager] Failed to save servers:', e);
    }
  }

  private saveLogs() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_SERVER_LOGS_KEY, JSON.stringify(this.logs.slice(0, 200)));
    } catch (e) {
      console.error('[HostingControlPanelManager] Failed to save logs:', e);
    }
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  public subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private getInitialLogs(): ControlPanelApiLog[] {
    return [
      {
        id: 'cplog-1',
        panelId: 'srv-cpanel-gh1',
        panelName: 'Ghana Primary Cloud Cluster (cPanel/WHM)',
        provider: 'cpanel',
        action: 'create_account',
        domain: 'enterpriseghana.com',
        username: 'enterpris',
        status: 'success',
        requestPayload: JSON.stringify({
          plan: 'NVMe Starter Hosting',
          domain: 'enterpriseghana.com',
          user: 'enterpris',
          quota: '10000M',
          bwlimit: '250000M',
          ssl: true,
        }),
        responsePayload: JSON.stringify({
          result: [{ status: 1, statusmsg: 'Account Creation Ok', rawout: 'Added /home/enterpris' }],
          cpanelUrl: 'https://whm01.accra.celoxaghana.online:2083',
          ip: '154.160.10.45',
        }),
        executionTimeMs: 420,
        timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
      },
      {
        id: 'cplog-2',
        panelId: 'srv-cpanel-gh1',
        panelName: 'Ghana Primary Cloud Cluster (cPanel/WHM)',
        provider: 'cpanel',
        action: 'test_connection',
        status: 'success',
        requestPayload: JSON.stringify({ command: 'version' }),
        responsePayload: JSON.stringify({ version: '118.0.8', status: 1 }),
        executionTimeMs: 95,
        timestamp: new Date(Date.now() - 3600000 * 6).toISOString(),
      },
    ];
  }

  public getServers(): HostingControlPanelConfig[] {
    return [...this.servers];
  }

  public getServerById(id: string): HostingControlPanelConfig | undefined {
    return this.servers.find((s) => s.id === id);
  }

  public getDefaultServer(): HostingControlPanelConfig {
    return this.servers.find((s) => s.isDefault) || this.servers[0] || DEFAULT_HOSTING_SERVERS[0];
  }

  public saveServer(config: HostingControlPanelConfig) {
    const exists = this.servers.some((s) => s.id === config.id);
    let updated: HostingControlPanelConfig[];

    if (config.isDefault) {
      this.servers = this.servers.map((s) => ({ ...s, isDefault: s.id === config.id }));
    }

    if (exists) {
      updated = this.servers.map((s) => (s.id === config.id ? config : s));
    } else {
      updated = [...this.servers, config];
    }

    this.servers = updated;
    this.saveServers();
    this.notify();

    systemDatabase.logAuditEvent(
      'UPDATE_SERVER_NODE',
      config.name,
      `Control Panel ${config.provider.toUpperCase()} config updated (${config.hostname})`
    );
  }

  public setDefaultServer(id: string) {
    this.servers = this.servers.map((s) => ({
      ...s,
      isDefault: s.id === id,
    }));
    this.saveServers();
    this.notify();
  }

  public async testConnection(id: string): Promise<{ success: boolean; message: string; latencyMs: number; accounts?: number }> {
    const server = this.getServerById(id);
    if (!server) return { success: false, message: 'Server not found', latencyMs: 0 };

    const startTime = performance.now();
    await new Promise((resolve) => setTimeout(resolve, Math.floor(Math.random() * 150) + 120));
    const latencyMs = Math.round(performance.now() - startTime);

    const success = true;
    const message = `Connected to ${server.name} via ${server.provider.toUpperCase()} API. Load: Normal, Accounts: ${server.activeAccounts}/${server.maxAccounts}.`;

    this.servers = this.servers.map((s) =>
      s.id === id
        ? {
            ...s,
            status: 'connected',
            statusMessage: message,
            lastHealthCheck: new Date().toISOString(),
          }
        : s
    );
    this.saveServers();

    this.addLog({
      panelId: server.id,
      panelName: server.name,
      provider: server.provider,
      action: 'test_connection',
      status: 'success',
      requestPayload: JSON.stringify({ endpoint: server.apiEndpoint, user: server.username }),
      responsePayload: JSON.stringify({ message, latencyMs, accounts: server.activeAccounts }),
      executionTimeMs: latencyMs,
    });

    this.notify();
    return { success, message, latencyMs, accounts: server.activeAccounts };
  }

  public async provisionAccount(params: {
    domain: string;
    packageName: string;
    customerName: string;
    customerEmail: string;
    diskMb?: number;
    bandwidthGb?: number;
    serverId?: string;
  }): Promise<{
    success: boolean;
    username: string;
    tempPassword?: string;
    cpanelUrl: string;
    serverIp: string;
    serverHostname: string;
    serverName: string;
    nameservers: string[];
    rawResponse?: any;
    errorMessage?: string;
  }> {
    const server = params.serverId ? this.getServerById(params.serverId) : this.getDefaultServer();
    const actualServer = server || this.getDefaultServer();

    const startTime = performance.now();

    // Sanitize username (cPanel restricts to 8-16 chars alphanumeric)
    const cleanDomain = params.domain.split('.')[0].replace(/[^a-z0-9]/gi, '').toLowerCase();
    const username = (cleanDomain.slice(0, 8) || `usr${Math.floor(1000 + Math.random() * 9000)}`);
    const tempPassword = `Pass#${Math.random().toString(36).substring(2, 8)}!${Math.floor(100 + Math.random() * 900)}`;

    // Simulate real control panel API execution
    await new Promise((resolve) => setTimeout(resolve, 450));
    const latencyMs = Math.round(performance.now() - startTime);

    const cpanelPort = actualServer.provider === 'cpanel' ? '2083' : actualServer.provider === 'directadmin' ? '2222' : '8443';
    const cpanelUrl = `https://${actualServer.hostname}:${cpanelPort}`;

    const rawResponse = {
      result: [{ status: 1, statusmsg: 'Account creation completed successfully', rawout: `Allocated /home/${username}` }],
      metadata: {
        serverIp: actualServer.ipAddress,
        hostname: actualServer.hostname,
        package: params.packageName,
        quotaMb: params.diskMb || 10000,
        sslStatus: actualServer.sslAutoInstall ? 'AutoSSL Active (Let\'s Encrypt)' : 'Pending',
      },
    };

    // Increment active accounts
    this.servers = this.servers.map((s) =>
      s.id === actualServer.id ? { ...s, activeAccounts: s.activeAccounts + 1 } : s
    );
    this.saveServers();

    this.addLog({
      panelId: actualServer.id,
      panelName: actualServer.name,
      provider: actualServer.provider,
      action: 'create_account',
      domain: params.domain,
      username,
      status: 'success',
      requestPayload: JSON.stringify({
        domain: params.domain,
        username,
        package: params.packageName,
        email: params.customerEmail,
        serverIp: actualServer.ipAddress,
      }),
      responsePayload: JSON.stringify(rawResponse),
      executionTimeMs: latencyMs,
    });

    return {
      success: true,
      username,
      tempPassword,
      cpanelUrl,
      serverIp: actualServer.ipAddress,
      serverHostname: actualServer.hostname,
      serverName: actualServer.name,
      nameservers: actualServer.defaultNameservers,
      rawResponse,
    };
  }

  public async suspendAccount(
    username: string,
    reason: string = 'Administrative Suspension',
    serverId?: string
  ): Promise<{ success: boolean; message: string }> {
    const server = serverId ? this.getServerById(serverId) : this.getDefaultServer();
    const actualServer = server || this.getDefaultServer();

    const startTime = performance.now();
    await new Promise((resolve) => setTimeout(resolve, 250));
    const latencyMs = Math.round(performance.now() - startTime);

    const message = `Account ${username} suspended on ${actualServer.name} (${reason})`;

    this.addLog({
      panelId: actualServer.id,
      panelName: actualServer.name,
      provider: actualServer.provider,
      action: 'suspend_account',
      username,
      status: 'success',
      requestPayload: JSON.stringify({ username, reason }),
      responsePayload: JSON.stringify({ status: 1, message }),
      executionTimeMs: latencyMs,
    });

    return { success: true, message };
  }

  public async unsuspendAccount(username: string, serverId?: string): Promise<{ success: boolean; message: string }> {
    const server = serverId ? this.getServerById(serverId) : this.getDefaultServer();
    const actualServer = server || this.getDefaultServer();

    const startTime = performance.now();
    await new Promise((resolve) => setTimeout(resolve, 250));
    const latencyMs = Math.round(performance.now() - startTime);

    const message = `Account ${username} unsuspended and restored on ${actualServer.name}`;

    this.addLog({
      panelId: actualServer.id,
      panelName: actualServer.name,
      provider: actualServer.provider,
      action: 'unsuspend_account',
      username,
      status: 'success',
      requestPayload: JSON.stringify({ username }),
      responsePayload: JSON.stringify({ status: 1, message }),
      executionTimeMs: latencyMs,
    });

    return { success: true, message };
  }

  public async terminateAccount(username: string, serverId?: string): Promise<{ success: boolean; message: string }> {
    const server = serverId ? this.getServerById(serverId) : this.getDefaultServer();
    const actualServer = server || this.getDefaultServer();

    const startTime = performance.now();
    await new Promise((resolve) => setTimeout(resolve, 300));
    const latencyMs = Math.round(performance.now() - startTime);

    const message = `Account ${username} permanently purged from ${actualServer.name}`;

    // Decrement active accounts
    this.servers = this.servers.map((s) =>
      s.id === actualServer.id ? { ...s, activeAccounts: Math.max(0, s.activeAccounts - 1) } : s
    );
    this.saveServers();

    this.addLog({
      panelId: actualServer.id,
      panelName: actualServer.name,
      provider: actualServer.provider,
      action: 'terminate_account',
      username,
      status: 'success',
      requestPayload: JSON.stringify({ username }),
      responsePayload: JSON.stringify({ status: 1, message }),
      executionTimeMs: latencyMs,
    });

    return { success: true, message };
  }

  public getLogs(): ControlPanelApiLog[] {
    return [...this.logs];
  }

  public addLog(log: Omit<ControlPanelApiLog, 'id' | 'timestamp'>) {
    const entry: ControlPanelApiLog = {
      ...log,
      id: `cplog-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
    };
    this.logs = [entry, ...this.logs.slice(0, 199)];
    this.saveLogs();
    this.notify();
  }

  public clearLogs() {
    this.logs = [];
    this.saveLogs();
    this.notify();
  }
}

export const hostingControlPanelManager = new HostingControlPanelManager();
