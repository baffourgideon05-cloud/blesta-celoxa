import React, { useState } from 'react';
import { 
  Server, 
  HardDrive, 
  Activity, 
  Globe, 
  Mail, 
  Database, 
  Download, 
  Terminal, 
  ExternalLink, 
  Key, 
  Settings, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Cpu, 
  Layers, 
  Zap, 
  FolderArchive, 
  ShieldCheck, 
  Lock, 
  Code, 
  RefreshCw,
  Search,
  Check
} from 'lucide-react';

import { HostingService, WhmcsCpanelEmailAccount, WhmcsCpanelDatabase, WhmcsSoftaculousApp } from '../types';
import { MOCK_CPANEL_EMAILS, MOCK_CPANEL_DATABASES, MOCK_SOFTACULOUS_APPS } from '../data/mockWhmcsData';
import { systemDatabase } from '../services/systemDatabase';

interface Props {
  service: HostingService;
  onBack?: () => void;
  currency?: string;
}

export const WhmcsHostingControlPanel: React.FC<Props> = ({ service, onBack, currency = 'USD' }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'softaculous' | 'databases' | 'emails' | 'php' | 'whmcs_actions'>('dashboard');

  // Interactive Local State for cPanel elements
  const [emails, setEmails] = useState<WhmcsCpanelEmailAccount[]>(MOCK_CPANEL_EMAILS);
  const [databases, setDatabases] = useState<WhmcsCpanelDatabase[]>(MOCK_CPANEL_DATABASES);
  const [apps, setApps] = useState<WhmcsSoftaculousApp[]>(MOCK_SOFTACULOUS_APPS);

  // PHP Settings State
  const [phpVersion, setPhpVersion] = useState<string>(service.phpVersion || '8.2');
  const [memoryLimit, setMemoryLimit] = useState<string>('512M');
  const [maxUpload, setMaxUpload] = useState<string>('128M');
  const [redisEnabled, setRedisEnabled] = useState<boolean>(true);
  const [imagickEnabled, setImagickEnabled] = useState<boolean>(true);

  // Form Modals
  const [showAddEmailModal, setShowAddEmailModal] = useState(false);
  const [newEmailPrefix, setNewEmailPrefix] = useState('');
  const [newEmailQuota, setNewEmailQuota] = useState(2048);

  const [showAddDbModal, setShowAddDbModal] = useState(false);
  const [newDbName, setNewDbName] = useState('');

  const [showInstallAppModal, setShowInstallAppModal] = useState(false);
  const [selectedAppName, setSelectedAppName] = useState('WordPress');
  const [installPath, setInstallPath] = useState('');

  // Handlers
  const handleCreateEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmailPrefix) return;
    const newAcc: WhmcsCpanelEmailAccount = {
      id: `em-${Date.now()}`,
      email: `${newEmailPrefix}@${service.domain}`,
      usageMb: 0,
      quotaMb: newEmailQuota,
    };
    setEmails([...emails, newAcc]);
    setShowAddEmailModal(false);
    setNewEmailPrefix('');
  };

  const handleCreateDb = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDbName) return;
    const prefix = service.cpanelUser ? service.cpanelUser.substring(0, 8) : 'dbuser';
    const newDb: WhmcsCpanelDatabase = {
      id: `db-${Date.now()}`,
      dbName: `${prefix}_${newDbName}`,
      dbUser: `${prefix}_usr`,
      sizeMb: 1,
    };
    setDatabases([...databases, newDb]);
    setShowAddDbModal(false);
    setNewDbName('');
  };

  const handleInstallApp = (e: React.FormEvent) => {
    e.preventDefault();
    const newApp: WhmcsSoftaculousApp = {
      id: `app-${Date.now()}`,
      name: selectedAppName,
      category: 'CMS',
      version: '6.6.1',
      installedUrl: `https://${service.domain}${installPath ? `/${installPath}` : ''}`,
      installedPath: `/public_html${installPath ? `/${installPath}` : ''}`,
      dbName: `${service.cpanelUser || 'user'}_wp${Math.floor(Math.random() * 900 + 100)}`,
      installedDate: new Date().toISOString().split('T')[0],
      autoUpdate: true,
    };
    setApps([...apps, newApp]);
    setShowInstallAppModal(false);
    setInstallPath('');
  };

  // Launch cPanel SSO
  const handleLaunchSso = (targetTool: string) => {
    alert(`[WHMCS cPanel Module API]: Generating single sign-on security token for user '${service.cpanelUser}' on server '${service.ipAddress}'. Launching ${targetTool}...`);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* cPanel & WHMCS Banner Header */}
      <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            {onBack && (
              <button
                onClick={onBack}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-lg mr-2"
              >
                ← Back
              </button>
            )}
            <span className="px-2.5 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-500 text-white">
              WHMCS cPanel Direct Portal
            </span>
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
              Status: {service.status.toUpperCase()}
            </span>
          </div>

          <h2 className="text-2xl font-black text-white mt-1.5 flex items-center gap-2">
            <Globe className="w-6 h-6 text-indigo-400" />
            <span>{service.domain}</span>
          </h2>

          <p className="text-xs text-slate-400 mt-1 font-mono">
            Plan: <strong className="text-slate-200">{service.planName}</strong> • Server IP: <strong className="text-slate-200">{service.ipAddress}</strong> • Username: <strong className="text-slate-200">{service.cpanelUser}</strong>
          </p>
        </div>

        {/* Direct cPanel One-Click SSO Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleLaunchSso('cPanel Dashboard')}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center gap-2 transition-all"
          >
            <Server className="w-4 h-4" />
            <span>cPanel SSO Login</span>
          </button>

          <button
            onClick={() => handleLaunchSso('Webmail Direct SSO')}
            className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 flex items-center gap-1.5"
          >
            <Mail className="w-4 h-4 text-sky-400" />
            <span>Webmail</span>
          </button>

          <button
            onClick={() => handleLaunchSso('phpMyAdmin Database Manager')}
            className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 flex items-center gap-1.5"
          >
            <Database className="w-4 h-4 text-emerald-400" />
            <span>phpMyAdmin</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs font-extrabold overflow-x-auto">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>cPanel Metrics & SSO</span>
        </button>

        <button
          onClick={() => setActiveTab('softaculous')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'softaculous' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Zap className="w-4 h-4 text-amber-400" />
          <span>Softaculous 1-Click Apps ({apps.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('databases')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'databases' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Database className="w-4 h-4 text-emerald-400" />
          <span>MySQL Databases ({databases.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('emails')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'emails' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Mail className="w-4 h-4 text-sky-400" />
          <span>Email Accounts ({emails.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('php')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'php' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Code className="w-4 h-4 text-purple-400" />
          <span>PHP Selector & Extensions</span>
        </button>

        {['admin', 'super_admin', 'administrator', 'staff'].includes(systemDatabase.getCurrentUser()?.role || '') && (
          <button
            onClick={() => setActiveTab('whmcs_actions')}
            className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'whmcs_actions' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Terminal className="w-4 h-4 text-rose-400" />
            <span>WHMCS Server Module Actions (Admin)</span>
          </button>
        )}
      </div>

      {/* TAB 1: METRICS & SSO SHORTCUTS */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Quick SSO Shortcuts Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <button
              onClick={() => handleLaunchSso('File Manager')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group"
            >
              <FolderArchive className="w-6 h-6 text-indigo-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">File Manager</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Browse /public_html files</div>
            </button>

            <button
              onClick={() => handleLaunchSso('phpMyAdmin')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group"
            >
              <Database className="w-6 h-6 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">phpMyAdmin</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Manage MySQL tables</div>
            </button>

            <button
              onClick={() => handleLaunchSso('Webmail Inbox')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group"
            >
              <Mail className="w-6 h-6 text-sky-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">Webmail SSO</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Roundcube webmail</div>
            </button>

            <button
              onClick={() => handleLaunchSso('Backup Wizard')}
              className="p-4 bg-slate-900 hover:bg-slate-800/80 rounded-2xl border border-slate-800 text-left transition-all group"
            >
              <Download className="w-6 h-6 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="font-extrabold text-white text-sm">Backup Wizard</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Download full home backup</div>
            </button>
          </div>

          {/* Real-time Usage Meters */}
          <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800 space-y-5">
            <h3 className="font-extrabold text-white text-base flex items-center gap-2">
              <Activity className="w-5 h-5 text-indigo-400" />
              <span>Real-Time cPanel Account Quotas & Usage</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* NVMe Disk */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-indigo-400" /> NVMe SSD Storage
                  </span>
                  <span className="font-mono text-white font-bold">
                    {(service.diskUsageMb / 1024).toFixed(2)} GB / {(service.diskLimitMb / 1024).toFixed(0)} GB ({((service.diskUsageMb / service.diskLimitMb) * 100).toFixed(1)}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${(service.diskUsageMb / service.diskLimitMb) * 100}%` }}></div>
                </div>
              </div>

              {/* Bandwidth */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-sky-400" /> Monthly Bandwidth
                  </span>
                  <span className="font-mono text-white font-bold">
                    {service.bandwidthUsageGb} GB / {service.bandwidthLimitGb} GB ({((service.bandwidthUsageGb / service.bandwidthLimitGb) * 100).toFixed(1)}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-sky-500 h-full rounded-full" style={{ width: `${(service.bandwidthUsageGb / service.bandwidthLimitGb) * 100}%` }}></div>
                </div>
              </div>

              {/* Inodes */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-amber-400" /> Inode File Count Limit
                  </span>
                  <span className="font-mono text-white font-bold">34,120 / 250,000 (13.6%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '13.6%' }}></div>
                </div>
              </div>

              {/* Physical Memory */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Cpu className="w-4 h-4 text-emerald-400" /> Physical RAM Allocation
                  </span>
                  <span className="font-mono text-white font-bold">428 MB / 2048 MB (20.9%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: '20.9%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SOFTACULOUS 1-CLICK APPS */}
      {activeTab === 'softaculous' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                <span>Softaculous Auto-Installer</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Instantly deploy applications onto {service.domain} with automated MySQL database configuration.
              </p>
            </div>

            <button
              onClick={() => setShowInstallAppModal(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Install New Application</span>
            </button>
          </div>

          <div className="space-y-3">
            {apps.map((app) => (
              <div key={app.id} className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-white text-sm">{app.name}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-950 text-indigo-300">
                      v{app.version}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono">
                    URL: <a href={app.installedUrl} target="_blank" rel="noreferrer" className="text-sky-400 underline">{app.installedUrl}</a> • Path: {app.installedPath}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`${app.installedUrl}/wp-admin`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-lg text-xs flex items-center gap-1"
                  >
                    <span>Admin Dashboard</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: MYSQL DATABASES */}
      {activeTab === 'databases' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <span>MySQL / MariaDB Database Manager</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Manage relational databases and user privileges on your WHMCS hosting instance.
              </p>
            </div>

            <button
              onClick={() => setShowAddDbModal(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create MySQL Database</span>
            </button>
          </div>

          <div className="space-y-3">
            {databases.map((db) => (
              <div key={db.id} className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
                <div>
                  <div className="font-extrabold text-white text-sm font-mono">{db.dbName}</div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    User: <strong className="text-slate-200">{db.dbUser}</strong> • Size: {db.sizeMb} MB
                  </div>
                </div>

                <button
                  onClick={() => handleLaunchSso(`phpMyAdmin (${db.dbName})`)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 font-extrabold rounded-lg text-xs border border-slate-700 flex items-center gap-1"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Launch phpMyAdmin
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: EMAIL ACCOUNTS */}
      {activeTab === 'emails' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Mail className="w-5 h-5 text-sky-400" />
                <span>cPanel Mailbox Accounts</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Create domain email accounts with POP3/IMAP SSL settings and Webmail direct access.
              </p>
            </div>

            <button
              onClick={() => setShowAddEmailModal(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create Email Account</span>
            </button>
          </div>

          <div className="space-y-3">
            {emails.map((em) => (
              <div key={em.id} className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
                <div>
                  <div className="font-extrabold text-white text-sm font-mono">{em.email}</div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Quota: {em.usageMb} MB / {em.quotaMb} MB ({((em.usageMb / em.quotaMb) * 100).toFixed(1)}%)
                  </div>
                </div>

                <button
                  onClick={() => handleLaunchSso(`Webmail (${em.email})`)}
                  className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-extrabold rounded-lg text-xs flex items-center gap-1"
                >
                  <Mail className="w-3.5 h-3.5" /> Webmail SSO
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: PHP SELECTOR */}
      {activeTab === 'php' && (
        <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800 space-y-6">
          <div className="flex items-center gap-3">
            <Code className="w-6 h-6 text-purple-400" />
            <div>
              <h3 className="font-extrabold text-white text-base">cPanel PHP Version & Directives</h3>
              <p className="text-xs text-slate-400">
                Switch PHP versions on the fly and toggle extensions for optimized site loading speed.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <label className="font-bold text-slate-300 block">Active PHP Runtime Version</label>
              <select
                value={phpVersion}
                onChange={(e) => setPhpVersion(e.target.value)}
                className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none"
              >
                <option value="8.3">PHP 8.3 (Latest - Recommended)</option>
                <option value="8.2">PHP 8.2 (Stable High Performance)</option>
                <option value="8.1">PHP 8.1</option>
                <option value="8.0">PHP 8.0</option>
                <option value="7.4">PHP 7.4 (Legacy Support)</option>
              </select>

              <div className="pt-2">
                <label className="font-bold text-slate-300 block mb-1">memory_limit Directive</label>
                <select
                  value={memoryLimit}
                  onChange={(e) => setMemoryLimit(e.target.value)}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                >
                  <option value="256M">256M</option>
                  <option value="512M">512M (Recommended for WP)</option>
                  <option value="1024M">1024M (1 GB)</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <label className="font-bold text-slate-300 block">PHP Extensions & Modules</label>
              <div className="space-y-2">
                <label className="flex items-center justify-between p-2 bg-slate-900 rounded-lg cursor-pointer">
                  <span>Redis Object Cache Extension</span>
                  <input
                    type="checkbox"
                    checked={redisEnabled}
                    onChange={(e) => setRedisEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between p-2 bg-slate-900 rounded-lg cursor-pointer">
                  <span>ImageMagick (imagick)</span>
                  <input
                    type="checkbox"
                    checked={imagickEnabled}
                    onChange={(e) => setImagickEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
                  />
                </label>
              </div>

              <button
                onClick={() => alert(`Saved PHP settings! Version updated to PHP ${phpVersion} with ${memoryLimit} memory limit.`)}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl shadow"
              >
                Apply PHP Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: WHMCS ACTION SIMULATOR */}
      {activeTab === 'whmcs_actions' && (
        <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800 space-y-5">
          <div className="flex items-center gap-3">
            <Terminal className="w-6 h-6 text-rose-400" />
            <div>
              <h3 className="font-extrabold text-white text-base">WHMCS Server Module Command Simulator</h3>
              <p className="text-xs text-slate-400">
                Test low-level WHMCS API commands for this account directly on the cPanel / WHM cluster.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-bold">
            <button
              onClick={() => alert(`[WHMCS Module API Response]: Success. Account '${service.domain}' recreated on server '${service.ipAddress}'.`)}
              className="p-3 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded-xl border border-emerald-800 text-left"
            >
              ▶ Re-Create Account
            </button>

            <button
              onClick={() => alert(`[WHMCS Module API Response]: Account '${service.domain}' suspended with reason: Admin Testing.`)}
              className="p-3 bg-amber-950 hover:bg-amber-900 text-amber-300 rounded-xl border border-amber-800 text-left"
            >
              ⏸ Suspend Account
            </button>

            <button
              onClick={() => alert(`[WHMCS Module API Response]: Account '${service.domain}' unsuspended successfully.`)}
              className="p-3 bg-sky-950 hover:bg-sky-900 text-sky-300 rounded-xl border border-sky-800 text-left"
            >
              ⏯ Unsuspend Account
            </button>

            <button
              onClick={() => alert(`[WHMCS Module API Response]: Password reset email dispatched for user '${service.cpanelUser}'.`)}
              className="p-3 bg-purple-950 hover:bg-purple-900 text-purple-300 rounded-xl border border-purple-800 text-left"
            >
              🔑 Reset Password
            </button>
          </div>
        </div>
      )}

      {/* MODAL: ADD EMAIL */}
      {showAddEmailModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-white text-base">Create cPanel Mailbox</h3>
              <button onClick={() => setShowAddEmailModal(false)} className="text-slate-400 hover:text-white font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleCreateEmail} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Email Username</label>
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    required
                    placeholder="e.g. support"
                    value={newEmailPrefix}
                    onChange={(e) => setNewEmailPrefix(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                  />
                  <span className="text-slate-400 font-mono text-xs font-bold">@{service.domain}</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Storage Quota (MB)</label>
                <input
                  type="number"
                  value={newEmailQuota}
                  onChange={(e) => setNewEmailQuota(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowAddEmailModal(false)} className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-indigo-600 text-white font-extrabold rounded-xl shadow">Create Mailbox</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD DATABASE */}
      {showAddDbModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-white text-base">Create MySQL Database</h3>
              <button onClick={() => setShowAddDbModal(false)} className="text-slate-400 hover:text-white font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleCreateDb} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Database Suffix Name</label>
                <div className="flex items-center gap-1">
                  <span className="text-slate-400 font-mono text-xs font-bold">{service.cpanelUser || 'user'}_</span>
                  <input
                    type="text"
                    required
                    placeholder="e.g. appdb"
                    value={newDbName}
                    onChange={(e) => setNewDbName(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowAddDbModal(false)} className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-emerald-600 text-white font-extrabold rounded-xl shadow">Create Database</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: INSTALL APP */}
      {showInstallAppModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-white text-base">Softaculous 1-Click Installer</h3>
              <button onClick={() => setShowInstallAppModal(false)} className="text-slate-400 hover:text-white font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleInstallApp} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Select Software</label>
                <select
                  value={selectedAppName}
                  onChange={(e) => setSelectedAppName(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-bold focus:outline-none"
                >
                  <option value="WordPress">WordPress CMS</option>
                  <option value="WooCommerce">WooCommerce E-Commerce Store</option>
                  <option value="Laravel">Laravel PHP Framework</option>
                  <option value="Joomla">Joomla CMS</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Installation Path (Optional)</label>
                <div className="flex items-center gap-1">
                  <span className="text-slate-400 font-mono text-[11px]">{service.domain}/</span>
                  <input
                    type="text"
                    placeholder="e.g. blog or shop (leave blank for root)"
                    value={installPath}
                    onChange={(e) => setInstallPath(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setShowInstallAppModal(false)} className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-indigo-600 text-white font-extrabold rounded-xl shadow">Install Software Now</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
