import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Globe, 
  Server, 
  ShieldCheck, 
  Mail, 
  Cpu, 
  Receipt, 
  Wallet, 
  CalendarDays, 
  Users, 
  LifeBuoy, 
  History, 
  Plus, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  ArrowUpRight, 
  Search, 
  Download, 
  Lock, 
  UserPlus, 
  ShieldAlert, 
  ChevronRight, 
  RefreshCw, 
  Paperclip, 
  FileText, 
  HelpCircle, 
  Check, 
  X, 
  ExternalLink, 
  DollarSign,
  AlertCircle,
  Eye,
  Settings,
  Send,
  Zap,
  Bookmark
} from 'lucide-react';

import { 
  RegisteredDomain, 
  HostingService, 
  SslService, 
  EmailService, 
  VpsService, 
  Invoice, 
  CustomerWallet, 
  TeamMember, 
  SupportTicket, 
  CustomerTimelineEvent, 
  RenewalReminderRule,
  ServiceStatus,
  TicketPriority,
  TicketStatus,
  Currency
} from '../types';

import { WhmcsHostingControlPanel } from './WhmcsHostingControlPanel';
import { WhmcsProductCatalogModal } from './WhmcsProductCatalogModal';
import { WhmcsServerManagementHub } from './WhmcsServerManagementHub';
import { FeatureAuditMatrixModal } from './FeatureAuditMatrixModal';
import { ClientDashboard } from './ClientDashboard';
import { SecurityCenter } from './SecurityCenter';
import { PaystackCheckoutModal } from './PaystackCheckoutModal';
import { systemDatabase } from '../services/systemDatabase';
import { calculateTaxBreakdown, convertPrice, formatCurrencyAmount, formatPrice, CURRENCY_RATES } from '../utils/domainSearchEngine';


import { 
  MOCK_HOSTING_SERVICES, 
  MOCK_SSL_SERVICES, 
  MOCK_EMAIL_SERVICES, 
  MOCK_VPS_SERVICES, 
  MOCK_INVOICES, 
  MOCK_CUSTOMER_WALLET, 
  MOCK_TEAM_MEMBERS, 
  MOCK_SUPPORT_TICKETS, 
  MOCK_CUSTOMER_TIMELINE, 
  MOCK_RENEWAL_RULES,
  CANNED_RESPONSE_TEMPLATES 
} from '../data/mockCustomerServices';

interface Props {
  registeredDomains: RegisteredDomain[];
  onOpenDomainHub: (domainName?: string) => void;
  isAdmin: boolean;
  onTriggerImpersonation: (customerName: string, customerEmail: string) => void;
  currency: Currency;
  onOpenSearch: () => void;
  initialTab?: 'overview' | 'services' | 'billing' | 'wallet' | 'renewals' | 'calendar' | 'team' | 'tickets' | 'timeline' | 'security';
}

export const CustomerCommandCenter: React.FC<Props> = ({
  registeredDomains,
  onOpenDomainHub,
  isAdmin,
  onTriggerImpersonation,
  currency,
  onOpenSearch,
  initialTab = 'overview'
}) => {
  // Database & Settings State
  const [currentUser, setCurrentUser] = useState(() => systemDatabase.getCurrentUser());
  const [systemSettings, setSystemSettings] = useState(() => systemDatabase.getSettings());

  useEffect(() => {
    const syncDatabaseState = () => {
      setCurrentUser(systemDatabase.getCurrentUser());
      setSystemSettings(systemDatabase.getSettings());
    };

    window.addEventListener('storage', syncDatabaseState);
    return () => window.removeEventListener('storage', syncDatabaseState);
  }, []);

  // Dynamic User & Organization Profile Branding
  const siteName = systemSettings?.general?.siteName || 'Celoxa Ghana Cloud Systems';
  const companyTitle = currentUser?.companyName || systemSettings?.general?.companyName || siteName;
  const personName = currentUser?.fullName || 'Gideon Baffour';
  const personRole = currentUser?.staffTitle || (currentUser?.role === 'super_admin' ? 'Super Admin' : currentUser?.role === 'administrator' ? 'Administrator' : currentUser?.role === 'staff' ? 'Staff' : 'Primary Owner');
  const userEmail = currentUser?.email || systemSettings?.general?.contactEmail || 'admin@celoxaghana.online';

  // Compute initials
  const initials = (() => {
    if (currentUser?.fullName) {
      const parts = currentUser.fullName.trim().split(/\s+/);
      if (parts.length >= 2) return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
      return parts[0].slice(0, 2).toUpperCase();
    }
    const parts = siteName.trim().split(/\s+/);
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return siteName.slice(0, 2).toUpperCase();
  })();

  // Navigation Section State
  const [activeTab, setActiveTab] = useState<
    'overview' | 'services' | 'billing' | 'wallet' | 'renewals' | 'calendar' | 'team' | 'tickets' | 'timeline' | 'security'
  >(initialTab);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const [serviceCategory, setServiceCategory] = useState<'domains' | 'hosting' | 'ssl' | 'email' | 'vps'>('domains');

  // WHMCS Integration State
  const [activeWhmcsHosting, setActiveWhmcsHosting] = useState<HostingService | null>(null);
  const [showWhmcsCatalog, setShowWhmcsCatalog] = useState(false);
  const [showWhmcsServerHub, setShowWhmcsServerHub] = useState(false);

  // Services State
  const [hostingList, setHostingList] = useState<HostingService[]>(MOCK_HOSTING_SERVICES);

  const [sslList, setSslList] = useState<SslService[]>(MOCK_SSL_SERVICES);
  const [emailList, setEmailList] = useState<EmailService[]>(MOCK_EMAIL_SERVICES);
  const [vpsList, setVpsList] = useState<VpsService[]>(MOCK_VPS_SERVICES);

  // Billing & Invoices State
  const [invoices, setInvoices] = useState<Invoice[]>(MOCK_INVOICES);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // Wallet State
  const [wallet, setWallet] = useState<CustomerWallet>(MOCK_CUSTOMER_WALLET);
  const [showTopUpModal, setShowTopUpModal] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState('500');
  const [topUpCurrency, setTopUpCurrency] = useState<Currency>(currency || 'GHS');
  const [nonRefundableConsent, setNonRefundableConsent] = useState(true);
  const [isPaystackTopUpOpen, setIsPaystackTopUpOpen] = useState(false);
  const [activeDepositOrderId, setActiveDepositOrderId] = useState('');
  const [activeDepositAmount, setActiveDepositAmount] = useState(500);
  const [activeDepositCurrency, setActiveDepositCurrency] = useState<Currency>('GHS');
  const [depositToast, setDepositToast] = useState<{ show: boolean; text: string; reference: string; amount: number; currency: string } | null>(null);

  // Renewals State
  const [selectedRenewals, setSelectedRenewals] = useState<string[]>([]);
  const [autoRenewAll, setAutoRenewAll] = useState(true);
  const [renewalRules, setRenewalRules] = useState<RenewalReminderRule[]>(MOCK_RENEWAL_RULES);

  // Team State
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(MOCK_TEAM_MEMBERS);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [newInviteEmail, setNewInviteEmail] = useState('');
  const [newInviteName, setNewInviteName] = useState('');
  const [newInviteRole, setNewInviteRole] = useState<'Billing Contact' | 'Technical Contact' | 'Administrative Contact'>('Technical Contact');

  // Support Tickets State
  const [tickets, setTickets] = useState<SupportTicket[]>(MOCK_SUPPORT_TICKETS);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(MOCK_SUPPORT_TICKETS[0]);
  const [showNewTicketModal, setShowNewTicketModal] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketDept, setTicketDept] = useState<'Domains' | 'Hosting' | 'Billing' | 'Technical' | 'SSL & Security'>('Technical');
  const [ticketPriority, setTicketPriority] = useState<TicketPriority>('normal');
  const [ticketContent, setTicketContent] = useState('');
  const [replyMessage, setReplyMessage] = useState('');
  const [isInternalNote, setIsInternalNote] = useState(false);

  // Timeline State
  const [timelineEvents, setTimelineEvents] = useState<CustomerTimelineEvent[]>(MOCK_CUSTOMER_TIMELINE);

  // Selected Service Detail Modal (for Service Timeline)
  const [selectedServiceTimeline, setSelectedServiceTimeline] = useState<{ title: string; timeline: any[] } | null>(null);

  // Impersonation Reason Modal
  const [showImpersonateModal, setShowImpersonateModal] = useState(false);
  const [impersonateReason, setImpersonateReason] = useState('Investigating DNS and hosting integration for customer');

  // --- Currency & Tax Helpers ---
  const defaultTaxPercent = systemSettings?.billing?.defaultTaxRate || 15;

  const formatGhs = (amountGhs: number): string => {
    const ghsRate = CURRENCY_RATES['GHS']?.rate || 15.5;
    const amountUsd = amountGhs / ghsRate;
    return formatPrice(amountUsd, currency);
  };

  // --- Helpers & Visual Badge Functions ---
  const getStatusBadge = (status: ServiceStatus | string) => {
    switch (status.toLowerCase()) {
      case 'active':
      case 'paid':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            ● Active
          </span>
        );
      case 'pending':
      case 'provisioning':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-sky-100 text-sky-800 dark:bg-sky-950/80 dark:text-sky-300 border border-sky-300 dark:border-sky-800">
            <RefreshCw className="w-2.5 h-2.5 animate-spin" />
            ● Provisioning
          </span>
        );
      case 'expiring':
      case 'unpaid':
      case 'open':
      case 'in_progress':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
            <AlertTriangle className="w-2.5 h-2.5" />
            ● Expiring / Action Required
          </span>
        );
      case 'suspended':
      case 'expired':
      case 'overdue':
      case 'failed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-red-100 text-red-800 dark:bg-red-950/80 dark:text-red-300 border border-red-300 dark:border-red-800">
            <X className="w-2.5 h-2.5" />
            ● Suspended / Overdue
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300">
            {status}
          </span>
        );
    }
  };

  const getPriorityBadge = (p: TicketPriority) => {
    switch (p) {
      case 'critical':
      case 'urgent':
        return <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-red-600 text-white">CRITICAL SLA</span>;
      case 'high':
        return <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-500 text-slate-950">HIGH PRIORITY</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">NORMAL</span>;
    }
  };

  // Handle Wallet Top-Up via Paystack with Multi-Currency Support
  const handleInitiatePaystackDeposit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const amt = Math.max(1, parseFloat(topUpAmount) || 50);
    const orderId = `WAL-${Date.now().toString().slice(-6)}`;
    setActiveDepositOrderId(orderId);
    setActiveDepositAmount(amt);
    setActiveDepositCurrency(topUpCurrency);
    setShowTopUpModal(false);
    setIsPaystackTopUpOpen(true);
  };

  const handlePaystackDepositSuccess = (reference: string) => {
    const amt = activeDepositAmount;
    const curr = activeDepositCurrency;
    
    // Accurate rate conversion
    const currInfo = CURRENCY_RATES[curr] || CURRENCY_RATES.GHS;
    const ghsRate = CURRENCY_RATES.GHS?.rate || 15.5;
    
    let amtUsd = 0;
    let amtGhs = 0;
    
    if (curr === 'USD') {
      amtUsd = amt;
      amtGhs = amt * ghsRate;
    } else if (curr === 'GHS') {
      amtGhs = amt;
      amtUsd = amt / ghsRate;
    } else {
      amtUsd = amt / (currInfo.rate || 1.0);
      amtGhs = amtUsd * ghsRate;
    }
    
    // Durable persistent database update
    if (currentUser?.id) {
      systemDatabase.topUpUserWallet(currentUser.id, amtGhs, amtUsd);
    }

    const newBal = wallet.balance + amtGhs;
    const verifiedRef = reference || `PSTK-WAL-${Math.floor(10000 + Math.random() * 90000)}`;
    const newTx = {
      id: `wtx-${Date.now()}`,
      type: 'credit' as const,
      amount: amtGhs,
      currency: 'GHS' as const,
      description: `Wallet Deposit via Paystack (${formatCurrencyAmount(amt, curr)})`,
      reference: verifiedRef,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      balanceAfter: newBal,
    };

    setWallet({
      balance: newBal,
      currency: 'GHS',
      transactions: [newTx, ...wallet.transactions],
    });

    setIsPaystackTopUpOpen(false);
    setDepositToast({
      show: true,
      text: `Wallet credited with ${formatCurrencyAmount(amt, curr)} (GH₵ ${amtGhs.toFixed(2)}) successfully via Paystack!`,
      reference: verifiedRef,
      amount: amtGhs,
      currency: curr,
    });

    setTimeout(() => {
      setDepositToast(null);
    }, 6000);
  };

  // Handle Invoice Payment via Wallet
  const handlePayInvoiceWithWallet = (inv: Invoice) => {
    if (wallet.balance < inv.total) {
      alert('Insufficient wallet balance. Please top up your wallet first.');
      return;
    }
    const newBal = wallet.balance - inv.total;
    const newTx = {
      id: `wtx-${Date.now()}`,
      type: 'debit' as const,
      amount: inv.total,
      currency: inv.currency,
      description: `Paid Invoice #${inv.invoiceNumber}`,
      reference: inv.invoiceNumber,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      balanceAfter: newBal,
    };

    setWallet({
      balance: newBal,
      currency: 'GHS',
      transactions: [newTx, ...wallet.transactions],
    });

    setInvoices(invoices.map((i) => (i.id === inv.id ? { ...i, status: 'paid', paidDate: new Date().toISOString().replace('T', ' ').substring(0, 16), paymentMethod: 'Account Wallet' } : i)));
    setSelectedInvoice(null);
  };

  // Handle Support Ticket Reply
  const handleSendTicketReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMessage.trim() || !selectedTicket) return;

    const newMsg = {
      id: `msg-${Date.now()}`,
      senderName: isInternalNote ? `${personName} (Staff)` : personName,
      senderEmail: isInternalNote ? (systemSettings?.general?.contactEmail || 'admin@celoxaghana.online') : userEmail,
      isStaff: isInternalNote || currentUser?.role !== 'client',
      isInternalNote,
      content: replyMessage,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    const updated = {
      ...selectedTicket,
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      messages: [...selectedTicket.messages, newMsg],
    };

    setSelectedTicket(updated);
    setTickets(tickets.map((t) => (t.id === updated.id ? updated : t)));
    setReplyMessage('');
    setIsInternalNote(false);
  };

  // Handle New Ticket Creation
  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketContent.trim()) return;

    const newTkt: SupportTicket = {
      id: `tkt-${Date.now()}`,
      ticketNumber: `TKT-${Math.floor(50000 + Math.random() * 40000)}`,
      subject: ticketSubject,
      department: ticketDept,
      priority: ticketPriority,
      status: 'open',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      slaTargetHours: ticketPriority === 'critical' ? 1 : 4,
      messages: [
        {
          id: `msg-init-${Date.now()}`,
          senderName: personName,
          senderEmail: userEmail,
          isStaff: false,
          isInternalNote: false,
          content: ticketContent,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        },
      ],
    };

    setTickets([newTkt, ...tickets]);
    setSelectedTicket(newTkt);
    setShowNewTicketModal(false);
    setTicketSubject('');
    setTicketContent('');
  };

  // Knowledgebase matching for Ticket Creation
  const kbSuggestions = [
    { title: 'How to update Nameservers & DNS Records', url: '#' },
    { title: 'Fixing SSL Mixed Content & HTTP to HTTPS redirects', url: '#' },
    { title: 'Increasing PHP Memory Limit in cPanel MultiPHP Manager', url: '#' },
  ].filter((item) => ticketSubject.length > 3);

  // Invite Team Member
  const handleInviteTeamMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInviteEmail || !newInviteName) return;

    const newMember: TeamMember = {
      id: `tm-${Date.now()}`,
      name: newInviteName,
      email: newInviteEmail,
      role: newInviteRole,
      isPrimaryOwner: false,
      status: 'active',
      addedDate: new Date().toISOString().substring(0, 10),
      permissions: {
        viewInvoices: newInviteRole === 'Billing Contact',
        payInvoices: newInviteRole === 'Billing Contact',
        downloadReceipts: true,
        manageDomains: newInviteRole === 'Technical Contact' || newInviteRole === 'Administrative Contact',
        manageHosting: newInviteRole === 'Technical Contact',
        cancelHosting: false,
        openTickets: true,
        manageTeam: false,
      },
    };

    setTeamMembers([...teamMembers, newMember]);
    setShowInviteModal(false);
    setNewInviteEmail('');
    setNewInviteName('');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col md:flex-row transition-colors">
      {/* LEFT SIDEBAR NAVIGATION */}
      <aside className="w-full md:w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 p-4 shrink-0 flex flex-col justify-between shadow-sm">
        <div>
          {/* Account Profile Header */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/60 mb-6">
            <div className="flex items-center gap-2.5">
              {currentUser?.avatarUrl ? (
                <img 
                  src={currentUser.avatarUrl} 
                  alt={personName} 
                  className="w-10 h-10 rounded-full object-cover border border-emerald-500/40 shadow shrink-0" 
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-600 to-teal-700 text-white font-black text-sm flex items-center justify-center shadow shrink-0 border border-emerald-400/30">
                  {initials}
                </div>
              )}
              <div className="overflow-hidden">
                <h3 className="font-extrabold text-slate-900 dark:text-white text-xs truncate" title={companyTitle}>
                  {companyTitle}
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate" title={`${personName} (${personRole})`}>
                  {personName} <span className="text-emerald-600 dark:text-emerald-400 font-medium">({personRole})</span>
                </p>
              </div>
            </div>
            <div className="mt-2.5 pt-2 border-t border-slate-200 dark:border-slate-700/50 flex items-center justify-between text-[11px]">
              <span className="text-slate-500 dark:text-slate-400 font-medium">Wallet Balance:</span>
              <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                {formatGhs(wallet.balance)}
              </span>
            </div>
          </div>

          {/* Quick Universal Search Trigger */}
          <button
            onClick={onOpenSearch}
            className="w-full py-2.5 px-3 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs rounded-xl flex items-center justify-between transition-all mb-4 group"
          >
            <span className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Search account...</span>
            </span>
            <kbd className="text-[9px] bg-slate-200 dark:bg-slate-800 px-1.5 py-0.5 rounded font-mono text-slate-600 dark:text-slate-400">Ctrl+K</kbd>
          </button>

          {/* Navigation Items */}
          <nav className="space-y-1 text-xs font-bold">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center gap-2.5 transition-all ${
                activeTab === 'overview'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Overview</span>
            </button>

            <button
              onClick={() => setActiveTab('services')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all ${
                activeTab === 'services'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Server className="w-4 h-4" />
                <span>My Services</span>
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono">
                {registeredDomains.length + hostingList.length + sslList.length + emailList.length + vpsList.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('billing')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all ${
                activeTab === 'billing'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Receipt className="w-4 h-4" />
                <span>Invoices & Billing</span>
              </span>
              {invoices.filter((i) => i.status === 'unpaid').length > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500 text-slate-950 font-black">
                  {invoices.filter((i) => i.status === 'unpaid').length} Unpaid
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('wallet')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all ${
                activeTab === 'wallet'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Wallet className="w-4 h-4" />
                <span>Customer Wallet</span>
              </span>
              <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">{formatGhs(wallet.balance)}</span>
            </button>

            <button
              onClick={() => setActiveTab('renewals')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center gap-2.5 transition-all ${
                activeTab === 'renewals'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <RefreshCw className="w-4 h-4" />
              <span>Renewal Center</span>
            </button>

            <button
              onClick={() => setActiveTab('calendar')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center gap-2.5 transition-all ${
                activeTab === 'calendar'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <CalendarDays className="w-4 h-4" />
              <span>Expiration Calendar</span>
            </button>

            <button
              onClick={() => setActiveTab('team')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center gap-2.5 transition-all ${
                activeTab === 'team'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Team & Contacts</span>
            </button>

            <button
              onClick={() => setActiveTab('tickets')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all ${
                activeTab === 'tickets'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <LifeBuoy className="w-4 h-4" />
                <span>Support Tickets</span>
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-indigo-500 text-white font-mono">
                {tickets.filter((t) => t.status !== 'closed').length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('timeline')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center gap-2.5 transition-all ${
                activeTab === 'timeline'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Account Timeline</span>
            </button>

            <button
              onClick={() => setActiveTab('security')}
              className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all ${
                activeTab === 'security'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Lock className="w-4 h-4" />
                <span>Security & IAM</span>
              </span>
              {!systemDatabase.getCurrentUser()?.isEmailVerified && (
                <span className="px-2 py-0.5 rounded-full text-[9px] bg-amber-500 text-slate-950 font-black">
                  Verify
                </span>
              )}
            </button>

            {/* WHMCS Product Catalog Link */}
            <div className="pt-3 my-2 border-t border-slate-200 dark:border-slate-800/80 space-y-1">
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-600 dark:text-indigo-400 px-3">
                Order & Services
              </span>
              <button
                onClick={() => setShowWhmcsCatalog(true)}
                className="w-full px-3 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl flex items-center justify-between transition-all"
              >
                <span className="flex items-center gap-2">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>Order Hosting & Addons</span>
                </span>
                <span className="text-[9px] bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 px-1.5 py-0.5 rounded font-mono">Catalog</span>
              </button>
            </div>
          </nav>
        </div>

        {/* Staff Impersonation Action for Admins */}
        {isAdmin && (
          <div className="pt-4 mt-6 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={() => setShowImpersonateModal(true)}
              className="w-full py-2.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Impersonate Customer</span>
            </button>
          </div>
        )}
      </aside>

      {/* RIGHT MAIN CONTENT AREA */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto max-w-7xl">
        {/* IF WHMCS CONTROL PANEL IS OPENED FOR A SPECIFIC HOSTING SERVICE */}
        {activeWhmcsHosting ? (
          <WhmcsHostingControlPanel
            service={activeWhmcsHosting}
            onBack={() => setActiveWhmcsHosting(null)}
            currency={currency}
          />
        ) : showWhmcsServerHub ? (
          <WhmcsServerManagementHub
            onClose={() => setShowWhmcsServerHub(false)}
          />
        ) : (
          <>
            {/* TAB 1: OVERVIEW DASHBOARD */}
            {activeTab === 'overview' && (
              <div className="space-y-6 animate-in fade-in">
                <ClientDashboard
                  user={systemDatabase.getCurrentUser() || undefined}
                  domainsCount={registeredDomains.length}
                  hostingCount={hostingList.length}
                  sslCount={sslList.length}
                  emailCount={emailList.length}
                  vpsCount={vpsList.length}
                  walletBalanceGhs={wallet.balance}
                  walletBalanceUsd={wallet.balance / 15.5}
                  unpaidInvoicesCount={invoices.filter((i) => i.status === 'unpaid').length}
                  unpaidTotalGhs={invoices.filter((i) => i.status === 'unpaid').reduce((acc, i) => acc + i.total, 0)}
                  openTicketsCount={tickets.filter((t) => t.status === 'open' || t.status === 'in_progress').length}
                  currency={currency}
                  onNavigateTab={(t) => setActiveTab(t as any)}
                  onOpenDepositModal={() => setShowTopUpModal(true)}
                  onOpenDomainHub={() => onOpenDomainHub()}
                  onOpenCatalog={() => setShowWhmcsCatalog(true)}
                />

                {/* Main Overview Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Active Services Quick Box */}
              <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <Server className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    <span>My Active Services</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab('services')}
                    className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 flex items-center gap-1"
                  >
                    <span>View All</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-3">
                  {hostingList.map((h) => (
                    <div
                      key={h.id}
                      className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 rounded-xl">
                          <Server className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-slate-900 dark:text-white text-xs">{h.name}</h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">{h.domain} • IP: {h.ipAddress}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        {getStatusBadge(h.status)}
                        <button
                          onClick={() =>
                            setSelectedServiceTimeline({
                              title: `${h.name} (${h.domain})`,
                              timeline: h.timeline,
                            })
                          }
                          className="px-2.5 py-1 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-[11px] font-bold rounded-lg"
                        >
                          History
                        </button>
                      </div>
                    </div>
                  ))}

                  {registeredDomains.slice(0, 2).map((d) => (
                    <div
                      key={d.id}
                      className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-xl">
                          <Globe className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-slate-900 dark:text-white text-xs">{d.domain}</h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">Registered • Expires {d.expiryDate}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        {getStatusBadge(d.status)}
                        <button
                          onClick={() => onOpenDomainHub(d.domain)}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold rounded-lg"
                        >
                          Manage DNS
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Customer Timeline Event Stream */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <History className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />
                    <span>Recent Activity</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab('timeline')}
                    className="text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                  >
                    Full Stream
                  </button>
                </div>

                <div className="space-y-3">
                  {timelineEvents.slice(0, 4).map((evt) => (
                    <div key={evt.id} className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 dark:text-white">{evt.title}</span>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500">{evt.timestamp}</span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 text-[11px]">{evt.description}</p>
                      <div className="text-[10px] font-mono text-slate-400 dark:text-slate-500 pt-1">Actor: {evt.actor}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MY SERVICES */}
        {activeTab === 'services' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
              <div>
                <h1 className="text-2xl font-black text-slate-900 dark:text-white">My Services Portfolio</h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Manage domain registrations, cloud hosting, SSL certificates, email suites, and VPS instances.
                </p>
              </div>

              <div className="flex items-center gap-3 flex-wrap">
                <button
                  onClick={() => setShowWhmcsCatalog(true)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Order Hosting</span>
                </button>

                {/* Category Sub-Tabs */}
                <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold">
                  <button
                    onClick={() => setServiceCategory('domains')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      serviceCategory === 'domains' ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Domains ({registeredDomains.length})
                  </button>
                  <button
                    onClick={() => setServiceCategory('hosting')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      serviceCategory === 'hosting' ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Hosting ({hostingList.length})
                  </button>
                  <button
                    onClick={() => setServiceCategory('ssl')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      serviceCategory === 'ssl' ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    SSL ({sslList.length})
                  </button>
                  <button
                    onClick={() => setServiceCategory('email')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      serviceCategory === 'email' ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Email ({emailList.length})
                  </button>
                  <button
                    onClick={() => setServiceCategory('vps')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      serviceCategory === 'vps' ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    VPS ({vpsList.length})
                  </button>
                </div>
              </div>
            </div>

            {/* SERVICE CATEGORY CONTENT */}
            {serviceCategory === 'hosting' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {hostingList.map((h) => (
                  <div key={h.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase text-sky-700 dark:text-sky-400 bg-sky-100 dark:bg-sky-950 px-2 py-0.5 rounded">
                          {h.planName}
                        </span>
                        <h3 className="font-extrabold text-slate-900 dark:text-white text-base mt-1">{h.name}</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{h.domain}</p>
                      </div>
                      {getStatusBadge(h.status)}
                    </div>

                    {/* Usage Gauges */}
                    <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                      <div>
                        <div className="flex justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                          <span>NVMe Storage</span>
                          <span>{(h.diskUsageMb / 1024).toFixed(1)} GB / {(h.diskLimitMb / 1024).toFixed(0)} GB</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full rounded-full"
                            style={{ width: `${(h.diskUsageMb / h.diskLimitMb) * 100}%` }}
                          ></div>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                          <span>Monthly Bandwidth</span>
                          <span>{h.bandwidthUsageGb} GB / {h.bandwidthLimitGb} GB</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-sky-500 h-full rounded-full"
                            style={{ width: `${(h.bandwidthUsageGb / h.bandwidthLimitGb) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800/80 text-xs grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-slate-500 text-[10px] block">Server IP</span>
                        <span className="font-mono text-slate-900 dark:text-white font-bold">{h.ipAddress}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">PHP Engine</span>
                        <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">{h.phpVersion}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                      <button
                        onClick={() => setSelectedServiceTimeline({ title: `${h.name} (${h.domain})`, timeline: h.timeline })}
                        className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center gap-1 font-bold"
                      >
                        <Clock className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Service Timeline</span>
                      </button>

                      <button
                        onClick={() => setActiveWhmcsHosting(h)}
                        className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-1.5"
                      >
                        <span>Manage Hosting</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {serviceCategory === 'domains' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-2xl border border-emerald-200 dark:border-emerald-900/50">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-md">
                      <Globe className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-900 dark:text-white text-sm">Customer Domain Services</h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {registeredDomains.length} registered domain{registeredDomains.length === 1 ? '' : 's'} managed by your account.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => onOpenDomainHub()}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow inline-flex items-center gap-1.5 self-start sm:self-auto"
                  >
                    <span>Launch Domain Hub</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {registeredDomains.map((d) => (
                    <div key={d.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-sm hover:border-emerald-500/50 transition-all">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500" />
                            <h4 className="font-black text-slate-900 dark:text-white text-base">{d.domain}</h4>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            Registered: {d.registeredDate} • Expires: {d.expiryDate}
                          </p>
                        </div>
                        {getStatusBadge(d.status)}
                      </div>

                      <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl text-xs">
                        <div>
                          <div className="text-[10px] font-bold text-slate-400 uppercase">Renewal Price</div>
                          <div className="font-bold text-slate-800 dark:text-slate-200 font-mono mt-0.5">
                            {formatCurrencyAmount(d.renewalPrice || 120, d.currency || currency)}/yr
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] font-bold text-slate-400 uppercase">Auto-Renew</div>
                          <div className="font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                            {d.autoRenew ? 'Enabled (Active)' : 'Disabled'}
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] font-bold text-slate-400 uppercase">Nameservers</div>
                          <div className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                            {d.nameserverMode === 'custom' ? 'Custom Nameservers' : 'System Default'}
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] font-bold text-slate-400 uppercase">Registrar</div>
                          <div className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                            Managed by System
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <button
                          onClick={() => setSelectedServiceTimeline({
                            title: `Domain Registration - ${d.domain}`,
                            timeline: (d.activityTimeline || []).map((a) => ({
                              id: a.id,
                              title: a.title,
                              description: a.description,
                              timestamp: a.date,
                              status: 'completed',
                              actor: 'Customer'
                            }))
                          })}
                          className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-bold flex items-center gap-1"
                        >
                          <History className="w-3.5 h-3.5" />
                          <span>Activity Timeline</span>
                        </button>

                        <button
                          onClick={() => onOpenDomainHub(d.domain)}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1.5"
                        >
                          <span>Manage Domain</span>
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {serviceCategory === 'ssl' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sslList.map((ssl) => (
                  <div key={ssl.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-sm">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded">
                          {ssl.type}
                        </span>
                        <h3 className="font-extrabold text-slate-900 dark:text-white text-base mt-1">{ssl.domain}</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Issuer: {ssl.issuer}</p>
                      </div>
                      {getStatusBadge(ssl.status)}
                    </div>

                    <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs space-y-1 font-mono text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800/80">
                      <div>SAN Coverage: {ssl.sanDomains.join(', ')}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">Issued: {ssl.issuedDate} | Expiry: {ssl.expiryDate}</div>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <button
                        onClick={() => setSelectedServiceTimeline({ title: `SSL Certificate - ${ssl.domain}`, timeline: ssl.timeline })}
                        className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center gap-1 font-bold"
                      >
                        <History className="w-3.5 h-3.5" />
                        <span>View SSL Timeline</span>
                      </button>
                      <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> 256-Bit RSA Active
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {serviceCategory === 'email' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {emailList.map((em) => (
                  <div key={em.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-sm">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded">
                          {em.provider}
                        </span>
                        <h3 className="font-extrabold text-slate-900 dark:text-white text-base mt-1">{em.domain}</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{em.mailboxesCount} Mailboxes Active</p>
                      </div>
                      {getStatusBadge(em.status)}
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs space-y-1 border border-slate-200 dark:border-slate-800/80">
                      <span className="text-slate-600 dark:text-slate-400">Storage per Mailbox: {em.storagePerMailboxGb} GB</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {serviceCategory === 'vps' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {vpsList.map((vps) => (
                  <div key={vps.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-sm">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded">
                          Dedicated VPS
                        </span>
                        <h3 className="font-extrabold text-slate-900 dark:text-white text-base mt-1">{vps.hostname}</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{vps.os}</p>
                      </div>
                      {getStatusBadge(vps.status)}
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs grid grid-cols-3 gap-2 font-mono border border-slate-200 dark:border-slate-800/80">
                      <div><span className="text-slate-500 text-[10px] block">vCPU</span>{vps.vCpus} Cores</div>
                      <div><span className="text-slate-500 text-[10px] block">RAM</span>{vps.ramGb} GB</div>
                      <div><span className="text-slate-500 text-[10px] block">Storage</span>{vps.ssdGb} GB NVMe</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: INVOICES & BILLING */}
        {activeTab === 'billing' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
              <div>
                <h1 className="text-2xl font-black text-slate-900 dark:text-white">Invoices & Billing Statements</h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Download tax invoices, pay pending balances, and manage payment histories.
                </p>
              </div>
            </div>

            {/* Invoices List */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 uppercase font-black tracking-wider text-[10px] border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-4">Invoice #</th>
                    <th className="p-4">Issue Date</th>
                    <th className="p-4">Due Date</th>
                    <th className="p-4">Total (w/ Tax)</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {invoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="p-4 font-mono font-extrabold text-slate-900 dark:text-white">{inv.invoiceNumber}</td>
                      <td className="p-4">{inv.issueDate}</td>
                      <td className="p-4">{inv.dueDate}</td>
                      <td className="p-4 font-bold font-mono text-emerald-600 dark:text-emerald-400">{formatGhs(inv.total)}</td>
                      <td className="p-4">{getStatusBadge(inv.status)}</td>
                      <td className="p-4 text-right space-x-2">
                        <button
                          onClick={() => setSelectedInvoice(inv)}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold rounded-lg text-xs transition-colors"
                        >
                          View Invoice
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: CUSTOMER WALLET */}
        {activeTab === 'wallet' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
              <div>
                <h1 className="text-2xl font-black text-slate-900 dark:text-white">Customer Wallet & Credits</h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Pre-funded balance for instant domain auto-renewals, backorders, and hosting billing.
                </p>
              </div>
              <button
                onClick={() => setShowTopUpModal(true)}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Top-Up Wallet</span>
              </button>
            </div>

            {/* Balance Card */}
            <div className="p-6 bg-gradient-to-r from-emerald-600 to-teal-700 dark:from-emerald-950 dark:to-slate-900 rounded-2xl border border-emerald-500/30 dark:border-emerald-800/60 flex items-center justify-between shadow-lg text-white">
              <div>
                <p className="text-xs font-bold text-emerald-100 dark:text-emerald-400 uppercase tracking-wider">Current Prepaid Balance</p>
                <h2 className="text-4xl font-black mt-1">{formatGhs(wallet.balance)}</h2>
                <p className="text-xs text-emerald-100 dark:text-slate-300 mt-1">● Secured with Paystack Instant Mobile Money & Card Settlement</p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowTopUpModal(true)}
                  className="px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white font-black text-xs rounded-xl border border-white/30 transition-all flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-3.5 h-3.5" /> Deposit Funds
                </button>
                <div className="p-4 bg-white/10 dark:bg-emerald-900/40 rounded-2xl text-white dark:text-emerald-400 border border-white/20 dark:border-emerald-700/50">
                  <Wallet className="w-8 h-8" />
                </div>
              </div>
            </div>

            {/* Non-Refundable Policy Notice Banner */}
            <div className="p-4 rounded-2xl bg-amber-500/10 dark:bg-amber-950/30 border border-amber-500/30 flex items-start gap-3.5 text-xs text-slate-800 dark:text-slate-200">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-extrabold text-amber-900 dark:text-amber-300 text-xs">Non-Refundable Deposit & Wallet Policy</h4>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-800 dark:text-amber-300 text-[10px] font-mono font-bold uppercase">Policy Notice</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
                  All funds added or topped up to your customer wallet via Paystack are <strong>strictly final and non-refundable</strong>. Wallet credits do not expire and can be utilized at any time for domain registrations, renewals, WHMCS hosting plans, VPS, SSL certificates, and cloud resources.
                </p>
              </div>
            </div>

            {/* Ledger Transactions */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-sm">
              <h3 className="font-extrabold text-slate-900 dark:text-white text-base">Wallet Ledger History</h3>
              <div className="space-y-2">
                {wallet.transactions.map((tx) => (
                  <div key={tx.id} className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-extrabold text-slate-900 dark:text-white">{tx.description}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">Ref: {tx.reference} • {tx.date}</div>
                    </div>
                    <div className="text-right font-mono">
                      <div className={`font-black text-sm ${tx.type === 'credit' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                        {tx.type === 'credit' ? '+' : '-'}{formatGhs(tx.amount)}
                      </div>
                      <div className="text-[10px] text-slate-400 dark:text-slate-500">Bal: {formatGhs(tx.balanceAfter)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: RENEWAL CENTER */}
        {activeTab === 'renewals' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
              <div>
                <h1 className="text-2xl font-black text-slate-900 dark:text-white">Centralized Renewal Center</h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Bulk renew upcoming domain registrations, SSL certificates, and hosting packages.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 cursor-pointer shadow-sm">
                  <input
                    type="checkbox"
                    checked={autoRenewAll}
                    onChange={(e) => setAutoRenewAll(e.target.checked)}
                    className="accent-emerald-600 rounded"
                  />
                  <span>Auto-Renew All Active Services</span>
                </label>

                <button
                  disabled={selectedRenewals.length === 0}
                  onClick={() => alert(`Bulk renewing ${selectedRenewals.length} service(s) using Wallet Balance...`)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Renew Selected ({selectedRenewals.length})</span>
                </button>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 uppercase font-black text-[10px] border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-4 w-10">Select</th>
                    <th className="p-4">Service</th>
                    <th className="p-4">Type</th>
                    <th className="p-4">Expiry Date</th>
                    <th className="p-4">Renewal Price</th>
                    <th className="p-4">Auto-Renew Protection</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {registeredDomains.map((d) => (
                    <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="p-4">
                        <input
                          type="checkbox"
                          checked={selectedRenewals.includes(d.id)}
                          onChange={(e) => {
                            if (e.target.checked) setSelectedRenewals([...selectedRenewals, d.id]);
                            else setSelectedRenewals(selectedRenewals.filter((i) => i !== d.id));
                          }}
                          className="accent-emerald-600 rounded"
                        />
                      </td>
                      <td className="p-4 font-extrabold text-slate-900 dark:text-white">{d.domain}</td>
                      <td className="p-4 uppercase text-[10px] font-black text-emerald-600 dark:text-emerald-400">Domain</td>
                      <td className="p-4">{d.expiryDate}</td>
                      <td className="p-4 font-mono font-bold text-slate-900 dark:text-white">{formatGhs(d.domain.length * 15.5)}</td>
                      <td className="p-4">
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold text-[11px] flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Auto-Renew Enabled
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 6: EXPIRATION CALENDAR */}
        {activeTab === 'calendar' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
              <h1 className="text-2xl font-black text-slate-900 dark:text-white">Expiration Calendar Schedule</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Visual monthly view of service renewals and domain milestones.</p>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-sm">
              <div className="text-center font-extrabold text-slate-900 dark:text-white text-base">September 2026</div>
              <div className="grid grid-cols-7 gap-2 text-center text-xs text-slate-500 dark:text-slate-400 font-bold pb-2 border-b border-slate-200 dark:border-slate-800">
                <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
              </div>
              <div className="grid grid-cols-7 gap-2 text-xs">
                {Array.from({ length: 30 }).map((_, i) => {
                  const day = i + 1;
                  const is15 = day === 15;
                  const is20 = day === 20;
                  return (
                    <div
                      key={day}
                      className={`h-20 p-2 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col justify-between ${
                        is15 || is20 ? 'border-emerald-500/50 bg-emerald-50 dark:bg-emerald-950/20' : ''
                      }`}
                    >
                      <span className="font-bold text-slate-600 dark:text-slate-400">{day}</span>
                      {is15 && (
                        <span className="bg-emerald-600 text-white text-[9px] font-black p-1 rounded truncate">
                          nexustech.io Expiry
                        </span>
                      )}
                      {is20 && (
                        <span className="bg-purple-600 text-white text-[9px] font-black p-1 rounded truncate">
                          Titan Email Expiry
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: TEAM & CONTACTS */}
        {activeTab === 'team' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
              <div>
                <h1 className="text-2xl font-black text-slate-900 dark:text-white">Team Accounts & Permissions</h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Grant granular role-based access for billing, technical management, and domain administration.
                </p>
              </div>
              <button
                onClick={() => setShowInviteModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>Invite Team Member</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {teamMembers.map((tm) => (
                <div key={tm.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded">
                      {tm.role}
                    </span>
                    {tm.isPrimaryOwner && <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold">● Primary Owner</span>}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 dark:text-white text-sm">{tm.name}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{tm.email}</p>
                  </div>
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1 text-[11px] text-slate-600 dark:text-slate-300">
                    <div className="flex items-center justify-between">
                      <span>View & Pay Invoices:</span>
                      <span className={tm.permissions.payInvoices ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-400'}>
                        {tm.permissions.payInvoices ? '✓ Allowed' : '✕ No'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Manage Domains & DNS:</span>
                      <span className={tm.permissions.manageDomains ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-400'}>
                        {tm.permissions.manageDomains ? '✓ Allowed' : '✕ No'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 8: SUPPORT TICKETS */}
        {activeTab === 'tickets' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
              <div>
                <h1 className="text-2xl font-black text-slate-900 dark:text-white">Support & SLA Desk</h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">24/7 assistance with guaranteed response targets.</p>
              </div>
              <button
                onClick={() => setShowNewTicketModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Open New Ticket</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Tickets List Column */}
              <div className="space-y-3">
                {tickets.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTicket(t)}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all space-y-2 shadow-sm ${
                      selectedTicket?.id === t.id
                        ? 'bg-slate-100 dark:bg-slate-800 border-emerald-500'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-emerald-600 dark:text-emerald-400">{t.ticketNumber}</span>
                      {getPriorityBadge(t.priority)}
                    </div>
                    <h4 className="font-extrabold text-slate-900 dark:text-white text-xs line-clamp-2">{t.subject}</h4>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                      <span>Dept: {t.department}</span>
                      <span>Updated: {t.updatedAt}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Active Ticket Discussion Thread */}
              {selectedTicket && (
                <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 flex flex-col justify-between shadow-sm">
                  <div className="space-y-4">
                    <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">{selectedTicket.ticketNumber}</span>
                        <h3 className="font-extrabold text-slate-900 dark:text-white text-base mt-0.5">{selectedTicket.subject}</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Assigned Agent: {selectedTicket.assignedAgent || 'Support Queue'}</p>
                      </div>
                      {getPriorityBadge(selectedTicket.priority)}
                    </div>

                    {/* Messages */}
                    <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                      {selectedTicket.messages.map((m) => (
                        <div
                          key={m.id}
                          className={`p-4 rounded-2xl border text-xs space-y-1 ${
                            m.isInternalNote
                              ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-100'
                              : m.isStaff
                              ? 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200'
                              : 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/40 text-emerald-900 dark:text-emerald-100 ml-4'
                          }`}
                        >
                          <div className="flex items-center justify-between font-bold">
                            <span>
                              {m.senderName} {m.isInternalNote && '(Internal Staff Note)'}
                            </span>
                            <span className="text-[10px] opacity-70">{m.timestamp}</span>
                          </div>
                          <p className="whitespace-pre-wrap">{m.content}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Reply Form */}
                  <form onSubmit={handleSendTicketReply} className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                    {isAdmin && (
                      <label className="flex items-center gap-2 text-xs text-amber-600 dark:text-amber-400 font-bold">
                        <input
                          type="checkbox"
                          checked={isInternalNote}
                          onChange={(e) => setIsInternalNote(e.target.checked)}
                          className="accent-amber-500 rounded"
                        />
                        <span>Post as Staff Internal Note (Visible to Staff Only)</span>
                      </label>
                    )}
                    <textarea
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      placeholder="Type your reply message..."
                      className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                      rows={3}
                    />
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Send Response</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 9: ACCOUNT TIMELINE */}
        {activeTab === 'timeline' && (
          <div className="space-y-6 animate-in fade-in">
            <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
              <h1 className="text-2xl font-black text-slate-900 dark:text-white">Full Customer Account Audit Stream</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Complete history of security events, renewals, payments, and support interactions.</p>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-sm">
              {timelineEvents.map((evt) => (
                <div key={evt.id} className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 flex items-start gap-4">
                  <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-xl shrink-0 mt-0.5">
                    <History className="w-5 h-5" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">{evt.title}</h4>
                      <span className="text-xs text-slate-400 dark:text-slate-500 font-mono">{evt.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{evt.description}</p>
                    <div className="text-[11px] text-slate-400 dark:text-slate-500 font-mono pt-1">Executed by: {evt.actor}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB: CLIENT SECURITY & IAM ================= */}
        {activeTab === 'security' && (
          <div className="animate-in fade-in">
            <SecurityCenter user={systemDatabase.getCurrentUser()} />
          </div>
        )}

          </>
        )}
      </main>


      {/* MODAL: TOP UP WALLET WITH REAL PAYSTACK INTEGRATION */}
      {showTopUpModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 space-y-5 shadow-2xl text-slate-900 dark:text-white">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
                    <Wallet className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">Top-Up Customer Wallet</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Pre-fund balance via Paystack Gateway</p>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setShowTopUpModal(false)} 
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleInitiatePaystackDeposit} className="space-y-4">
              
              {/* Currency Selection Pills */}
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Select Deposit Currency
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {(['GHS', 'USD', 'EUR', 'GBP', 'NGN'] as Currency[]).map((curr) => {
                    const info = CURRENCY_RATES[curr] || { symbol: curr, rate: 1.0 };
                    return (
                      <button
                        key={curr}
                        type="button"
                        onClick={() => {
                          setTopUpCurrency(curr);
                          if (curr === 'GHS') setTopUpAmount('500');
                          else if (curr === 'USD' || curr === 'EUR' || curr === 'GBP') setTopUpAmount('50');
                          else if (curr === 'NGN') setTopUpAmount('50000');
                        }}
                        className={`py-2 px-1.5 rounded-xl text-center text-xs font-black transition-all ${
                          topUpCurrency === curr
                            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/25 scale-[1.02]'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <div>{curr}</div>
                        <div className="text-[10px] opacity-80">{info.symbol}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Quick Preset Buttons */}
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                  Select Quick Amount ({CURRENCY_RATES[topUpCurrency]?.symbol || topUpCurrency})
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(topUpCurrency === 'GHS'
                    ? ['50', '100', '250', '500', '1000', '2500']
                    : topUpCurrency === 'NGN'
                    ? ['10000', '25000', '50000', '100000', '250000', '500000']
                    : ['10', '25', '50', '100', '250', '500']
                  ).map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setTopUpAmount(preset)}
                      className={`py-2 px-3 rounded-xl font-mono text-xs font-black transition-all ${
                        topUpAmount === preset
                          ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/25 scale-[1.02]'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                      }`}
                    >
                      {CURRENCY_RATES[topUpCurrency]?.symbol || ''} {parseInt(preset).toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Input */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Deposit Amount ({topUpCurrency})
                  </label>
                  {topUpCurrency !== 'GHS' ? (
                    <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                      ≈ GH₵ {(((parseFloat(topUpAmount) || 0) / (CURRENCY_RATES[topUpCurrency]?.rate || 1)) * (CURRENCY_RATES.GHS?.rate || 15.5)).toFixed(2)} GHS
                    </span>
                  ) : (
                    <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                      ≈ ${((parseFloat(topUpAmount) || 0) / (CURRENCY_RATES.GHS?.rate || 15.5)).toFixed(2)} USD
                    </span>
                  )}
                </div>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                    {CURRENCY_RATES[topUpCurrency]?.symbol || '$'}
                  </span>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={topUpAmount}
                    onChange={(e) => setTopUpAmount(e.target.value)}
                    placeholder="Enter deposit amount"
                    className="w-full pl-14 pr-4 py-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-2xl text-slate-900 dark:text-white font-mono text-lg font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Supported Payment Channels */}
              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                  <span className="font-bold text-slate-700 dark:text-slate-300">Paystack Channels:</span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">Instant Credit</span>
                </div>
                <div className="flex items-center gap-2 flex-wrap text-[10px] font-bold text-slate-600 dark:text-slate-300">
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">MTN MoMo</span>
                  <span className="px-2 py-0.5 rounded-md bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20">Telecel Cash</span>
                  <span className="px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">Visa / Mastercard</span>
                  <span className="px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">Bank</span>
                </div>
              </div>

              {/* MANDATORY NON-REFUNDABLE POLICY DISCLOSURE */}
              <div className="p-4 rounded-2xl bg-amber-500/10 dark:bg-amber-950/40 border border-amber-500/30 text-xs space-y-2">
                <div className="flex items-center gap-2 font-black uppercase tracking-wider text-[11px] text-amber-800 dark:text-amber-300">
                  <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Non-Refundable Policy Notice</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 text-[11px] leading-relaxed font-medium">
                  All funds deposited or added to your customer wallet are <strong>strictly final and non-refundable</strong>. Deposited funds are credited to your balance instantly and never expire.
                </p>
                <label className="flex items-center gap-2.5 pt-1 cursor-pointer select-none text-[11px] font-bold text-slate-800 dark:text-slate-200">
                  <input
                    type="checkbox"
                    checked={nonRefundableConsent}
                    onChange={(e) => setNonRefundableConsent(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 dark:border-slate-700"
                  />
                  <span>I agree and acknowledge money paid is not refundable.</span>
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={!nonRefundableConsent || (parseFloat(topUpAmount) || 0) <= 0}
                className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-black text-sm rounded-2xl shadow-xl shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99]"
              >
                <Zap className="w-4 h-4 text-amber-300" />
                <span>Pay {CURRENCY_RATES[topUpCurrency]?.symbol || ''} {parseFloat(topUpAmount) > 0 ? parseFloat(topUpAmount).toLocaleString('en-US', { minimumFractionDigits: 2 }) : '0.00'} with Paystack</span>
              </button>

            </form>
          </div>
        </div>
      )}

      {/* PAYSTACK OFFICIAL CHECKOUT MODAL FOR WALLET DEPOSITS */}
      {isPaystackTopUpOpen && (
        <PaystackCheckoutModal
          amount={activeDepositAmount}
          currency={activeDepositCurrency}
          customerEmail={userEmail}
          customerName={personName}
          paystackConfig={systemSettings?.paymentGateways?.paystack || {
            enabled: true,
            publicKey: 'pk_live_93621f2292fc2f1396ddc18fea182881a6f55e1b',
            currencyPreference: 'GHS',
            environment: 'live'
          }}
          orderId={activeDepositOrderId}
          purpose="wallet_deposit"
          description="Prepaid Customer Wallet Deposit"
          nonRefundableNotice={true}
          onSuccess={handlePaystackDepositSuccess}
          onClose={() => setIsPaystackTopUpOpen(false)}
        />
      )}

      {/* FLOATING SUCCESS NOTIFICATION */}
      {depositToast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md bg-slate-900 text-white p-4 rounded-2xl shadow-2xl border border-emerald-500/50 flex items-start gap-3.5 animate-in slide-in-from-bottom-5">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="space-y-0.5 flex-1">
            <h4 className="font-extrabold text-sm text-emerald-400">Wallet Funded Successfully</h4>
            <p className="text-xs text-slate-300">{depositToast.text}</p>
            <p className="text-[10px] font-mono text-slate-400 pt-0.5">Ref: {depositToast.reference}</p>
          </div>
          <button 
            onClick={() => setDepositToast(null)}
            className="text-slate-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* MODAL: SELECTED INVOICE DETAIL & TAX BREAKDOWN */}
      {selectedInvoice && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-2xl text-slate-900 dark:text-white">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <Receipt className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <h3 className="font-extrabold text-sm">Tax Invoice #{selectedInvoice.invoiceNumber}</h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">Issue Date: {selectedInvoice.issueDate} • Due: {selectedInvoice.dueDate}</p>
                </div>
              </div>
              <button onClick={() => setSelectedInvoice(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Line Items */}
            <div className="space-y-2">
              <div className="text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">Invoice Items</div>
              <div className="space-y-1.5 bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                {selectedInvoice.items.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-800 dark:text-slate-200">{item.description}</span>
                    <span className="font-mono font-bold">{formatGhs(item.amount)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Itemized Tax Breakdown */}
            {(() => {
              const ghsRate = CURRENCY_RATES['GHS']?.rate || 15.5;
              const subtotalUsd = (selectedInvoice.total / ghsRate) / (1 + defaultTaxPercent / 100);
              const tax = calculateTaxBreakdown({
                subtotalUsd,
                currency,
                taxRatePercent: defaultTaxPercent,
              });
              return (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-600 dark:text-slate-400">
                    <span>Subtotal:</span>
                    <span className="font-mono">{tax.subtotalFormatted}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 dark:text-slate-400 text-[11px]">
                    <span>VAT & Statutory Levies ({tax.taxRatePercent}%):</span>
                    <span className="font-mono">{tax.taxAmountFormatted}</span>
                  </div>
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between font-extrabold text-sm text-slate-900 dark:text-white">
                    <span>Total Amount Due:</span>
                    <span className="font-mono text-emerald-600 dark:text-emerald-400">{tax.grandTotalFormatted}</span>
                  </div>
                </div>
              );
            })()}

            {/* Actions */}
            <div className="flex items-center justify-between pt-2">
              <div className="text-xs">
                Status: {getStatusBadge(selectedInvoice.status)}
              </div>
              <div className="flex gap-2">
                {selectedInvoice.status === 'unpaid' && (
                  <button
                    onClick={() => handlePayInvoiceWithWallet(selectedInvoice)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow transition-colors"
                  >
                    Pay with Wallet ({formatGhs(wallet.balance)})
                  </button>
                )}
                <button
                  onClick={() => window.print()}
                  className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download / Print</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: NEW TICKET */}
      {showNewTicketModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-2xl text-slate-900 dark:text-white">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base">Open Technical Support Ticket</h3>
              <button onClick={() => setShowNewTicketModal(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Department</label>
                <select
                  value={ticketDept}
                  onChange={(e) => setTicketDept(e.target.value as any)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white text-xs focus:outline-none"
                >
                  <option value="Domains">Domains & DNS</option>
                  <option value="Hosting">Hosting & Control Panel</option>
                  <option value="Billing">Invoices & Payments</option>
                  <option value="Technical">Technical Operations</option>
                  <option value="SSL & Security">SSL & Security</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Subject</label>
                <input
                  type="text"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  placeholder="Summarize your technical issue..."
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* KB Suggestions */}
              {kbSuggestions.length > 0 && (
                <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 rounded-xl text-xs space-y-1">
                  <span className="font-bold text-indigo-700 dark:text-indigo-300 block">Suggested Knowledgebase Articles:</span>
                  {kbSuggestions.map((art, idx) => (
                    <a key={idx} href="#" className="block text-indigo-600 dark:text-indigo-400 underline hover:text-indigo-800 dark:hover:text-indigo-200 text-[11px]">
                      • {art.title}
                    </a>
                  ))}
                </div>
              )}

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Description</label>
                <textarea
                  value={ticketContent}
                  onChange={(e) => setTicketContent(e.target.value)}
                  placeholder="Provide steps to reproduce, error codes, or domain names..."
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white text-xs focus:outline-none focus:border-emerald-500"
                  rows={4}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg"
              >
                Submit Ticket to Queue
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: INVITE TEAM MEMBER */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-2xl text-slate-900 dark:text-white">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base">Invite Team Member</h3>
              <button onClick={() => setShowInviteModal(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleInviteTeamMember} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Full Name</label>
                <input
                  type="text"
                  value={newInviteName}
                  onChange={(e) => setNewInviteName(e.target.value)}
                  placeholder="e.g. Sarah Jenkins"
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Email Address</label>
                <input
                  type="email"
                  value={newInviteEmail}
                  onChange={(e) => setNewInviteEmail(e.target.value)}
                  placeholder="sarah@company.com"
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Role & Permissions</label>
                <select
                  value={newInviteRole}
                  onChange={(e) => setNewInviteRole(e.target.value as any)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white text-xs focus:outline-none"
                >
                  <option value="Technical Contact">Technical Contact (DNS & Hosting)</option>
                  <option value="Billing Contact">Billing Contact (Invoices & Payments)</option>
                  <option value="Administrative Contact">Administrative Contact (Full Management)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg"
              >
                Send Invitation
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: STAFF IMPERSONATION PROMPT */}
      {showImpersonateModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-amber-400 dark:border-amber-500/50 rounded-2xl p-6 space-y-4 shadow-2xl text-slate-900 dark:text-white">
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-extrabold">
              <ShieldAlert className="w-5 h-5" />
              <span>Admin Customer Impersonation</span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              You are about to launch a secure, time-limited staff impersonation session for <strong>Alex Morgan</strong> (alex.morgan@nexustech.io).
            </p>

            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Reason for Impersonation (Audit Logged)</label>
              <textarea
                value={impersonateReason}
                onChange={(e) => setImpersonateReason(e.target.value)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white text-xs focus:outline-none"
                rows={3}
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowImpersonateModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onTriggerImpersonation('Alex Morgan', 'alex.morgan@nexustech.io');
                  setShowImpersonateModal(false);
                }}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold rounded-xl"
              >
                Start Impersonation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SERVICE TIMELINE MODAL */}
      {selectedServiceTimeline && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-2xl text-slate-900 dark:text-white">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base">{selectedServiceTimeline.title}</h3>
              <button onClick={() => setSelectedServiceTimeline(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              {selectedServiceTimeline.timeline.map((st: any) => (
                <div key={st.id} className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                  <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white">
                    <span>{st.title}</span>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500">{st.timestamp}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400">{st.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* WHMCS PRODUCT CATALOG ORDER MODAL */}
      <WhmcsProductCatalogModal
        isOpen={showWhmcsCatalog}
        onClose={() => setShowWhmcsCatalog(false)}
        onOrderComplete={(newSrv) => {
          setHostingList([newSrv, ...hostingList]);
          setActiveWhmcsHosting(newSrv);
        }}
        userDomains={registeredDomains.map((d) => d.domain)}
        currency={currency}
      />
    </div>
  );
};

