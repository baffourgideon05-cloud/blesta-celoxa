import React, { useState, useEffect, useRef } from 'react';
import { 
  Settings, 
  Server, 
  Globe, 
  ShieldCheck, 
  DollarSign, 
  Mail, 
  Save, 
  RefreshCw, 
  Check, 
  AlertTriangle, 
  Sliders, 
  Cpu, 
  Lock, 
  Sparkles, 
  Plus, 
  X, 
  Zap, 
  Layers, 
  Key, 
  CheckCircle2, 
  Info,
  Building,
  Terminal,
  Database,
  Download,
  Upload,
  Table,
  FileJson,
  RotateCcw,
  FileText,
  Play,
  HardDrive,
  Search,
  Activity,
  Trash2,
  Edit3,
  CreditCard
} from 'lucide-react';
import { SystemSettingsConfig, Currency, Language, TLDDetail, PaymentMethodSettings, PaymentSubmission } from '../types';
import { DEFAULT_SYSTEM_SETTINGS } from '../data/defaultSystemSettings';
import { DEFAULT_PAYMENT_SETTINGS } from '../data/paymentSettings';
import { systemDatabase, SystemDatabaseState } from '../services/systemDatabase';
import { HostingPackageBlueprint } from './HostingProvisionSystem';
import { AdminPaymentSettings } from './AdminPaymentSettings';

interface SystemSettingsViewProps {
  settings?: SystemSettingsConfig;
  onSaveSettings?: (newSettings: SystemSettingsConfig) => void;
  currency?: Currency;
  paymentSettings?: PaymentMethodSettings;
  onUpdatePaymentSettings?: (newSettings: PaymentMethodSettings) => void;
  paymentSubmissions?: PaymentSubmission[];
  onApproveSubmission?: (submissionId: string) => void;
  onRejectSubmission?: (submissionId: string) => void;
}

export const SystemSettingsView: React.FC<SystemSettingsViewProps> = ({
  settings: initialSettings,
  onSaveSettings,
  currency = 'USD',
  paymentSettings = DEFAULT_PAYMENT_SETTINGS,
  onUpdatePaymentSettings = () => {},
  paymentSubmissions = [],
  onApproveSubmission = () => {},
  onRejectSubmission = () => {},
}) => {
  const [config, setConfig] = useState<SystemSettingsConfig>(initialSettings || systemDatabase.getSettings());
  const [activeTab, setActiveTab] = useState<'general' | 'database' | 'hosting' | 'domains' | 'security' | 'billing' | 'payment_gateways' | 'mail'>('general');
  const [isSaved, setIsSaved] = useState(false);
  const [testEmailSending, setTestEmailSending] = useState(false);
  const [testEmailSuccess, setTestEmailSuccess] = useState(false);
  const [newIpAddress, setNewIpAddress] = useState('');

  // Hosting Packages Admin State
  const [editingPackage, setEditingPackage] = useState<HostingPackageBlueprint | null>(null);
  const [isPkgModalOpen, setIsPkgModalOpen] = useState(false);

  // TLD Admin State
  const [editingTld, setEditingTld] = useState<TLDDetail | null>(null);
  const [isTldModalOpen, setIsTldModalOpen] = useState(false);
  const [tldSearchQuery, setTldSearchQuery] = useState('');

  // Database Management Tab State
  const [dbState, setDbState] = useState<SystemDatabaseState>(systemDatabase.getState());
  const [selectedTable, setSelectedTable] = useState<'system_settings' | 'hosting_packages' | 'control_panel_gateways' | 'server_cluster_nodes' | 'provisioned_accounts' | 'audit_logs'>('system_settings');
  const [tableSearch, setTableSearch] = useState('');
  const [sqlQuery, setSqlQuery] = useState('SELECT * FROM system_settings');
  const [sqlResult, setSqlResult] = useState<{ success: boolean; data?: any[]; message: string } | null>(null);
  const [dbNotification, setDbNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const logoFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const dataUrl = evt.target?.result as string;
        if (dataUrl) {
          const updated = {
            ...config,
            general: { ...config.general, logoUrl: dataUrl },
          };
          setConfig(updated);
          systemDatabase.updateSettings(updated);
          setIsSaved(true);
          setTimeout(() => setIsSaved(false), 3000);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    if (initialSettings) {
      setConfig(initialSettings);
    }
  }, [initialSettings]);

  useEffect(() => {
    const unsubscribe = systemDatabase.subscribe((updatedDb) => {
      setDbState(updatedDb);
      setConfig(updatedDb.settings);
    });
    return () => unsubscribe();
  }, []);

  const handleSave = () => {
    systemDatabase.updateSettings(config);
    if (onSaveSettings) {
      onSaveSettings(config);
    }
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleReset = () => {
    if (window.confirm('Reset all system settings and database store to enterprise default configuration?')) {
      systemDatabase.resetToFactoryDefaults();
      setConfig(systemDatabase.getSettings());
      if (onSaveSettings) {
        onSaveSettings(systemDatabase.getSettings());
      }
      setDbNotification({ type: 'success', message: 'System database reset to factory defaults.' });
      setTimeout(() => setDbNotification(null), 4000);
    }
  };

  const handleSendTestEmail = () => {
    setTestEmailSending(true);
    setTestEmailSuccess(false);
    setTimeout(() => {
      setTestEmailSending(false);
      setTestEmailSuccess(true);
      setTimeout(() => setTestEmailSuccess(false), 4000);
    }, 1200);
  };

  const handleAddStaffIp = () => {
    if (!newIpAddress.trim()) return;
    if (config.securityAntiSpam.staffIpWhitelist.includes(newIpAddress.trim())) return;
    
    setConfig({
      ...config,
      securityAntiSpam: {
        ...config.securityAntiSpam,
        staffIpWhitelist: [...config.securityAntiSpam.staffIpWhitelist, newIpAddress.trim()],
      },
    });
    setNewIpAddress('');
  };

  const handleRemoveStaffIp = (ip: string) => {
    setConfig({
      ...config,
      securityAntiSpam: {
        ...config.securityAntiSpam,
        staffIpWhitelist: config.securityAntiSpam.staffIpWhitelist.filter((item) => item !== ip),
      },
    });
  };

  // Database Management Actions
  const handleExecuteSql = () => {
    if (!sqlQuery.trim()) return;
    const res = systemDatabase.executeQuery(sqlQuery);
    setSqlResult(res);
  };

  const handleExportDatabase = () => {
    const dump = systemDatabase.exportJsonDump();
    const blob = new Blob([dump], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `celoxa_system_database_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setDbNotification({ type: 'success', message: 'Full system database dump downloaded.' });
    setTimeout(() => setDbNotification(null), 4000);
  };

  const handleImportDatabase = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      if (content) {
        const success = systemDatabase.importJsonDump(content);
        if (success) {
          setDbNotification({ type: 'success', message: 'Database state successfully restored from JSON dump.' });
        } else {
          setDbNotification({ type: 'error', message: 'Failed to import DB: Invalid schema format.' });
        }
        setTimeout(() => setDbNotification(null), 4000);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const getTableRecords = () => {
    let raw: any[] = [];
    if (selectedTable === 'system_settings') raw = [dbState.settings.general];
    if (selectedTable === 'hosting_packages') raw = dbState.hostingPackages;
    if (selectedTable === 'control_panel_gateways') raw = dbState.controlPanelGateways;
    if (selectedTable === 'server_cluster_nodes') raw = dbState.serverClusterNodes;
    if (selectedTable === 'provisioned_accounts') raw = dbState.provisionedAccounts;
    if (selectedTable === 'audit_logs') raw = dbState.auditLogs;

    if (!tableSearch.trim()) return raw;
    const s = tableSearch.toLowerCase();
    return raw.filter((item) => JSON.stringify(item).toLowerCase().includes(s));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      
      {/* HEADER BAR */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shadow-lg">
            <Settings className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black tracking-tight text-white">System Settings Control Panel</h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                WHMCS v0.8.0 Active
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Configure global system parameters, hosting auto-provisioning rules, security filters, and currency rate sync.
            </p>
          </div>
        </div>

        {/* TOP ACTIONS */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleReset}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold rounded-xl border border-slate-700 transition-colors flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4 text-slate-400" />
            <span>Restore Defaults</span>
          </button>

          <button
            onClick={handleSave}
            className={`px-5 py-2.5 font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 ${
              isSaved
                ? 'bg-emerald-500 text-slate-950 scale-105'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/25'
            }`}
          >
            {isSaved ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Settings Saved!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Save All Changes</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* SYSTEM INTEGRITY SCORE & MAINTENANCE STATUS BANNER */}
      {config.general.maintenanceMode && (
        <div className="bg-amber-500/15 border border-amber-500/30 text-amber-200 p-4 rounded-2xl flex items-center gap-3 text-xs">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
          <div>
            <strong className="text-amber-300 font-bold">System Maintenance Mode is Active:</strong> Public customer access is currently paused. Only staff members with whitelisted IP addresses can access the client area.
          </div>
        </div>
      )}

      {/* TAB NAVIGATION HEADER */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-2 shadow-sm flex items-center gap-1 overflow-x-auto scrollbar-none">
        {[
          { id: 'general', label: 'General System', icon: Building, color: 'text-blue-500' },
          { id: 'database', label: 'Database & Storage Engine', icon: Database, color: 'text-cyan-500' },
          { id: 'hosting', label: 'Hosting & Provisioning', icon: Server, color: 'text-indigo-500' },
          { id: 'domains', label: 'Domains & Registrar', icon: Globe, color: 'text-teal-500' },
          { id: 'security', label: 'Security & Anti-Spam', icon: ShieldCheck, color: 'text-emerald-500' },
          { id: 'billing', label: 'Billing & Rates Sync', icon: DollarSign, color: 'text-amber-500' },
          { id: 'payment_gateways', label: 'Payment Gateways & Paystack', icon: CreditCard, color: 'text-emerald-500' },
          { id: 'mail', label: 'Mail & Alerts', icon: Mail, color: 'text-purple-500' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: GENERAL SYSTEM SETTINGS */}
      {activeTab === 'general' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Building className="w-5 h-5 text-blue-500" />
              <span>General System Identification</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Basic company brand details, support contact handles, and global client area display defaults.
            </p>
          </div>

          {/* CUSTOM BRAND LOGO MANAGER */}
          <div className="p-5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-500" />
                  <span>Custom System Logo & Brand Emblem</span>
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Upload an image from your computer or provide a URL to update the header, client portal, and invoices.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => logoFileInputRef.current?.click()}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload Custom Logo</span>
                </button>
                <input
                  type="file"
                  ref={logoFileInputRef}
                  onChange={handleLogoFileUpload}
                  accept="image/*"
                  className="hidden"
                />

                {config.general.logoUrl && (
                  <button
                    type="button"
                    onClick={() => {
                      const updated = {
                        ...config,
                        general: { ...config.general, logoUrl: '' },
                      };
                      setConfig(updated);
                      systemDatabase.updateSettings(updated);
                    }}
                    className="px-3 py-2 bg-rose-600/10 hover:bg-rose-600/20 text-rose-500 font-bold text-xs rounded-xl border border-rose-500/20 transition-all flex items-center gap-1.5"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Clear Logo</span>
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
              {/* Preview Box */}
              <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col items-center justify-center space-y-2 min-h-[90px]">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Live Navbar Preview</span>
                {config.general.logoUrl ? (
                  <img
                    src={config.general.logoUrl}
                    alt="Custom Logo Preview"
                    className="max-h-10 w-auto object-contain rounded"
                  />
                ) : (
                  <div className="flex items-center gap-2 text-slate-400 text-xs font-bold">
                    <Globe className="w-5 h-5 text-blue-500" />
                    <span>Default Icon Logo</span>
                  </div>
                )}
              </div>

              {/* URL Input */}
              <div className="sm:col-span-2 space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 font-mono">Or Image URL / Base64</label>
                <input
                  type="text"
                  value={config.general.logoUrl}
                  onChange={(e) => setConfig({
                    ...config,
                    general: { ...config.general, logoUrl: e.target.value }
                  })}
                  placeholder="https://example.com/logo.png or data:image/png;base64,..."
                  className="w-full px-3.5 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            
            {/* Site Name */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Site Branding Name</label>
              <input
                type="text"
                value={config.general.siteName}
                onChange={(e) => setConfig({
                  ...config,
                  general: { ...config.general, siteName: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Company Name */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Legal Company Name</label>
              <input
                type="text"
                value={config.general.companyName}
                onChange={(e) => setConfig({
                  ...config,
                  general: { ...config.general, companyName: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Contact Email */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">System Admin Email</label>
              <input
                type="email"
                value={config.general.contactEmail}
                onChange={(e) => setConfig({
                  ...config,
                  general: { ...config.general, contactEmail: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Support Phone */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Customer Support Phone</label>
              <input
                type="text"
                value={config.general.supportPhone}
                onChange={(e) => setConfig({
                  ...config,
                  general: { ...config.general, supportPhone: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Default Currency */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">System Base Currency</label>
              <select
                value={config.general.defaultCurrency}
                onChange={(e) => setConfig({
                  ...config,
                  general: { ...config.general, defaultCurrency: e.target.value as Currency }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="USD">USD ($ - US Dollar)</option>
                <option value="GHS">GHS (GH₵ - Ghana Cedi)</option>
                <option value="EUR">EUR (€ - Euro)</option>
                <option value="GBP">GBP (£ - British Pound)</option>
              </select>
            </div>

            {/* System Timezone */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">System Timezone</label>
              <input
                type="text"
                value={config.general.timezone}
                onChange={(e) => setConfig({
                  ...config,
                  general: { ...config.general, timezone: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

          </div>

          {/* Maintenance Mode Toggle */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div>
              <span className="font-extrabold text-slate-900 dark:text-white text-sm block">System Maintenance Mode</span>
              <span className="text-xs text-slate-500">Temporarily lock client registration and storefront checkout for maintenance.</span>
            </div>
            <button
              onClick={() => setConfig({
                ...config,
                general: { ...config.general, maintenanceMode: !config.general.maintenanceMode }
              })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                config.general.maintenanceMode ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                config.general.maintenanceMode ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>

        </div>
      )}

      {/* TAB: DATABASE ENGINE & STORAGE SYSTEM */}
      {activeTab === 'database' && (
        <div className="space-y-6">
          
          {/* Notification Alert */}
          {dbNotification && (
            <div className={`p-4 rounded-2xl border text-xs flex items-center gap-3 ${
              dbNotification.type === 'success'
                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                : 'bg-rose-500/15 border-rose-500/30 text-rose-300'
            }`}>
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>{dbNotification.message}</span>
            </div>
          )}

          {/* DB HEALTH & METRICS CARDS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Storage Engine</span>
                <Database className="w-4 h-4 text-cyan-500" />
              </div>
              <div className="text-xl font-black text-slate-900 dark:text-white">LocalStorage + IndexedDB</div>
              <p className="text-[11px] text-emerald-500 font-bold flex items-center gap-1">
                <Activity className="w-3 h-3" /> Live Persisted & Auto-Synced
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Total Size Used</span>
                <HardDrive className="w-4 h-4 text-indigo-500" />
              </div>
              <div className="text-xl font-black text-slate-900 dark:text-white">
                {(JSON.stringify(dbState).length / 1024).toFixed(2)} KB
              </div>
              <p className="text-[11px] text-slate-400">Schema Version {dbState.version}</p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Total Rows Persisted</span>
                <Table className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-xl font-black text-slate-900 dark:text-white">
                {1 + dbState.hostingPackages.length + dbState.controlPanelGateways.length + dbState.serverClusterNodes.length + dbState.provisionedAccounts.length + dbState.auditLogs.length} Records
              </div>
              <p className="text-[11px] text-slate-400">Across 6 System Tables</p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-2 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Last System Sync</span>
                <RotateCcw className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-base font-black text-slate-900 dark:text-white truncate">
                {new Date(dbState.lastUpdated).toLocaleTimeString()}
              </div>
              <p className="text-[11px] text-slate-400">Multi-tab live broadcast enabled</p>
            </div>

          </div>

          {/* BACKUP, RESTORE & DUMP TOOLS */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-cyan-500" />
                  <span>Database Backup, Restore & DDL Dumps</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Export full JSON backups, restore existing system database snapshots, or wipe database back to initial seed data.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportDatabase}
                  className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download JSON Dump</span>
                </button>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-extrabold text-xs rounded-xl border border-slate-700 transition-all flex items-center gap-2"
                >
                  <Upload className="w-4 h-4 text-indigo-400" />
                  <span>Restore from File</span>
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImportDatabase}
                  accept=".json"
                  className="hidden"
                />

                <button
                  onClick={handleReset}
                  className="px-4 py-2.5 bg-rose-600/10 hover:bg-rose-600/20 text-rose-500 font-extrabold text-xs rounded-xl border border-rose-500/20 transition-all flex items-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset Seed Data</span>
                </button>
              </div>
            </div>

            {/* VISUAL TABLE INSPECTOR */}
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {[
                    { id: 'system_settings', label: 'system_settings', count: 1 },
                    { id: 'hosting_packages', label: 'hosting_packages', count: dbState.hostingPackages.length },
                    { id: 'control_panel_gateways', label: 'control_panel_gateways', count: dbState.controlPanelGateways.length },
                    { id: 'server_cluster_nodes', label: 'server_cluster_nodes', count: dbState.serverClusterNodes.length },
                    { id: 'provisioned_accounts', label: 'provisioned_accounts', count: dbState.provisionedAccounts.length },
                    { id: 'audit_logs', label: 'audit_logs', count: dbState.auditLogs.length },
                  ].map((tbl) => (
                    <button
                      key={tbl.id}
                      onClick={() => setSelectedTable(tbl.id as any)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                        selectedTable === tbl.id
                          ? 'bg-slate-900 text-cyan-400 border border-cyan-500/30 shadow-sm'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <Table className="w-3.5 h-3.5" />
                      <span>{tbl.label}</span>
                      <span className="px-1.5 py-0.2 text-[10px] bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-full font-bold">
                        {tbl.count}
                      </span>
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={tableSearch}
                    onChange={(e) => setTableSearch(e.target.value)}
                    placeholder={`Filter records in ${selectedTable}...`}
                    className="pl-8 pr-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
              </div>

              {/* TABLE DATA GRID */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-slate-950 text-slate-200 text-xs">
                <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 font-mono font-bold text-[11px] text-cyan-400 flex items-center justify-between">
                  <span>TABLE SCHEMA: public.{selectedTable}</span>
                  <span className="text-slate-400 font-sans text-xs">Showing {getTableRecords().length} record(s)</span>
                </div>
                <div className="max-h-72 overflow-y-auto p-4 font-mono text-[11px] space-y-2">
                  {getTableRecords().length === 0 ? (
                    <div className="text-slate-500 py-6 text-center font-sans">
                      No records matched search filter "{tableSearch}"
                    </div>
                  ) : (
                    getTableRecords().map((item, idx) => (
                      <div key={idx} className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 space-y-1">
                        <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold border-b border-slate-800/80 pb-1">
                          <span>RECORD #{idx + 1} ({item.id || item.siteName || 'DEFAULT_ROW'})</span>
                          <span className="text-cyan-400 font-mono">{selectedTable}</span>
                        </div>
                        <pre className="text-cyan-300 overflow-x-auto whitespace-pre-wrap leading-relaxed">
                          {JSON.stringify(item, null, 2)}
                        </pre>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* INTERACTIVE SQL QUERY CONSOLE */}
            <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-500" />
                  <span>Interactive SQL Query Console</span>
                </h4>
                <div className="flex items-center gap-1.5 text-[11px]">
                  <span className="text-slate-500">Quick queries:</span>
                  {[
                    'SELECT * FROM system_settings',
                    'SELECT * FROM hosting_packages',
                    'SHOW TABLES',
                  ].map((q) => (
                    <button
                      key={q}
                      onClick={() => setSqlQuery(q)}
                      className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded font-mono text-[10px]"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <div className="relative">
                  <textarea
                    value={sqlQuery}
                    onChange={(e) => setSqlQuery(e.target.value)}
                    rows={3}
                    placeholder="Enter SQL statement e.g. UPDATE system_settings SET site_name = 'My Host Name'"
                    className="w-full font-mono text-xs p-3.5 bg-slate-950 text-emerald-400 border border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    onClick={handleExecuteSql}
                    className="absolute right-3 bottom-4 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Run Query</span>
                  </button>
                </div>

                {sqlResult && (
                  <div className={`p-4 rounded-2xl border font-mono text-xs space-y-2 ${
                    sqlResult.success
                      ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                  }`}>
                    <div className="flex items-center justify-between border-b border-emerald-500/20 pb-1">
                      <span className="font-bold flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        {sqlResult.message}
                      </span>
                      <span className="text-[10px] opacity-70">STATUS: SUCCESS</span>
                    </div>
                    {sqlResult.data && (
                      <pre className="text-[11px] text-emerald-200 overflow-x-auto whitespace-pre-wrap">
                        {JSON.stringify(sqlResult.data, null, 2)}
                      </pre>
                    )}
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* TAB 2: HOSTING & PROVISIONING SETTINGS */}
      {activeTab === 'hosting' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Server className="w-5 h-5 text-indigo-500" />
              <span>Hosting Provisioning Engine Rules</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Control auto-provision triggers upon order payment, default server manager (WHMCS/cPanel/DirectAdmin/Plesk), and cluster nameservers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            
            {/* Default Server Manager */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default Control Panel Server Manager</label>
              <select
                value={config.hostingProvisioning.defaultServerManager}
                onChange={(e) => setConfig({
                  ...config,
                  hostingProvisioning: {
                    ...config.hostingProvisioning,
                    defaultServerManager: e.target.value as any,
                  }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-indigo-600 dark:text-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="whmcs">WHMCS Enterprise Server Module (Auto-provision)</option>
                <option value="cpanel">cPanel & WHM Native API</option>
                <option value="directadmin">DirectAdmin API</option>
                <option value="plesk">Plesk Onyx / Obsidian API</option>
              </select>
            </div>

            {/* Server Node Pool */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default Server Node Allocation Pool</label>
              <input
                type="text"
                value={config.hostingProvisioning.serverNodePool}
                onChange={(e) => setConfig({
                  ...config,
                  hostingProvisioning: { ...config.hostingProvisioning, serverNodePool: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* cPanel Theme */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default cPanel Theme Template</label>
              <input
                type="text"
                value={config.hostingProvisioning.cpanelTheme}
                onChange={(e) => setConfig({
                  ...config,
                  hostingProvisioning: { ...config.hostingProvisioning, cpanelTheme: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Default PHP Version */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default PHP FPM Runtime</label>
              <select
                value={config.hostingProvisioning.phpVersion}
                onChange={(e) => setConfig({
                  ...config,
                  hostingProvisioning: { ...config.hostingProvisioning, phpVersion: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-emerald-600 dark:text-emerald-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="8.3">PHP 8.3 (Latest Stable)</option>
                <option value="8.2">PHP 8.2 (Recommended)</option>
                <option value="8.1">PHP 8.1</option>
                <option value="8.0">PHP 8.0</option>
              </select>
            </div>

          </div>

          {/* Nameservers Array */}
          <div className="space-y-3 pt-2">
            <h4 className="font-extrabold text-slate-900 dark:text-white text-xs">Cluster Default Nameservers</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
              {config.hostingProvisioning.defaultNameservers.map((ns, idx) => (
                <div key={idx} className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-500">Nameserver {idx + 1}</label>
                  <input
                    type="text"
                    value={ns}
                    onChange={(e) => {
                      const updated = [...config.hostingProvisioning.defaultNameservers] as [string, string, string, string];
                      updated[idx] = e.target.value;
                      setConfig({
                        ...config,
                        hostingProvisioning: { ...config.hostingProvisioning, defaultNameservers: updated }
                      });
                    }}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-xs text-indigo-600 dark:text-indigo-400 font-bold focus:outline-none"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-200 dark:border-slate-800 text-xs">
            
            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">Auto Provision on Order Payment</span>
                <span className="text-[11px] text-slate-500">Create hosting account instantly when invoice status becomes paid.</span>
              </div>
              <button
                onClick={() => setConfig({
                  ...config,
                  hostingProvisioning: { ...config.hostingProvisioning, autoProvisionOnPayment: !config.hostingProvisioning.autoProvisionOnPayment }
                })}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  config.hostingProvisioning.autoProvisionOnPayment ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                  config.hostingProvisioning.autoProvisionOnPayment ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">AutoSSL Certificate Issuance</span>
                <span className="text-[11px] text-slate-500">Auto-request Let's Encrypt 90-day SSL upon domain creation.</span>
              </div>
              <button
                onClick={() => setConfig({
                  ...config,
                  hostingProvisioning: { ...config.hostingProvisioning, autoSslEnabled: !config.hostingProvisioning.autoSslEnabled }
                })}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  config.hostingProvisioning.autoSslEnabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                  config.hostingProvisioning.autoSslEnabled ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

          </div>

          {/* ADMIN AREA: HOSTING PACKAGES MANAGEMENT */}
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Server className="w-5 h-5 text-indigo-500" />
                  <span>Admin Hosting Package Manager</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Add, edit pricing, disk quotas, WHMCS package handles, and features for all active hosting tiers.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingPackage({
                    id: `custom-pkg-${Date.now()}`,
                    name: 'New Custom Package',
                    category: 'Shared Hosting',
                    controlPanelType: 'cpanel',
                    cpanelPackageName: 'celoxa_custom_tier',
                    diskQuotaMb: 10240,
                    bandwidthQuotaGb: 100,
                    bandwidthQuotaMb: 102400,
                    maxDatabases: 10,
                    maxEmails: 20,
                    maxSubdomains: 5,
                    ramMb: 2048,
                    cpuCores: 2,
                    priceMonthly: 5,
                    priceMonthlyGhs: 45,
                    priceAnnualGhs: 450,
                    popular: false,
                    preinstalledCms: 'WordPress',
                    autoSsl: true,
                    redisCache: true,
                    dailyBackups: true,
                    maxWebsites: 5,
                    features: ['10 GB NVMe Storage', '100 GB Bandwidth', 'Free SSL', '5 Email Accounts'],
                  });
                  setIsPkgModalOpen(true);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition-all shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add Hosting Package</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {systemDatabase.getHostingPackages().map((pkg: any) => (
                <div key={pkg.id} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3 relative">
                  {pkg.popular && (
                    <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 text-[10px] font-bold">
                      Popular
                    </span>
                  )}
                  
                  <div>
                    <h5 className="font-extrabold text-sm text-slate-900 dark:text-white">{pkg.name}</h5>
                    <p className="text-[11px] font-mono text-indigo-500 font-bold">{pkg.cpanelPackageName || pkg.id}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Monthly Price</span>
                      <span className="font-bold text-slate-900 dark:text-white">GH₵ {pkg.priceMonthly ?? pkg.priceMonthlyGhs ?? 0}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Annual Price</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">GH₵ {pkg.priceAnnually ?? pkg.priceAnnualGhs ?? (pkg.priceMonthly ? pkg.priceMonthly * 10 : 0)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Disk Storage</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{((pkg.diskLimitMb || pkg.diskQuotaMb || 10240) / 1024).toFixed(0)} GB</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Bandwidth</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{pkg.bandwidthLimitGb || (pkg.bandwidthQuotaMb ? (pkg.bandwidthQuotaMb / 1024).toFixed(0) : 250)} GB</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                    <button
                      onClick={() => {
                        setEditingPackage({ ...pkg });
                        setIsPkgModalOpen(true);
                      }}
                      className="px-3 py-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold transition-all flex items-center gap-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete package '${pkg.name}'?`)) {
                          systemDatabase.deleteHostingPackage(pkg.id);
                        }
                      }}
                      className="px-2.5 py-1.5 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-600 text-rose-600 dark:text-rose-400 hover:text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: DOMAINS & REGISTRAR */}
      {activeTab === 'domains' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-teal-500" />
              <span>Domains & Registrar Markup Rules</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Configure profit margins on wholesale registry prices, Privacy defaults, and EPP authorization locks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default TLD Pricing Markup (%)</label>
              <input
                type="number"
                value={config.domains.defaultPricingMarkupPercent}
                onChange={(e) => setConfig({
                  ...config,
                  domains: { ...config.domains, defaultPricingMarkupPercent: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-teal-600 dark:text-teal-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Auto-Renew Grace Period (Days)</label>
              <input
                type="number"
                value={config.domains.autoRenewGraceDays}
                onChange={(e) => setConfig({
                  ...config,
                  domains: { ...config.domains, autoRenewGraceDays: parseInt(e.target.value) || 0 }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

          </div>

          {/* ADMIN AREA: TLD PRICING & EXTENSION EDITOR */}
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-teal-500" />
                  <span>Admin TLD Extensions & Pricing Manager</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Manage registration fees, renewal costs, transfers, and ICANN charges for all domain extensions.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingTld({
                    tld: '.tech',
                    name: 'Technology',
                    category: 'Tech & Business',
                    registrationPrice: 25,
                    renewalPrice: 28,
                    transferPrice: 25,
                    restorePrice: 80,
                    icannFee: 0.18,
                    description: 'Ideal for tech startups and innovation hubs',
                  });
                  setIsTldModalOpen(true);
                }}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition-all shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add New TLD Extension</span>
              </button>
            </div>

            {/* TLD Search Bar */}
            <div className="relative max-w-xs">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={tldSearchQuery}
                onChange={(e) => setTldSearchQuery(e.target.value)}
                placeholder="Filter TLDs (e.g. .com, .gh)..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* TLD Table */}
            <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-100 dark:bg-slate-900 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Extension</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Register Price</th>
                    <th className="py-3 px-4">Renewal Price</th>
                    <th className="py-3 px-4">Transfer Fee</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {systemDatabase.getTlds()
                    .filter((t) => tldSearchQuery === '' || t.tld.toLowerCase().includes(tldSearchQuery.toLowerCase()) || t.category.toLowerCase().includes(tldSearchQuery.toLowerCase()))
                    .map((tldItem) => (
                      <tr key={tldItem.tld} className="hover:bg-slate-100/60 dark:hover:bg-slate-900/60 transition-colors">
                        <td className="py-3 px-4 font-black text-teal-600 dark:text-teal-400 font-mono text-sm">
                          {tldItem.tld}
                        </td>
                        <td className="py-3 px-4 text-slate-600 dark:text-slate-300 font-medium">
                          {tldItem.category}
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                          ${tldItem.registrationPrice}
                        </td>
                        <td className="py-3 px-4 font-semibold text-slate-700 dark:text-slate-300">
                          ${tldItem.renewalPrice}
                        </td>
                        <td className="py-3 px-4 font-semibold text-slate-700 dark:text-slate-300">
                          ${tldItem.transferPrice}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setEditingTld({ ...tldItem });
                                setIsTldModalOpen(true);
                              }}
                              className="px-2.5 py-1 bg-slate-200 dark:bg-slate-800 hover:bg-teal-600 hover:text-white text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold transition-all flex items-center gap-1"
                            >
                              <Edit3 className="w-3 h-3" />
                              <span>Edit</span>
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Are you sure you want to delete TLD extension '${tldItem.tld}'?`)) {
                                  systemDatabase.deleteTld(tldItem.tld);
                                }
                              }}
                              className="p-1 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-600 text-rose-600 hover:text-white rounded-lg transition-all"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-200 dark:border-slate-800 text-xs">
            
            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">Default Free WHOIS Privacy</span>
                <span className="text-[11px] text-slate-500">Automatically bundle free ID Protection with new domain registrations.</span>
              </div>
              <button
                onClick={() => setConfig({
                  ...config,
                  domains: { ...config.domains, defaultWhoisPrivacy: !config.domains.defaultWhoisPrivacy }
                })}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  config.domains.defaultWhoisPrivacy ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                  config.domains.defaultWhoisPrivacy ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">Require EPP Code for Transfers</span>
                <span className="text-[11px] text-slate-500">Mandate valid EPP authorization key before initializing domain transfer.</span>
              </div>
              <button
                onClick={() => setConfig({
                  ...config,
                  domains: { ...config.domains, requireEppForTransfers: !config.domains.requireEppForTransfers }
                })}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  config.domains.requireEppForTransfers ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                  config.domains.requireEppForTransfers ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

          </div>
        </div>
      )}

      {/* TAB 4: SECURITY & ANTI-SPAM */}
      {activeTab === 'security' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-500" />
              <span>Security & Anti-Spam Protection Module</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Set up CAPTCHA providers, FakeFilter disposable email blocking, Stop Forum Spam database integration, and staff IP whitelists.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            
            {/* CAPTCHA Provider Select */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Bot Protection CAPTCHA Provider</label>
              <select
                value={config.securityAntiSpam.captchaProvider}
                onChange={(e) => setConfig({
                  ...config,
                  securityAntiSpam: {
                    ...config.securityAntiSpam,
                    captchaProvider: e.target.value as any,
                  }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-emerald-600 dark:text-emerald-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="turnstile">Cloudflare Turnstile (Recommended & Non-Intrusive)</option>
                <option value="recaptcha_v3">Google reCAPTCHA v3 (Score Based)</option>
                <option value="recaptcha_v2">Google reCAPTCHA v2 (Checkbox Challenge)</option>
                <option value="hcaptcha">hCaptcha Privacy-Focused</option>
                <option value="none">Disabled (Not Recommended)</option>
              </select>
            </div>

            {/* Rate Limit */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">API Rate Limit (Req/Min/IP)</label>
              <input
                type="number"
                value={config.securityAntiSpam.ipRateLimitRequestsPerMin}
                onChange={(e) => setConfig({
                  ...config,
                  securityAntiSpam: {
                    ...config.securityAntiSpam,
                    ipRateLimitRequestsPerMin: parseInt(e.target.value) || 60,
                  }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

          </div>

          {/* Toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 text-xs">
            
            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">Stop Forum Spam</span>
                <span className="text-[11px] text-slate-500">Cross-reference registrations against global spammer database.</span>
              </div>
              <button
                onClick={() => setConfig({
                  ...config,
                  securityAntiSpam: {
                    ...config.securityAntiSpam,
                    stopForumSpamEnabled: !config.securityAntiSpam.stopForumSpamEnabled,
                  }
                })}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  config.securityAntiSpam.stopForumSpamEnabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                  config.securityAntiSpam.stopForumSpamEnabled ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">FakeFilter Email Block</span>
                <span className="text-[11px] text-slate-500">Reject disposable email domains (e.g. mailinator, tempmail).</span>
              </div>
              <button
                onClick={() => setConfig({
                  ...config,
                  securityAntiSpam: {
                    ...config.securityAntiSpam,
                    disposableEmailFilter: !config.securityAntiSpam.disposableEmailFilter,
                  }
                })}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  config.securityAntiSpam.disposableEmailFilter ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                  config.securityAntiSpam.disposableEmailFilter ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">Central Security Alerts</span>
                <span className="text-[11px] text-slate-500">Receive instant alerts for zero-day vulnerability checks.</span>
              </div>
              <button
                onClick={() => setConfig({
                  ...config,
                  securityAntiSpam: {
                    ...config.securityAntiSpam,
                    centralSecurityAlerts: !config.securityAntiSpam.centralSecurityAlerts,
                  }
                })}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  config.securityAntiSpam.centralSecurityAlerts ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                  config.securityAntiSpam.centralSecurityAlerts ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

          </div>

          {/* PRIVILEGED PORTAL PATHS & RESTRICTED ACCESS CONFIGURATION */}
          <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div>
              <h4 className="font-extrabold text-slate-900 dark:text-white text-xs flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-purple-500" />
                <span>Privileged Staff & Admin Portal Custom Paths</span>
              </h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Privileged portals are never advertised on public navigation. Configure custom undisclosed entry points and session parameters.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">Staff Portal Entry URL Path</label>
                <input
                  type="text"
                  value={config.securityAntiSpam.staffPortalPath || '/staff/login'}
                  onChange={(e) => setConfig({
                    ...config,
                    securityAntiSpam: {
                      ...config.securityAntiSpam,
                      staffPortalPath: e.target.value,
                    }
                  })}
                  placeholder="/staff/login"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-purple-600 dark:text-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300">Admin Portal Entry URL Path</label>
                <input
                  type="text"
                  value={config.securityAntiSpam.adminPortalPath || '/admin/login'}
                  onChange={(e) => setConfig({
                    ...config,
                    securityAntiSpam: {
                      ...config.securityAntiSpam,
                      adminPortalPath: e.target.value,
                    }
                  })}
                  placeholder="/admin/login"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-rose-600 dark:text-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-1">
              <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Mandatory 2FA / MFA for Staff</span>
                  <span className="text-[11px] text-slate-500">Require TOTP or Google Authenticator verification.</span>
                </div>
                <button
                  onClick={() => setConfig({
                    ...config,
                    securityAntiSpam: {
                      ...config.securityAntiSpam,
                      requireMfaForStaff: !config.securityAntiSpam.requireMfaForStaff,
                    }
                  })}
                  className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                    config.securityAntiSpam.requireMfaForStaff !== false ? 'bg-purple-600' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                    config.securityAntiSpam.requireMfaForStaff !== false ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Mandatory 2FA / MFA for Admins</span>
                  <span className="text-[11px] text-slate-500">Enforce multi-factor auth on all administrator operations.</span>
                </div>
                <button
                  onClick={() => setConfig({
                    ...config,
                    securityAntiSpam: {
                      ...config.securityAntiSpam,
                      requireMfaForAdmin: !config.securityAntiSpam.requireMfaForAdmin,
                    }
                  })}
                  className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                    config.securityAntiSpam.requireMfaForAdmin !== false ? 'bg-rose-600' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                    config.securityAntiSpam.requireMfaForAdmin !== false ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>
          </div>

          {/* STAFF IP WHITELIST EDITOR */}
          <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <h4 className="font-extrabold text-slate-900 dark:text-white text-xs flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-500" />
              <span>Admin Staff IP Access Restrictions Whitelist</span>
            </h4>
            <div className="flex flex-wrap gap-2">
              {config.securityAntiSpam.staffIpWhitelist.map((ip) => (
                <span
                  key={ip}
                  className="px-3 py-1 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-2"
                >
                  <span>{ip}</span>
                  <button
                    onClick={() => handleRemoveStaffIp(ip)}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2 max-w-md pt-1">
              <input
                type="text"
                placeholder="e.g. 198.51.100.99"
                value={newIpAddress}
                onChange={(e) => setNewIpAddress(e.target.value)}
                className="flex-1 px-3.5 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-900 dark:text-white focus:outline-none"
              />
              <button
                onClick={handleAddStaffIp}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1 shadow"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add IP</span>
              </button>
            </div>
          </div>

        </div>
      )}

      {/* TAB 5: BILLING & RATES SYNC */}
      {activeTab === 'billing' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-amber-500" />
              <span>Billing, Invoicing & Exchange Rate Sync</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Automate daily exchange rate synchronization for multi-currency pricing, invoice numbering, and tax calculation rules.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            
            {/* Auto Exchange Sync Provider */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Exchange Rate API Provider</label>
              <select
                value={config.billing.rateSyncProvider}
                onChange={(e) => setConfig({
                  ...config,
                  billing: { ...config.billing, rateSyncProvider: e.target.value as any }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-amber-600 dark:text-amber-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ExchangeRate-API">ExchangeRate-API (Recommended - Live GHS/USD/EUR/GBP)</option>
                <option value="CurrencyDataAPI">Currency Data API</option>
                <option value="currencylayer">currencylayer Enterprise API</option>
              </select>
            </div>

            {/* Invoice Prefix */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Invoice Number Prefix</label>
              <input
                type="text"
                value={config.billing.invoicePrefix}
                onChange={(e) => setConfig({
                  ...config,
                  billing: { ...config.billing, invoicePrefix: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-xs text-indigo-600 dark:text-indigo-400 font-bold focus:outline-none"
              />
            </div>

            {/* Payment Due Days */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default Invoice Payment Terms (Days)</label>
              <input
                type="number"
                value={config.billing.invoiceDueDays}
                onChange={(e) => setConfig({
                  ...config,
                  billing: { ...config.billing, invoiceDueDays: parseInt(e.target.value) || 14 }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none"
              />
            </div>

            {/* Default Tax Rate */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default Tax / VAT Rate (%)</label>
              <input
                type="number"
                value={config.billing.defaultTaxRate}
                onChange={(e) => setConfig({
                  ...config,
                  billing: { ...config.billing, defaultTaxRate: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white focus:outline-none"
              />
            </div>

          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
            <div>
              <span className="font-extrabold text-slate-900 dark:text-white block">Automatic Exchange Rate Daily Cron Sync</span>
              <span className="text-slate-500">Automatically sync currency rates daily at midnight UTC to prevent loss on currency volatility.</span>
            </div>
            <button
              onClick={() => setConfig({
                ...config,
                billing: { ...config.billing, autoExchangeRateSync: !config.billing.autoExchangeRateSync }
              })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                config.billing.autoExchangeRateSync ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                config.billing.autoExchangeRateSync ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>

        </div>
      )}

      {/* TAB 6: PAYMENT GATEWAYS & PAYSTACK CONTROL */}
      {activeTab === 'payment_gateways' && (
        <div className="space-y-6">
          <AdminPaymentSettings
            settings={paymentSettings}
            onUpdateSettings={onUpdatePaymentSettings}
            submissions={paymentSubmissions}
            onApproveSubmission={onApproveSubmission}
            onRejectSubmission={onRejectSubmission}
            currency={currency}
          />
        </div>
      )}

      {/* TAB 7: MAIL & ALERTS */}
      {activeTab === 'mail' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Mail className="w-5 h-5 text-purple-500" />
              <span>Transactional Mailer & System Alerts</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Configure SMTP gateway server connection, sender credentials, and automated low disk / SSL expiry notifications.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">SMTP Relay Host</label>
              <input
                type="text"
                value={config.notifications.smtpHost}
                onChange={(e) => setConfig({
                  ...config,
                  notifications: { ...config.notifications, smtpHost: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-xs text-purple-600 dark:text-purple-400 font-bold focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">SMTP Port (TLS/SSL)</label>
              <input
                type="number"
                value={config.notifications.smtpPort}
                onChange={(e) => setConfig({
                  ...config,
                  notifications: { ...config.notifications, smtpPort: parseInt(e.target.value) || 587 }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-xs text-slate-900 dark:text-white focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">SMTP User Username</label>
              <input
                type="text"
                value={config.notifications.smtpUser}
                onChange={(e) => setConfig({
                  ...config,
                  notifications: { ...config.notifications, smtpUser: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300">Default "From Email" Address</label>
              <input
                type="email"
                value={config.notifications.smtpFromEmail}
                onChange={(e) => setConfig({
                  ...config,
                  notifications: { ...config.notifications, smtpFromEmail: e.target.value }
                })}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-900 dark:text-white focus:outline-none"
              />
            </div>

          </div>

          {/* Test Email Button & Toggles */}
          <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-700 dark:text-slate-300">SMTP Gateway Connection Test</span>
              <button
                onClick={handleSendTestEmail}
                disabled={testEmailSending}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-2"
              >
                {testEmailSending ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Connecting to SMTP...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5" />
                    <span>Send Test Email</span>
                  </>
                )}
              </button>
            </div>

            {testEmailSuccess && (
              <div className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 p-3 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>SMTP Test Email sent successfully to <strong>{config.general.contactEmail}</strong>! Mailer socket is operational.</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-2">
              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">Low Disk Space Alerts</span>
                  <span className="text-[11px] text-slate-500">Notify admin when server partition exceeds 85% disk usage.</span>
                </div>
                <button
                  onClick={() => setConfig({
                    ...config,
                    notifications: { ...config.notifications, sendLowDiskAlerts: !config.notifications.sendLowDiskAlerts }
                  })}
                  className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                    config.notifications.sendLowDiskAlerts ? 'bg-purple-500' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                    config.notifications.sendLowDiskAlerts ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">SSL Expiry Notifications</span>
                  <span className="text-[11px] text-slate-500">Alert client 14 days before AutoSSL certificate expiration.</span>
                </div>
                <button
                  onClick={() => setConfig({
                    ...config,
                    notifications: { ...config.notifications, sendSslExpiryAlerts: !config.notifications.sendSslExpiryAlerts }
                  })}
                  className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                    config.notifications.sendSslExpiryAlerts ? 'bg-purple-500' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full bg-white block transition-transform ${
                    config.notifications.sendSslExpiryAlerts ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* MODAL 1: EDIT / CREATE HOSTING PACKAGE */}
      {isPkgModalOpen && editingPackage && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-xl">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Hosting Package Editor</h3>
                  <p className="text-xs text-slate-500">Configure hosting plan pricing and server specs</p>
                </div>
              </div>
              <button
                onClick={() => setIsPkgModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Package Title</label>
                  <input
                    type="text"
                    value={editingPackage.name}
                    onChange={(e) => setEditingPackage({ ...editingPackage, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">WHMCS / cPanel Package ID</label>
                  <input
                    type="text"
                    value={editingPackage.cpanelPackageName}
                    onChange={(e) => setEditingPackage({ ...editingPackage, cpanelPackageName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-indigo-500 font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Monthly Price (GHS)</label>
                  <input
                    type="number"
                    value={editingPackage.priceMonthlyGhs}
                    onChange={(e) => setEditingPackage({ ...editingPackage, priceMonthlyGhs: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Annual Price (GHS)</label>
                  <input
                    type="number"
                    value={editingPackage.priceAnnualGhs}
                    onChange={(e) => setEditingPackage({ ...editingPackage, priceAnnualGhs: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-emerald-600 dark:text-emerald-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Disk Space (GB)</label>
                  <input
                    type="number"
                    value={Math.round(editingPackage.diskQuotaMb / 1024)}
                    onChange={(e) => setEditingPackage({ ...editingPackage, diskQuotaMb: (parseInt(e.target.value) || 1) * 1024 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Bandwidth (GB)</label>
                  <input
                    type="number"
                    value={Math.round(editingPackage.bandwidthQuotaMb / 1024)}
                    onChange={(e) => setEditingPackage({ ...editingPackage, bandwidthQuotaMb: (parseInt(e.target.value) || 1) * 1024 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Max Websites</label>
                  <input
                    type="number"
                    value={editingPackage.maxWebsites}
                    onChange={(e) => setEditingPackage({ ...editingPackage, maxWebsites: parseInt(e.target.value) || 1 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">Features List (Comma Separated)</label>
                <textarea
                  rows={2}
                  value={editingPackage.features.join(', ')}
                  onChange={(e) => setEditingPackage({ ...editingPackage, features: e.target.value.split(',').map((s) => s.trim()) })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                <span className="font-bold text-slate-800 dark:text-slate-200">Highlight as "Popular Plan"</span>
                <button
                  type="button"
                  onClick={() => setEditingPackage({ ...editingPackage, popular: !editingPackage.popular })}
                  className={`w-10 h-5 rounded-full transition-colors relative p-0.5 ${editingPackage.popular ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'}`}
                >
                  <span className={`w-4 h-4 rounded-full bg-white block transition-transform ${editingPackage.popular ? 'translate-x-5' : 'translate-x-0'}`} />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setIsPkgModalOpen(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  systemDatabase.saveHostingPackage(editingPackage);
                  setIsPkgModalOpen(false);
                }}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Save Package</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: EDIT / CREATE TLD EXTENSION */}
      {isTldModalOpen && editingTld && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400 rounded-xl">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Domain TLD Pricing Editor</h3>
                  <p className="text-xs text-slate-500">Configure extension registration fees and registry pricing</p>
                </div>
              </div>
              <button
                onClick={() => setIsTldModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Extension (e.g. .com)</label>
                  <input
                    type="text"
                    value={editingTld.tld}
                    onChange={(e) => setEditingTld({ ...editingTld, tld: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-teal-600 dark:text-teal-400 font-black focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Category Tag</label>
                  <input
                    type="text"
                    value={editingTld.category}
                    onChange={(e) => setEditingTld({ ...editingTld, category: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Register Price ($)</label>
                  <input
                    type="number"
                    value={editingTld.registrationPrice}
                    onChange={(e) => setEditingTld({ ...editingTld, registrationPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Renewal Price ($)</label>
                  <input
                    type="number"
                    value={editingTld.renewalPrice}
                    onChange={(e) => setEditingTld({ ...editingTld, renewalPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Transfer Fee ($)</label>
                  <input
                    type="number"
                    value={editingTld.transferPrice}
                    onChange={(e) => setEditingTld({ ...editingTld, transferPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-bold focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Restore Price ($)</label>
                  <input
                    type="number"
                    value={editingTld.restorePrice}
                    onChange={(e) => setEditingTld({ ...editingTld, restorePrice: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">ICANN Registry Fee ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={editingTld.icannFee}
                    onChange={(e) => setEditingTld({ ...editingTld, icannFee: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-300">Description</label>
                <input
                  type="text"
                  value={editingTld.description}
                  onChange={(e) => setEditingTld({ ...editingTld, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-medium focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setIsTldModalOpen(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  systemDatabase.saveTld(editingTld);
                  setIsTldModalOpen(false);
                }}
                className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Save TLD Pricing</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
