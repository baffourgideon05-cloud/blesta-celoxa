import express from "express";
import path from "path";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { authRouter } from "./src/server/authRoutes.js";

const app = express();
const PORT = 3000;

app.use(express.json());

// Mount IAM & Authentication API Router
app.use("/api/auth", authRouter);

// Initialize Gemini SDK with User-Agent header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// AI Domain Brain & Generator API
app.post("/api/domains/ai-generate", async (req, res) => {
  try {
    const { keyword, category, style, count = 8 } = req.body;
    
    if (!keyword) {
      return res.status(400).json({ error: "Keyword or description is required" });
    }

    const prompt = `You are a world-class domain naming expert and brand consultant. 
Generate ${count} creative, memorable, high-converting domain name ideas based on:
- Concept/Keywords: "${keyword}"
- Preferred Category: "${category || 'All'}"
- Naming Style: "${style || 'Creative'}"

For each domain, provide:
1. domain (full name with extension, e.g., 'nexusai.io', 'apexcloud.com')
2. tld (e.g., '.io', '.com', '.app', '.dev', '.ai', '.tech', '.co', '.store')
3. brandScore (number from 70 to 99 representing brandability)
4. rationale (1 short sentence explaining why this domain is powerful)
5. estimatedValue (estimated market value in USD integer, e.g. 1200 to 15000)
6. available (boolean, assume true for generated ideas)
7. price (suggested annual registration price in USD, e.g. 12.99, 29.99, 69.99)
8. category (e.g., 'Tech & AI', 'Business', 'Creative', 'E-commerce')`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          description: "List of AI-generated domain suggestions",
          items: {
            type: Type.OBJECT,
            properties: {
              domain: { type: Type.STRING },
              tld: { type: Type.STRING },
              brandScore: { type: Type.INTEGER },
              rationale: { type: Type.STRING },
              estimatedValue: { type: Type.INTEGER },
              available: { type: Type.BOOLEAN },
              price: { type: Type.NUMBER },
              category: { type: Type.STRING },
            },
            required: ["domain", "tld", "brandScore", "rationale", "estimatedValue", "available", "price", "category"],
          },
        },
      },
    });

    const suggestions = JSON.parse(response.text || "[]");
    res.json({ suggestions });
  } catch (error: any) {
    console.error("AI Domain Generation Error:", error);
    res.status(500).json({ error: error.message || "Failed to generate domain suggestions" });
  }
});

// AI Domain Appraisal API
app.post("/api/domains/appraise", async (req, res) => {
  try {
    const { domain } = req.body;
    if (!domain) {
      return res.status(400).json({ error: "Domain name is required" });
    }

    const prompt = `Perform a comprehensive domain valuation & brand assessment for "${domain}".
Provide:
- domain: string
- estimatedValue: number (in USD)
- brandabilityScore: number (0 to 100)
- seoScore: number (0 to 100)
- lengthScore: number (0 to 100)
- summary: string (2 sentence valuation summary)
- pros: array of strings (3 key strengths)
- cons: array of strings (1-2 potential challenges)
- comparableSales: array of 3 objects with { domain: string, price: number, year: number }`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            domain: { type: Type.STRING },
            estimatedValue: { type: Type.INTEGER },
            brandabilityScore: { type: Type.INTEGER },
            seoScore: { type: Type.INTEGER },
            lengthScore: { type: Type.INTEGER },
            summary: { type: Type.STRING },
            pros: { type: Type.ARRAY, items: { type: Type.STRING } },
            cons: { type: Type.ARRAY, items: { type: Type.STRING } },
            comparableSales: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  domain: { type: Type.STRING },
                  price: { type: Type.INTEGER },
                  year: { type: Type.INTEGER },
                },
                required: ["domain", "price", "year"],
              },
            },
          },
          required: ["domain", "estimatedValue", "brandabilityScore", "seoScore", "lengthScore", "summary", "pros", "cons", "comparableSales"],
        },
      },
    });

    const appraisal = JSON.parse(response.text || "{}");
    res.json({ appraisal });
  } catch (error: any) {
    console.error("AI Domain Appraisal Error:", error);
    res.status(500).json({ error: error.message || "Failed to appraise domain" });
  }
});

// Simulated Server WHOIS API
app.get("/api/whois/:domain", (req, res) => {
  const domain = req.params.domain.toLowerCase();
  
  // Deterministic or semi-realistic status check
  const isTaken = domain.startsWith("google") || domain.startsWith("apple") || domain.startsWith("amazon") || domain.startsWith("meta") || domain.startsWith("tech") || domain.length <= 4;
  
  const createdYear = 2010 + (domain.length % 12);
  const updatedYear = 2025;
  const expiryYear = 2027 + (domain.length % 5);

  const whoisData = {
    domainName: domain.toUpperCase(),
    status: isTaken ? "REGISTERED (clientTransferProhibited)" : "AVAILABLE",
    registrar: isTaken ? "ApexRegistrar Inc. (IANA ID 9942)" : "N/A",
    creationDate: isTaken ? `${createdYear}-03-15T12:00:00Z` : "N/A",
    updatedDate: isTaken ? `${updatedYear}-01-10T08:30:00Z` : "N/A",
    expirationDate: isTaken ? `${expiryYear}-03-15T12:00:00Z` : "N/A",
    registrantOrganization: isTaken ? "Privacy Protection Service Ltd / Hidden" : "N/A",
    registrantCountry: isTaken ? "US" : "N/A",
    nameServers: isTaken ? ["ns1.apexdomain.com", "ns2.apexdomain.com"] : [],
    dnssec: "unsigned",
    rawWhoisText: isTaken
      ? `Domain Name: ${domain.toUpperCase()}
Registry Domain ID: 2948201948_DOMAIN_COM-VRSN
Registrar WHOIS Server: whois.apexregistrar.com
Registrar URL: https://apexdomain.com
Updated Date: ${updatedYear}-01-10T08:30:00Z
Creation Date: ${createdYear}-03-15T12:00:00Z
Registry Expiry Date: ${expiryYear}-03-15T12:00:00Z
Registrar: ApexRegistrar Inc.
Registrar IANA ID: 9942
Registrar Abuse Contact Email: abuse@apexdomain.com
Registrar Abuse Contact Phone: +1.8005550199
Domain Status: clientTransferProhibited https://icann.org/epp#clientTransferProhibited
Registry Registrant ID: REDACTED FOR PRIVACY
Registrant Name: REDACTED FOR PRIVACY
Registrant Organization: Privacy Protection Service Ltd
Name Server: NS1.APEXDOMAIN.COM
Name Server: NS2.APEXDOMAIN.COM
DNSSEC: unsigned
URL of the ICANN Whois Inaccuracy Complaint Form: https://www.icann.org/wicf/`
      : `Domain ${domain} is available for immediate registration.`,
  };

  res.json({ whois: whoisData });
});

// Helper to get Paystack Secret Key
function getPaystackSecretKey(reqSecretKey?: string): string {
  if (reqSecretKey && reqSecretKey.trim().length > 5) {
    return reqSecretKey.trim();
  }
  return process.env.PAYSTACK_SECRET_KEY || 'sk_test_1234567890abcdef1234567890abcdef';
}

// 1. Paystack API Credentials Verification Endpoint
app.post("/api/paystack/test-credentials", async (req, res) => {
  try {
    const { secretKey } = req.body;
    const keyToTest = getPaystackSecretKey(secretKey);

    const response = await fetch("https://api.paystack.co/bank", {
      headers: {
        Authorization: `Bearer ${keyToTest}`,
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();
    if (response.ok && data.status) {
      res.json({
        success: true,
        message: "Paystack API key verified successfully with Paystack server!",
        banksCount: data.data?.length || 0,
      });
    } else {
      res.status(400).json({
        success: false,
        message: data.message || "Invalid Paystack Secret Key",
        paystackResponse: data,
      });
    }
  } catch (err: any) {
    res.status(500).json({
      success: false,
      message: err.message || "Failed to reach Paystack servers",
    });
  }
});

// 2. Paystack Initialize Transaction Endpoint
app.post("/api/paystack/initialize", async (req, res) => {
  try {
    const { email, amount, currency = "GHS", reference, metadata, callbackUrl, secretKey } = req.body;

    if (!email || !amount) {
      return res.status(400).json({ error: "Email and amount are required" });
    }

    const key = getPaystackSecretKey(secretKey);
    const ref = reference || `PSTK-APX-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

    // Convert amount to Paystack subunit (pesewas/kobo/cents = amount * 100)
    const amountInSubunits = Math.round(Number(amount) * 100);

    const paystackBody: any = {
      email,
      amount: amountInSubunits,
      currency: currency.toUpperCase(),
      reference: ref,
      metadata: metadata || {},
    };

    if (callbackUrl) {
      paystackBody.callback_url = callbackUrl;
    }

    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(paystackBody),
    });

    const data = await response.json();

    if (response.ok && data.status) {
      res.json({
        success: true,
        authorization_url: data.data.authorization_url,
        access_code: data.data.access_code,
        reference: data.data.reference,
        paystackData: data.data,
      });
    } else {
      res.status(response.status || 400).json({
        success: false,
        error: data.message || "Failed to initialize Paystack transaction",
        paystackResponse: data,
      });
    }
  } catch (error: any) {
    console.error("Paystack Initialize Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Internal server error connecting to Paystack",
    });
  }
});

// 3. Paystack Verify Transaction Endpoint
app.get("/api/paystack/verify/:reference", async (req, res) => {
  try {
    const { reference } = req.params;
    const reqKey = req.headers["x-paystack-secret-key"] as string | undefined;
    const key = getPaystackSecretKey(reqKey);

    const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();

    if (response.ok && data.status) {
      res.json({
        success: true,
        verified: data.data.status === "success",
        status: data.data.status,
        amount: data.data.amount / 100,
        currency: data.data.currency,
        reference: data.data.reference,
        paidAt: data.data.paid_at,
        channel: data.data.channel,
        customer: data.data.customer,
        gatewayResponse: data.data.gateway_response,
        paystackData: data.data,
      });
    } else {
      res.status(400).json({
        success: false,
        verified: false,
        error: data.message || "Unable to verify transaction with Paystack",
        paystackResponse: data,
      });
    }
  } catch (error: any) {
    console.error("Paystack Verify Error:", error);
    res.status(500).json({
      success: false,
      verified: false,
      error: error.message || "Internal server error verifying Paystack transaction",
    });
  }
});

// 4. Paystack Direct Charge Endpoint (Mobile Money / USSD / Card)
app.post("/api/paystack/charge", async (req, res) => {
  try {
    const { email, amount, currency = "GHS", channel, mobileMoney, card, reference, secretKey } = req.body;
    const key = getPaystackSecretKey(secretKey);

    const ref = reference || `PSTK-CHG-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const amountInSubunits = Math.round(Number(amount) * 100);

    const chargePayload: any = {
      email,
      amount: amountInSubunits,
      currency: currency.toUpperCase(),
      reference: ref,
    };

    if (channel === "mobile_money" && mobileMoney) {
      chargePayload.mobile_money = {
        phone: mobileMoney.phone,
        provider: mobileMoney.provider.toLowerCase(), // e.g. 'mtn', 'vod' (Telecel), 'tgo'
      };
    } else if (channel === "card" && card) {
      chargePayload.card = {
        number: card.number.replace(/\s/g, ""),
        cvv: card.cvv,
        expiry_month: card.expiryMonth,
        expiry_year: card.expiryYear,
      };
    }

    const response = await fetch("https://api.paystack.co/charge", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(chargePayload),
    });

    const data = await response.json();

    if (response.ok && data.status) {
      res.json({
        success: true,
        status: data.data.status, // e.g., 'pay_offline', 'send_pin', 'send_otp', 'success'
        displayText: data.data.display_text,
        reference: data.data.reference,
        paystackData: data.data,
      });
    } else {
      res.status(400).json({
        success: false,
        error: data.message || "Paystack charge failed",
        paystackResponse: data,
      });
    }
  } catch (error: any) {
    console.error("Paystack Charge Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Direct charge failed",
    });
  }
});

// 5. Paystack Webhook Handler
app.post("/api/paystack/webhook", (req, res) => {
  try {
    const secret = process.env.PAYSTACK_SECRET_KEY || "";
    const hash = crypto.createHmac("sha512", secret).update(JSON.stringify(req.body)).digest("hex");

    if (req.headers["x-paystack-signature"] !== hash && secret) {
      console.warn("Paystack Webhook signature mismatch");
      return res.status(401).send("Invalid signature");
    }

    const event = req.body;
    console.log("Received Paystack Webhook Event:", event.event, event.data?.reference);

    if (event.event === "charge.success") {
      // Transaction successful!
      console.log(`Payment confirmed for reference: ${event.data.reference}, amount: ${event.data.amount / 100} ${event.data.currency}`);
    }

    res.sendStatus(200);
  } catch (err: any) {
    console.error("Webhook error:", err);
    res.sendStatus(500);
  }
});

// Start Express + Vite setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ApexDomain Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
