import { 
  SystemSettingsConfig, 
  CartItem, 
  TLDDetail,
  PlatformRole,
  UserAccountStatus,
  ModulePermissions,
  UserSession,
  LoginActivityRecord,
  StaffInvitation,
  ClientApiKey,
  WhmcsHostingPackage
} from '../types';
import { DEFAULT_SYSTEM_SETTINGS } from '../data/defaultSystemSettings';
import { TLD_CATALOG } from '../data/tlds';
import { MOCK_WHMCS_PACKAGES } from '../data/mockWhmcsData';
import { 
  HostingPackageBlueprint, 
  INITIAL_BLUEPRINTS,
  ControlPanelGateway,
  INITIAL_GATEWAYS,
  ServerClusterNode,
  INITIAL_NODES,
  ProvisionTask,
  INITIAL_PROVISION_TASKS
} from '../components/HostingProvisionSystem';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  details: string;
  ipAddress: string;
  status: 'success' | 'warning' | 'error' | 'info';
}

export const DEFAULT_SUPER_ADMIN_PERMISSIONS: ModulePermissions = {
  customers: { view: true, create: true, edit: true, suspend: true, delete: true },
  domains: { view: true, register: true, transfer: true, editDns: true, delete: true },
  hosting: { view: true, provision: true, suspend: true, unsuspend: true, terminate: true },
  billing: { viewInvoices: true, createInvoice: true, refundPayment: true, managePaymentSettings: true },
  servers: { view: true, manage: true, restart: true },
  staff: { view: true, create: true, edit: true, suspend: true, manageRoles: true },
  systemSettings: { view: true, edit: true },
  auditLogs: { view: true, export: true },
};

export const DEFAULT_ADMIN_PERMISSIONS: ModulePermissions = {
  ...DEFAULT_SUPER_ADMIN_PERMISSIONS,
  staff: { view: true, create: true, edit: true, suspend: false, manageRoles: false },
};

export const DEFAULT_SUPPORT_STAFF_PERMISSIONS: ModulePermissions = {
  customers: { view: true, create: false, edit: true, suspend: false, delete: false },
  domains: { view: true, register: true, transfer: true, editDns: true, delete: false },
  hosting: { view: true, provision: true, suspend: true, unsuspend: true, terminate: false },
  billing: { viewInvoices: true, createInvoice: false, refundPayment: false, managePaymentSettings: false },
  servers: { view: true, manage: false, restart: false },
  staff: { view: true, create: false, edit: false, suspend: false, manageRoles: false },
  systemSettings: { view: true, edit: false },
  auditLogs: { view: true, export: false },
};

export const DEFAULT_FINANCE_STAFF_PERMISSIONS: ModulePermissions = {
  customers: { view: true, create: true, edit: true, suspend: false, delete: false },
  domains: { view: true, register: false, transfer: false, editDns: false, delete: false },
  hosting: { view: true, provision: false, suspend: false, unsuspend: false, terminate: false },
  billing: { viewInvoices: true, createInvoice: true, refundPayment: true, managePaymentSettings: true },
  servers: { view: false, manage: false, restart: false },
  staff: { view: false, create: false, edit: false, suspend: false, manageRoles: false },
  systemSettings: { view: true, edit: false },
  auditLogs: { view: true, export: true },
};

export const DEFAULT_CLIENT_PERMISSIONS: ModulePermissions = {
  customers: { view: false, create: false, edit: false, suspend: false, delete: false },
  domains: { view: true, register: true, transfer: true, editDns: true, delete: false },
  hosting: { view: true, provision: false, suspend: false, unsuspend: false, terminate: false },
  billing: { viewInvoices: true, createInvoice: false, refundPayment: false, managePaymentSettings: false },
  servers: { view: false, manage: false, restart: false },
  staff: { view: false, create: false, edit: false, suspend: false, manageRoles: false },
  systemSettings: { view: false, edit: false },
  auditLogs: { view: true, export: false },
};

export interface SystemUser {
  id: string;
  fullName: string;
  email: string;
  password?: string;
  role: 'admin' | 'customer' | 'reseller' | 'super_admin' | 'administrator' | 'staff' | 'client';
  platformRole: PlatformRole;
  staffTitle?: string;
  department?: string;
  accountStatus: UserAccountStatus;
  isEmailVerified: boolean;
  verificationToken?: string;
  resetToken?: string;
  companyName?: string;
  phone?: string;
  country?: string;
  avatarUrl?: string;
  walletBalanceGhs: number;
  walletBalanceUsd: number;
  twoFactorEnabled: boolean;
  mfaSecret?: string;
  mfaBackupCodes?: string[];
  permissions: ModulePermissions;
  createdAt: string;
  lastLoginAt?: string;
  lastLoginIp?: string;
  isBusinessAccount?: boolean;
}

export interface SystemDatabaseState {
  version: string;
  lastUpdated: string;
  settings: SystemSettingsConfig;
  hostingPackages: HostingPackageBlueprint[];
  tlds: TLDDetail[];
  controlPanelGateways: ControlPanelGateway[];
  serverClusterNodes: ServerClusterNode[];
  provisionedAccounts: ProvisionTask[];
  auditLogs: AuditLogEntry[];
  users: SystemUser[];
  currentUser: SystemUser | null;
  persistentCart: CartItem[];
  staffInvitations: StaffInvitation[];
  activeSessions: UserSession[];
  loginActivity: LoginActivityRecord[];
  clientApiKeys: ClientApiKey[];
}

const STORAGE_KEY = 'CELOXA_SYSTEM_DATABASE_V1';

const DEFAULT_USERS: SystemUser[] = [
  {
    id: 'user-admin-google-001',
    fullName: 'Gideon Baffour (Google Admin)',
    email: 'baffourgideon05@gmail.com',
    password: 'admin',
    role: 'super_admin',
    platformRole: 'super_admin',
    staffTitle: 'Chief System Administrator',
    department: 'Executive Systems',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Cloud Enterprise',
    phone: '+233 (0) 24 123 4567',
    country: 'Ghana',
    avatarUrl: 'https://api.dicebear.com/7.x/initials/svg?seed=Gideon%20Baffour',
    walletBalanceGhs: 25000.00,
    walletBalanceUsd: 1850.00,
    twoFactorEnabled: true,
    mfaSecret: 'JBSWY3DPEHPK3PXP',
    mfaBackupCodes: ['8942-1029', '3910-8271', '4019-2819', '5910-2018'],
    permissions: DEFAULT_SUPER_ADMIN_PERMISSIONS,
    createdAt: '2025-01-01 00:00:00',
    lastLoginAt: '2026-08-10 18:20:00',
    lastLoginIp: '198.51.100.1',
  },
  {
    id: 'user-admin-101',
    fullName: 'Chief Admin (System Owner)',
    email: 'admin@celoxaghana.online',
    password: 'admin',
    role: 'super_admin',
    platformRole: 'super_admin',
    staffTitle: 'Super Administrator',
    department: 'Executive Systems',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Technologies Ltd',
    phone: '+233 (0) 30 291 8840',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop',
    walletBalanceGhs: 12500.00,
    walletBalanceUsd: 850.00,
    twoFactorEnabled: true,
    mfaSecret: 'JBSWY3DPEHPK3PXP',
    mfaBackupCodes: ['8942-1029', '3910-8271', '4019-2819', '5910-2018'],
    permissions: DEFAULT_SUPER_ADMIN_PERMISSIONS,
    createdAt: '2025-01-10 08:00:00',
    lastLoginAt: '2026-08-09 10:45:00',
    lastLoginIp: '198.51.100.42',
  },
  {
    id: 'user-admin-102',
    fullName: 'Operations Admin',
    email: 'ops@celoxaghana.online',
    password: 'admin',
    role: 'administrator',
    platformRole: 'administrator',
    staffTitle: 'Systems Administrator',
    department: 'Cloud Infrastructure',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Systems',
    phone: '+233 (0) 20 812 3456',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop',
    walletBalanceGhs: 5000.00,
    walletBalanceUsd: 350.00,
    twoFactorEnabled: true,
    mfaSecret: 'KRSXG5CTMVRXEZLU',
    mfaBackupCodes: ['1204-9831', '5928-1039', '8810-2391'],
    permissions: DEFAULT_ADMIN_PERMISSIONS,
    createdAt: '2025-02-01 09:15:00',
    lastLoginAt: '2026-08-09 11:20:00',
    lastLoginIp: '198.51.100.43',
  },
  {
    id: 'user-staff-103',
    fullName: 'Sarah Konadu',
    email: 'sarah.support@celoxaghana.online',
    password: 'staff123',
    role: 'staff',
    platformRole: 'staff',
    staffTitle: 'Technical Support Lead',
    department: 'Technical Support',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Support',
    phone: '+233 (0) 24 991 2233',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop',
    walletBalanceGhs: 800.00,
    walletBalanceUsd: 60.00,
    twoFactorEnabled: true,
    permissions: DEFAULT_SUPPORT_STAFF_PERMISSIONS,
    createdAt: '2025-02-15 11:00:00',
    lastLoginAt: '2026-08-09 08:30:00',
    lastLoginIp: '198.51.100.44',
  },
  {
    id: 'user-staff-104',
    fullName: 'Emmanuel Osei',
    email: 'emmanuel.finance@celoxaghana.online',
    password: 'staff123',
    role: 'staff',
    platformRole: 'staff',
    staffTitle: 'Billing & Finance Officer',
    department: 'Finance',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Celoxa Finance',
    phone: '+233 (0) 27 334 5566',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop',
    walletBalanceGhs: 1200.00,
    walletBalanceUsd: 90.00,
    twoFactorEnabled: true,
    permissions: DEFAULT_FINANCE_STAFF_PERMISSIONS,
    createdAt: '2025-03-01 10:00:00',
    lastLoginAt: '2026-08-08 16:45:00',
    lastLoginIp: '198.51.100.45',
  },
  {
    id: 'user-cust-102',
    fullName: 'Kwame Mensah',
    email: 'kwame@enterpriseghana.com',
    password: 'password123',
    role: 'client',
    platformRole: 'client',
    staffTitle: 'Client Owner',
    department: 'Customer',
    accountStatus: 'active',
    isEmailVerified: true,
    companyName: 'Akwaaba Digital Hub',
    phone: '+233 (0) 24 123 4567',
    country: 'Ghana',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop',
    walletBalanceGhs: 1450.00,
    walletBalanceUsd: 100.00,
    twoFactorEnabled: false,
    permissions: DEFAULT_CLIENT_PERMISSIONS,
    createdAt: '2025-03-15 14:20:00',
    lastLoginAt: '2026-08-09 09:12:00',
    lastLoginIp: '154.160.18.22',
    isBusinessAccount: true,
  },
];

const DEFAULT_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'log-1001',
    timestamp: '2026-08-09 10:30:12',
    actor: 'System Admin (Chief Administrator)',
    action: 'UPDATE_SYSTEM_SETTINGS',
    target: 'general.siteName',
    details: 'System database initial seed bootstrapped successfully',
    ipAddress: '198.51.100.42',
    status: 'info',
  },
  {
    id: 'log-1002',
    timestamp: '2026-08-09 10:15:00',
    actor: 'Automated Provisioner',
    action: 'PROVISION_CPANEL_ACCOUNT',
    target: 'celoxaghana.online',
    details: 'Account celox_admin created on US-EAST-GH1',
    ipAddress: '185.199.108.153',
    status: 'success',
  },
];

const DEFAULT_STAFF_INVITATIONS: StaffInvitation[] = [
  {
    id: 'inv-101',
    email: 'kofi.mensah@celoxaghana.online',
    fullName: 'Kofi Mensah',
    role: 'staff',
    department: 'Technical Support',
    staffTitle: 'Junior Support Engineer',
    permissions: DEFAULT_SUPPORT_STAFF_PERMISSIONS,
    token: 'inv_tok_9823101923',
    expiresAt: '2026-08-10T18:00:00Z',
    status: 'pending',
    createdByEmail: 'admin@celoxaghana.online',
    createdAt: '2026-08-09T14:30:00Z',
  }
];

const DEFAULT_ACTIVE_SESSIONS: UserSession[] = [
  {
    id: 'sess-1001',
    userId: 'user-admin-101',
    device: 'Chrome 127.0 (macOS Sequoia)',
    ip: '198.51.100.42',
    location: 'Accra, Ghana',
    createdAt: '2026-08-09 10:00:00',
    lastActiveAt: 'Just now',
    isCurrent: true,
  },
  {
    id: 'sess-1002',
    userId: 'user-admin-101',
    device: 'Safari Mobile (iOS 17.6)',
    ip: '154.160.18.22',
    location: 'Kumasi, Ghana',
    createdAt: '2026-08-08 19:22:00',
    lastActiveAt: '1 day ago',
    isCurrent: false,
  },
  {
    id: 'sess-1003',
    userId: 'user-cust-102',
    device: 'Firefox 128 (Windows 11)',
    ip: '154.160.18.22',
    location: 'Accra, Ghana',
    createdAt: '2026-08-09 09:12:00',
    lastActiveAt: '3 hours ago',
    isCurrent: true,
  }
];

const DEFAULT_LOGIN_ACTIVITY: LoginActivityRecord[] = [
  {
    id: 'act-1',
    userId: 'user-admin-101',
    userEmail: 'admin@celoxaghana.online',
    timestamp: '2026-08-09 10:45:12',
    device: 'Chrome 127.0 (macOS)',
    ip: '198.51.100.42',
    status: 'success',
  },
  {
    id: 'act-2',
    userId: 'user-admin-101',
    userEmail: 'admin@celoxaghana.online',
    timestamp: '2026-08-08 14:10:05',
    device: 'Chrome 127.0 (macOS)',
    ip: '198.51.100.42',
    status: 'failed',
    failureReason: 'Invalid MFA verification code provided',
  },
  {
    id: 'act-3',
    userId: 'user-cust-102',
    userEmail: 'kwame@enterpriseghana.com',
    timestamp: '2026-08-09 09:12:00',
    device: 'Firefox 128 (Windows)',
    ip: '154.160.18.22',
    status: 'success',
  }
];

const DEFAULT_CLIENT_API_KEYS: ClientApiKey[] = [
  {
    id: 'key-101',
    userId: 'user-cust-102',
    keyName: 'Akwaaba Domain Automator',
    keySecret: 'clx_live_sk_902319028301923',
    scopes: ['domain:read', 'hosting:read', 'tickets:write'],
    createdAt: '2026-07-01',
    lastUsedAt: '2026-08-09 08:15:00',
    active: true,
  }
];

const INITIAL_DB_STATE: SystemDatabaseState = {
  version: '2.5.0-ENTERPRISE-DB',
  lastUpdated: new Date().toISOString(),
  settings: DEFAULT_SYSTEM_SETTINGS,
  hostingPackages: INITIAL_BLUEPRINTS,
  tlds: TLD_CATALOG,
  controlPanelGateways: INITIAL_GATEWAYS,
  serverClusterNodes: INITIAL_NODES,
  provisionedAccounts: INITIAL_PROVISION_TASKS,
  auditLogs: DEFAULT_AUDIT_LOGS,
  users: DEFAULT_USERS,
  currentUser: DEFAULT_USERS[0], // Logged in as Chief Admin by default
  persistentCart: [],
  staffInvitations: DEFAULT_STAFF_INVITATIONS,
  activeSessions: DEFAULT_ACTIVE_SESSIONS,
  loginActivity: DEFAULT_LOGIN_ACTIVITY,
  clientApiKeys: DEFAULT_CLIENT_API_KEYS,
};

type DatabaseChangeListener = (state: SystemDatabaseState) => void;

class SystemDatabaseEngine {
  private state: SystemDatabaseState;
  private listeners: Set<DatabaseChangeListener> = new Set();

  constructor() {
    this.state = this.loadFromStorage();

    // Sync across browser tabs automatically
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_KEY) {
          this.state = this.loadFromStorage();
          this.notifyListeners();
        }
      });
    }
  }

  private loadFromStorage(): SystemDatabaseState {
    if (typeof localStorage === 'undefined') return INITIAL_DB_STATE;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        this.saveToStorage(INITIAL_DB_STATE);
        return INITIAL_DB_STATE;
      }
      const parsed = JSON.parse(raw) as SystemDatabaseState;
      // Ensure missing keys are merged from default
      return {
        ...INITIAL_DB_STATE,
        ...parsed,
        settings: {
          ...DEFAULT_SYSTEM_SETTINGS,
          ...(parsed.settings || {}),
          general: {
            ...DEFAULT_SYSTEM_SETTINGS.general,
            ...(parsed.settings?.general || {}),
          },
        },
      };
    } catch (err) {
      console.error('[SystemDatabase] Failed to parse local database store:', err);
      return INITIAL_DB_STATE;
    }
  }

  private saveToStorage(newState: SystemDatabaseState) {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
    } catch (err) {
      console.error('[SystemDatabase] Failed to write to local storage:', err);
    }
  }

  private commit(newState: SystemDatabaseState, actionName?: string, actionTarget?: string, actionDetails?: string) {
    const updatedState: SystemDatabaseState = {
      ...newState,
      lastUpdated: new Date().toISOString(),
    };

    if (actionName) {
      const logItem: AuditLogEntry = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
        actor: 'Admin Console',
        action: actionName,
        target: actionTarget || 'System',
        details: actionDetails || 'Database updated',
        ipAddress: '127.0.0.1 (Local Session)',
        status: 'success',
      };
      updatedState.auditLogs = [logItem, ...(updatedState.auditLogs || [])].slice(0, 100);
    }

    this.state = updatedState;
    this.saveToStorage(updatedState);
    this.notifyListeners();
  }

  public subscribe(listener: DatabaseChangeListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener(this.state));
  }

  // --- GETTERS ---
  public getState(): SystemDatabaseState {
    return this.state;
  }

  public getSettings(): SystemSettingsConfig {
    return this.state.settings;
  }

  public getHostingPackages(): HostingPackageBlueprint[] {
    return this.state.hostingPackages || [];
  }

  public getTlds(): TLDDetail[] {
    return this.state.tlds || TLD_CATALOG;
  }

  public getControlPanelGateways(): ControlPanelGateway[] {
    return this.state.controlPanelGateways || [];
  }

  public getServerNodes(): ServerClusterNode[] {
    return this.state.serverClusterNodes || [];
  }

  public getProvisionedAccounts(): ProvisionTask[] {
    return this.state.provisionedAccounts || [];
  }

  public getAuditLogs(): AuditLogEntry[] {
    return this.state.auditLogs || [];
  }

  // --- USER AUTHENTICATION & CARTS ---
  public getUsers(): SystemUser[] {
    return this.state.users || DEFAULT_USERS;
  }

  public getCurrentUser(): SystemUser | null {
    return this.state.currentUser;
  }

  public loginUser(email: string, password?: string): { success: boolean; user?: SystemUser; error?: string; targetPortal?: 'admin' | 'staff' | 'account' } {
    const cleanEmail = email.trim().toLowerCase();
    const found = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );

    const nowStr = new Date().toISOString().replace('T', ' ').slice(0, 19);

    if (!found) {
      // Record failed attempt
      const failRecord: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: 'unknown',
        userEmail: cleanEmail,
        timestamp: nowStr,
        device: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 30) : 'Browser',
        ip: '198.51.100.42',
        status: 'failed',
        failureReason: 'Account with provided email address does not exist',
      };
      this.commit({
        ...this.state,
        loginActivity: [failRecord, ...(this.state.loginActivity || [])].slice(0, 100),
      }, 'LOGIN_FAILED', cleanEmail, 'Unknown account email login attempt');

      return { success: false, error: 'User account with this email address was not found.' };
    }

    // Check account status
    if (found.accountStatus === 'suspended') {
      return { success: false, error: 'This account has been suspended by an administrator. Please contact billing/support.' };
    }
    if (found.accountStatus === 'locked') {
      return { success: false, error: 'This account is locked due to security policy. Please reset your password or contact support.' };
    }
    if (found.accountStatus === 'deactivated') {
      return { success: false, error: 'This account has been deactivated.' };
    }

    if (password && found.password && found.password !== password) {
      const failRecord: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: found.id,
        userEmail: found.email,
        timestamp: nowStr,
        device: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 30) : 'Browser',
        ip: '198.51.100.42',
        status: 'failed',
        failureReason: 'Invalid password credentials provided',
      };
      this.commit({
        ...this.state,
        loginActivity: [failRecord, ...(this.state.loginActivity || [])].slice(0, 100),
      }, 'LOGIN_FAILED', found.email, 'Invalid password attempt');

      return { success: false, error: 'Invalid password. Please double check your credentials.' };
    }

    const updatedUser: SystemUser = {
      ...found,
      lastLoginAt: nowStr,
      lastLoginIp: '198.51.100.42',
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);

    // Record session & login activity
    const successActivity: LoginActivityRecord = {
      id: `act-${Date.now()}`,
      userId: found.id,
      userEmail: found.email,
      timestamp: nowStr,
      device: typeof navigator !== 'undefined' ? (navigator.userAgent.includes('Mac') ? 'Chrome (macOS)' : 'Chrome (Windows)') : 'Web Browser',
      ip: '198.51.100.42',
      status: 'success',
    };

    const newSession: UserSession = {
      id: `sess-${Date.now()}`,
      userId: found.id,
      device: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 35) : 'Chrome Web Session',
      ip: '198.51.100.42',
      location: 'Accra, Ghana',
      createdAt: nowStr,
      lastActiveAt: 'Just now',
      isCurrent: true,
    };

    // Determine target portal based on role
    let targetPortal: 'admin' | 'staff' | 'account' = 'account';
    if (found.role === 'super_admin' || found.role === 'administrator' || found.role === 'admin') {
      targetPortal = 'admin';
    } else if (found.role === 'staff') {
      targetPortal = 'staff';
    } else {
      targetPortal = 'account';
    }

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedUser,
      loginActivity: [successActivity, ...(this.state.loginActivity || [])].slice(0, 100),
      activeSessions: [newSession, ...(this.state.activeSessions || []).map(s => s.userId === found.id ? { ...s, isCurrent: false } : s)],
    }, 'USER_LOGIN', updatedUser.email, `Authenticated as ${found.role.toUpperCase()} -> Routed to ${targetPortal.toUpperCase()}`);

    return { success: true, user: updatedUser, targetPortal };
  }

  public registerClientUser(userData: {
    fullName: string;
    email: string;
    phone?: string;
    companyName?: string;
    country?: string;
    password?: string;
  }): { success: boolean; user?: SystemUser; verificationToken?: string; error?: string } {
    const cleanEmail = userData.email.trim().toLowerCase();
    const existing = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );
    if (existing) {
      return { success: false, error: 'An account with this email address already exists. Please sign in.' };
    }

    const verificationToken = `vtok_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;

    const newUser: SystemUser = {
      id: `user-${Date.now()}`,
      fullName: userData.fullName,
      email: cleanEmail,
      password: userData.password || 'password123',
      role: 'client',
      platformRole: 'client',
      staffTitle: 'Client Owner',
      department: 'Customer',
      accountStatus: 'pending_verification',
      isEmailVerified: false,
      verificationToken,
      phone: userData.phone || '',
      companyName: userData.companyName || '',
      country: userData.country || 'Ghana',
      walletBalanceGhs: 100.00,
      walletBalanceUsd: 10.00,
      twoFactorEnabled: false,
      permissions: DEFAULT_CLIENT_PERMISSIONS,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginIp: '154.160.18.22',
      isBusinessAccount: !!userData.companyName,
    };

    const updatedUsers = [...(this.state.users || DEFAULT_USERS), newUser];

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: newUser,
    }, 'REGISTER_CLIENT_USER', newUser.email, `Client account created. Sent verification email with token ${verificationToken.slice(0, 10)}...`);

    return { success: true, user: newUser, verificationToken };
  }

  public verifyUserEmail(email: string, token: string): { success: boolean; error?: string } {
    const cleanEmail = email.trim().toLowerCase();
    const found = (this.state.users || DEFAULT_USERS).find((u) => u.email.toLowerCase() === cleanEmail);
    if (!found) {
      return { success: false, error: 'Account not found.' };
    }
    if (found.isEmailVerified) {
      return { success: true };
    }
    if (found.verificationToken && found.verificationToken !== token) {
      return { success: false, error: 'Invalid or expired verification token link.' };
    }

    const updatedUser: SystemUser = {
      ...found,
      isEmailVerified: true,
      accountStatus: 'active',
      verificationToken: undefined,
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);
    const isCurrent = this.state.currentUser?.id === found.id;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: isCurrent ? updatedUser : this.state.currentUser,
    }, 'VERIFY_EMAIL', found.email, 'Email address successfully verified via single-use link');

    return { success: true };
  }

  public sendPasswordReset(email: string): { success: boolean; resetToken?: string; message: string } {
    const cleanEmail = email.trim().toLowerCase();
    const found = (this.state.users || DEFAULT_USERS).find((u) => u.email.toLowerCase() === cleanEmail);
    const genericMsg = 'If an account exists for that email address, we have sent password reset instructions.';
    
    if (!found) {
      return { success: true, message: genericMsg };
    }

    const resetToken = `rst_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    const updatedUser: SystemUser = {
      ...found,
      resetToken,
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);

    this.commit({
      ...this.state,
      users: updatedUsers,
    }, 'PASSWORD_RESET_DISPATCH', cleanEmail, `Sent password reset email with token ${resetToken.slice(0, 10)}...`);

    return { success: true, resetToken, message: genericMsg };
  }

  public resetPasswordWithToken(token: string, newPassword?: string): { success: boolean; error?: string } {
    const found = (this.state.users || DEFAULT_USERS).find((u) => u.resetToken === token);
    if (!found) {
      return { success: false, error: 'Invalid or expired password reset link token.' };
    }

    const updatedUser: SystemUser = {
      ...found,
      password: newPassword || 'newpassword123',
      resetToken: undefined,
    };

    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => u.id === found.id ? updatedUser : u);

    this.commit({
      ...this.state,
      users: updatedUsers,
    }, 'PASSWORD_RESET_COMPLETE', found.email, 'Password updated via reset token. Revoked active sessions.');

    return { success: true };
  }

  // --- STAFF & ADMIN INVITATIONS ---
  public getStaffInvitations(): StaffInvitation[] {
    return this.state.staffInvitations || [];
  }

  public createStaffInvitation(invite: {
    email: string;
    fullName: string;
    role: PlatformRole;
    department?: string;
    staffTitle?: string;
    permissions: ModulePermissions;
  }): { success: boolean; invitation?: StaffInvitation; error?: string } {
    const cleanEmail = invite.email.trim().toLowerCase();
    const existingUser = (this.state.users || DEFAULT_USERS).find((u) => u.email.toLowerCase() === cleanEmail);
    if (existingUser) {
      return { success: false, error: `User with email ${cleanEmail} already has an account.` };
    }

    const inviteToken = `inv_tok_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    const newInvite: StaffInvitation = {
      id: `inv-${Date.now()}`,
      email: cleanEmail,
      fullName: invite.fullName,
      role: invite.role,
      department: invite.department || 'Operations',
      staffTitle: invite.staffTitle || 'Staff Member',
      permissions: invite.permissions,
      token: inviteToken,
      expiresAt,
      status: 'pending',
      createdByEmail: this.state.currentUser?.email || 'admin@celoxaghana.online',
      createdAt: new Date().toISOString(),
    };

    const updatedInvites = [newInvite, ...(this.state.staffInvitations || [])];

    this.commit({
      ...this.state,
      staffInvitations: updatedInvites,
    }, 'CREATE_STAFF_INVITATION', cleanEmail, `Sent invitation link for role ${invite.role.toUpperCase()}`);

    return { success: true, invitation: newInvite };
  }

  public acceptStaffInvitation(token: string, password?: string): { success: boolean; user?: SystemUser; error?: string } {
    const invite = (this.state.staffInvitations || []).find((i) => i.token === token && i.status === 'pending');
    if (!invite) {
      return { success: false, error: 'Invitation link is invalid or has already been used.' };
    }

    if (new Date(invite.expiresAt) < new Date()) {
      return { success: false, error: 'Invitation link has expired. Please request a new invitation from Super Admin.' };
    }

    const newStaffUser: SystemUser = {
      id: `user-staff-${Date.now()}`,
      fullName: invite.fullName,
      email: invite.email,
      password: password || 'staff123',
      role: invite.role,
      platformRole: invite.role,
      staffTitle: invite.staffTitle,
      department: invite.department,
      accountStatus: 'active',
      isEmailVerified: true,
      companyName: 'Celoxa Technologies Ltd',
      phone: '+233 (0) 30 291 8840',
      country: 'Ghana',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop',
      walletBalanceGhs: 500.00,
      walletBalanceUsd: 35.00,
      twoFactorEnabled: true,
      mfaSecret: 'JBSWY3DPEHPK3PXP',
      mfaBackupCodes: ['9910-2391', '4019-2019', '8812-4019'],
      permissions: invite.permissions,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginIp: '198.51.100.42',
    };

    const updatedInvites = (this.state.staffInvitations || []).map((i) => i.id === invite.id ? { ...i, status: 'accepted' as const } : i);
    const updatedUsers = [...(this.state.users || DEFAULT_USERS), newStaffUser];

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: newStaffUser,
      staffInvitations: updatedInvites,
    }, 'ACCEPT_STAFF_INVITATION', invite.email, `Activated staff account for ${invite.fullName} (${invite.role.toUpperCase()})`);

    return { success: true, user: newStaffUser };
  }

  public cancelStaffInvitation(invitationId: string): void {
    const updatedInvites = (this.state.staffInvitations || []).filter((i) => i.id !== invitationId);
    this.commit({
      ...this.state,
      staffInvitations: updatedInvites,
    }, 'CANCEL_STAFF_INVITATION', invitationId, 'Cancelled staff invitation');
  }

  // --- PERMISSIONS & ACCOUNT STATUS MANAGEMENT ---
  public updateUserPermissions(userId: string, permissions: ModulePermissions): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return { ...u, permissions };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    const updatedCurrent = isCurrent ? { ...this.state.currentUser!, permissions } : this.state.currentUser;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'UPDATE_USER_PERMISSIONS', userId, 'Updated module permission matrix');
  }

  public setUserAccountStatus(userId: string, status: UserAccountStatus, reason?: string): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return { ...u, accountStatus: status };
      }
      return u;
    });

    const targetUser = (this.state.users || DEFAULT_USERS).find((u) => u.id === userId);

    this.commit({
      ...this.state,
      users: updatedUsers,
    }, 'SET_USER_STATUS', targetUser?.email || userId, `Account status changed to ${status.toUpperCase()}. Reason: ${reason || 'Admin Action'}`);
  }

  // --- SESSIONS & MFA & API KEYS ---
  public getUserSessions(userId: string): UserSession[] {
    return (this.state.activeSessions || []).filter((s) => s.userId === userId);
  }

  public revokeSession(sessionId: string): void {
    const updated = (this.state.activeSessions || []).filter((s) => s.id !== sessionId);
    this.commit({
      ...this.state,
      activeSessions: updated,
    }, 'REVOKE_SESSION', sessionId, 'Revoked user session');
  }

  public revokeAllOtherSessions(userId: string): void {
    const updated = (this.state.activeSessions || []).filter((s) => s.userId !== userId || s.isCurrent);
    this.commit({
      ...this.state,
      activeSessions: updated,
    }, 'REVOKE_ALL_SESSIONS', userId, 'Revoked all other active sessions for user');
  }

  public getLoginActivityRecords(userId: string): LoginActivityRecord[] {
    return (this.state.loginActivity || []).filter((a) => a.userId === userId || a.userId === 'unknown');
  }

  public updateUserMfa(userId: string, enabled: boolean, secret?: string, backupCodes?: string[]): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return {
          ...u,
          twoFactorEnabled: enabled,
          mfaSecret: secret || u.mfaSecret,
          mfaBackupCodes: backupCodes || u.mfaBackupCodes,
        };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    const updatedCurrent = isCurrent 
      ? { ...this.state.currentUser!, twoFactorEnabled: enabled, mfaSecret: secret || this.state.currentUser?.mfaSecret, mfaBackupCodes: backupCodes || this.state.currentUser?.mfaBackupCodes }
      : this.state.currentUser;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'UPDATE_MFA_STATUS', userId, `Multi-Factor Authentication (MFA) ${enabled ? 'ENABLED' : 'DISABLED'}`);
  }

  public getClientApiKeys(userId: string): ClientApiKey[] {
    return (this.state.clientApiKeys || []).filter((k) => k.userId === userId);
  }

  public createClientApiKey(userId: string, keyName: string, scopes: ClientApiKey['scopes']): ClientApiKey {
    const secret = `clx_live_sk_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    const newKey: ClientApiKey = {
      id: `key-${Date.now()}`,
      userId,
      keyName,
      keySecret: secret,
      scopes,
      createdAt: new Date().toISOString().slice(0, 10),
      active: true,
    };

    const updated = [newKey, ...(this.state.clientApiKeys || [])];
    this.commit({
      ...this.state,
      clientApiKeys: updated,
    }, 'CREATE_API_KEY', userId, `Generated API Key "${keyName}" with ${scopes.length} scopes`);

    return newKey;
  }

  public revokeClientApiKey(keyId: string): void {
    const updated = (this.state.clientApiKeys || []).filter((k) => k.id !== keyId);
    this.commit({
      ...this.state,
      clientApiKeys: updated,
    }, 'REVOKE_API_KEY', keyId, 'Revoked Client API Key');
  }

  public registerUser(userData: Partial<SystemUser> & { fullName: string; email: string }): { success: boolean; user?: SystemUser; error?: string } {
    const cleanEmail = userData.email.trim().toLowerCase();
    const existing = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );
    if (existing) {
      return { success: false, error: 'An account with this email address already exists. Please sign in.' };
    }

    const pRole: PlatformRole = userData.platformRole || (userData.role as PlatformRole) || 'client';

    const newUser: SystemUser = {
      id: `user-${Date.now()}`,
      fullName: userData.fullName,
      email: cleanEmail,
      password: userData.password || 'password123',
      role: pRole,
      platformRole: pRole,
      staffTitle: userData.staffTitle || (pRole === 'client' ? 'Client Owner' : 'Staff Member'),
      department: userData.department || 'Customer',
      accountStatus: userData.accountStatus || 'active',
      isEmailVerified: userData.isEmailVerified ?? true,
      companyName: userData.companyName || '',
      phone: userData.phone || '',
      country: userData.country || 'Ghana',
      avatarUrl: userData.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop',
      walletBalanceGhs: userData.walletBalanceGhs || 500.00,
      walletBalanceUsd: userData.walletBalanceUsd || 35.00,
      twoFactorEnabled: userData.twoFactorEnabled ?? false,
      permissions: userData.permissions || DEFAULT_CLIENT_PERMISSIONS,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastLoginIp: '198.51.100.42',
    };

    const updatedUsers = [...(this.state.users || DEFAULT_USERS), newUser];

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: newUser,
    }, 'REGISTER_USER', newUser.email, `New account created for ${newUser.fullName}`);

    return { success: true, user: newUser };
  }

  public loginOrRegisterWithGoogle(googleProfile: {
    fullName: string;
    email: string;
    avatarUrl?: string;
  }): { success: boolean; user: SystemUser; isNewUser: boolean } {
    const cleanEmail = googleProfile.email.trim().toLowerCase();
    const existing = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );

    const now = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const isAdminEmail = cleanEmail === 'baffourgideon05@gmail.com' || cleanEmail.includes('admin') || cleanEmail.endsWith('@celoxaghana.online');

    if (existing) {
      const updatedUser: SystemUser = {
        ...existing,
        lastLoginAt: now,
        avatarUrl: googleProfile.avatarUrl || existing.avatarUrl,
        isEmailVerified: true,
        ...(isAdminEmail ? {
          role: 'super_admin',
          platformRole: 'super_admin',
          staffTitle: 'Chief System Administrator',
          department: 'Executive Systems',
          permissions: DEFAULT_SUPER_ADMIN_PERMISSIONS,
        } : {})
      };

      const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) =>
        u.id === existing.id ? updatedUser : u
      );

      const newAudit: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: existing.id,
        userEmail: existing.email,
        timestamp: now,
        ip: '66.249.66.1',
        device: 'Google OAuth / Chrome',
        status: 'success',
      };

      this.commit({
        ...this.state,
        users: updatedUsers,
        currentUser: updatedUser,
        loginActivity: [newAudit, ...(this.state.loginActivity || [])],
      }, 'GOOGLE_SIGN_IN', existing.email, `User signed in via Google Account`);

      return { success: true, user: updatedUser, isNewUser: false };
    } else {
      const newUser: SystemUser = {
        id: `user-${Date.now()}`,
        fullName: googleProfile.fullName || googleProfile.email.split('@')[0],
        email: cleanEmail,
        password: 'admin',
        role: isAdminEmail ? 'super_admin' : 'client',
        platformRole: isAdminEmail ? 'super_admin' : 'client',
        staffTitle: isAdminEmail ? 'Chief System Administrator' : 'Client Owner',
        department: isAdminEmail ? 'Executive Systems' : 'Customer',
        accountStatus: 'active',
        isEmailVerified: true,
        companyName: isAdminEmail ? 'Celoxa Executive Admin' : 'Google Account User',
        phone: '+233 (0) 24 000 0000',
        country: 'Ghana',
        avatarUrl: googleProfile.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(googleProfile.fullName)}`,
        walletBalanceGhs: isAdminEmail ? 25000.00 : 500.00,
        walletBalanceUsd: isAdminEmail ? 1850.00 : 35.00,
        twoFactorEnabled: false,
        permissions: isAdminEmail ? DEFAULT_SUPER_ADMIN_PERMISSIONS : DEFAULT_CLIENT_PERMISSIONS,
        createdAt: now,
        lastLoginAt: now,
        lastLoginIp: '66.249.66.1',
      };

      const newAudit: LoginActivityRecord = {
        id: `act-${Date.now()}`,
        userId: newUser.id,
        userEmail: newUser.email,
        timestamp: now,
        ip: '66.249.66.1',
        device: 'Google OAuth / Chrome',
        status: 'success',
      };

      const updatedUsers = [...(this.state.users || DEFAULT_USERS), newUser];

      this.commit({
        ...this.state,
        users: updatedUsers,
        currentUser: newUser,
        loginActivity: [newAudit, ...(this.state.loginActivity || [])],
      }, 'GOOGLE_SIGN_UP', newUser.email, `New account registered via Google SSO`);

      return { success: true, user: newUser, isNewUser: true };
    }
  }

  public verifyUserPassword(email: string, passwordAttempt: string): boolean {
    const cleanEmail = email.trim().toLowerCase();
    const user = (this.state.users || DEFAULT_USERS).find(
      (u) => u.email.toLowerCase() === cleanEmail
    );
    if (!user) return false;
    // Allow master password 'admin' for demo system or exact stored password
    if (passwordAttempt === 'admin' || user.password === passwordAttempt) {
      return true;
    }
    return false;
  }

  public logoutUser(): void {
    const active = this.state.currentUser;
    this.commit({
      ...this.state,
      currentUser: null,
    }, 'USER_LOGOUT', active?.email || 'User', 'Session terminated');
  }

  public updateUserProfile(userId: string, updates: Partial<SystemUser>): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return { ...u, ...updates };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    const updatedCurrent = isCurrent ? { ...this.state.currentUser!, ...updates } : this.state.currentUser;

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'UPDATE_USER_PROFILE', userId, 'Account profile details updated');
  }

  public topUpUserWallet(userId: string, amountGhs: number, amountUsd: number): void {
    const updatedUsers = (this.state.users || DEFAULT_USERS).map((u) => {
      if (u.id === userId) {
        return {
          ...u,
          walletBalanceGhs: u.walletBalanceGhs + amountGhs,
          walletBalanceUsd: u.walletBalanceUsd + amountUsd,
        };
      }
      return u;
    });

    const isCurrent = this.state.currentUser?.id === userId;
    let updatedCurrent = this.state.currentUser;
    if (isCurrent && updatedCurrent) {
      updatedCurrent = {
        ...updatedCurrent,
        walletBalanceGhs: updatedCurrent.walletBalanceGhs + amountGhs,
        walletBalanceUsd: updatedCurrent.walletBalanceUsd + amountUsd,
      };
    }

    this.commit({
      ...this.state,
      users: updatedUsers,
      currentUser: updatedCurrent,
    }, 'WALLET_TOPUP', userId, `Added GH₵${amountGhs} / $${amountUsd} to wallet`);
  }

  public getUserPermissions(userId: string): ModulePermissions {
    const found = (this.state.users || DEFAULT_USERS).find(u => u.id === userId);
    if (found?.permissions) return found.permissions;
    if (found?.role === 'super_admin' || found?.platformRole === 'super_admin') return DEFAULT_SUPER_ADMIN_PERMISSIONS;
    if (found?.role === 'administrator' || found?.platformRole === 'administrator') return DEFAULT_ADMIN_PERMISSIONS;
    if (found?.role === 'staff' || found?.platformRole === 'staff') return DEFAULT_SUPPORT_STAFF_PERMISSIONS;
    return DEFAULT_CLIENT_PERMISSIONS;
  }

  public getPersistentCart(): CartItem[] {
    return this.state.persistentCart || [];
  }

  public savePersistentCart(cart: CartItem[]): void {
    this.commit({
      ...this.state,
      persistentCart: cart,
    });
  }

  // --- SETTERS & MUTATORS ---
  public updateSettings(newSettings: SystemSettingsConfig) {
    const siteTitleChanged = newSettings.general.siteName !== this.state.settings.general.siteName;
    const detailMsg = siteTitleChanged 
      ? `Site Title updated to "${newSettings.general.siteName}"`
      : 'System Configuration Parameters Saved';

    this.commit({
      ...this.state,
      settings: newSettings,
    }, 'UPDATE_SYSTEM_SETTINGS', 'system_settings', detailMsg);
  }

  public getHostingPackages(): WhmcsHostingPackage[] {
    const list = this.state.hostingPackages || [];
    if (!list || list.length === 0) return MOCK_WHMCS_PACKAGES;
    return list.map((pkg: any) => ({
      id: pkg.id || `pkg-${Math.random().toString(36).substring(2, 7)}`,
      name: pkg.name || 'Hosting Package',
      category: pkg.category || 'Shared Web Hosting',
      module: pkg.module || pkg.controlPanelType || 'cpanel',
      description: pkg.description || 'High performance web hosting plan.',
      diskLimitMb: pkg.diskLimitMb ?? pkg.diskQuotaMb ?? 10000,
      bandwidthLimitGb: pkg.bandwidthLimitGb ?? pkg.bandwidthQuotaGb ?? 250,
      maxDatabases: pkg.maxDatabases ?? 5,
      maxSubdomains: pkg.maxSubdomains ?? 10,
      maxMailboxes: pkg.maxMailboxes ?? pkg.maxEmails ?? 10,
      priceMonthly: pkg.priceMonthly ?? 4.99,
      priceAnnually: pkg.priceAnnually ?? 49.90,
      freeDomainEligible: pkg.freeDomainEligible ?? true,
      features: pkg.features || ['Free SSL Certificate', 'cPanel Control Panel', 'Daily Backups', '1-Click WordPress Installer'],
    }));
  }

  public saveHostingPackage(pkg: any) {
    const packagesList = this.state.hostingPackages || [];
    const exists = packagesList.some((p: any) => p.id === pkg.id);
    let updated: any[];
    if (exists) {
      updated = packagesList.map((p: any) => (p.id === pkg.id ? pkg : p));
    } else {
      updated = [pkg, ...packagesList];
    }
    this.commit({
      ...this.state,
      hostingPackages: updated,
    }, exists ? 'UPDATE_PACKAGE' : 'CREATE_PACKAGE', pkg.name || 'Hosting Plan', `Saved hosting plan: ${pkg.name}`);
  }

  public deleteHostingPackage(id: string) {
    const pkg = this.state.hostingPackages.find((p) => p.id === id);
    this.commit({
      ...this.state,
      hostingPackages: this.state.hostingPackages.filter((p) => p.id !== id),
    }, 'DELETE_PACKAGE', pkg?.name || id, 'Removed hosting package from database');
  }

  public saveTld(tldItem: TLDDetail) {
    const currentTlds = this.state.tlds || TLD_CATALOG;
    const exists = currentTlds.some((t) => t.tld.toLowerCase() === tldItem.tld.toLowerCase());
    let updated: TLDDetail[];
    if (exists) {
      updated = currentTlds.map((t) => (t.tld.toLowerCase() === tldItem.tld.toLowerCase() ? tldItem : t));
    } else {
      updated = [...currentTlds, tldItem];
    }
    this.commit({
      ...this.state,
      tlds: updated,
    }, exists ? 'UPDATE_TLD' : 'CREATE_TLD', tldItem.tld, `Saved pricing for TLD ${tldItem.tld}`);
  }

  public deleteTld(tldName: string) {
    const currentTlds = this.state.tlds || TLD_CATALOG;
    this.commit({
      ...this.state,
      tlds: currentTlds.filter((t) => t.tld.toLowerCase() !== tldName.toLowerCase()),
    }, 'DELETE_TLD', tldName, 'Removed domain extension from database');
  }

  public saveControlPanelGateway(gw: ControlPanelGateway) {
    const exists = this.state.controlPanelGateways.some((g) => g.id === gw.id);
    let updated: ControlPanelGateway[];
    if (exists) {
      updated = this.state.controlPanelGateways.map((g) => (g.id === gw.id ? gw : g));
    } else {
      updated = [...this.state.controlPanelGateways, gw];
    }
    this.commit({
      ...this.state,
      controlPanelGateways: updated,
    }, exists ? 'UPDATE_GATEWAY' : 'CONNECT_GATEWAY', gw.name, `Control Panel API Gateway ${gw.type.toUpperCase()}`);
  }

  public deleteControlPanelGateway(id: string) {
    const gw = this.state.controlPanelGateways.find((g) => g.id === id);
    this.commit({
      ...this.state,
      controlPanelGateways: this.state.controlPanelGateways.filter((g) => g.id !== id),
    }, 'DISCONNECT_GATEWAY', gw?.name || id, 'Disconnected Control Panel API');
  }

  public saveServerNode(node: ServerClusterNode) {
    const exists = this.state.serverClusterNodes.some((n) => n.id === node.id);
    let updated: ServerClusterNode[];
    if (exists) {
      updated = this.state.serverClusterNodes.map((n) => (n.id === node.id ? node : n));
    } else {
      updated = [...this.state.serverClusterNodes, node];
    }
    this.commit({
      ...this.state,
      serverClusterNodes: updated,
    }, exists ? 'UPDATE_NODE' : 'REGISTER_NODE', node.name, `Server node registered IP ${node.ip}`);
  }

  public saveProvisionedAccount(account: ProvisionTask) {
    const exists = this.state.provisionedAccounts.some((a) => a.id === account.id);
    let updated: ProvisionTask[];
    if (exists) {
      updated = this.state.provisionedAccounts.map((a) => (a.id === account.id ? account : a));
    } else {
      updated = [account, ...this.state.provisionedAccounts];
    }
    this.commit({
      ...this.state,
      provisionedAccounts: updated,
    }, exists ? 'UPDATE_HOSTING_ACCOUNT' : 'PROVISION_ACCOUNT', account.domain, `User: ${account.username}`);
  }

  public deleteProvisionedAccount(id: string) {
    const acc = this.state.provisionedAccounts.find((a) => a.id === id);
    this.commit({
      ...this.state,
      provisionedAccounts: this.state.provisionedAccounts.filter((a) => a.id !== id),
    }, 'TERMINATE_ACCOUNT', acc?.domain || id, 'Hosting account terminated');
  }

  // --- DATABASE EXPORT / IMPORT / RESET ---
  public exportJsonDump(): string {
    return JSON.stringify(this.state, null, 2);
  }

  public importJsonDump(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString) as SystemDatabaseState;
      if (!parsed.settings || !parsed.settings.general || !parsed.version) {
        throw new Error('Invalid database dump schema structure.');
      }
      this.commit(parsed, 'RESTORE_DATABASE', 'SystemDatabase', 'Imported database dump from JSON file');
      return true;
    } catch (err) {
      console.error('[SystemDatabase] Failed to import DB dump:', err);
      return false;
    }
  }

  public resetToFactoryDefaults() {
    this.commit(INITIAL_DB_STATE, 'RESET_DATABASE', 'SystemDatabase', 'Factory default state restored');
  }

  // --- SQL QUERY EXECUTION UTILITY ---
  public executeQuery(query: string): { success: boolean; data?: any[]; message: string; rowsAffected?: number } {
    const q = query.trim();
    const lower = q.toLowerCase();

    try {
      if (lower.startsWith('select')) {
        if (lower.includes('from system_settings') || lower.includes('from settings')) {
          return { success: true, data: [this.state.settings.general], message: 'Selected 1 record from system_settings' };
        }
        if (lower.includes('from hosting_packages') || lower.includes('from packages')) {
          return { success: true, data: this.state.hostingPackages, message: `Selected ${this.state.hostingPackages.length} records from hosting_packages` };
        }
        if (lower.includes('from control_panel_gateways') || lower.includes('from gateways')) {
          return { success: true, data: this.state.controlPanelGateways, message: `Selected ${this.state.controlPanelGateways.length} records from control_panel_gateways` };
        }
        if (lower.includes('from server_cluster_nodes') || lower.includes('from nodes')) {
          return { success: true, data: this.state.serverClusterNodes, message: `Selected ${this.state.serverClusterNodes.length} records from server_cluster_nodes` };
        }
        if (lower.includes('from provisioned_accounts') || lower.includes('from accounts')) {
          return { success: true, data: this.state.provisionedAccounts, message: `Selected ${this.state.provisionedAccounts.length} records from provisioned_accounts` };
        }
        if (lower.includes('from users') || lower.includes('from user')) {
          return { success: true, data: this.state.users, message: `Selected ${this.state.users.length} records from users` };
        }
        if (lower.includes('from persistent_cart') || lower.includes('from cart')) {
          return { success: true, data: this.state.persistentCart, message: `Selected ${this.state.persistentCart.length} records from persistent_cart` };
        }
        if (lower.includes('from audit_logs') || lower.includes('from logs')) {
          return { success: true, data: this.state.auditLogs, message: `Selected ${this.state.auditLogs.length} records from audit_logs` };
        }
        return { success: true, data: [{ database: 'CELOXA_SYSTEM_DB', tables: ['system_settings', 'users', 'persistent_cart', 'hosting_packages', 'control_panel_gateways', 'server_cluster_nodes', 'provisioned_accounts', 'audit_logs'] }], message: 'Tables listing query executed' };
      }

      if (lower.startsWith('show tables')) {
        return {
          success: true,
          data: [
            { table_name: 'system_settings', records: 1 },
            { table_name: 'users', records: this.state.users.length },
            { table_name: 'persistent_cart', records: this.state.persistentCart.length },
            { table_name: 'hosting_packages', records: this.state.hostingPackages.length },
            { table_name: 'control_panel_gateways', records: this.state.controlPanelGateways.length },
            { table_name: 'server_cluster_nodes', records: this.state.serverClusterNodes.length },
            { table_name: 'provisioned_accounts', records: this.state.provisionedAccounts.length },
            { table_name: 'audit_logs', records: this.state.auditLogs.length },
          ],
          message: 'Retrieved 8 database tables'
        };
      }

      if (lower.startsWith('update system_settings')) {
        // e.g. UPDATE system_settings SET site_title = 'My Title'
        const match = q.match(/site_name\s*=\s*['"]([^'"]+)['"]/i) || q.match(/site_title\s*=\s*['"]([^'"]+)['"]/i);
        if (match && match[1]) {
          const newName = match[1];
          const newSettings = {
            ...this.state.settings,
            general: {
              ...this.state.settings.general,
              siteName: newName,
            },
          };
          this.updateSettings(newSettings);
          return { success: true, message: `UPDATE 1 row in system_settings. siteName set to "${newName}"`, rowsAffected: 1 };
        }
      }

      return { success: true, message: `Query executed successfully. Database state verified.`, data: [] };
    } catch (err: any) {
      return { success: false, message: `SQL Syntax or Execution Error: ${err?.message || 'Failed'}` };
    }
  }
}

export const systemDatabase = new SystemDatabaseEngine();
