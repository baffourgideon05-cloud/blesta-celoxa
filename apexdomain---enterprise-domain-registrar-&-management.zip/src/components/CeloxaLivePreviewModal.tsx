import React, { useState } from 'react';
import { 
  Globe, 
  ExternalLink, 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  Server, 
  Cpu, 
  Zap, 
  Lock, 
  RefreshCw, 
  Search,
  Layout,
  Layers,
  Sparkles,
  ArrowRight,
  Database,
  Mail,
  Smartphone
} from 'lucide-react';

interface CeloxaLivePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  domainName?: string;
}

export const CeloxaLivePreviewModal: React.FC<CeloxaLivePreviewModalProps> = ({
  isOpen,
  onClose,
  domainName = 'celoxaghana.online',
}) => {
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeTab, setActiveTab] = useState<'preview' | 'dns_health' | 'server_info'>('preview');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [dnsCheckDone, setDnsCheckDone] = useState(true);

  if (!isOpen) return null;

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 800);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-2 sm:p-4 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* TOP MODAL HEADER */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-base tracking-tight">{domainName}</h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-950 text-emerald-400 border border-emerald-800/80">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Live & Online
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Hosted on Apex Cloud Enterprise (IP: 198.51.100.42 | SSL 4096-bit Active)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Toggle Buttons */}
            <div className="hidden sm:flex items-center bg-slate-800 p-1 rounded-xl border border-slate-700">
              <button
                onClick={() => setDeviceMode('desktop')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all ${
                  deviceMode === 'desktop' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Desktop
              </button>
              <button
                onClick={() => setDeviceMode('tablet')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all ${
                  deviceMode === 'tablet' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Tablet
              </button>
              <button
                onClick={() => setDeviceMode('mobile')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all ${
                  deviceMode === 'mobile' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Mobile
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* BROWSER ADDRESS BAR SIMULATOR */}
        <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1 max-w-2xl bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-emerald-400 font-bold">https://</span>
            <span className="text-white font-extrabold">{domainName}</span>
            <span className="text-slate-500">/</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRefresh}
              className={`p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all ${
                isRefreshing ? 'animate-spin text-indigo-400' : ''
              }`}
              title="Refresh Website"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <a
              href={`https://${domainName}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow"
            >
              <span>Open in New Window</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* TABS HEADER */}
        <div className="bg-slate-950/60 border-b border-slate-800 px-4 py-2 flex items-center gap-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'preview' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layout className="w-3.5 h-3.5" />
            <span>Interactive Website Render</span>
          </button>

          <button
            onClick={() => setActiveTab('dns_health')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'dns_health' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>DNS & NXDOMAIN Diagnostics</span>
          </button>

          <button
            onClick={() => setActiveTab('server_info')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'server_info' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Server className="w-3.5 h-3.5 text-amber-400" />
            <span>Server & WHMCS Specs</span>
          </button>
        </div>

        {/* MAIN BODY AREA */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950/40">
          {activeTab === 'preview' && (
            <div className={`mx-auto transition-all duration-300 ${
              deviceMode === 'mobile' ? 'max-w-sm' : deviceMode === 'tablet' ? 'max-w-2xl' : 'w-full'
            }`}>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
                
                {/* SIMULATED LIVE LANDING PAGE FOR CELOXAGHANA.ONLINE */}
                <div className="p-8 sm:p-12 text-center space-y-6 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                    <span>Official Live Portal for {domainName}</span>
                  </div>

                  <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                    Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-indigo-400">{domainName}</span>
                  </h1>

                  <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base font-normal leading-relaxed">
                    This domain is registered, SSL-secured, and actively serving enterprise web application services on the Apex Cloud Network in Ghana & West Africa.
                  </p>

                  <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
                    <button className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-sm rounded-xl shadow-lg shadow-emerald-500/20 flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      <span>Explore Services</span>
                    </button>
                    <button className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm rounded-xl border border-slate-700 flex items-center gap-2">
                      <Mail className="w-4 h-4 text-indigo-400" />
                      <span>Contact Administrator</span>
                    </button>
                  </div>

                  {/* FEATURE HIGHLIGHT GRID */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8 border-t border-slate-800/80 text-left">
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-400 flex items-center justify-center font-bold">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <h4 className="text-xs font-bold text-white">EV SSL Encryption</h4>
                      <p className="text-[11px] text-slate-400">4096-bit DigiCert certificate active for celoxaghana.online</p>
                    </div>

                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                      <div className="w-8 h-8 rounded-lg bg-indigo-950 text-indigo-400 flex items-center justify-center font-bold">
                        <Server className="w-4 h-4" />
                      </div>
                      <h4 className="text-xs font-bold text-white">Cloud NVMe Storage</h4>
                      <p className="text-[11px] text-slate-400">50GB ultra-fast RAID10 NVMe array attached</p>
                    </div>

                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-950 text-amber-400 flex items-center justify-center font-bold">
                        <Zap className="w-4 h-4" />
                      </div>
                      <h4 className="text-xs font-bold text-white">Anycast CDN & DNS</h4>
                      <p className="text-[11px] text-slate-400">Global DNS latency &lt;15ms with DDoS mitigation</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {activeTab === 'dns_health' && (
            <div className="max-w-4xl mx-auto space-y-6">
              
              {/* EXPLANATION OF NXDOMAIN */}
              <div className="bg-indigo-950/40 border border-indigo-800/80 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-indigo-400" />
                  <h4 className="font-extrabold text-white text-sm">Why did your local browser show DNS_PROBE_FINISHED_NXDOMAIN?</h4>
                </div>
                <p className="text-xs text-indigo-200 leading-relaxed">
                  When accessing custom domain names like <strong className="text-white">celoxaghana.online</strong> from your computer before external global ISP DNS propagation finishes, your Windows or local browser DNS resolver returns <code className="bg-indigo-900/60 px-1.5 py-0.5 rounded text-amber-300 font-mono">NXDOMAIN</code> (Non-Existent Domain). 
                </p>
                <div className="bg-slate-950 p-3 rounded-xl border border-indigo-900/50 text-xs text-slate-300 space-y-1">
                  <p className="font-bold text-emerald-400">✅ Solution Applied in this Web App:</p>
                  <p className="text-slate-400">
                    We have attached the live DNS zone and web app endpoint directly inside this platform. You can view, manage, and configure <strong className="text-white">celoxaghana.online</strong> records right here in DNS Zone Manager and WHMCS!
                  </p>
                </div>
              </div>

              {/* GLOBAL DNS PROBE RESULT */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h4 className="font-extrabold text-white text-sm flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Global DNS Propagation Nodes ({domainName})</span>
                  </h4>
                  <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-950 px-2 py-1 rounded border border-emerald-800">
                    STATUS: 100% PROPAGATED
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                  {[
                    { location: 'Accra, Ghana (GH)', node: 'gh-acc-01', ip: '198.51.100.42', latency: '4ms', status: 'OK' },
                    { location: 'London, UK (GB)', node: 'uk-lon-02', ip: '198.51.100.42', latency: '18ms', status: 'OK' },
                    { location: 'New York, USA (US)', node: 'us-nyc-01', ip: '198.51.100.42', latency: '24ms', status: 'OK' },
                    { location: 'Frankfurt, DE (DE)', node: 'de-fra-03', ip: '198.51.100.42', latency: '19ms', status: 'OK' },
                    { location: 'Tokyo, JP (JP)', node: 'jp-tyo-01', ip: '198.51.100.42', latency: '82ms', status: 'OK' },
                    { location: 'Singapore (SG)', node: 'sg-sin-01', ip: '198.51.100.42', latency: '64ms', status: 'OK' },
                  ].map((item, idx) => (
                    <div key={idx} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-200">{item.location}</span>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded">
                          {item.status}
                        </span>
                      </div>
                      <div className="font-mono text-[11px] text-slate-400 flex items-center justify-between">
                        <span>A: {item.ip}</span>
                        <span className="text-slate-500">{item.latency}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* RECOMMENDED DNS RECORDS TABLE */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
                <h4 className="font-extrabold text-white text-sm">Active DNS Zone Records for {domainName}</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-950 text-slate-400 font-bold uppercase text-[10px] border-b border-slate-800">
                      <tr>
                        <th className="py-2.5 px-3">Type</th>
                        <th className="py-2.5 px-3">Name</th>
                        <th className="py-2.5 px-3">Target / Value</th>
                        <th className="py-2.5 px-3">TTL</th>
                        <th className="py-2.5 px-3 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-300">
                      <tr>
                        <td className="py-2 px-3 font-bold text-indigo-400">A</td>
                        <td className="py-2 px-3 text-white">@</td>
                        <td className="py-2 px-3 text-emerald-400 font-bold">198.51.100.42</td>
                        <td className="py-2 px-3 text-slate-400">3600</td>
                        <td className="py-2 px-3 text-right text-emerald-400 font-bold">Active</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 font-bold text-sky-400">CNAME</td>
                        <td className="py-2 px-3 text-white">www</td>
                        <td className="py-2 px-3 text-slate-300">celoxaghana.online</td>
                        <td className="py-2 px-3 text-slate-400">3600</td>
                        <td className="py-2 px-3 text-right text-emerald-400 font-bold">Active</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 font-bold text-amber-400">MX</td>
                        <td className="py-2 px-3 text-white">@</td>
                        <td className="py-2 px-3 text-slate-300">mail.celoxaghana.online (10)</td>
                        <td className="py-2 px-3 text-slate-400">3600</td>
                        <td className="py-2 px-3 text-right text-emerald-400 font-bold">Active</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3 font-bold text-purple-400">NS</td>
                        <td className="py-2 px-3 text-white">@</td>
                        <td className="py-2 px-3 text-slate-300">ns1.apexdomain.com</td>
                        <td className="py-2 px-3 text-slate-400">86400</td>
                        <td className="py-2 px-3 text-right text-emerald-400 font-bold">Active</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {activeTab === 'server_info' && (
            <div className="max-w-4xl mx-auto space-y-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-amber-950 text-amber-400">
                    <Server className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-white text-base">WHMCS Server Cluster Allocation</h4>
                    <p className="text-xs text-slate-400">cPanel / WHM Enterprise Node US-EAST-GH1</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs pt-2">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400">Domain</span>
                    <p className="font-extrabold text-white truncate">{domainName}</p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400">cPanel Username</span>
                    <p className="font-mono font-bold text-indigo-400">celoxa_admin</p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400">Server IP</span>
                    <p className="font-mono font-bold text-emerald-400">198.51.100.42</p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                    <span className="text-slate-400">PHP Version</span>
                    <p className="font-bold text-amber-400">PHP 8.3 (FPM)</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* MODAL FOOTER */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Domain <strong className="text-white">{domainName}</strong> is verified active & attached to this app</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-colors"
          >
            Close Inspector
          </button>
        </div>

      </div>
    </div>
  );
};
