import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Lock,
  Users,
  History,
  Key,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  LogOut,
  Smartphone,
  Globe,
  Eye,
  EyeOff,
  Check,
  Zap,
  Server
} from 'lucide-react';
import { systemDatabase, SystemUser } from '../services/systemDatabase';
import { UserSession, LoginActivityRecord } from '../types';

export interface PasswordValidationResult {
  isValid: boolean;
  score: number;
  feedback: {
    minLength: boolean;
    hasUppercase: boolean;
    hasLowercase: boolean;
    hasNumber: boolean;
    hasSpecial: boolean;
  };
  errors: string[];
}

export function validatePasswordPolicy(password: string): PasswordValidationResult {
  const minLength = password.length >= 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);

  const errors: string[] = [];
  if (!minLength) errors.push('At least 8 characters in length');
  if (!hasUppercase) errors.push('At least one uppercase letter (A-Z)');
  if (!hasLowercase) errors.push('At least one lowercase letter (a-z)');
  if (!hasNumber) errors.push('At least one number (0-9)');
  if (!hasSpecial) errors.push('At least one special character (!@#$%^&*)');

  let score = 0;
  if (minLength) score += 20;
  if (hasUppercase) score += 20;
  if (hasLowercase) score += 20;
  if (hasNumber) score += 20;
  if (hasSpecial) score += 20;

  return {
    isValid: errors.length === 0,
    score,
    feedback: { minLength, hasUppercase, hasLowercase, hasNumber, hasSpecial },
    errors
  };
}

interface SecurityCenterProps {
  user?: SystemUser | null;
  onSecurityUpdate?: () => void;
}

export const SecurityCenter: React.FC<SecurityCenterProps> = ({ user: initialUser, onSecurityUpdate }) => {
  const [currentUser, setCurrentUser] = useState<SystemUser | null>(initialUser || systemDatabase.getCurrentUser());
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [loginHistory, setLoginHistory] = useState<LoginActivityRecord[]>([]);

  // Password Form State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [passChangeSuccess, setPassChangeSuccess] = useState<string | null>(null);
  const [passChangeError, setPassChangeError] = useState<string | null>(null);
  const [isSubmittingPass, setIsSubmittingPass] = useState(false);

  // MFA state
  const [mfaLoading, setMfaLoading] = useState(false);

  // Load state
  useEffect(() => {
    refreshData();
  }, [initialUser]);

  const refreshData = () => {
    const user = systemDatabase.getCurrentUser() || initialUser || null;
    setCurrentUser(user);
    if (user) {
      setSessions(systemDatabase.getUserSessions(user.id));
      setLoginHistory(systemDatabase.getLoginActivityRecords(user.id));
    }
  };

  const passValidation = validatePasswordPolicy(newPassword);

  // Toggle MFA Status
  const handleToggleMfa = async () => {
    if (!currentUser) return;
    setMfaLoading(true);

    try {
      const nextState = !currentUser.twoFactorEnabled;
      const secret = nextState ? 'JBSWY3DPEHPK3PXP' : undefined;
      const backupCodes = nextState ? ['8942-1029', '3910-8271', '4019-2819', '5910-3819'] : undefined;

      systemDatabase.updateUserMfa(currentUser.id, nextState, secret, backupCodes);
      refreshData();
      if (onSecurityUpdate) onSecurityUpdate();
    } catch (err: any) {
      console.error('MFA update error:', err);
    } finally {
      setMfaLoading(false);
    }
  };

  // Log Out All Other Sessions
  const handleRevokeAllOtherSessions = () => {
    if (!currentUser) return;
    if (confirm('Are you sure you want to log out all other active web sessions across all devices?')) {
      systemDatabase.revokeAllOtherSessions(currentUser.id);
      refreshData();
      if (onSecurityUpdate) onSecurityUpdate();
    }
  };

  // Revoke Specific Session
  const handleRevokeSession = (sessionId: string) => {
    systemDatabase.revokeSession(sessionId);
    refreshData();
    if (onSecurityUpdate) onSecurityUpdate();
  };

  // Change Password Submission
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPassChangeSuccess(null);
    setPassChangeError(null);

    if (!currentUser) {
      setPassChangeError('User account session not found.');
      return;
    }

    if (!currentPassword) {
      setPassChangeError('Please enter your current password.');
      return;
    }

    if (!passValidation.isValid) {
      setPassChangeError('New password does not meet the policy criteria.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPassChangeError('New password and confirmation password do not match.');
      return;
    }

    setIsSubmittingPass(true);

    setTimeout(() => {
      systemDatabase.updateUserProfile(currentUser.id, { password: newPassword });
      setPassChangeSuccess('Your password has been successfully updated! Secure hash re-encrypted.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setIsSubmittingPass(false);
      refreshData();
      if (onSecurityUpdate) onSecurityUpdate();
    }, 600);
  };

  const getScoreColor = (score: number) => {
    if (score <= 40) return 'bg-rose-500';
    if (score <= 80) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const getScoreLabel = (score: number) => {
    if (score <= 40) return 'Weak';
    if (score <= 80) return 'Medium';
    return 'Strong';
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] font-black uppercase tracking-wider rounded-full flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
              IAM Security Operations Center
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Security & Session Control Center</h1>
          <p className="text-xs text-slate-400 mt-1">
            Manage Multi-Factor Authentication (MFA), active sessions, login history, and account password policy compliance.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={refreshData}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl border border-slate-700 flex items-center gap-2 transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh State</span>
          </button>
        </div>
      </div>

      {/* Grid Row 1: MFA Status & Active Web Sessions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Module 1: MFA Status & Toggle */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">Multi-Factor Authentication (MFA)</h3>
                  <p className="text-[11px] text-slate-400">Time-based One-Time Password (TOTP)</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5 ${
                currentUser?.twoFactorEnabled 
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                {currentUser?.twoFactorEnabled ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Active
                  </>
                ) : (
                  <>
                    <XCircle className="w-3.5 h-3.5 text-slate-400" /> Disabled
                  </>
                )}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Enforce an extra layer of protection during login using an authenticator app like Google Authenticator or Authy.
            </p>

            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-200 font-bold">MFA Status Switch</span>
                <button
                  type="button"
                  onClick={handleToggleMfa}
                  disabled={mfaLoading}
                  className={`px-4 py-2 rounded-xl font-black text-xs transition-all flex items-center gap-2 ${
                    currentUser?.twoFactorEnabled
                      ? 'bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20'
                  }`}
                >
                  {mfaLoading ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : currentUser?.twoFactorEnabled ? (
                    'Disable MFA'
                  ) : (
                    'Enable MFA Protection'
                  )}
                </button>
              </div>

              {currentUser?.twoFactorEnabled && (
                <div className="pt-3 border-t border-slate-800 space-y-3 text-xs">
                  <div className="flex items-center justify-between text-slate-400 text-[11px]">
                    <span>TOTP Secret Key:</span>
                    <span className="font-mono text-cyan-400 font-bold">{currentUser.mfaSecret || 'JBSWY3DPEHPK3PXP'}</span>
                  </div>
                  <div>
                    <p className="text-[11px] text-slate-400 font-bold mb-1.5">Emergency Single-Use Backup Codes:</p>
                    <div className="grid grid-cols-2 gap-2 font-mono text-[11px] text-emerald-400 font-bold bg-slate-900 p-3 rounded-xl border border-slate-800">
                      {(currentUser.mfaBackupCodes || ['8942-1029', '3910-8271', '4019-2819', '5910-3819']).map((code, idx) => (
                        <span key={idx} className="flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-500" /> {code}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span>Compliant with ISO 27001 & NIST 800-63B Authentication standards.</span>
          </div>
        </div>

        {/* Module 2: Active Sessions & Log Out Others */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">Active Web Sessions ({sessions.length})</h3>
                  <p className="text-[11px] text-slate-400">Authenticated HTTP-Only cookie sessions</p>
                </div>
              </div>

              {sessions.length > 1 && (
                <button
                  type="button"
                  onClick={handleRevokeAllOtherSessions}
                  className="px-3 py-1.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-all"
                >
                  <LogOut className="w-3.5 h-3.5" /> Log Out All Other Sessions
                </button>
              )}
            </div>

            <p className="text-xs text-slate-300">
              List of active web browser sessions currently authorized to access your client account.
            </p>

            <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
              {sessions.map((sess) => (
                <div
                  key={sess.id}
                  className={`p-3.5 rounded-2xl border text-xs flex items-center justify-between gap-3 ${
                    sess.isCurrent
                      ? 'bg-slate-950 border-indigo-500/40 shadow-sm'
                      : 'bg-slate-950/60 border-slate-800'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <div className="p-2 rounded-xl bg-slate-900 text-slate-300 mt-0.5">
                      <Smartphone className="w-4 h-4" />
                    </div>
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-white">{sess.device}</span>
                        {sess.isCurrent && (
                          <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold text-[9px] rounded-md">
                            Current Session
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {sess.ip} • {sess.location}
                      </p>
                      <p className="text-[10px] text-slate-500">Last active: {sess.lastActiveAt}</p>
                    </div>
                  </div>

                  {!sess.isCurrent && (
                    <button
                      type="button"
                      onClick={() => handleRevokeSession(sess.id)}
                      className="px-2.5 py-1 text-[11px] font-bold text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 rounded-lg border border-rose-500/20 transition-all shrink-0"
                    >
                      Revoke
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Sessions automatically expire after 7 days of inactivity.</span>
            {sessions.length === 1 && (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Single active session
              </span>
            )}
          </div>
        </div>

      </div>

      {/* Grid Row 2: Central Password Policy Change Form & Login Activity Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Change Password Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-white">Change Account Password</h3>
              <p className="text-[11px] text-slate-400">Validated against Central Password Policy</p>
            </div>
          </div>

          {passChangeSuccess && (
            <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-xs text-emerald-300 font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{passChangeSuccess}</span>
            </div>
          )}

          {passChangeError && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-xs text-rose-300 font-bold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{passChangeError}</span>
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-4 text-xs">
            {/* Current Password */}
            <div className="space-y-1">
              <label className="font-bold text-slate-300 block">Current Password</label>
              <div className="relative">
                <input
                  type={showCurrentPass ? 'text' : 'password'}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full p-3 pr-10 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPass(!showCurrentPass)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
                >
                  {showCurrentPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* New Password */}
            <div className="space-y-1">
              <label className="font-bold text-slate-300 block">New Password</label>
              <div className="relative">
                <input
                  type={showNewPass ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new strong password"
                  className="w-full p-3 pr-10 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPass(!showNewPass)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
                >
                  {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Password Policy Strength Indicator */}
            {newPassword.length > 0 && (
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-[11px] font-bold">
                  <span className="text-slate-400">Policy Strength:</span>
                  <span className={passValidation.score >= 80 ? 'text-emerald-400' : 'text-amber-400'}>
                    {getScoreLabel(passValidation.score)} ({passValidation.score}%)
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${getScoreColor(passValidation.score)}`}
                    style={{ width: `${passValidation.score}%` }}
                  />
                </div>

                {/* Requirements checklist */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1 text-[11px]">
                  <div className={`flex items-center gap-1.5 ${passValidation.feedback.minLength ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                    {passValidation.feedback.minLength ? <Check className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    <span>At least 8 characters</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${passValidation.feedback.hasUppercase ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                    {passValidation.feedback.hasUppercase ? <Check className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    <span>Uppercase letter (A-Z)</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${passValidation.feedback.hasLowercase ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                    {passValidation.feedback.hasLowercase ? <Check className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    <span>Lowercase letter (a-z)</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${passValidation.feedback.hasNumber ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                    {passValidation.feedback.hasNumber ? <Check className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    <span>Number (0-9)</span>
                  </div>
                  <div className={`flex items-center gap-1.5 sm:col-span-2 ${passValidation.feedback.hasSpecial ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
                    {passValidation.feedback.hasSpecial ? <Check className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    <span>Special character (!@#$%^&*)</span>
                  </div>
                </div>
              </div>
            )}

            {/* Confirm Password */}
            <div className="space-y-1">
              <label className="font-bold text-slate-300 block">Confirm New Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmittingPass || !passValidation.isValid}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-extrabold rounded-xl shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
            >
              {isSubmittingPass ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Updating Password...</span>
                </>
              ) : (
                <>
                  <Key className="w-4 h-4" />
                  <span>Update Account Password</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Login History Stream */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <History className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-white">Login History & Audit Log</h3>
                <p className="text-[11px] text-slate-400">Historical authentication attempts</p>
              </div>
            </div>

            <p className="text-xs text-slate-300">
              Audit trail of recent successful and failed sign-in attempts for account surveillance.
            </p>

            <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
              {loginHistory.map((rec) => (
                <div
                  key={rec.id}
                  className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs flex items-center justify-between gap-3"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white">{rec.device}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                          rec.status === 'success'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {rec.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-mono">
                      {rec.ip} • {rec.location}
                    </p>
                    <p className="text-[10px] text-slate-500">{rec.timestamp}</p>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-500 font-mono">ID: {rec.id.slice(0, 8)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span>IP address geolocation and fraud check enabled automatically.</span>
          </div>
        </div>

      </div>
    </div>
  );
};
