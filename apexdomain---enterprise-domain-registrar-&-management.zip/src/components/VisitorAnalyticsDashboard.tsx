import React, { useState } from 'react';
import {
  TrendingUp,
  Search,
  CheckCircle2,
  Users,
  DollarSign,
  Calendar,
  Filter,
  Download,
  RefreshCw,
  Zap,
  Globe,
  ArrowUpRight,
  ArrowDownRight,
  BarChart2,
  PieChart as PieIcon,
  Activity,
  Layers,
  Sparkles,
  MousePointerClick,
  ShoppingBag,
  Target,
  Clock,
  ShieldCheck
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  BarChart
} from 'recharts';
import { Currency } from '../types';

interface VisitorAnalyticsDashboardProps {
  currency?: Currency;
  onNavigate?: (view: string) => void;
}

// Mock Analytics Data for Monthly Domain Searches & Conversion Rates
const MONTHLY_TRENDS_DATA = [
  { month: 'Jan', searches: 8400, uniqueVisitors: 6200, registrations: 1260, conversionRate: 15.0, revenueGhs: 126000, revenueUsd: 8820 },
  { month: 'Feb', searches: 9200, uniqueVisitors: 6800, registrations: 1480, conversionRate: 16.1, revenueGhs: 148000, revenueUsd: 10360 },
  { month: 'Mar', searches: 11500, uniqueVisitors: 8400, registrations: 1955, conversionRate: 17.0, revenueGhs: 195500, revenueUsd: 13685 },
  { month: 'Apr', searches: 10800, uniqueVisitors: 7900, registrations: 1890, conversionRate: 17.5, revenueGhs: 189000, revenueUsd: 13230 },
  { month: 'May', searches: 13400, uniqueVisitors: 9800, registrations: 2480, conversionRate: 18.5, revenueGhs: 248000, revenueUsd: 17360 },
  { month: 'Jun', searches: 15200, uniqueVisitors: 11200, registrations: 2888, conversionRate: 19.0, revenueGhs: 288800, revenueUsd: 20216 },
  { month: 'Jul', searches: 14600, uniqueVisitors: 10800, registrations: 2701, conversionRate: 18.5, revenueGhs: 270100, revenueUsd: 18907 },
  { month: 'Aug', searches: 17800, uniqueVisitors: 13100, registrations: 3471, conversionRate: 19.5, revenueGhs: 347100, revenueUsd: 24297 },
  { month: 'Sep', searches: 16900, uniqueVisitors: 12400, registrations: 3261, conversionRate: 19.3, revenueGhs: 326100, revenueUsd: 22827 },
  { month: 'Oct', searches: 19500, uniqueVisitors: 14200, registrations: 3939, conversionRate: 20.2, revenueGhs: 393900, revenueUsd: 27573 },
  { month: 'Nov', searches: 22100, uniqueVisitors: 16500, registrations: 4685, conversionRate: 21.2, revenueGhs: 468500, revenueUsd: 32795 },
  { month: 'Dec', searches: 24800, uniqueVisitors: 18900, registrations: 5456, conversionRate: 22.0, revenueGhs: 545600, revenueUsd: 38192 },
];

const TLD_CONVERSION_DATA = [
  { tld: '.com', searches: 52400, registrations: 11528, conversionRate: 22.0, color: '#3b82f6' },
  { tld: '.ai', searches: 38100, registrations: 9144, conversionRate: 24.0, color: '#8b5cf6' },
  { tld: '.gh', searches: 29400, registrations: 6174, conversionRate: 21.0, color: '#10b981' },
  { tld: '.io', searches: 24100, registrations: 4579, conversionRate: 19.0, color: '#f59e0b' },
  { tld: '.org', searches: 18200, registrations: 3094, conversionRate: 17.0, color: '#ec4899' },
  { tld: '.net', searches: 12100, registrations: 1815, conversionRate: 15.0, color: '#06b6d4' },
];

const TRAFFIC_SOURCE_DATA = [
  { name: 'Organic Search', value: 42, color: '#3b82f6' },
  { name: 'Direct Visits', value: 28, color: '#10b981' },
  { name: 'Referrals & Affiliates', value: 18, color: '#8b5cf6' },
  { name: 'Social / Campaigns', value: 12, color: '#f59e0b' },
];

const DEVICE_BREAKDOWN_DATA = [
  { name: 'Desktop (Chrome/Firefox/Safari)', percentage: 64, color: '#3b82f6' },
  { name: 'Mobile (iOS/Android)', percentage: 31, color: '#10b981' },
  { name: 'Tablet & API Integrations', percentage: 5, color: '#f59e0b' },
];

export const VisitorAnalyticsDashboard: React.FC<VisitorAnalyticsDashboardProps> = ({
  currency = 'USD',
  onNavigate
}) => {
  const [timeRange, setTimeRange] = useState<'12m' | '6m' | '30d'>('12m');
  const [selectedTldFilter, setSelectedTldFilter] = useState<string>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeChartTab, setActiveChartTab] = useState<'overview' | 'conversion' | 'tld_breakdown'>('overview');

  const filteredTrends = React.useMemo(() => {
    if (timeRange === '30d') return MONTHLY_TRENDS_DATA.slice(-2);
    if (timeRange === '6m') return MONTHLY_TRENDS_DATA.slice(-6);
    return MONTHLY_TRENDS_DATA;
  }, [timeRange]);

  const totals = React.useMemo(() => {
    const totalSearches = filteredTrends.reduce((acc, curr) => acc + curr.searches, 0);
    const totalRegistrations = filteredTrends.reduce((acc, curr) => acc + curr.registrations, 0);
    const avgConversion = (totalRegistrations / totalSearches) * 100;
    const totalRevenueGhs = filteredTrends.reduce((acc, curr) => acc + curr.revenueGhs, 0);
    const totalRevenueUsd = filteredTrends.reduce((acc, curr) => acc + curr.revenueUsd, 0);

    return {
      searches: totalSearches,
      registrations: totalRegistrations,
      avgConversion: avgConversion.toFixed(1),
      revenueGhs: totalRevenueGhs,
      revenueUsd: totalRevenueUsd
    };
  }, [filteredTrends]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 800);
  };

  const handleExportCSV = () => {
    const headers = ['Month', 'Searches', 'Unique Visitors', 'Registrations', 'Conversion Rate %', 'Revenue (GHS)', 'Revenue (USD)'];
    const rows = filteredTrends.map(item => [
      item.month,
      item.searches,
      item.uniqueVisitors,
      item.registrations,
      `${item.conversionRate}%`,
      item.revenueGhs,
      item.revenueUsd
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `domain_visitor_analytics_${timeRange}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 border border-indigo-400/30 rounded-full text-indigo-300 text-xs font-semibold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Admin Real-Time Intelligence</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
              Visitor Analytics & Conversion Dashboard
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl">
              Track real-time domain search traffic, monthly registration trends, conversion funnel performance, and top-performing TLD metrics.
            </p>
          </div>

          {/* Action Controls */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center bg-slate-800/80 p-1 rounded-2xl border border-slate-700">
              <button
                onClick={() => setTimeRange('30d')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  timeRange === '30d' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                30 Days
              </button>
              <button
                onClick={() => setTimeRange('6m')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  timeRange === '6m' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                6 Months
              </button>
              <button
                onClick={() => setTimeRange('12m')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  timeRange === '12m' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                12 Months
              </button>
            </div>

            <button
              onClick={handleRefresh}
              className={`p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-2xl transition-all ${
                isRefreshing ? 'animate-spin text-indigo-400' : ''
              }`}
              title="Refresh Analytics Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={handleExportCSV}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-2xl shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Domain Searches */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Total Domain Searches
            </span>
            <div className="p-3 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 rounded-2xl">
              <Search className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {totals.searches.toLocaleString()}
            </span>
            <span className="inline-flex items-center text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
              +18.4%
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Queries executed across search engine & AI brain
          </p>
        </div>

        {/* Total Conversions / Registrations */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Domain Registrations
            </span>
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 rounded-2xl">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {totals.registrations.toLocaleString()}
            </span>
            <span className="inline-flex items-center text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
              +22.1%
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Successful domain purchases & checkouts
          </p>
        </div>

        {/* Average Conversion Rate */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Avg Conversion Rate
            </span>
            <div className="p-3 bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 rounded-2xl">
              <Target className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {totals.avgConversion}%
            </span>
            <span className="inline-flex items-center text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
              +2.8% pts
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Search to completed checkout conversion
          </p>
        </div>

        {/* Estimated Revenue Generated */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Registration Revenue
            </span>
            <div className="p-3 bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 rounded-2xl">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {currency === 'GHS' ? `GH₵${totals.revenueGhs.toLocaleString()}` : `$${totals.revenueUsd.toLocaleString()}`}
            </span>
            <span className="inline-flex items-center text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
              +25.4%
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Direct sales from domain registrations
          </p>
        </div>
      </div>

      {/* Main Chart Section: Monthly Trends and Conversion Rates */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <span>Monthly Domain Search Trends vs Conversion Rate</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Visualizing search volume growth (bars/area) overlaid with registration conversion percentage (line).
            </p>
          </div>

          {/* Chart View Switcher */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setActiveChartTab('overview')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeChartTab === 'overview'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Search & Registrations
            </button>
            <button
              onClick={() => setActiveChartTab('conversion')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeChartTab === 'conversion'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Conversion Rate %
            </button>
            <button
              onClick={() => setActiveChartTab('tld_breakdown')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeChartTab === 'tld_breakdown'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Top TLD Breakdown
            </button>
          </div>
        </div>

        {/* Recharts Main Graph Container */}
        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            {activeChartTab === 'overview' ? (
              <ComposedChart data={filteredTrends} margin={{ top: 10, right: 20, bottom: 20, left: 0 }}>
                <defs>
                  <linearGradient id="searchGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} tickLine={false} />
                <YAxis yAxisId="left" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis yAxisId="right" orientation="right" stroke="#10b981" fontSize={12} tickLine={false} axisLine={false} unit="%" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '16px',
                    color: '#fff',
                    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)'
                  }}
                  formatter={(value: any, name: string) => {
                    if (name === 'conversionRate') return [`${value}%`, 'Conversion Rate'];
                    if (name === 'searches') return [value.toLocaleString(), 'Domain Searches'];
                    if (name === 'registrations') return [value.toLocaleString(), 'Registrations'];
                    return [value, name];
                  }}
                />
                <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '12px' }} />
                <Area yAxisId="left" type="monotone" dataKey="searches" name="searches" fill="url(#searchGradient)" stroke="#6366f1" strokeWidth={2} />
                <Bar yAxisId="left" dataKey="registrations" name="registrations" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={24} />
                <Line yAxisId="right" type="monotone" dataKey="conversionRate" name="conversionRate" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981' }} activeDot={{ r: 6 }} />
              </ComposedChart>
            ) : activeChartTab === 'conversion' ? (
              <ComposedChart data={filteredTrends} margin={{ top: 10, right: 20, bottom: 20, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} tickLine={false} />
                <YAxis stroke="#10b981" fontSize={12} tickLine={false} axisLine={false} unit="%" domain={[10, 25]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '16px',
                    color: '#fff'
                  }}
                  formatter={(value: any) => [`${value}%`, 'Conversion Rate']}
                />
                <Bar dataKey="conversionRate" name="Conversion Rate (%)" fill="#10b981" radius={[8, 8, 0, 0]} barSize={32} />
                <Line type="monotone" dataKey="conversionRate" stroke="#f59e0b" strokeWidth={3} dot={{ r: 5, fill: '#f59e0b' }} />
              </ComposedChart>
            ) : (
              <BarChart data={TLD_CONVERSION_DATA} margin={{ top: 10, right: 20, bottom: 20, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="tld" stroke="#94a3b8" fontSize={12} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '16px',
                    color: '#fff'
                  }}
                />
                <Legend verticalAlign="top" height={36} />
                <Bar dataKey="searches" name="Searches" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                <Bar dataKey="registrations" name="Registrations" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Secondary Graphs: Traffic Sources & TLD Conversion Rates */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* TLD Conversion Performance */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-500" />
                <span>TLD Search to Registration Conversion</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Conversion rates across popular domain extensions
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {TLD_CONVERSION_DATA.map((item) => (
              <div key={item.tld} className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 w-32 shrink-0">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">
                    {item.tld}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="flex-1 hidden sm:block">
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
                    <span>{item.searches.toLocaleString()} searches</span>
                    <span>{item.registrations.toLocaleString()} registered</span>
                  </div>
                  <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${item.conversionRate * 3}%`,
                        backgroundColor: item.color
                      }}
                    />
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-sm font-black text-slate-900 dark:text-white">
                    {item.conversionRate}%
                  </span>
                  <span className="block text-[10px] text-slate-400">conv. rate</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Traffic Source Breakdown Pie Chart */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-purple-500" />
              <span>Traffic Source Mix</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Where domain search visitors originate
            </p>
          </div>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={TRAFFIC_SOURCE_DATA}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {TRAFFIC_SOURCE_DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '12px',
                    color: '#fff'
                  }}
                  formatter={(value: any) => [`${value}%`, 'Share']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            {TRAFFIC_SOURCE_DATA.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-600 dark:text-slate-300 font-medium">{item.name}</span>
                </div>
                <span className="font-bold text-slate-900 dark:text-white">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Detailed Monthly Analytics Data Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-600" />
              <span>Monthly Visitor & Conversion Audit Log</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Granular breakdown of search queries, unique traffic, checkout conversions, and revenue.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-800">
              <tr>
                <th className="px-6 py-3.5">Month</th>
                <th className="px-6 py-3.5">Domain Searches</th>
                <th className="px-6 py-3.5">Unique Visitors</th>
                <th className="px-6 py-3.5">Registrations</th>
                <th className="px-6 py-3.5">Conversion Rate</th>
                <th className="px-6 py-3.5">Est. Revenue</th>
                <th className="px-6 py-3.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-200 font-medium">
              {filteredTrends.map((row) => (
                <tr key={row.month} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">
                    {row.month} 2026
                  </td>
                  <td className="px-6 py-4 font-mono">
                    {row.searches.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 font-mono">
                    {row.uniqueVisitors.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                    {row.registrations.toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 rounded-full font-bold">
                      {row.conversionRate}%
                    </span>
                  </td>
                  <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">
                    {currency === 'GHS' ? `GH₵${row.revenueGhs.toLocaleString()}` : `$${row.revenueUsd.toLocaleString()}`}
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200">
                      <CheckCircle2 className="w-3 h-3" />
                      Audited
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
