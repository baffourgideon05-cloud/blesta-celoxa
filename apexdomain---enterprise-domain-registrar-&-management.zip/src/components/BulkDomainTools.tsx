import React, { useState } from 'react';
import { Layers, Search, RefreshCw, ArrowRightLeft, Server, Download, CheckCircle2, ShoppingCart, Check } from 'lucide-react';
import { DomainResult, Currency } from '../types';
import { generateDomainResults, formatPrice } from '../utils/domainSearchEngine';

interface BulkDomainToolsProps {
  currency: Currency;
  onAddToCart: (domain: DomainResult) => void;
  cartItemIds: string[];
}

export const BulkDomainTools: React.FC<BulkDomainToolsProps> = ({
  currency,
  onAddToCart,
  cartItemIds,
}) => {
  const [activeTab, setActiveTab] = useState<'search' | 'transfer' | 'renew' | 'export'>('search');
  const [bulkInput, setBulkInput] = useState('nexusapp.com\ncloudstack.io\nventurelabs.ai\nmybrand.app\nstorefront.shop');
  const [bulkResults, setBulkResults] = useState<DomainResult[]>([]);
  const [eppCodes, setEppCodes] = useState('');

  const handleBulkSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const lines = bulkInput
      .split(/[\n,]+/)
      .map((l) => l.trim())
      .filter(Boolean)
      .slice(0, 50);

    const compiled: DomainResult[] = [];
    lines.forEach((line) => {
      const res = generateDomainResults(line);
      if (res.length > 0) compiled.push(res[0]);
    });

    setBulkResults(compiled);
  };

  const handleExportCsv = () => {
    if (bulkResults.length === 0) return;
    const header = 'Domain,Available,Registration Price,Renewal Price,Category\n';
    const rows = bulkResults
      .map(
        (r) => `${r.domain},${r.isAvailable},${r.registrationPrice},${r.renewalPrice},${r.category}`
      )
      .join('\n');

    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `apexdomain_bulk_search_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-xs font-bold">
          <Layers className="w-4 h-4" /> Enterprise Bulk Operations Hub
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">Bulk Domain Tools</h1>
        <p className="text-sm text-slate-500 max-w-2xl">
          Search, register, renew, or transfer up to 50 domains simultaneously with automated CSV reporting.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-6">
        <button
          onClick={() => setActiveTab('search')}
          className={`pb-3 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
            activeTab === 'search'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Search className="w-4 h-4" /> Bulk Domain Search
        </button>

        <button
          onClick={() => setActiveTab('transfer')}
          className={`pb-3 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
            activeTab === 'transfer'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <ArrowRightLeft className="w-4 h-4" /> Bulk Transfer
        </button>

        <button
          onClick={() => setActiveTab('renew')}
          className={`pb-3 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
            activeTab === 'renew'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <RefreshCw className="w-4 h-4" /> Bulk Renew
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'search' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Input Form */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
            <div>
              <label className="font-extrabold text-sm text-slate-900 dark:text-white">
                Enter Domains (One per line or comma separated)
              </label>
              <textarea
                rows={10}
                value={bulkInput}
                onChange={(e) => setBulkInput(e.target.value)}
                className="w-full mt-2 p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              onClick={handleBulkSearch}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all"
            >
              Check Availability (Up to 50 Domains)
            </button>
          </div>

          {/* Results Table */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Bulk Search Results ({bulkResults.length})
              </h3>

              {bulkResults.length > 0 && (
                <button
                  onClick={handleExportCsv}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" /> Export CSV
                </button>
              )}
            </div>

            {bulkResults.length === 0 ? (
              <div className="p-12 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl text-slate-400 text-xs font-medium">
                Click "Check Availability" above to display bulk status report.
              </div>
            ) : (
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                <table className="w-full text-left text-xs font-medium">
                  <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 font-bold text-slate-400">
                    <tr>
                      <th className="p-3">Domain</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Price</th>
                      <th className="p-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {bulkResults.map((item) => {
                      const inCart = cartItemIds.includes(item.id);
                      return (
                        <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                          <td className="p-3 font-extrabold text-slate-900 dark:text-white">{item.domain}</td>
                          <td className="p-3">
                            {item.isAvailable ? (
                              <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" /> Available
                              </span>
                            ) : (
                              <span className="text-slate-400">Registered</span>
                            )}
                          </td>
                          <td className="p-3 font-bold text-slate-900 dark:text-white">
                            {formatPrice(item.registrationPrice, currency)}
                          </td>
                          <td className="p-3 text-right">
                            {item.isAvailable ? (
                              <button
                                onClick={() => onAddToCart(item)}
                                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                                  inCart ? 'bg-emerald-600 text-white' : 'bg-blue-600 text-white hover:bg-blue-700'
                                }`}
                              >
                                {inCart ? 'Added' : 'Add to Cart'}
                              </button>
                            ) : (
                              <span className="text-slate-400 text-[11px]">Taken</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>
      )}

      {activeTab === 'transfer' && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-2xl space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Bulk Transfer Domains</h3>
          <p className="text-xs text-slate-500">
            Format: domain.com, EPP-AUTH-CODE (One per line)
          </p>
          <textarea
            rows={8}
            value={eppCodes}
            onChange={(e) => setEppCodes(e.target.value)}
            placeholder="mycompany.com, EPP-882319-COM&#10;startup.io, EPP-119283-IO"
            className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono"
          />
          <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md">
            Initiate Bulk Transfer
          </button>
        </div>
      )}

      {activeTab === 'renew' && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-2xl space-y-4">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Bulk Domain Renewal</h3>
          <p className="text-xs text-slate-500">
            Enter registered domain names you wish to extend for +1 to +5 years.
          </p>
          <textarea
            rows={6}
            placeholder="apexcloud.io&#10;nexusapp.com"
            className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono"
          />
          <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md">
            Calculate Bulk Renewal Total
          </button>
        </div>
      )}

    </div>
  );
};
