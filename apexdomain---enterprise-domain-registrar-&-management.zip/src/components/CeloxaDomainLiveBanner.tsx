import React, { useState } from 'react';
import { 
  Globe, 
  ExternalLink, 
  ShieldCheck, 
  Zap, 
  Server, 
  Sparkles, 
  ChevronRight, 
  X,
  CheckCircle2,
  Lock,
  ArrowRight
} from 'lucide-react';
import { CeloxaLivePreviewModal } from './CeloxaLivePreviewModal';

interface CeloxaDomainLiveBannerProps {
  onOpenCommandCenter?: () => void;
  onOpenManagementHub?: () => void;
  domainName?: string;
}

export const CeloxaDomainLiveBanner: React.FC<CeloxaDomainLiveBannerProps> = ({
  onOpenCommandCenter,
  onOpenManagementHub,
  domainName = 'celoxaghana.online',
}) => {
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [bannerDismissed, setBannerDismissed] = useState(false);

  if (bannerDismissed) return null;

  return (
    <>
      <div className="bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 border-b border-indigo-900/60 text-white px-4 py-2.5 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          
          {/* LEFT: STATUS & DOMAIN NAME */}
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Globe className="w-4 h-4 animate-pulse" />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-extrabold text-white text-sm tracking-tight">{domainName}</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Live Website & DNS Online
              </span>
              <span className="hidden md:inline-block text-slate-400 text-[11px]">
                (IP: 198.51.100.42 • SSL Active • WHMCS Enterprise Node)
              </span>
            </div>
          </div>

          {/* RIGHT: QUICK ACTION BUTTONS */}
          <div className="flex items-center gap-2 ml-auto sm:ml-0">
            <button
              onClick={() => setIsPreviewOpen(true)}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Launch Site Preview</span>
            </button>

            {onOpenManagementHub && (
              <button
                onClick={onOpenManagementHub}
                className="hidden sm:flex px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 transition-colors items-center gap-1.5"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span>DNS Zone</span>
              </button>
            )}

            {onOpenCommandCenter && (
              <button
                onClick={onOpenCommandCenter}
                className="hidden md:flex px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-colors items-center gap-1.5"
              >
                <Server className="w-3.5 h-3.5" />
                <span>WHMCS Portal</span>
              </button>
            )}

            <button
              onClick={() => setBannerDismissed(true)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Hide Banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>

      {/* PREVIEW MODAL */}
      <CeloxaLivePreviewModal
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        domainName={domainName}
      />
    </>
  );
};
