import React from 'react';
import { ShieldAlert, Lock, ArrowRight, UserCheck } from 'lucide-react';
import { SystemUser } from '../services/systemDatabase';

interface AccessDeniedModalProps {
  isOpen: boolean;
  onClose: () => void;
  reason: string;
  attemptedView: string;
  currentUser: SystemUser | null;
  onRedirectToAllowedView: () => void;
  onOpenAuthModal: () => void;
}

export const AccessDeniedModal: React.FC<AccessDeniedModalProps> = ({
  isOpen,
  onClose,
  reason,
  attemptedView,
  currentUser,
  onRedirectToAllowedView,
  onOpenAuthModal
}) => {
  if (!isOpen) return null;

  const roleLabel = currentUser 
    ? (currentUser.platformRole || currentUser.role).toUpperCase().replace('_', ' ')
    : 'UNAUTHENTICATED VISITOR';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border-2 border-rose-500/50 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-6 relative overflow-hidden">
        
        {/* Top Decorative Alert Bar */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-rose-500 via-amber-500 to-rose-600" />

        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0 border border-rose-500/20">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 font-extrabold text-[10px] uppercase tracking-wider border border-rose-500/30">
                403 Access Denied
              </span>
              <span className="text-xs text-slate-400 font-mono">View: /{attemptedView}</span>
            </div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white">
              Insufficient Access Permissions
            </h2>
          </div>
        </div>

        <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 rounded-2xl p-4 space-y-3">
          <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
            {reason}
          </p>
          <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold">
            <span className="text-slate-500">Your Current Identity Role:</span>
            <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
              {roleLabel}
            </span>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => {
              onClose();
              onRedirectToAllowedView();
            }}
            className="w-full py-3.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
          >
            <span>Return to Authorized Portal Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {!currentUser ? (
            <button
              onClick={() => {
                onClose();
                onOpenAuthModal();
              }}
              className="w-full py-3 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4 text-slate-400" />
              <span>Sign In with Staff / Admin Credentials</span>
            </button>
          ) : (
            <button
              onClick={() => {
                onClose();
                onOpenAuthModal();
              }}
              className="w-full py-2.5 px-4 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 font-bold text-xs transition-all flex items-center justify-center gap-2"
            >
              <UserCheck className="w-4 h-4" />
              <span>Switch Account / Manage Profile</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
