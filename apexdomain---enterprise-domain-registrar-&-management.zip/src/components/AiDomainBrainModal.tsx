import React, { useState } from 'react';
import { X, Sparkles, Zap, ArrowRight, ShoppingCart, Check, TrendingUp, ShieldCheck, RefreshCw } from 'lucide-react';
import { AiDomainSuggestion, AiAppraisalResult, Currency, DomainResult } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';

interface AiDomainBrainModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  onAddToCart: (domain: DomainResult) => void;
  cartItemIds: string[];
}

export const AiDomainBrainModal: React.FC<AiDomainBrainModalProps> = ({
  isOpen,
  onClose,
  currency,
  onAddToCart,
  cartItemIds,
}) => {
  const [keyword, setKeyword] = useState('');
  const [category, setCategory] = useState('Tech & AI');
  const [style, setStyle] = useState('Short & Brandable');
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<AiDomainSuggestion[]>([]);
  const [selectedAppraisal, setSelectedAppraisal] = useState<AiAppraisalResult | null>(null);
  const [appraising, setAppraising] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyword.trim()) return;

    setLoading(true);
    setSuggestions([]);

    try {
      const res = await fetch('/api/domains/ai-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword, category, style, count: 8 }),
      });
      const data = await res.json();
      if (data.suggestions) {
        setSuggestions(data.suggestions);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAppraiseDomain = async (domainName: string) => {
    setAppraising(true);
    setSelectedAppraisal(null);

    try {
      const res = await fetch('/api/domains/appraise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domainName }),
      });
      const data = await res.json();
      if (data.appraisal) {
        setSelectedAppraisal(data.appraisal);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAppraising(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
              <Sparkles className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight text-white">Gemini AI Domain Brain</h2>
                <span className="px-2 py-0.5 text-[9px] font-black uppercase bg-gradient-to-r from-indigo-500 to-pink-500 text-white rounded-full">
                  AI Powered
                </span>
              </div>
              <p className="text-xs text-indigo-200/80">Generate brandable names & AI commercial appraisals instantly</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Controls */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
          <form onSubmit={handleGenerate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              
              <div className="md:col-span-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Business Concept or Keywords</label>
                <input
                  type="text"
                  required
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  placeholder="e.g. AI video editor, cloud database, luxury coffee..."
                  className="w-full px-3 py-2.5 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Industry Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2.5 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
                >
                  <option value="Tech & AI">Tech & AI (.io, .ai, .app)</option>
                  <option value="Business">Business & Corporate (.com, .co)</option>
                  <option value="E-commerce">E-commerce & Retail (.store, .shop)</option>
                  <option value="Creative">Creative & Web3 (.xyz, .me, .design)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Naming Style</label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full px-3 py-2.5 mt-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
                >
                  <option value="Short & Brandable">Short & Brandable (e.g., Nexus, Velo)</option>
                  <option value="Prefix / Suffix Compound">Action Compound (Get, Try, HQ, Flow)</option>
                  <option value="Modern Tech">Modern Tech (-lab, -stack, -grid)</option>
                  <option value="Executive Premium">Executive & Luxury</option>
                </select>
              </div>

            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-extrabold text-sm shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition-all"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Gemini AI is Brainstorming High-Value Names...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Creative Domain Names with Gemini AI</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {suggestions.length > 0 ? (
            <div className="space-y-4">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center justify-between">
                <span>AI Generated Domain Candidates</span>
                <span className="text-xs text-indigo-500 font-medium">Click "Appraise" for full commercial valuation</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {suggestions.map((item, idx) => {
                  const mappedDomain: DomainResult = {
                    id: `ai-dom-${idx}`,
                    domain: item.domain,
                    name: item.domain.split('.')[0],
                    tld: `.${item.tld.replace('.', '')}`,
                    isAvailable: item.available,
                    isPremium: item.brandScore > 90,
                    registrationPrice: item.price,
                    renewalPrice: item.price + 5,
                    transferPrice: item.price,
                    restorePrice: 80,
                    icannFee: 0.18,
                    category: item.category,
                    description: item.rationale,
                    timeEstimate: 'Instant',
                    popularityScore: item.brandScore,
                    characterLength: item.domain.length,
                    brandScore: item.brandScore,
                    hasPrivacyIncluded: true,
                  };

                  const inCart = cartItemIds.includes(mappedDomain.id);

                  return (
                    <div
                      key={idx}
                      className="bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-4 space-y-3 shadow-sm hover:shadow-md transition-all"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-black text-base text-slate-900 dark:text-white flex items-center gap-2">
                            {item.domain}
                            <span className="px-2 py-0.5 text-[9px] font-extrabold uppercase bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 rounded-full">
                              Score: {item.brandScore}/100
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{item.rationale}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                        <div>
                          <span className="text-slate-400 text-[11px]">Est. Brand Valuation:</span>
                          <div className="font-extrabold text-indigo-600 dark:text-indigo-400">
                            ${item.estimatedValue.toLocaleString()}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleAppraiseDomain(item.domain)}
                            className="px-2.5 py-1.5 rounded-lg border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 text-xs font-bold text-indigo-600 dark:text-indigo-400 transition-colors"
                          >
                            Appraise
                          </button>

                          <button
                            onClick={() => onAddToCart(mappedDomain)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                              inCart ? 'bg-emerald-600 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'
                            }`}
                          >
                            {inCart ? <Check className="w-3.5 h-3.5" /> : <ShoppingCart className="w-3.5 h-3.5" />}
                            {formatPrice(item.price, currency)}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-200">Enter a concept to ignite Gemini AI</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Type your startup idea or keywords above and Gemini AI will construct high-converting domain names.
              </p>
            </div>
          )}

          {/* Appraisal Modal Result Breakdown */}
          {appraising && (
            <div className="p-6 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 text-center space-y-2">
              <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin mx-auto" />
              <p className="text-xs font-bold text-indigo-900 dark:text-indigo-300">Gemini AI is analyzing commercial valuation & SEO metrics...</p>
            </div>
          )}

          {selectedAppraisal && (
            <div className="p-6 rounded-2xl bg-slate-900 text-white border border-indigo-500/30 space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">Gemini AI Valuation Report</span>
                  <h4 className="text-xl font-black text-white">{selectedAppraisal.domain}</h4>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-black text-emerald-400">${selectedAppraisal.estimatedValue.toLocaleString()}</div>
                  <span className="text-[10px] text-slate-400">Estimated Market Value</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{selectedAppraisal.summary}</p>

              <div className="grid grid-cols-3 gap-3 text-center text-xs">
                <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700">
                  <div className="font-black text-indigo-400 text-base">{selectedAppraisal.brandabilityScore}/100</div>
                  <span className="text-[10px] text-slate-400">Brandability</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700">
                  <div className="font-black text-emerald-400 text-base">{selectedAppraisal.seoScore}/100</div>
                  <span className="text-[10px] text-slate-400">SEO Potential</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700">
                  <div className="font-black text-pink-400 text-base">{selectedAppraisal.lengthScore}/100</div>
                  <span className="text-[10px] text-slate-400">Length Rating</span>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
