import React from 'react';
import { X, ArrowRightLeft, ShoppingCart, Check, Trash2, ShieldCheck, CheckCircle2, XCircle } from 'lucide-react';
import { DomainResult, Currency } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';

interface DomainComparisonModalProps {
  compareList: DomainResult[];
  currency: Currency;
  onClose: () => void;
  onRemoveFromCompare: (domainId: string) => void;
  onAddToCart: (domain: DomainResult) => void;
  cartItemIds: string[];
}

export const DomainComparisonModal: React.FC<DomainComparisonModalProps> = ({
  compareList,
  currency,
  onClose,
  onRemoveFromCompare,
  onAddToCart,
  cartItemIds,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-6xl max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white">Side-by-Side Domain Comparison</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Compare up to 10 domains across price, renewal rates, and specs</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {compareList.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
              <ArrowRightLeft className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 dark:text-slate-200">No Domains Selected for Comparison</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Click the compare icon (<ArrowRightLeft className="w-3 h-3 inline" />) on any domain card to compare them side-by-side.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto p-6">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800">
                  <th className="py-3 px-4 text-xs font-bold uppercase text-slate-400 w-44">Feature</th>
                  {compareList.map((item) => (
                    <th key={item.id} className="py-3 px-4 min-w-[200px]">
                      <div className="flex items-center justify-between gap-2 bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                        <span className="font-extrabold text-sm text-slate-900 dark:text-white truncate">{item.domain}</span>
                        <button
                          onClick={() => onRemoveFromCompare(item.id)}
                          className="text-slate-400 hover:text-red-500 transition-colors p-1"
                          title="Remove from comparison"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300">
                
                {/* Status */}
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-500">Availability</td>
                  {compareList.map((item) => (
                    <td key={item.id} className="py-3 px-4">
                      {item.isAvailable ? (
                        <span className="inline-flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" /> Available
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 font-bold text-slate-400">
                          <XCircle className="w-4 h-4" /> Taken
                        </span>
                      )}
                    </td>
                  ))}
                </tr>

                {/* 1st Year Registration Price */}
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-500">1st Year Price</td>
                  {compareList.map((item) => (
                    <td key={item.id} className="py-3 px-4 text-sm font-extrabold text-blue-600 dark:text-blue-400">
                      {formatPrice(item.registrationPrice, currency)}
                    </td>
                  ))}
                </tr>

                {/* Renewal Price */}
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-500">Renewal Price</td>
                  {compareList.map((item) => (
                    <td key={item.id} className="py-3 px-4">
                      {formatPrice(item.renewalPrice, currency)} / yr
                    </td>
                  ))}
                </tr>

                {/* Transfer Price */}
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-500">Transfer Cost</td>
                  {compareList.map((item) => (
                    <td key={item.id} className="py-3 px-4">
                      {formatPrice(item.transferPrice, currency)}
                    </td>
                  ))}
                </tr>

                {/* Brandability Rating */}
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-500">Brand Score</td>
                  {compareList.map((item) => (
                    <td key={item.id} className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-blue-500 to-indigo-500" 
                            style={{ width: `${item.brandScore}%` }} 
                          />
                        </div>
                        <span className="font-extrabold text-slate-900 dark:text-white">{item.brandScore}/100</span>
                      </div>
                    </td>
                  ))}
                </tr>

                {/* Character Length */}
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-500">Length</td>
                  {compareList.map((item) => (
                    <td key={item.id} className="py-3 px-4">
                      {item.characterLength} chars
                    </td>
                  ))}
                </tr>

                {/* WHOIS Privacy */}
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-500">WHOIS Privacy</td>
                  {compareList.map((item) => (
                    <td key={item.id} className="py-3 px-4 text-emerald-600 dark:text-emerald-400 font-bold">
                      <ShieldCheck className="w-4 h-4 inline mr-1" /> Free Included
                    </td>
                  ))}
                </tr>

                {/* Action Row */}
                <tr>
                  <td className="py-4 px-4 font-bold text-slate-500">Action</td>
                  {compareList.map((item) => {
                    const inCart = cartItemIds.includes(item.id);
                    return (
                      <td key={item.id} className="py-4 px-4">
                        {item.isAvailable ? (
                          <button
                            onClick={() => onAddToCart(item)}
                            className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                              inCart ? 'bg-emerald-600 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md'
                            }`}
                          >
                            {inCart ? <Check className="w-3.5 h-3.5" /> : <ShoppingCart className="w-3.5 h-3.5" />}
                            {inCart ? 'In Cart' : 'Add to Cart'}
                          </button>
                        ) : (
                          <span className="text-slate-400 text-xs font-medium">Not Available</span>
                        )}
                      </td>
                    );
                  })}
                </tr>

              </tbody>
            </table>
          </div>
        )}

      </div>
    </div>
  );
};
