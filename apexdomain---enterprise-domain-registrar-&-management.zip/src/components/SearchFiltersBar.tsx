import React from 'react';
import { 
  LayoutGrid, 
  List, 
  AlignJustify, 
  Table as TableIcon, 
  ArrowUpDown, 
  RotateCcw
} from 'lucide-react';
import { ViewMode, SearchFilter, SortOption } from '../types';

interface SearchFiltersBarProps {
  viewMode?: ViewMode;
  setViewMode?: (mode: ViewMode) => void;
  onViewModeChange?: (mode: ViewMode) => void;

  filters?: SearchFilter;
  setFilters?: React.Dispatch<React.SetStateAction<SearchFilter>>;

  selectedCategory?: string;
  onCategoryChange?: (cat: string) => void;

  tldFilter?: string;
  onTldFilterChange?: (tld: string) => void;

  priceRange?: [number, number];
  onPriceRangeChange?: (range: [number, number]) => void;

  sortBy?: any;
  onSortByChange?: (sort: any) => void;

  availabilityOnly?: boolean;
  onAvailabilityOnlyChange?: (val: boolean) => void;

  sortOption?: SortOption;
  setSortOption?: (sort: SortOption) => void;

  resultsCount?: number;
  resetFilters?: () => void;
  onResetFilters?: () => void;
}

export const SearchFiltersBar: React.FC<SearchFiltersBarProps> = ({
  viewMode = 'card',
  setViewMode,
  onViewModeChange,
  filters,
  setFilters,
  selectedCategory,
  onCategoryChange,
  tldFilter,
  onTldFilterChange,
  priceRange,
  onPriceRangeChange,
  sortBy,
  onSortByChange,
  availabilityOnly,
  onAvailabilityOnlyChange,
  sortOption,
  setSortOption,
  resultsCount = 0,
  resetFilters,
  onResetFilters,
}) => {
  const currentViewMode = viewMode;

  const handleSetViewMode = (mode: ViewMode) => {
    if (onViewModeChange) onViewModeChange(mode);
    if (setViewMode) setViewMode(mode);
  };

  const currentCategory = selectedCategory ?? filters?.category ?? 'All';
  const handleCategoryChange = (cat: string) => {
    if (onCategoryChange) onCategoryChange(cat);
    if (setFilters) setFilters((prev) => ({ ...prev, category: cat }));
  };

  const currentTld = tldFilter ?? filters?.tld ?? 'All';
  const handleTldChange = (tld: string) => {
    if (onTldFilterChange) onTldFilterChange(tld);
    if (setFilters) setFilters((prev) => ({ ...prev, tld }));
  };

  const currentMaxPrice = priceRange ? priceRange[1] : (filters?.maxPrice ?? 10000);
  const handleMaxPriceChange = (val: number) => {
    if (onPriceRangeChange) onPriceRangeChange([priceRange ? priceRange[0] : 0, val]);
    if (setFilters) setFilters((prev) => ({ ...prev, maxPrice: val }));
  };

  const currentAvail = availabilityOnly ?? (filters?.availability === 'available' || filters?.availabilityOnly === true);
  const handleAvailChange = (val: string) => {
    const isAvailOnly = val === 'available' || val === 'true';
    if (onAvailabilityOnlyChange) onAvailabilityOnlyChange(isAvailOnly);
    if (setFilters) {
      setFilters((prev) => ({
        ...prev,
        availability: val as any,
        availabilityOnly: isAvailOnly,
      }));
    }
  };

  const currentSort = sortBy ?? sortOption ?? 'popular';
  const handleSortChange = (val: any) => {
    if (onSortByChange) onSortByChange(val);
    if (setSortOption) setSortOption(val);
  };

  const handleReset = () => {
    if (onResetFilters) onResetFilters();
    if (resetFilters) resetFilters();
  };

  return (
    <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 py-3 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        
        {/* Left: View Modes & Results Count */}
        <div className="flex items-center justify-between md:justify-start gap-4">
          <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => handleSetViewMode('card')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                currentViewMode === 'card'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Card View"
            >
              <LayoutGrid className="w-4 h-4" />
              <span className="hidden sm:inline">Cards</span>
            </button>

            <button
              onClick={() => handleSetViewMode('list')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                currentViewMode === 'list'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">List</span>
            </button>

            <button
              onClick={() => handleSetViewMode('compact')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                currentViewMode === 'compact'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Compact View"
            >
              <AlignJustify className="w-4 h-4" />
              <span className="hidden sm:inline">Compact</span>
            </button>

            <button
              onClick={() => handleSetViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                currentViewMode === 'table'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Table View"
            >
              <TableIcon className="w-4 h-4" />
              <span className="hidden sm:inline">Table</span>
            </button>
          </div>

          <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
            Showing <span className="text-slate-900 dark:text-white font-extrabold">{resultsCount}</span> Domain Results
          </span>
        </div>

        {/* Right: Filters & Sorting */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          
          {/* Availability Status Filter */}
          <select
            value={currentAvail ? 'available' : 'all'}
            onChange={(e) => handleAvailChange(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Statuses</option>
            <option value="available">Available Only</option>
          </select>

          {/* TLD Category Filter */}
          <select
            value={currentCategory}
            onChange={(e) => handleCategoryChange(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Categories</option>
            <option value="Popular">Popular gTLDs</option>
            <option value="Tech & AI">Tech & AI</option>
            <option value="Business">Business & Corporate</option>
            <option value="E-commerce">E-commerce & Shopping</option>
            <option value="ccTLD">Country ccTLDs</option>
            <option value="Creative">Creative & Web3</option>
          </select>

          {/* TLD Extension Filter */}
          <select
            value={currentTld}
            onChange={(e) => handleTldChange(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Extensions</option>
            <option value=".com">.com</option>
            <option value=".ai">.ai</option>
            <option value=".io">.io</option>
            <option value=".org">.org</option>
            <option value=".net">.net</option>
            <option value=".co">.co</option>
            <option value=".app">.app</option>
            <option value=".dev">.dev</option>
          </select>

          {/* Max Price Cap */}
          <select
            value={currentMaxPrice}
            onChange={(e) => handleMaxPriceChange(Number(e.target.value))}
            className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value={10000}>Max Price: Any</option>
            <option value={15}>Under $15 / yr</option>
            <option value={35}>Under $35 / yr</option>
            <option value={75}>Under $75 / yr</option>
            <option value={200}>Under $200 / yr</option>
          </select>

          {/* Sort Option */}
          <div className="flex items-center gap-1.5">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={currentSort}
              onChange={(e) => handleSortChange(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="popular">Most Popular</option>
              <option value="price_asc">Lowest Price</option>
              <option value="price-asc">Lowest Price</option>
              <option value="price_desc">Highest Price</option>
              <option value="price-desc">Highest Price</option>
              <option value="alpha">Alphabetical (A-Z)</option>
              <option value="alphabetical">Alphabetical (A-Z)</option>
              <option value="score">Brandability Score</option>
            </select>
          </div>

          {/* Reset Filters */}
          <button
            onClick={handleReset}
            className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
            title="Reset Filters"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
