import React, { useState, useRef, useEffect } from 'react';
import { Search, Sparkles, Clock, X, ArrowRight, ShieldCheck, CheckCircle2, TrendingUp, Zap } from 'lucide-react';
import { DomainResult } from '../types';

interface HeroSearchProps {
  searchTerm?: string;
  query?: string;
  setSearchTerm?: (term: string) => void;
  onQueryChange?: (term: string) => void;
  onSearchSubmit?: (term: string) => void;
  onSearch?: (term: string) => void;
  suggestions?: DomainResult[];
  onSelectSuggestion?: (sugg: DomainResult) => void;
  searchHistory?: string[];
  clearSearchHistory?: () => void;
  onClearHistory?: () => void;
  openAiBrain?: () => void;
  onOpenAiBrain?: () => void;
  quickCategoryFilter?: (category: string) => void;
}

export const HeroSearch: React.FC<HeroSearchProps> = ({
  searchTerm,
  query,
  setSearchTerm,
  onQueryChange,
  onSearchSubmit,
  onSearch,
  suggestions: propSuggestions,
  onSelectSuggestion,
  searchHistory = [],
  clearSearchHistory,
  onClearHistory,
  openAiBrain,
  onOpenAiBrain,
  quickCategoryFilter,
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentTerm = searchTerm ?? query ?? '';

  const handleTermChange = (val: string) => {
    if (setSearchTerm) setSearchTerm(val);
    if (onQueryChange) onQueryChange(val);
  };

  const handleSearchSubmit = (valToSearch: string) => {
    if (onSearchSubmit) onSearchSubmit(valToSearch);
    if (onSearch) onSearch(valToSearch);
  };

  const handleClearHistory = () => {
    if (clearSearchHistory) clearSearchHistory();
    if (onClearHistory) onClearHistory();
  };

  const handleOpenAi = () => {
    if (openAiBrain) openAiBrain();
    if (onOpenAiBrain) onOpenAiBrain();
  };

  // Suggestions generated on the fly while typing
  const cleanTerm = (currentTerm || '').toLowerCase().trim().replace(/[^a-z0-9]/g, '');
  
  const generatedSuggestions = cleanTerm
    ? [
        { label: `${cleanTerm}.com`, type: 'Exact Match', badge: 'Popular', price: '$10.99' },
        { label: `${cleanTerm}.io`, type: 'Tech Favorite', badge: 'SaaS Standard', price: '$32.99' },
        { label: `${cleanTerm}.ai`, type: 'AI Trend', badge: 'Hot', price: '$69.99' },
        { label: `${cleanTerm}.app`, type: 'Secure HTTPS', badge: 'Google TLD', price: '$14.99' },
        { label: `get${cleanTerm}.com`, type: 'Prefix Alternative', badge: 'Brandable', price: '$10.99' },
        { label: `${cleanTerm}hq.com`, type: 'Suffix Alternative', badge: 'High Converting', price: '$10.99' },
      ]
    : [];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentTerm.trim()) {
      handleSearchSubmit(currentTerm.trim());
      setIsFocused(false);
    }
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white py-14 sm:py-20 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
      
      {/* Subtle Background Glow Accent */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-blue-600/15 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[300px] h-[200px] bg-indigo-600/10 blur-[100px] rounded-full pointer-events-none" />

      <div className="relative max-w-4xl mx-auto text-center space-y-6">
        
        {/* Top Tag Banner */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/80 text-xs text-slate-300 font-medium backdrop-blur-md">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>ICANN Accredited Registrar</span>
          <span className="w-1 h-1 rounded-full bg-slate-500" />
          <span className="text-blue-400 font-semibold">Free WHOIS Privacy Forever</span>
        </div>

        {/* Main Headline */}
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight text-white">
          Find & Register Your Next <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400">
            Enterprise Domain Name
          </span>
        </h1>

        <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto font-normal leading-relaxed">
          Search over 800+ top-level extensions with instant DNS setup, automated WHOIS privacy protection, and AI-powered brand valuations.
        </p>

        {/* Search Bar Container */}
        <div ref={dropdownRef} className="relative max-w-2xl mx-auto mt-8 text-left">
          <form onSubmit={handleSubmit} className="relative group">
            <div className="relative flex items-center bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border-2 border-slate-700/50 focus-within:border-blue-500 transition-all p-2">
              
              <div className="pl-3 text-slate-400">
                <Search className="w-5 h-5 text-slate-400" />
              </div>

              <input
                type="text"
                value={currentTerm}
                onChange={(e) => handleTermChange(e.target.value)}
                onFocus={() => setIsFocused(true)}
                placeholder="Search your domain (e.g. mystartup, nexus.io, or business idea)..."
                className="w-full py-3 px-3 bg-transparent text-slate-900 dark:text-white placeholder-slate-400 text-sm sm:text-base font-medium focus:outline-none"
              />

              {currentTerm && (
                <button
                  type="button"
                  onClick={() => handleTermChange('')}
                  className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              <button
                type="submit"
                className="ml-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-md shadow-blue-600/30 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0"
              >
                <span>Search</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Search Dropdown / History / Live Suggestions */}
          {isFocused && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden z-50 animate-in fade-in zoom-in-95">
              
              {/* Live Autocomplete Suggestions */}
              {propSuggestions && propSuggestions.length > 0 ? (
                <div className="p-2 border-b border-slate-100 dark:border-slate-700/60">
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                    <span>Live Domain Suggestions</span>
                    <span className="text-blue-500 text-[10px] font-medium">Instant Availability Check</span>
                  </div>
                  {propSuggestions.map((sug) => (
                    <button
                      key={sug.id}
                      onClick={() => {
                        if (onSelectSuggestion) onSelectSuggestion(sug);
                        else {
                          handleTermChange(sug.domain);
                          handleSearchSubmit(sug.domain);
                        }
                        setIsFocused(false);
                      }}
                      className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700/50 flex items-center justify-between transition-colors group"
                    >
                      <div className="flex items-center gap-2.5">
                        <Zap className="w-4 h-4 text-amber-500" />
                        <span className="font-semibold text-slate-800 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                          {sug.domain}
                        </span>
                        <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-medium">
                          {sug.isAvailable ? 'Available' : 'Taken'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-blue-600 dark:text-blue-400">${sug.registrationPrice}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  ))}
                </div>
              ) : generatedSuggestions.length > 0 ? (
                <div className="p-2 border-b border-slate-100 dark:border-slate-700/60">
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                    <span>Live Domain Suggestions</span>
                    <span className="text-blue-500 text-[10px] font-medium">Instant Availability Check</span>
                  </div>
                  {generatedSuggestions.map((sug, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        handleTermChange(sug.label);
                        handleSearchSubmit(sug.label);
                        setIsFocused(false);
                      }}
                      className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700/50 flex items-center justify-between transition-colors group"
                    >
                      <div className="flex items-center gap-2.5">
                        <Zap className="w-4 h-4 text-amber-500" />
                        <span className="font-semibold text-slate-800 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                          {sug.label}
                        </span>
                        <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-medium">
                          {sug.type}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-blue-600 dark:text-blue-400">{sug.price}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  ))}
                </div>
              ) : null}

              {/* Search History */}
              {searchHistory.length > 0 && (
                <div className="p-2">
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Recent Searches
                    </span>
                    <button
                      onClick={handleClearHistory}
                      className="text-[10px] text-slate-400 hover:text-red-500 transition-colors"
                    >
                      Clear History
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5 p-1">
                    {searchHistory.map((item, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          handleTermChange(item);
                          handleSearchSubmit(item);
                          setIsFocused(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-700/60 hover:bg-blue-50 dark:hover:bg-blue-900/30 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-1.5"
                      >
                        <span>{item}</span>
                        <ArrowRight className="w-3 h-3 text-slate-400" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Brain Callout inside search dropdown */}
              <div className="p-3 bg-gradient-to-r from-indigo-900/30 to-purple-900/30 border-t border-indigo-500/20 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400 animate-bounce" />
                  <span className="text-xs text-indigo-200 font-medium">Need creative name ideas? Let Gemini AI assist you.</span>
                </div>
                <button
                  onClick={() => {
                    handleOpenAi();
                    setIsFocused(false);
                  }}
                  className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all"
                >
                  Open AI Brain
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Extension Quick Pills - Displayed when domain search is being used or focused */}
        {(currentTerm.trim().length > 0 || isFocused) && (
          <div className="pt-2 flex flex-wrap items-center justify-center gap-2 animate-in fade-in">
            <span className="text-xs text-slate-400 font-medium mr-1">Matching TLD Extensions:</span>
            {[
              { tld: '.com', price: 'GH₵ 180', category: 'Popular' },
              { tld: '.com.gh', price: 'GH₵ 150', category: 'Ghana Local' },
              { tld: '.io', price: 'GH₵ 420', category: 'Tech & AI' },
              { tld: '.ai', price: 'GH₵ 950', category: 'Tech & AI' },
              { tld: '.org', price: 'GH₵ 190', category: 'Popular' },
              { tld: '.site', price: 'GH₵ 45', category: 'E-commerce' },
            ].map((item) => (
              <button
                key={item.tld}
                onClick={() => {
                  const queryToUse = currentTerm.trim() ? `${currentTerm.split('.')[0]}${item.tld}` : `mybrand${item.tld}`;
                  handleTermChange(queryToUse);
                  handleSearchSubmit(queryToUse);
                }}
                className="px-3 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-xs font-semibold text-slate-200 hover:text-white transition-all flex items-center gap-1.5 shadow-sm"
              >
                <span className="text-cyan-400 font-extrabold">{item.tld}</span>
                <span className="text-[11px] text-slate-400">{item.price}</span>
              </button>
            ))}

            <button
              onClick={handleOpenAi}
              className="px-3 py-1 rounded-lg bg-indigo-900/60 hover:bg-indigo-800/80 border border-indigo-500/40 text-xs font-bold text-indigo-300 flex items-center gap-1.5 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              AI Ideas
            </button>
          </div>
        )}

        {/* Enterprise Trust Stats */}
        <div className="pt-8 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-xl sm:text-2xl font-black text-white">12M+</div>
            <div className="text-xs text-slate-400 font-medium">Domains Managed</div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-white">99.999%</div>
            <div className="text-xs text-slate-400 font-medium">DNS Anycast Uptime</div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-white">800+</div>
            <div className="text-xs text-slate-400 font-medium">TLD Extensions</div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-white">24 / 7 / 365</div>
            <div className="text-xs text-slate-400 font-medium">Enterprise Support</div>
          </div>
        </div>

      </div>
    </div>
  );
};
