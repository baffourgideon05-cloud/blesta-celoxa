import React from 'react';
import { Globe, ShieldCheck, Server, Clock, Lock, CheckCircle2, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: any) => void;
  siteName?: string;
  companyName?: string;
  logoUrl?: string;
}

export const Footer: React.FC<FooterProps> = ({ 
  onNavigate, 
  siteName = 'Celoxa Ghana Cloud Systems', 
  companyName = 'Celoxa Technologies Ltd',
  logoUrl
}) => {
  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 mt-20">
      
      {/* Trust Badges Banner */}
      <div className="border-b border-slate-900 bg-slate-900/40 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          
          <div className="space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-white font-extrabold text-sm">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> ICANN Accredited
            </div>
            <p className="text-xs text-slate-500">Official Direct Registry Integration</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-white font-extrabold text-sm">
              <Lock className="w-4 h-4 text-blue-400" /> Free WHOIS Privacy
            </div>
            <p className="text-xs text-slate-500">Full WHOIS Guard Protection</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-white font-extrabold text-sm">
              <Server className="w-4 h-4 text-indigo-400" /> 100% Anycast DNS Uptime
            </div>
            <p className="text-xs text-slate-500">30+ Global Edge Locations</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-white font-extrabold text-sm">
              <Clock className="w-4 h-4 text-purple-400" /> 24/7 Concierge Support
            </div>
            <p className="text-xs text-slate-500">Enterprise SLA Engineering</p>
          </div>

        </div>
      </div>

      {/* Main Links Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-5 gap-8 text-xs">
        
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center gap-2.5 text-white font-black text-lg">
            {logoUrl ? (
              <div className="h-10 px-2 bg-slate-900/80 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden shadow-sm shrink-0">
                <img src={logoUrl} alt={siteName} className="h-7 w-auto object-contain max-w-[140px]" />
              </div>
            ) : (
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shrink-0">
                <Globe className="w-5 h-5" />
              </div>
            )}
            <span>{siteName}</span>
          </div>

          <p className="text-slate-400 max-w-sm leading-relaxed">
            The next-generation enterprise domain registrar powered by Gemini AI. Instantly search, appraise, manage, and secure premium digital assets.
          </p>

          <div className="text-[11px] text-slate-500">
            ICANN IANA Registrar ID: #88921-APX • SSL 256-Bit Encrypted
          </div>
        </div>

        {/* Navigation Column 1 */}
        <div className="space-y-3">
          <h4 className="font-extrabold uppercase tracking-wider text-white">Products & Tools</h4>
          <ul className="space-y-2 text-slate-400">
            <li><button onClick={() => onNavigate('search')} className="hover:text-white transition-colors">Domain Search Engine</button></li>
            <li><button onClick={() => onNavigate('bulk')} className="hover:text-white transition-colors">Bulk Operations Hub</button></li>
            <li><button onClick={() => onNavigate('management')} className="hover:text-white transition-colors">DNS Zone Manager</button></li>
            <li><button onClick={() => onNavigate('tlds')} className="hover:text-white transition-colors">TLD Directory Catalog</button></li>
            <li><button onClick={() => onNavigate('command_center')} className="hover:text-white transition-colors font-semibold text-emerald-400">Command Center (WHMCS & Hosting)</button></li>
          </ul>
        </div>

        {/* Navigation Column 2 */}
        <div className="space-y-3">
          <h4 className="font-extrabold uppercase tracking-wider text-white">Resources & Support</h4>
          <ul className="space-y-2 text-slate-400">
            <li><button onClick={() => onNavigate('academy')} className="hover:text-white transition-colors">Registrar Academy</button></li>
            <li><a href="#whois" className="hover:text-white transition-colors">ICANN WHOIS Database</a></li>
            <li><a href="#support" className="hover:text-white transition-colors">Knowledgebase & FAQs</a></li>
            <li><a href="#security" className="hover:text-white transition-colors">DNSSEC & SSL Security</a></li>
          </ul>
        </div>

        {/* Newsletter Column */}
        <div className="space-y-3">
          <h4 className="font-extrabold uppercase tracking-wider text-white">TLD Drop Alerts</h4>
          <p className="text-slate-400 text-[11px]">Receive daily price drops, new gTLD launches, and expired domain lists.</p>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="Email address..."
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors">
              Join
            </button>
          </div>
        </div>

      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-900 py-6 text-center text-[11px] text-slate-600">
        © {new Date().getFullYear()} ApexDomain Registrar Inc. All rights reserved. Built with Gemini AI.
      </div>

    </footer>
  );
};
