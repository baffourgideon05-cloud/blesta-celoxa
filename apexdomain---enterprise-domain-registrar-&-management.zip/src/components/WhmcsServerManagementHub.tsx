import React, { useState } from 'react';
import { 
  Server, 
  Cpu, 
  HardDrive, 
  Activity, 
  ShieldCheck, 
  Plus, 
  Terminal, 
  RefreshCw, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Settings, 
  ListFilter, 
  Play, 
  Pause, 
  Trash2, 
  Key, 
  Globe, 
  Layers, 
  Check, 
  Database,
  ExternalLink
} from 'lucide-react';

import { 
  WhmcsServerNode, 
  WhmcsProvisioningQueueItem, 
  WhmcsAutomationCronLog,
  WhmcsHostingPackage 
} from '../types';

import { 
  MOCK_WHMCS_SERVERS, 
  MOCK_WHMCS_PROVISIONING_QUEUE, 
  MOCK_WHMCS_CRON_LOGS, 
  MOCK_WHMCS_PACKAGES 
} from '../data/mockWhmcsData';

interface Props {
  onClose?: () => void;
}

export const WhmcsServerManagementHub: React.FC<Props> = ({ onClose }) => {
  const [activeSubTab, setActiveSubTab] = useState<'servers' | 'queue' | 'cron' | 'packages' | 'whm_api'>('servers');
  
  // State
  const [servers, setServers] = useState<WhmcsServerNode[]>(MOCK_WHMCS_SERVERS);
  const [queue, setQueue] = useState<WhmcsProvisioningQueueItem[]>(MOCK_WHMCS_PROVISIONING_QUEUE);
  const [cronLogs, setCronLogs] = useState<WhmcsAutomationCronLog[]>(MOCK_WHMCS_CRON_LOGS);
  const [packages, setPackages] = useState<WhmcsHostingPackage[]>(MOCK_WHMCS_PACKAGES);

  // New Server Form Modal
  const [showAddServerModal, setShowAddServerModal] = useState(false);
  const [newSrvName, setNewSrvName] = useState('');
  const [newSrvHost, setNewSrvHost] = useState('');
  const [newSrvIp, setNewSrvIp] = useState('');
  const [newSrvModule, setNewSrvModule] = useState<'cpanel' | 'directadmin' | 'plesk' | 'solusvm'>('cpanel');
  const [newSrvDatacenter, setNewSrvDatacenter] = useState('US-East Equinix NY4');

  // Trigger Manual Queue Action
  const handleProcessQueueItem = (id: string) => {
    setQueue(queue.map(q => q.id === id ? {
      ...q,
      status: 'success',
      completedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
    } : q));
  };

  // Trigger Manual Cron Execution
  const handleRunCronManually = (jobName: string) => {
    const newLog: WhmcsAutomationCronLog = {
      id: `cron-${Date.now()}`,
      jobName,
      category: 'Provisioning Queue',
      executedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      status: 'success',
      recordsProcessed: Math.floor(5 + Math.random() * 25),
      details: `Manual WHMCS Admin trigger for ${jobName}. All server modules responding synchronously.`,
    };
    setCronLogs([newLog, ...cronLogs]);
  };

  // Add Server Handler
  const handleAddServer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSrvName || !newSrvHost) return;

    const newSrv: WhmcsServerNode = {
      id: `srv-${Date.now()}`,
      name: newSrvName,
      hostname: newSrvHost,
      ipAddress: newSrvIp || '198.51.100.120',
      module: newSrvModule,
      serverGroup: 'North America Enterprise NVMe Group',
      datacenter: newSrvDatacenter,
      maxAccounts: 200,
      activeAccounts: 0,
      status: 'online',
      cpuLoadPercentage: 8,
      ramUsagePercentage: 15,
      diskUsagePercentage: 12,
      activeIpPool: [newSrvIp || '198.51.100.120'],
      accessHashConfigured: true,
    };

    setServers([...servers, newSrv]);
    setShowAddServerModal(false);
    setNewSrvName('');
    setNewSrvHost('');
    setNewSrvIp('');
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* WHMCS Header Banner */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl border border-indigo-900/60 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-500 text-white tracking-wider">
              WHMCS System Core
            </span>
            <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              WHMCS v8.10 API Connected
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1 tracking-tight">
            WHMCS Server & Provisioning Automation Hub
          </h1>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Real-time server node management, cPanel/WHM API synchronization, automated cron execution, and WHMCS module command queue status.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddServerModal(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg flex items-center gap-2 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Connect WHM / cPanel Server</span>
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl border border-slate-700"
            >
              Close
            </button>
          )}
        </div>
      </div>

      {/* WHMCS Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs font-extrabold overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('servers')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'servers'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>Server Cluster Nodes ({servers.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('queue')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'queue'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Zap className="w-4 h-4 text-amber-400" />
          <span>Provisioning Queue ({queue.filter(q => q.status === 'queued').length} Pending)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('cron')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'cron'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Clock className="w-4 h-4 text-emerald-400" />
          <span>WHMCS Cron Automation Logs</span>
        </button>

        <button
          onClick={() => setActiveSubTab('packages')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'packages'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4 text-sky-400" />
          <span>Hosting Products & Catalog</span>
        </button>

        <button
          onClick={() => setActiveSubTab('whm_api')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'whm_api'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Key className="w-4 h-4 text-purple-400" />
          <span>WHM API Credentials & Keys</span>
        </button>
      </div>

      {/* SUB-TAB 1: SERVER NODES CLUSTER */}
      {activeSubTab === 'servers' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {servers.map((srv) => (
            <div key={srv.id} className="p-5 bg-slate-900 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-950 text-indigo-300 font-mono">
                      Module: {srv.module.toUpperCase()}
                    </span>
                    <span className="text-[10px] text-slate-400">{srv.datacenter}</span>
                  </div>
                  <h3 className="font-extrabold text-white text-base mt-1">{srv.name}</h3>
                  <p className="text-xs text-slate-400 font-mono">{srv.hostname} ({srv.ipAddress})</p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Online
                </span>
              </div>

              {/* Resource Usage Meters */}
              <div className="space-y-2.5 pt-3 border-t border-slate-800 text-xs">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span className="flex items-center gap-1"><Cpu className="w-3.5 h-3.5 text-indigo-400" /> CPU Load Average</span>
                    <span className="font-mono text-white font-bold">{srv.cpuLoadPercentage}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${srv.cpuLoadPercentage}%` }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span className="flex items-center gap-1"><Activity className="w-3.5 h-3.5 text-sky-400" /> RAM Allocation</span>
                    <span className="font-mono text-white font-bold">{srv.ramUsagePercentage}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-sky-500 h-full rounded-full" style={{ width: `${srv.ramUsagePercentage}%` }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span className="flex items-center gap-1"><HardDrive className="w-3.5 h-3.5 text-emerald-400" /> NVMe SSD Pool</span>
                    <span className="font-mono text-white font-bold">{srv.diskUsagePercentage}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${srv.diskUsagePercentage}%` }}></div>
                  </div>
                </div>
              </div>

              {/* Server Stats Grid */}
              <div className="p-3 bg-slate-950 rounded-xl text-xs grid grid-cols-2 gap-2 font-mono text-slate-300 border border-slate-800/80">
                <div>
                  <span className="text-slate-500 text-[10px] block">Active Hosting Accounts</span>
                  <span className="font-bold text-white">{srv.activeAccounts} / {srv.maxAccounts}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Server Group</span>
                  <span className="truncate block text-slate-300">{srv.serverGroup}</span>
                </div>
              </div>

              {/* Server Actions */}
              <div className="flex items-center justify-between pt-2">
                <a
                  href={`https://${srv.hostname}:2087`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                >
                  <span>Launch WHM Panel</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <button
                  onClick={() => alert(`Synchronized WHM API access hash for ${srv.hostname}. Connection OK.`)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-extrabold rounded-lg flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Test API Handshake</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUB-TAB 2: PROVISIONING QUEUE */}
      {activeSubTab === 'queue' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                <span>WHMCS Module Command Queue</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Automated cPanel, DirectAdmin, and SolusVM account creation, suspension, and password resets.
              </p>
            </div>

            <button
              onClick={() => handleRunCronManually('Module Command Queue Processor')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Process Pending Queue Now</span>
            </button>
          </div>

          <div className="space-y-3">
            {queue.map((q) => (
              <div key={q.id} className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-white text-sm">{q.domain}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-950 text-indigo-300">
                      {q.action}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">({q.packageName})</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Server: <strong className="text-slate-300">{q.serverName}</strong> • Queued At: {q.queuedAt}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  {q.status === 'success' ? (
                    <span className="px-3 py-1 bg-emerald-950 text-emerald-400 font-extrabold rounded-lg text-xs flex items-center gap-1 border border-emerald-800">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                    </span>
                  ) : (
                    <button
                      onClick={() => handleProcessQueueItem(q.id)}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs flex items-center gap-1 shadow"
                    >
                      <Play className="w-3.5 h-3.5" /> Execute Action
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: WHMCS CRON AUTOMATION LOGS */}
      {activeSubTab === 'cron' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Clock className="w-5 h-5 text-emerald-400" />
                <span>WHMCS System Cron Task History</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Audit trail for WHMCS daily billing, domain status synchronization, auto-suspension, and SSL issuance.
              </p>
            </div>

            <button
              onClick={() => handleRunCronManually('WHMCS Master Cron Trigger')}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow flex items-center gap-2"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Run Master Cron</span>
            </button>
          </div>

          <div className="space-y-3">
            {cronLogs.map((log) => (
              <div key={log.id} className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/60 text-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-white text-sm">{log.jobName}</span>
                  <span className="text-[11px] font-mono text-slate-400">{log.executedAt}</span>
                </div>
                <p className="text-slate-300 text-xs">{log.details}</p>
                <div className="flex items-center justify-between pt-1 text-[11px] font-mono text-slate-400">
                  <span>Category: {log.category}</span>
                  <span className="text-emerald-400 font-bold">Processed: {log.recordsProcessed} record(s)</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 4: HOSTING PRODUCTS CATALOG */}
      {activeSubTab === 'packages' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {packages.map((pkg) => (
            <div key={pkg.id} className="p-5 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-950 text-indigo-300">
                    {pkg.category}
                  </span>
                  <h3 className="font-extrabold text-white text-base mt-1">{pkg.name}</h3>
                </div>
                <div className="text-right font-mono">
                  <div className="text-xl font-black text-emerald-400">${pkg.priceMonthly.toFixed(2)}<span className="text-xs text-slate-400">/mo</span></div>
                  <div className="text-[10px] text-slate-400">${pkg.priceAnnually.toFixed(2)} /year</div>
                </div>
              </div>

              <p className="text-xs text-slate-400">{pkg.description}</p>

              <div className="p-3 bg-slate-950 rounded-xl text-xs grid grid-cols-3 gap-2 font-mono text-slate-300 border border-slate-800/80">
                <div><span className="text-slate-500 text-[10px] block">Storage</span>{pkg.diskLimitMb === 0 ? 'Unlimited' : `${pkg.diskLimitMb / 1024} GB`}</div>
                <div><span className="text-slate-500 text-[10px] block">Bandwidth</span>{pkg.bandwidthLimitGb === 0 ? 'Unlimited' : `${pkg.bandwidthLimitGb} GB`}</div>
                <div><span className="text-slate-500 text-[10px] block">Databases</span>{pkg.maxDatabases === 0 ? 'Unlimited' : pkg.maxDatabases}</div>
              </div>

              <div className="space-y-1 text-xs text-slate-300 pt-1">
                {pkg.features.map((f, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 text-[11px]">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{f}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUB-TAB 5: WHM API CREDENTIALS & KEYS */}
      {activeSubTab === 'whm_api' && (
        <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800 space-y-5">
          <div className="flex items-center gap-3">
            <Key className="w-6 h-6 text-purple-400" />
            <div>
              <h3 className="font-extrabold text-white text-base">WHM Remote API Tokens & Access Hashes</h3>
              <p className="text-xs text-slate-400">
                Configure your cPanel/WHM API Tokens, DirectAdmin login keys, or Plesk API secrets for auto-provisioning.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <label className="text-xs font-bold text-slate-300 block">cPanel / WHM API Token (Root or Reseller)</label>
              <input
                type="password"
                readOnly
                value="whm_token_live_sec_99281928129381928391283912"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 font-mono text-xs text-emerald-400 focus:outline-none"
              />
              <p className="text-[11px] text-slate-500">
                Grants WHMCS system permission to automatically generate cPanel accounts, suspend users, and modify package quotas.
              </p>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <label className="text-xs font-bold text-slate-300 block">DirectAdmin Command Line API Key</label>
              <input
                type="password"
                readOnly
                value="da_cmd_key_8829102910"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 font-mono text-xs text-sky-400 focus:outline-none"
              />
            </div>
          </div>
        </div>
      )}

      {/* ADD SERVER MODAL */}
      {showAddServerModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-white text-base">Connect New WHM / Control Panel Host</h3>
              <button onClick={() => setShowAddServerModal(false)} className="text-slate-400 hover:text-white font-bold text-xs">
                ✕
              </button>
            </div>

            <form onSubmit={handleAddServer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Server Display Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. US-West cPanel Cluster 02"
                  value={newSrvName}
                  onChange={(e) => setNewSrvName(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Hostname</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. whm02.us-west.apexhosting.net"
                  value={newSrvHost}
                  onChange={(e) => setNewSrvHost(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Primary IP Address</label>
                <input
                  type="text"
                  placeholder="e.g. 198.51.100.120"
                  value={newSrvIp}
                  onChange={(e) => setNewSrvIp(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Control Panel Module</label>
                <select
                  value={newSrvModule}
                  onChange={(e: any) => setNewSrvModule(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="cpanel">cPanel / WHM API Module</option>
                  <option value="directadmin">DirectAdmin Module</option>
                  <option value="plesk">Plesk Obsidian Module</option>
                  <option value="solusvm">SolusVM KVM Module</option>
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddServerModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl shadow"
                >
                  Connect & Verify Handshake
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
