import React, { useState, useEffect } from 'react';
import { X, Shield, Globe, Clock, Server, CheckCircle2, AlertCircle, Bell, Mail, Copy, Check } from 'lucide-react';
import { WhoisData } from '../types';

interface WhoisModalProps {
  domainName: string;
  onClose: () => void;
}

export const WhoisModal: React.FC<WhoisModalProps> = ({ domainName, onClose }) => {
  const [loading, setLoading] = useState(true);
  const [whois, setWhois] = useState<WhoisData | null>(null);
  const [activeTab, setActiveTab] = useState<'structured' | 'raw'>('structured');
  const [copied, setCopied] = useState(false);
  const [alertEmail, setAlertEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    fetch(`/api/whois/${encodeURIComponent(domainName)}`)
      .then((res) => res.json())
      .then((data) => {
        if (isMounted) {
          setWhois(data.whois);
          setLoading(false);
        }
      })
      .catch(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [domainName]);

  const handleCopyRaw = () => {
    if (whois?.rawWhoisText) {
      navigator.clipboard.writeText(whois.rawWhoisText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (alertEmail) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setAlertEmail('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white">Domain Registration Details</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">{domainName}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 pt-3 border-b border-slate-200 dark:border-slate-800 flex items-center gap-4 bg-white dark:bg-slate-900">
          <button
            onClick={() => setActiveTab('structured')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 ${
              activeTab === 'structured'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Structured Overview
          </button>
          <button
            onClick={() => setActiveTab('raw')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 ${
              activeTab === 'raw'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Raw Domain Registry Output
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {loading ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs text-slate-500 font-medium">Querying ICANN WHOIS Registry Servers...</p>
            </div>
          ) : whois ? (
            activeTab === 'structured' ? (
              <div className="space-y-6">
                
                {/* Primary Status Banner */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${
                  whois.status.includes('AVAILABLE')
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                }`}>
                  <div className="flex items-center gap-2.5">
                    {whois.status.includes('AVAILABLE') ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
                    )}
                    <div>
                      <div className="font-extrabold text-sm">{whois.domainName}</div>
                      <div className="text-xs font-medium opacity-90">{whois.status}</div>
                    </div>
                  </div>
                </div>

                {/* Grid Properties */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium">Registrar:</span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.registrar}</div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium">Registrant Entity:</span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.registrantOrganization}</div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium">Creation Date:</span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.creationDate}</div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
                    <span className="text-slate-400 font-medium">Expiration Date:</span>
                    <div className="font-bold text-slate-800 dark:text-slate-200">{whois.expirationDate}</div>
                  </div>
                </div>

                {/* Name Servers */}
                {whois.nameServers.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5" /> Name Servers
                    </h4>
                    <div className="bg-slate-900 text-slate-200 rounded-xl p-3 font-mono text-xs space-y-1">
                      {whois.nameServers.map((ns, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <span className="text-blue-400 font-bold">NS{idx + 1}:</span> {ns}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Backorder / Drop Alert Form */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-blue-900/30 to-indigo-900/30 border border-blue-500/20 space-y-3">
                  <div className="flex items-center gap-2 text-blue-300 font-bold text-xs">
                    <Bell className="w-4 h-4 text-blue-400" />
                    <span>Get Notified on Expiration or Status Change</span>
                  </div>
                  <form onSubmit={handleSubscribe} className="flex gap-2">
                    <input
                      type="email"
                      required
                      value={alertEmail}
                      onChange={(e) => setAlertEmail(e.target.value)}
                      placeholder="Enter your email address..."
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white border border-slate-300 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg transition-colors shrink-0"
                    >
                      Subscribe
                    </button>
                  </form>
                  {subscribed && (
                    <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Alert set! We will email you when {domainName} becomes available.
                    </div>
                  )}
                </div>

              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">Raw Text Query Result</span>
                  <button
                    onClick={handleCopyRaw}
                    className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'Copied' : 'Copy WHOIS'}
                  </button>
                </div>
                <pre className="bg-slate-950 text-emerald-400 p-4 rounded-xl font-mono text-xs overflow-x-auto whitespace-pre-wrap max-h-80 leading-relaxed border border-slate-800">
                  {whois.rawWhoisText}
                </pre>
              </div>
            )
          ) : null}
        </div>

      </div>
    </div>
  );
};
