import React, { useState } from 'react';
import { 
  ShieldCheck, 
  User, 
  Users, 
  Server, 
  Globe, 
  CreditCard, 
  FileText, 
  Activity, 
  Lock, 
  CheckCircle2, 
  AlertTriangle, 
  Search, 
  Clock, 
  RefreshCw, 
  Eye, 
  Key, 
  Building2, 
  Smartphone, 
  LogOut,
  Sliders,
  Filter,
  Check,
  XCircle,
  HelpCircle
} from 'lucide-react';
import { systemDatabase, SystemUser } from '../services/systemDatabase';
import { ModulePermissions, PlatformRole } from '../types';

interface StaffPortalViewProps {
  currentUser: SystemUser;
  onNavigateToView?: (view: string) => void;
}

export const StaffPortalView: React.FC<StaffPortalViewProps> = ({
  currentUser,
  onNavigateToView
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'customers' | 'services' | 'billing' | 'audit' | 'profile'>('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const permissions: ModulePermissions = currentUser.permissions || {
    customers: { view: true, create: false, edit: true, suspend: false, delete: false },
    domains: { view: true, register: true, transfer: true, editDns: true, delete: false },
    hosting: { view: true, provision: true, suspend: true, unsuspend: true, terminate: false },
    billing: { viewInvoices: true, createInvoice: false, refundPayment: false, managePaymentSettings: false },
    servers: { view: true, manage: false, restart: false },
    staff: { view: false, create: false, edit: false, suspend: false, manageRoles: false },
    systemSettings: { view: false, edit: false },
    auditLogs: { view: true, export: false },
  };

  const allUsers = systemDatabase.getUsers();
  const clientUsers = allUsers.filter(u => u.role === 'client' || u.role === 'customer');
  const auditLogs = systemDatabase.getAuditLogs();
  const provisionAccounts = systemDatabase.getProvisionedAccounts();
  const activeSessions = systemDatabase.getUserSessions(currentUser.id);
  const loginActivity = systemDatabase.getLoginActivityRecords(currentUser.id);

  const filteredClients = clientUsers.filter(u => 
    u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.companyName && u.companyName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleLogout = () => {
    systemDatabase.logoutUser();
    if (onNavigateToView) onNavigateToView('home');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans p-4 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
            <div className="flex items-center gap-4">
              <img 
                src={currentUser.avatarUrl || "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop"} 
                alt={currentUser.fullName} 
                className="w-16 h-16 rounded-2xl object-cover ring-4 ring-indigo-500/30 border border-indigo-400/30 shadow-xl"
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-black uppercase tracking-wider rounded-full flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                    Celoxa Staff Member
                  </span>
                  <span className="px-2.5 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold rounded-md">
                    {currentUser.department || 'Technical Operations'}
                  </span>
                </div>
                <h1 className="text-2xl lg:text-3xl font-black text-white tracking-tight mt-1">
                  {currentUser.fullName}
                </h1>
                <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                  <span>{currentUser.staffTitle || 'Support Lead'}</span>
                  <span>•</span>
                  <span>{currentUser.email}</span>
                  <span>•</span>
                  <span className="text-slate-500">ID: {currentUser.id}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              {onNavigateToView && (
                <button 
                  onClick={() => onNavigateToView('home')}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition-all"
                >
                  Public Website
                </button>
              )}
              <button 
                onClick={handleLogout}
                className="px-4 py-2.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 text-xs font-bold rounded-xl border border-rose-500/30 transition-all flex items-center gap-2"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            </div>
          </div>
        </div>

        {/* Permission Overview Notification */}
        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3 text-slate-300">
            <Lock className="w-4 h-4 text-indigo-400 shrink-0" />
            <span>
              <strong>RBAC Permission Engine:</strong> Active scope enforced. Module actions are restricted based on your assigned staff role matrix.
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.customers.view ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Clients</span>
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.hosting.view ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Hosting</span>
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.billing.viewInvoices ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Billing</span>
            <span className={`px-2 py-0.5 rounded font-bold ${permissions.auditLogs.view ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>Audit Logs</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'overview'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Activity className="w-4 h-4" />
            Shift Overview
          </button>

          {permissions.customers.view && (
            <button
              onClick={() => setActiveTab('customers')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'customers'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              Client Directory ({clientUsers.length})
            </button>
          )}

          {permissions.hosting.view && (
            <button
              onClick={() => setActiveTab('services')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'services'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Server className="w-4 h-4" />
              Provisioning Queue ({provisionAccounts.length})
            </button>
          )}

          {permissions.billing.viewInvoices && (
            <button
              onClick={() => setActiveTab('billing')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'billing'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              Billing & Transactions
            </button>
          )}

          {permissions.auditLogs.view && (
            <button
              onClick={() => setActiveTab('audit')}
              className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
                activeTab === 'audit'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              Platform Audit Logs
            </button>
          )}

          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
              activeTab === 'profile'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <User className="w-4 h-4" />
            Staff Security Profile
          </button>
        </div>

        {/* STATUS ALERT */}
        {statusMessage && (
          <div className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between border ${
            statusMessage.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
          }`}>
            <span>{statusMessage.text}</span>
            <button onClick={() => setStatusMessage(null)} className="text-slate-400 hover:text-white">✕</button>
          </div>
        )}

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Assigned Department</span>
                  <Building2 className="w-4 h-4 text-indigo-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{currentUser.department || 'Operations'}</p>
                <p className="text-[11px] text-slate-500 mt-1">Role: {currentUser.staffTitle}</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Total Managed Clients</span>
                  <Users className="w-4 h-4 text-emerald-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{clientUsers.length} Active Accounts</p>
                <p className="text-[11px] text-emerald-400 mt-1">GH₵ and USD Wallets verified</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Provisioning Tasks</span>
                  <Server className="w-4 h-4 text-cyan-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{provisionAccounts.length} Clusters</p>
                <p className="text-[11px] text-slate-400 mt-1">cPanel & Plesk automated nodes</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl">
                <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
                  <span>Audit Trail Log Entries</span>
                  <Activity className="w-4 h-4 text-amber-400" />
                </div>
                <p className="text-xl font-black text-white mt-2">{auditLogs.length} Events Logged</p>
                <p className="text-[11px] text-slate-400 mt-1">Real-time system events</p>
              </div>
            </div>

            {/* Shift Activity & Task Queue */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Staff Operations Matrix
                </h2>
                <p className="text-xs text-slate-400">
                  Welcome to the Celoxa Staff Workspace. Based on your assigned department permissions, you can manage client billing, monitor automated provisioning queues, and view system audit records.
                </p>
                <div className="space-y-2 pt-2">
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs flex items-center justify-between">
                    <span className="text-slate-300">Customer Account Access</span>
                    <span className={`font-bold ${permissions.customers.view ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {permissions.customers.view ? 'READ / WRITE' : 'RESTRICTED'}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs flex items-center justify-between">
                    <span className="text-slate-300">Hosting Provisioning & Suspend</span>
                    <span className={`font-bold ${permissions.hosting.provision ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {permissions.hosting.provision ? 'FULL PROVISIONING' : 'READ ONLY'}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs flex items-center justify-between">
                    <span className="text-slate-300">Staff & Role Management</span>
                    <span className="font-bold text-rose-400">SUPER ADMIN ONLY</span>
                  </div>
                </div>
              </div>

              {/* Recent Audit Entries */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <Clock className="w-4 h-4 text-indigo-400" />
                  Recent System Events
                </h2>
                <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                  {auditLogs.slice(0, 5).map(log => (
                    <div key={log.id} className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-indigo-300">{log.action}</span>
                        <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                      </div>
                      <p className="text-slate-400 text-[11px]">{log.details}</p>
                      <div className="text-[10px] text-slate-500 flex items-center justify-between">
                        <span>Actor: {log.actor}</span>
                        <span>IP: {log.ipAddress}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: CUSTOMERS */}
        {activeTab === 'customers' && permissions.customers.view && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="relative w-full sm:w-96">
                <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder="Search client by name, email, or company..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <span className="text-xs text-slate-400 font-bold">
                Showing {filteredClients.length} client accounts
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                      <th className="p-4 font-extrabold uppercase">Client Name</th>
                      <th className="p-4 font-extrabold uppercase">Company / Phone</th>
                      <th className="p-4 font-extrabold uppercase">Status</th>
                      <th className="p-4 font-extrabold uppercase">Wallet Balances</th>
                      <th className="p-4 font-extrabold uppercase text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredClients.map(client => (
                      <tr key={client.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img 
                              src={client.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop"} 
                              alt="" 
                              className="w-9 h-9 rounded-xl object-cover"
                            />
                            <div>
                              <p className="font-extrabold text-white">{client.fullName}</p>
                              <p className="text-[11px] text-slate-400">{client.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="font-bold text-slate-200">{client.companyName || 'Individual'}</p>
                          <p className="text-[11px] text-slate-400">{client.phone || 'N/A'}</p>
                        </td>
                        <td className="p-4">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            client.accountStatus === 'active' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' :
                            client.accountStatus === 'suspended' ? 'bg-rose-500/10 border border-rose-500/30 text-rose-400' :
                            'bg-amber-500/10 border border-amber-500/30 text-amber-400'
                          }`}>
                            {client.accountStatus || 'ACTIVE'}
                          </span>
                        </td>
                        <td className="p-4 font-mono font-bold">
                          <p className="text-emerald-400">GH₵ {(client.walletBalanceGhs || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                          <p className="text-slate-400 text-[11px]">$ {(client.walletBalanceUsd || 0).toFixed(2)} USD</p>
                        </td>
                        <td className="p-4 text-right">
                          <button 
                            onClick={() => {
                              systemDatabase.topUpUserWallet(client.id, 100, 7);
                              setStatusMessage({ type: 'success', text: `Credited GH₵100 wallet adjustment to ${client.fullName}` });
                            }}
                            className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 font-bold text-[11px] rounded-lg border border-indigo-500/30 transition-all"
                          >
                            + GH₵100 Adjustment
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SERVICES / PROVISIONING QUEUE */}
        {activeTab === 'services' && permissions.hosting.view && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
              <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Server className="w-4 h-4 text-indigo-400" />
                Active Hosting Provisioning Tasks
              </h2>
              <div className="space-y-3">
                {provisionAccounts.map((task, idx) => (
                  <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
                    <div>
                      <p className="font-extrabold text-white text-sm">{task.domain}</p>
                      <p className="text-slate-400 text-[11px]">Server: {task.serverNodeName} • Package: {task.packageName}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold rounded-lg">
                        {task.status || 'ACTIVE_PROVISIONED'}
                      </span>
                      <button 
                        onClick={() => setStatusMessage({ type: 'success', text: `Provisioning ping sent for ${task.domain}` })}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] rounded-lg border border-slate-700"
                      >
                        Ping Node
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: BILLING */}
        {activeTab === 'billing' && permissions.billing.viewInvoices && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-400" />
              Staff Invoice & MoMo Payment Audit
            </h2>
            <p className="text-xs text-slate-400">
              Review transaction histories and Mobile Money (MTN MoMo, Telecel Cash, AT Money) payment gateways.
            </p>
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl text-xs space-y-2">
              <div className="flex items-center justify-between font-bold text-slate-200">
                <span>Ghana MoMo Gateway Intermediary</span>
                <span className="text-emerald-400">OPERATIONAL</span>
              </div>
              <p className="text-slate-400 text-[11px]">Instant Mobile Money callback listener running on port 3000 API routes.</p>
            </div>
          </div>
        )}

        {/* TAB 5: AUDIT LOGS */}
        {activeTab === 'audit' && permissions.auditLogs.view && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              Platform Audit Logs
            </h2>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {auditLogs.map(log => (
                <div key={log.id} className="p-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-300">{log.action}</span>
                    <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                  </div>
                  <p className="text-slate-300 font-mono text-[11px]">{log.target}: {log.details}</p>
                  <div className="text-[10px] text-slate-500 flex items-center justify-between">
                    <span>Actor: {log.actor}</span>
                    <span>IP: {log.ipAddress}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: SECURITY PROFILE */}
        {activeTab === 'profile' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
            <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Key className="w-4 h-4 text-indigo-400" />
              Staff Security & Session Management
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <h3 className="font-extrabold text-xs text-slate-200 uppercase">Multi-Factor Authentication</h3>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Status:</span>
                  <span className="font-bold text-emerald-400">ENABLED (TOTP Authenticator)</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Staff accounts require 2FA enforcement for all sensitive administrative operations.
                </p>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <h3 className="font-extrabold text-xs text-slate-200 uppercase">Active Web Sessions ({activeSessions.length})</h3>
                <div className="space-y-2">
                  {activeSessions.map(sess => (
                    <div key={sess.id} className="p-2 bg-slate-900 rounded-lg text-[11px] flex items-center justify-between">
                      <div>
                        <p className="font-bold text-slate-200">{sess.device}</p>
                        <p className="text-[10px] text-slate-500">{sess.ip} • {sess.location}</p>
                      </div>
                      {sess.isCurrent ? (
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold text-[10px] rounded">Current</span>
                      ) : (
                        <button 
                          onClick={() => {
                            systemDatabase.revokeSession(sess.id);
                            setStatusMessage({ type: 'success', text: 'Revoked staff web session' });
                          }}
                          className="text-rose-400 hover:underline font-bold text-[10px]"
                        >
                          Revoke
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
