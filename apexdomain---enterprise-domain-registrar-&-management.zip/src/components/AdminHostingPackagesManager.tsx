import React, { useState } from 'react';
import {
  Server,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  HardDrive,
  Zap,
  Database,
  Mail,
  DollarSign,
  Globe,
  Layers,
  Settings,
  RefreshCw,
  Search,
  ShieldCheck,
  Cpu,
  Activity,
  X,
  Copy
} from 'lucide-react';
import { WhmcsHostingPackage, WhmcsServerNode, WhmcsModuleType, Currency } from '../types';
import { MOCK_WHMCS_SERVERS } from '../data/mockWhmcsData';
import { formatPrice } from '../utils/domainSearchEngine';

interface AdminHostingPackagesManagerProps {
  hostingPackages: WhmcsHostingPackage[];
  onAddPackage: (pkg: WhmcsHostingPackage) => void;
  onUpdatePackage: (pkg: WhmcsHostingPackage) => void;
  onDeletePackage: (id: string) => void;
  currency?: Currency;
}

export const AdminHostingPackagesManager: React.FC<AdminHostingPackagesManagerProps> = ({
  hostingPackages,
  onAddPackage,
  onUpdatePackage,
  onDeletePackage,
  currency = 'USD'
}) => {
  const [activeTab, setActiveTab] = useState<'packages' | 'servers'>('packages');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Modal States
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState<WhmcsHostingPackage | null>(null);

  // New Package Form State
  const [formState, setFormState] = useState<Omit<WhmcsHostingPackage, 'id'>>({
    name: '',
    category: 'Shared Web Hosting',
    module: 'cpanel',
    description: '',
    diskLimitMb: 20000,
    bandwidthLimitGb: 500,
    maxDatabases: 10,
    maxSubdomains: 10,
    maxMailboxes: 20,
    priceMonthly: 7.99,
    priceAnnually: 79.90,
    freeDomainEligible: true,
    features: ['cPanel Control Panel', 'Free Wildcard SSL', 'Daily Backups', '1-Click App Installer']
  });

  const [featureInput, setFeatureInput] = useState('');

  const filteredPackages = hostingPackages.filter(pkg => {
    const matchesSearch = pkg.name.toLowerCase().includes(searchQuery.toLowerCase()) || pkg.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'all' || pkg.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handleOpenCreateModal = () => {
    setFormState({
      name: '',
      category: 'Shared Web Hosting',
      module: 'cpanel',
      description: '',
      diskLimitMb: 20000,
      bandwidthLimitGb: 500,
      maxDatabases: 10,
      maxSubdomains: 10,
      maxMailboxes: 20,
      priceMonthly: 7.99,
      priceAnnually: 79.90,
      freeDomainEligible: true,
      features: ['cPanel Control Panel', 'Free Wildcard SSL', 'Daily Backups', '1-Click App Installer']
    });
    setEditingPackage(null);
    setIsCreateModalOpen(true);
  };

  const handleOpenEditModal = (pkg: WhmcsHostingPackage) => {
    setEditingPackage(pkg);
    setFormState({
      name: pkg.name,
      category: pkg.category,
      module: pkg.module,
      description: pkg.description,
      diskLimitMb: pkg.diskLimitMb,
      bandwidthLimitGb: pkg.bandwidthLimitGb,
      maxDatabases: pkg.maxDatabases,
      maxSubdomains: pkg.maxSubdomains,
      maxMailboxes: pkg.maxMailboxes,
      priceMonthly: pkg.priceMonthly,
      priceAnnually: pkg.priceAnnually,
      freeDomainEligible: pkg.freeDomainEligible,
      features: [...pkg.features]
    });
    setIsCreateModalOpen(true);
  };

  const handleAddFeature = () => {
    if (featureInput.trim()) {
      setFormState(prev => ({ ...prev, features: [...prev.features, featureInput.trim()] }));
      setFeatureInput('');
    }
  };

  const handleRemoveFeature = (index: number) => {
    setFormState(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name.trim()) return;

    if (editingPackage) {
      const updated: WhmcsHostingPackage = {
        ...formState,
        id: editingPackage.id
      };
      onUpdatePackage(updated);
    } else {
      const newPkg: WhmcsHostingPackage = {
        ...formState,
        id: `pkg-${Date.now()}`
      };
      onAddPackage(newPkg);
    }

    setIsCreateModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold mb-2">
              <Server className="w-3.5 h-3.5 text-indigo-400" />
              <span>WHMCS & Server Cluster Control</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Hosting Package & Server Admin
            </h1>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              Create, edit, and publish Web Hosting plans, Cloud VPS tiers, and WHMCS provisioning server nodes.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleOpenCreateModal}
              className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-2xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Package</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('packages')}
          className={`pb-2 text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'packages'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Active Hosting Packages ({hostingPackages.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('servers')}
          className={`pb-2 text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'servers'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>Provisioning Server Nodes ({MOCK_WHMCS_SERVERS.length})</span>
        </button>
      </div>

      {activeTab === 'packages' ? (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search packages by title or specs..."
                className="w-full pl-9 pr-4 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
              >
                <option value="all">All Categories</option>
                <option value="Shared Web Hosting">Shared Web Hosting</option>
                <option value="WordPress Cloud">WordPress Cloud</option>
                <option value="Reseller Hosting">Reseller Hosting</option>
                <option value="KVM VPS">KVM VPS</option>
                <option value="Dedicated Server">Dedicated Server</option>
              </select>
            </div>
          </div>

          {/* Packages Table / Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                        {pkg.category}
                      </span>
                      <h3 className="text-lg font-black text-slate-900 dark:text-white mt-2">
                        {pkg.name}
                      </h3>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          const duplicated: WhmcsHostingPackage = {
                            ...pkg,
                            id: `pkg-${Date.now()}`,
                            name: `${pkg.name} (Copy)`
                          };
                          onAddPackage(duplicated);
                        }}
                        className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
                        title="Duplicate Package"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleOpenEditModal(pkg)}
                        className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
                        title="Edit Package"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeletePackage(pkg.id)}
                        className="p-2 text-slate-400 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
                        title="Delete Package"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                    {pkg.description}
                  </p>

                  <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Monthly</span>
                      <div className="text-sm font-black text-slate-900 dark:text-white">
                        {formatPrice(pkg.priceMonthly, currency)} / mo
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Annual</span>
                      <div className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                        {formatPrice(pkg.priceAnnually, currency)} / yr
                      </div>
                    </div>
                  </div>

                  {/* Specs */}
                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Storage:</span>
                      <span className="font-bold">{pkg.diskLimitMb === 0 ? 'Unlimited' : `${pkg.diskLimitMb / 1000} GB`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Bandwidth:</span>
                      <span className="font-bold">{pkg.bandwidthLimitGb === 0 ? 'Unlimited' : `${pkg.bandwidthLimitGb} GB`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">WHMCS Module:</span>
                      <span className="font-mono font-bold uppercase text-indigo-500">{pkg.module}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Live on Frontend Hosting Storefront</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Server Nodes Tab */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {MOCK_WHMCS_SERVERS.map((server) => (
            <div
              key={server.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                    {server.status.toUpperCase()}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mt-2">
                    {server.name}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    {server.hostname} ({server.ipAddress})
                  </p>
                </div>

                <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-indigo-500">
                  <Server className="w-5 h-5" />
                </div>
              </div>

              {/* Server Load Gauges */}
              <div className="grid grid-cols-3 gap-3 text-center pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="p-2 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-bold">CPU Load</span>
                  <div className="text-sm font-black text-slate-900 dark:text-white">{server.cpuLoadPercentage}%</div>
                </div>
                <div className="p-2 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-bold">RAM Usage</span>
                  <div className="text-sm font-black text-slate-900 dark:text-white">{server.ramUsagePercentage}%</div>
                </div>
                <div className="p-2 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-bold">Accounts</span>
                  <div className="text-sm font-black text-indigo-600 dark:text-indigo-400">{server.activeAccounts} / {server.maxAccounts}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Create or Edit Package */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl my-8 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h2 className="text-xl font-black">
                {editingPackage ? 'Edit Hosting Package' : 'Create New Hosting Package'}
              </h2>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Package Name</label>
                  <input
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    placeholder="e.g. Ultra NVMe Business Pro"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Category</label>
                  <select
                    value={formState.category}
                    onChange={(e: any) => setFormState({ ...formState, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold"
                  >
                    <option value="Shared Web Hosting">Shared Web Hosting</option>
                    <option value="WordPress Cloud">WordPress Cloud</option>
                    <option value="Reseller Hosting">Reseller Hosting</option>
                    <option value="KVM VPS">KVM VPS</option>
                    <option value="Dedicated Server">Dedicated Server</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">WHMCS Module</label>
                  <select
                    value={formState.module}
                    onChange={(e: any) => setFormState({ ...formState, module: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold"
                  >
                    <option value="cpanel">cPanel / WHM</option>
                    <option value="directadmin">DirectAdmin</option>
                    <option value="plesk">Plesk Obsidian</option>
                    <option value="solusvm">SolusVM (VPS)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Free Domain Eligibility</label>
                  <select
                    value={formState.freeDomainEligible ? 'yes' : 'no'}
                    onChange={(e) => setFormState({ ...formState, freeDomainEligible: e.target.value === 'yes' })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold"
                  >
                    <option value="yes">Eligible for Free Domain</option>
                    <option value="no">Not Eligible</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">Description</label>
                <textarea
                  rows={2}
                  value={formState.description}
                  onChange={(e) => setFormState({ ...formState, description: e.target.value })}
                  placeholder="Describe package performance & target audience..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              {/* Resource Limits */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Disk (MB)</label>
                  <input
                    type="number"
                    value={formState.diskLimitMb}
                    onChange={(e) => setFormState({ ...formState, diskLimitMb: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Bandwidth (GB)</label>
                  <input
                    type="number"
                    value={formState.bandwidthLimitGb}
                    onChange={(e) => setFormState({ ...formState, bandwidthLimitGb: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Max Databases</label>
                  <input
                    type="number"
                    value={formState.maxDatabases}
                    onChange={(e) => setFormState({ ...formState, maxDatabases: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Max Mailboxes</label>
                  <input
                    type="number"
                    value={formState.maxMailboxes}
                    onChange={(e) => setFormState({ ...formState, maxMailboxes: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono"
                  />
                </div>
              </div>

              {/* Pricing Inputs */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Monthly Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formState.priceMonthly}
                    onChange={(e) => setFormState({ ...formState, priceMonthly: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">Annual Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formState.priceAnnually}
                    onChange={(e) => setFormState({ ...formState, priceAnnually: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono font-bold"
                  />
                </div>
              </div>

              {/* Feature Checklist Builder */}
              <div className="space-y-2">
                <label className="font-bold text-slate-300">Feature Bullet Points</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={featureInput}
                    onChange={(e) => setFeatureInput(e.target.value)}
                    placeholder="e.g. Free Redis Caching..."
                    className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddFeature}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 font-bold text-white rounded-xl"
                  >
                    Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-2 pt-1">
                  {formState.features.map((feat, index) => (
                    <span key={index} className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-200 text-[11px] flex items-center gap-1.5">
                      <span>{feat}</span>
                      <button type="button" onClick={() => handleRemoveFeature(index)} className="text-slate-400 hover:text-red-400 font-bold">
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30"
                >
                  {editingPackage ? 'Save Changes' : 'Publish Package Live'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
