import React, { useState } from 'react';
import { 
  Search, 
  Zap, 
  ShieldCheck, 
  Server, 
  Globe, 
  CheckCircle2, 
  MessageCircle, 
  ArrowRight, 
  Sparkles, 
  Headphones, 
  HardDrive, 
  Lock, 
  Cpu, 
  DollarSign, 
  Star,
  Building,
  Check,
  ChevronRight,
  TrendingUp,
  CreditCard,
  ShoppingCart
} from 'lucide-react';
import { Currency, WhmcsHostingPackage } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';
import { systemDatabase } from '../services/systemDatabase';

interface VikalinkHomepageProps {
  onExecuteSearch: (query: string) => void;
  currency: Currency;
  onOpenAuthModal?: () => void;
  onOpenHostingModal?: () => void;
  onAddToCart?: (item: any) => void;
  onOpenCart?: () => void;
  hostingPackages?: WhmcsHostingPackage[];
  cartItems?: any[];
}

export const VikalinkHomepage: React.FC<VikalinkHomepageProps> = ({
  onExecuteSearch,
  currency,
  onOpenAuthModal,
  onOpenHostingModal,
  onAddToCart,
  onOpenCart,
  hostingPackages: propPackages,
  cartItems = []
}) => {
  const [heroSearchInput, setHeroSearchInput] = useState('');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually'>('monthly');
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<string>('All');
  const [addedSuccessId, setAddedSuccessId] = useState<string | null>(null);

  // Load hosting packages from database if not passed or empty
  const packages = propPackages && propPackages.length > 0
    ? propPackages
    : systemDatabase.getHostingPackages();

  // Unique categories
  const categories = ['All', ...Array.from(new Set(packages.map(p => p.category)))];

  const filteredPackages = selectedCategoryTab === 'All'
    ? packages
    : packages.filter(p => p.category === selectedCategoryTab);

  const handleAddPackageToCart = (pkg: WhmcsHostingPackage) => {
    const rawPrice = billingCycle === 'annually' ? pkg.priceAnnually : pkg.priceMonthly;
    const cartItem = {
      id: `hosting-${pkg.id}-${Date.now()}`,
      itemType: 'hosting' as const,
      domainName: `hosting-${pkg.name.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
      planId: pkg.id,
      planName: pkg.name,
      billingCycle: billingCycle,
      price: rawPrice,
      category: pkg.category,
      module: pkg.module
    };

    onAddToCart?.(cartItem);
    setAddedSuccessId(pkg.id);
    setTimeout(() => {
      setAddedSuccessId(null);
    }, 2000);
  };

  const handleOrderNowDirect = (pkg: WhmcsHostingPackage) => {
    handleAddPackageToCart(pkg);
    onOpenCart?.();
  };

  const isPackageInCart = (pkgId: string) => {
    return cartItems.some(item => item.itemType === 'hosting' && item.planId === pkgId);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearchInput.trim()) {
      onExecuteSearch(heroSearchInput.trim());
    }
  };

  const handleTldQuickSearch = (tld: string) => {
    const term = heroSearchInput.trim() ? `${heroSearchInput.split('.')[0]}${tld}` : `mybrand${tld}`;
    onExecuteSearch(term);
  };

  const dbTlds = systemDatabase.getTlds();
  const ghanaFeatured = [
    { ext: '.com.gh', defaultPrice: 12, tag: 'Most Popular' },
    { ext: '.gh', defaultPrice: 22, tag: 'Premium' },
    { ext: '.org.gh', defaultPrice: 12, tag: 'Non-Profit' },
    { ext: '.edu.gh', defaultPrice: 12, tag: 'School/College' },
  ].map((item) => {
    const matched = dbTlds.find((t) => t.tld.toLowerCase() === item.ext.toLowerCase());
    const rawPrice = matched ? matched.registrationPrice : item.defaultPrice;
    return {
      ext: item.ext,
      price: `${formatPrice(rawPrice, currency)}`,
      tag: item.tag,
    };
  });

  return (
    <div className="space-y-12 pb-20 text-slate-900 dark:text-slate-100">
      
      {/* GHANA LOCAL .GH DOMAIN EXTENSIONS SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-blue-900/20 via-indigo-900/20 to-slate-900/40 border border-blue-500/30 rounded-3xl p-6 sm:p-8 relative overflow-hidden">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="space-y-3 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-black">
                <Globe className="w-4 h-4" /> Official Ghana Country Extensions (.GH)
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                Establish Your Brand Locally with a <span className="text-blue-500 dark:text-cyan-400">.com.gh</span> Domain
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-xl">
                Boost search rankings in Ghana, build maximum customer trust, and secure your company identity with official .GH, .com.gh, .org.gh, and .edu.gh extensions.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full lg:w-auto shrink-0">
              {ghanaFeatured.map((item) => (
                <button
                  key={item.ext}
                  onClick={() => handleTldQuickSearch(item.ext)}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 transition-all text-center group shadow-sm"
                >
                  <span className="text-xs font-extrabold uppercase text-blue-500 block">{item.tag}</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white group-hover:text-blue-500 transition-colors block">
                    {item.ext}
                  </span>
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block mt-1">
                    {item.price} /yr
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* WEB HOSTING PRICING PACKAGES - CELOXA DYNAMIC DB SYSTEM */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 text-xs font-extrabold">
            <Server className="w-4 h-4" /> Celoxa High-Performance Web Hosting
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-slate-900 dark:text-white">
            Fast, Reliable & Secure NVMe SSD Web Hosting
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-2xl mx-auto">
            Choose the perfect hosting plan for your business. Includes cPanel control panel, LiteSpeed Web Server, 1-click WordPress, and instant automated provisioning.
          </p>

          {/* Category Filter Tabs */}
          {categories.length > 2 && (
            <div className="flex items-center justify-center gap-2 flex-wrap pt-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategoryTab(cat)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    selectedCategoryTab === cat
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}

          {/* Monthly / Annual Toggle */}
          <div className="flex items-center justify-center pt-2">
            <div className="bg-slate-100 dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 inline-flex items-center gap-2">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all ${
                  billingCycle === 'monthly'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Monthly Billing
              </button>
              <button
                onClick={() => setBillingCycle('annually')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                  billingCycle === 'annually'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>Annual Billing</span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-black text-[9px]">
                  SAVE 20%
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* HOSTING PLAN CARDS (DYNAMIC FROM ADMIN DATABASE) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {filteredPackages.map((pkg, idx) => {
            const isPopular = idx === 1 || pkg.name.toLowerCase().includes('business') || pkg.name.toLowerCase().includes('pro');
            const inCart = isPackageInCart(pkg.id);
            const rawPrice = billingCycle === 'annually' ? pkg.priceAnnually : pkg.priceMonthly;
            const displayPrice = formatPrice(rawPrice, currency);

            return (
              <div
                key={pkg.id}
                className={`rounded-3xl p-6 sm:p-8 space-y-6 flex flex-col justify-between transition-all relative ${
                  isPopular
                    ? 'bg-slate-900 text-white border-2 border-cyan-500 shadow-2xl md:scale-105 z-10'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-md hover:shadow-xl'
                }`}
              >
                {isPopular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow-md">
                    ★ Most Popular in Ghana
                  </div>
                )}

                <div className="space-y-4 pt-1">
                  <div className="flex items-center justify-between">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black ${
                      isPopular ? 'bg-cyan-500/20 text-cyan-400' : 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                    }`}>
                      <HardDrive className="w-6 h-6" />
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-mono font-bold uppercase">
                      {pkg.module}
                    </span>
                  </div>

                  <div>
                    <h3 className={`text-xl font-black ${isPopular ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                      {pkg.name}
                    </h3>
                    <p className={`text-xs mt-0.5 ${isPopular ? 'text-cyan-200' : 'text-slate-500 dark:text-slate-400'}`}>
                      {pkg.description}
                    </p>
                  </div>

                  <div className={`pt-2 border-t ${isPopular ? 'border-slate-800' : 'border-slate-100 dark:border-slate-800'}`}>
                    <div className="flex items-baseline gap-1">
                      <span className={`text-3xl font-black ${isPopular ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                        {displayPrice}
                      </span>
                      <span className="text-xs font-bold text-slate-400">
                        {billingCycle === 'annually' ? '/ year' : '/ month'}
                      </span>
                    </div>
                  </div>

                  {/* Quotas & Features */}
                  <ul className={`space-y-2.5 text-xs font-medium ${isPopular ? 'text-slate-200' : 'text-slate-600 dark:text-slate-300'}`}>
                    <li className="flex items-center gap-2.5">
                      <Check className={`w-4 h-4 shrink-0 ${isPopular ? 'text-cyan-400' : 'text-emerald-500'}`} />
                      <span><strong>{pkg.diskLimitMb >= 1000 ? `${(pkg.diskLimitMb / 1024).toFixed(0)} GB` : `${pkg.diskLimitMb} MB`}</strong> Ultra-Fast NVMe Storage</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className={`w-4 h-4 shrink-0 ${isPopular ? 'text-cyan-400' : 'text-emerald-500'}`} />
                      <span><strong>{pkg.bandwidthLimitGb} GB</strong> Monthly Bandwidth</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <Check className={`w-4 h-4 shrink-0 ${isPopular ? 'text-cyan-400' : 'text-emerald-500'}`} />
                      <span><strong>{pkg.maxDatabases}</strong> MySQL Databases & Mailboxes</span>
                    </li>
                    {pkg.freeDomainEligible && (
                      <li className="flex items-center gap-2.5">
                        <Check className={`w-4 h-4 shrink-0 ${isPopular ? 'text-cyan-400' : 'text-emerald-500'}`} />
                        <span><strong>FREE</strong> Domain Name Included (.com / .com.gh)</span>
                      </li>
                    )}
                    {pkg.features && pkg.features.map((feat, fIdx) => (
                      <li key={fIdx} className="flex items-center gap-2.5">
                        <Check className={`w-4 h-4 shrink-0 ${isPopular ? 'text-cyan-400' : 'text-emerald-500'}`} />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Direct Checkout & Add to Cart Action Buttons */}
                <div className="pt-4 space-y-2">
                  <button
                    onClick={() => handleOrderNowDirect(pkg)}
                    className={`w-full py-3.5 px-4 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-2 shadow-lg ${
                      isPopular
                        ? 'bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 shadow-cyan-500/20 hover:scale-[1.02]'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 hover:scale-[1.02]'
                    }`}
                  >
                    <span>Order Now & Direct Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleAddPackageToCart(pkg)}
                    className={`w-full py-2.5 px-4 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${
                      addedSuccessId === pkg.id
                        ? 'bg-emerald-500 text-slate-950 font-black'
                        : inCart
                        ? 'bg-slate-800 text-indigo-300 border border-indigo-500/50'
                        : isPopular
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                        : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    {addedSuccessId === pkg.id ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-slate-950" />
                        <span>Added to Cart!</span>
                      </>
                    ) : inCart ? (
                      <>
                        <ShoppingCart className="w-4 h-4 text-indigo-400" />
                        <span>In Cart - Add Extra</span>
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-4 h-4" />
                        <span>Add to Cart</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </section>

      {/* WHY CHOOSE CELOXA FEATURES GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            Why Ghanaian Businesses Choose Celoxa Hosting
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto">
            Engineered for high performance, local Ghana mobile money payments, and zero-downtime website hosting.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-3 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/10 text-blue-500 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">LiteSpeed & NVMe Storage</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Experience up to 10x faster page loading speeds with our pure NVMe SSD arrays and LiteSpeed Web Server with built-in LSCache.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-3 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600/10 text-emerald-500 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Ghana MoMo & Paystack Integration</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Pay seamlessly using MTN Mobile Money, Telecel Cash, AT Money, or Visa/Mastercard. Instant automatic account activation upon payment.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-3 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/10 text-indigo-500 flex items-center justify-center">
              <Headphones className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">24/7 Local WhatsApp Support</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Never wait for email responses. Get immediate assistance via WhatsApp or phone directly from Ghanaian hosting experts in Kumasi & Accra.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-3 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-2xl bg-amber-600/10 text-amber-500 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">99.99% Guaranteed Server Uptime</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Our cloud servers are deployed across Tier-4 enterprise datacenters in the EU, UK, and USA with redundant network routing.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-3 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-2xl bg-cyan-600/10 text-cyan-500 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Free SSL & Daily Cloud Backups</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Automated Let's Encrypt SSL certificates issued for every domain, paired with daily offsite backup snapshots for peace of mind.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-3 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-2xl bg-rose-600/10 text-rose-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">Free Website Migration</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Switching from another host? Our technical team will migrate your WordPress files, databases, and emails to Celoxa completely free!
            </p>
          </div>

        </div>

      </section>

      {/* WHATSAPP SUPPORT DIRECT CTA BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-emerald-950 text-white border border-emerald-500/30 rounded-3xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl relative overflow-hidden">
          <div className="space-y-2 text-center md:text-left z-10">
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-black uppercase tracking-wider">
              Instant Ghana Client Support
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-white">
              Need Help Choosing a Plan or Migrating Your Site?
            </h3>
            <p className="text-xs sm:text-sm text-emerald-200 max-w-lg">
              Our local Ghanaian technical team is available 24/7 on WhatsApp to guide your domain registration or server setup.
            </p>
          </div>

          <a
            href="https://wa.me/233240000000"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm shadow-lg transition-all flex items-center gap-2 shrink-0 z-10 hover:scale-105"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Chat on WhatsApp Now</span>
          </a>
        </div>
      </section>

    </div>
  );
};
