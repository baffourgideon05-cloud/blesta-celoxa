import React, { useState } from 'react';
import { 
  ShieldCheck, 
  UserPlus, 
  Users, 
  Lock, 
  Mail, 
  Key, 
  Check, 
  X, 
  AlertCircle, 
  CheckCircle2, 
  Sliders, 
  Building, 
  Search, 
  Copy, 
  Trash2, 
  RefreshCw, 
  ShieldAlert, 
  Activity, 
  Clock, 
  Send,
  Eye,
  Info
} from 'lucide-react';
import { 
  systemDatabase, 
  SystemUser, 
  DEFAULT_SUPPORT_STAFF_PERMISSIONS, 
  DEFAULT_FINANCE_STAFF_PERMISSIONS, 
  DEFAULT_ADMIN_PERMISSIONS 
} from '../services/systemDatabase';
import { ModulePermissions, PlatformRole, UserAccountStatus, StaffInvitation } from '../types';

interface AdminIamManagementProps {
  currentUser: SystemUser;
}

export const AdminIamManagement: React.FC<AdminIamManagementProps> = ({ currentUser }) => {
  const users = systemDatabase.getUsers();
  const staffInvitations = systemDatabase.getStaffInvitations();
  const auditLogs = systemDatabase.getAuditLogs();

  const [activeTab, setActiveTab] = useState<'users' | 'invite' | 'invitations' | 'audit'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [selectedUserForEdit, setSelectedUserForEdit] = useState<SystemUser | null>(null);

  // Status Change Modal State
  const [statusModalUser, setStatusModalUser] = useState<SystemUser | null>(null);
  const [newStatus, setNewStatus] = useState<UserAccountStatus>('suspended');
  const [statusReason, setStatusReason] = useState('');

  // Invite Form State
  const [inviteFullName, setInviteFullName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<PlatformRole>('staff');
  const [inviteDepartment, setInviteDepartment] = useState('Technical Support');
  const [inviteStaffTitle, setInviteStaffTitle] = useState('Support Engineer');
  const [customPermissions, setCustomPermissions] = useState<ModulePermissions>(DEFAULT_SUPPORT_STAFF_PERMISSIONS);

  // Copy Feedback
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const filteredUsers = users.filter(u => {
    const matchesSearch = u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (u.companyName && u.companyName.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesRole = roleFilter === 'all' ? true : u.role === roleFilter || u.platformRole === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedbackMessage(null);

    if (!inviteFullName || !inviteEmail) {
      setFeedbackMessage({ type: 'error', text: 'Please complete full name and email address.' });
      return;
    }

    const res = systemDatabase.createStaffInvitation({
      email: inviteEmail,
      fullName: inviteFullName,
      role: inviteRole,
      department: inviteDepartment,
      staffTitle: inviteStaffTitle,
      permissions: customPermissions,
    });

    if (res.success && res.invitation) {
      setFeedbackMessage({ 
        type: 'success', 
        text: `Staff invitation created! Single-use token: ${res.invitation.token}` 
      });
      setInviteEmail('');
      setInviteFullName('');
      setActiveTab('invitations');
    } else {
      setFeedbackMessage({ type: 'error', text: res.error || 'Failed to generate invitation.' });
    }
  };

  const handleApplyPresetPermissions = (preset: 'support' | 'finance' | 'admin') => {
    if (preset === 'support') setCustomPermissions(DEFAULT_SUPPORT_STAFF_PERMISSIONS);
    if (preset === 'finance') setCustomPermissions(DEFAULT_FINANCE_STAFF_PERMISSIONS);
    if (preset === 'admin') setCustomPermissions(DEFAULT_ADMIN_PERMISSIONS);
  };

  const handlePermissionToggle = (
    moduleKey: keyof ModulePermissions, 
    actionKey: string, 
    value: boolean
  ) => {
    setCustomPermissions(prev => ({
      ...prev,
      [moduleKey]: {
        ...prev[moduleKey],
        [actionKey]: value,
      }
    }));
  };

  const handleStatusUpdateSubmit = () => {
    if (!statusModalUser) return;
    systemDatabase.setUserAccountStatus(statusModalUser.id, newStatus, statusReason);
    setFeedbackMessage({ type: 'success', text: `Account status for ${statusModalUser.fullName} set to ${newStatus.toUpperCase()}` });
    setStatusModalUser(null);
    setStatusReason('');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedToken(text);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8 space-y-6 text-slate-200">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-[10px] font-black uppercase tracking-wider rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
              Identity & Access Management (IAM)
            </span>
            <span className="px-2.5 py-0.5 bg-slate-800 text-slate-400 text-[11px] font-bold rounded-md">
              RBAC v2.5 Engine
            </span>
          </div>
          <h2 className="text-xl lg:text-2xl font-black text-white tracking-tight mt-1">
            Platform Users, Staff Invitations & Permissions
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage Super Admins, Administrators, Staff Members, and Client accounts with granular module permission matrix.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('invite')}
          className="px-5 py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          <span>Invite Staff / Admin</span>
        </button>
      </div>

      {/* Feedback Banner */}
      {feedbackMessage && (
        <div className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between border ${
          feedbackMessage.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
        }`}>
          <span>{feedbackMessage.text}</span>
          <button onClick={() => setFeedbackMessage(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-800 pb-2 gap-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'users' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          Platform Users Directory ({users.length})
        </button>

        <button
          onClick={() => setActiveTab('invite')}
          className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'invite' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          Invite Staff Member
        </button>

        <button
          onClick={() => setActiveTab('invitations')}
          className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'invitations' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <Mail className="w-4 h-4" />
          Pending Invitations ({staffInvitations.length})
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'audit' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <Activity className="w-4 h-4" />
          Security Audit Trail
        </button>
      </div>

      {/* TAB 1: USERS DIRECTORY */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="Search user name, email, or company..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-xs text-slate-400 font-bold">Filter Role:</span>
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none"
              >
                <option value="all">All Roles</option>
                <option value="super_admin">Super Admin</option>
                <option value="administrator">Administrator</option>
                <option value="staff">Staff</option>
                <option value="client">Client</option>
              </select>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900 text-slate-400 border-b border-slate-800">
                    <th className="p-4 font-extrabold uppercase">User Identity</th>
                    <th className="p-4 font-extrabold uppercase">Role & Department</th>
                    <th className="p-4 font-extrabold uppercase">Account Status</th>
                    <th className="p-4 font-extrabold uppercase">2FA / Security</th>
                    <th className="p-4 font-extrabold uppercase">Last Login</th>
                    <th className="p-4 font-extrabold uppercase text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredUsers.map(user => (
                    <tr key={user.id} className="hover:bg-slate-900/50 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <img 
                            src={user.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop"} 
                            alt="" 
                            className="w-9 h-9 rounded-xl object-cover ring-2 ring-indigo-500/20"
                          />
                          <div>
                            <p className="font-extrabold text-white flex items-center gap-1.5">
                              {user.fullName}
                              {user.id === currentUser.id && (
                                <span className="px-1.5 py-0.2 bg-blue-500/20 text-blue-300 text-[9px] font-bold rounded">YOU</span>
                              )}
                            </p>
                            <p className="text-[11px] text-slate-400">{user.email}</p>
                          </div>
                        </div>
                      </td>

                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                          user.role === 'super_admin' ? 'bg-amber-500/20 border border-amber-500/30 text-amber-300' :
                          user.role === 'administrator' || user.role === 'admin' ? 'bg-purple-500/20 border border-purple-500/30 text-purple-300' :
                          user.role === 'staff' ? 'bg-indigo-500/20 border border-indigo-500/30 text-indigo-300' :
                          'bg-blue-500/10 border border-blue-500/30 text-blue-400'
                        }`}>
                          {user.role}
                        </span>
                        <p className="text-[10px] text-slate-400 mt-1">{user.department || user.staffTitle || 'Customer'}</p>
                      </td>

                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          user.accountStatus === 'active' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' :
                          user.accountStatus === 'suspended' ? 'bg-rose-500/10 border border-rose-500/30 text-rose-400' :
                          user.accountStatus === 'locked' ? 'bg-amber-500/10 border border-amber-500/30 text-amber-400' :
                          'bg-slate-800 text-slate-400'
                        }`}>
                          {user.accountStatus || 'ACTIVE'}
                        </span>
                      </td>

                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            user.twoFactorEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-500'
                          }`}>
                            2FA: {user.twoFactorEnabled ? 'ON' : 'OFF'}
                          </span>
                          {user.isEmailVerified && (
                            <span className="text-emerald-400 font-bold text-[10px]">✓ Email</span>
                          )}
                        </div>
                      </td>

                      <td className="p-4 text-slate-400 text-[11px] font-mono">
                        {user.lastLoginAt || 'Never'}
                      </td>

                      <td className="p-4 text-right space-x-2">
                        <button
                          onClick={() => {
                            setStatusModalUser(user);
                            setNewStatus(user.accountStatus || 'suspended');
                          }}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[10px] rounded-lg border border-slate-700"
                        >
                          Change Status
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INVITE STAFF MEMBER */}
      {activeTab === 'invite' && (
        <form onSubmit={handleInviteSubmit} className="space-y-6">
          <div className="p-4 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl text-xs space-y-1">
            <h3 className="font-extrabold text-indigo-300 flex items-center gap-2">
              <Info className="w-4 h-4 text-indigo-400" />
              Secure Invitation System
            </h3>
            <p className="text-slate-300">
              Staff and Admin members cannot self-register publicly. Super Admins generate single-use invitation tokens with custom permissions attached.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Staff Full Name</label>
                <input
                  type="text"
                  required
                  value={inviteFullName}
                  onChange={(e) => setInviteFullName(e.target.value)}
                  placeholder="e.g. Ama Mensah"
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Work Email Address</label>
                <input
                  type="email"
                  required
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="ama.support@celoxaghana.online"
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">Platform Role</label>
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value as PlatformRole)}
                    className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none"
                  >
                    <option value="staff">Staff Member</option>
                    <option value="administrator">Administrator</option>
                    <option value="super_admin">Super Admin</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">Department</label>
                  <input
                    type="text"
                    value={inviteDepartment}
                    onChange={(e) => setInviteDepartment(e.target.value)}
                    placeholder="Technical Support"
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Job Title</label>
                <input
                  type="text"
                  value={inviteStaffTitle}
                  onChange={(e) => setInviteStaffTitle(e.target.value)}
                  placeholder="Support Specialist"
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none"
                />
              </div>

              {/* Permission Presets */}
              <div className="pt-2">
                <label className="text-xs font-bold text-slate-300 block mb-2">Quick Permission Presets:</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleApplyPresetPermissions('support')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] rounded-lg border border-slate-700"
                  >
                    Support Staff
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyPresetPermissions('finance')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] rounded-lg border border-slate-700"
                  >
                    Finance & Billing
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyPresetPermissions('admin')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] rounded-lg border border-slate-700"
                  >
                    Full Admin
                  </button>
                </div>
              </div>
            </div>

            {/* Granular Permissions Matrix Editor */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
              <h3 className="text-xs font-black text-indigo-300 uppercase tracking-wider flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-400" />
                Granular Module Permissions Matrix
              </h3>

              <div className="space-y-3 text-xs">
                {/* Customers */}
                <div className="p-3 bg-slate-900 rounded-xl space-y-2">
                  <p className="font-bold text-white">Customers Module</p>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={customPermissions.customers.view} 
                        onChange={(e) => handlePermissionToggle('customers', 'view', e.target.checked)} 
                        className="rounded accent-indigo-600"
                      />
                      <span>View Customers</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={customPermissions.customers.edit} 
                        onChange={(e) => handlePermissionToggle('customers', 'edit', e.target.checked)} 
                        className="rounded accent-indigo-600"
                      />
                      <span>Edit Customer Profiles</span>
                    </label>
                  </div>
                </div>

                {/* Hosting & Provisioning */}
                <div className="p-3 bg-slate-900 rounded-xl space-y-2">
                  <p className="font-bold text-white">Hosting & Servers Module</p>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={customPermissions.hosting.provision} 
                        onChange={(e) => handlePermissionToggle('hosting', 'provision', e.target.checked)} 
                        className="rounded accent-indigo-600"
                      />
                      <span>Provision Accounts</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={customPermissions.hosting.suspend} 
                        onChange={(e) => handlePermissionToggle('hosting', 'suspend', e.target.checked)} 
                        className="rounded accent-indigo-600"
                      />
                      <span>Suspend / Unsuspend</span>
                    </label>
                  </div>
                </div>

                {/* Billing */}
                <div className="p-3 bg-slate-900 rounded-xl space-y-2">
                  <p className="font-bold text-white">Billing & Invoices Module</p>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={customPermissions.billing.viewInvoices} 
                        onChange={(e) => handlePermissionToggle('billing', 'viewInvoices', e.target.checked)} 
                        className="rounded accent-indigo-600"
                      />
                      <span>View Invoices</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={customPermissions.billing.createInvoice} 
                        onChange={(e) => handlePermissionToggle('billing', 'createInvoice', e.target.checked)} 
                        className="rounded accent-indigo-600"
                      />
                      <span>Create & Edit Invoices</span>
                    </label>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 mt-4"
              >
                <Send className="w-4 h-4" />
                <span>Generate Invitation Token</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* TAB 3: PENDING INVITATIONS */}
      {activeTab === 'invitations' && (
        <div className="space-y-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h3 className="font-extrabold text-xs text-white uppercase tracking-wider flex items-center gap-2">
              <Mail className="w-4 h-4 text-indigo-400" />
              Active Staff Invitations Queue
            </h3>

            {staffInvitations.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 text-center">No pending invitations.</p>
            ) : (
              <div className="space-y-3">
                {staffInvitations.map((inv) => (
                  <div key={inv.id} className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
                    <div>
                      <p className="font-extrabold text-white text-sm">{inv.fullName}</p>
                      <p className="text-slate-400 text-[11px]">{inv.email} • Role: {inv.role.toUpperCase()} ({inv.department})</p>
                      <p className="text-[10px] text-slate-500 mt-1">Invited by: {inv.createdByEmail} • Expires: {inv.expiresAt.slice(0, 16)}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => copyToClipboard(`${window.location.origin}/?inviteToken=${inv.token}`)}
                        className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 font-bold text-[11px] rounded-lg border border-indigo-500/30 flex items-center gap-1.5"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{copiedToken === `${window.location.origin}/?inviteToken=${inv.token}` ? 'Copied Link!' : 'Copy Invite Link'}</span>
                      </button>

                      <button
                        onClick={() => {
                          systemDatabase.cancelStaffInvitation(inv.id);
                          setFeedbackMessage({ type: 'success', text: 'Cancelled invitation' });
                        }}
                        className="p-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-lg border border-rose-500/30"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: AUDIT TRAIL */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h3 className="font-extrabold text-xs text-white uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-400" />
              Real-time Security Audit Log Stream
            </h3>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-3 bg-slate-900 border border-slate-800/80 rounded-xl text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-indigo-300">{log.action}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{log.timestamp}</span>
                  </div>
                  <p className="text-slate-300 font-mono text-[11px]">{log.target} - {log.details}</p>
                  <div className="text-[10px] text-slate-500 flex items-center justify-between">
                    <span>Actor: {log.actor}</span>
                    <span>IP: {log.ipAddress}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STATUS CHANGE MODAL */}
      {statusModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 space-y-4 text-slate-200">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-sm text-white flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                Change Account Status
              </h3>
              <button onClick={() => setStatusModalUser(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <p className="text-xs text-slate-400">
              Updating account status for <strong>{statusModalUser.fullName}</strong> ({statusModalUser.email}).
            </p>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">New Status</label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as UserAccountStatus)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none"
                >
                  <option value="active">Active (Normal Access)</option>
                  <option value="suspended">Suspended (Block Login)</option>
                  <option value="locked">Locked (Require Security Reset)</option>
                  <option value="deactivated">Deactivated (Terminated)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Reason / Notes for Audit Log</label>
                <textarea
                  value={statusReason}
                  onChange={(e) => setStatusReason(e.target.value)}
                  placeholder="e.g. Non-payment of invoice or requested by account holder"
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={handleStatusUpdateSubmit}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl"
                >
                  Save Status
                </button>
                <button
                  onClick={() => setStatusModalUser(null)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
