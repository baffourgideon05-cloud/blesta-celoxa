import React, { useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  ShoppingCart, 
  Heart, 
  ArrowRightLeft, 
  Share2, 
  Copy, 
  Info, 
  Clock, 
  ShieldCheck, 
  ExternalLink,
  Check,
  Zap
} from 'lucide-react';
import { DomainResult, ViewMode, Currency } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';

interface DomainCardProps {
  domain: DomainResult;
  viewMode: ViewMode;
  currency: Currency;
  isInCart: boolean;
  isWishlisted: boolean;
  isCompared: boolean;
  onAddToCart: (domain: DomainResult) => void;
  onToggleWishlist: (domain: DomainResult) => void;
  onToggleCompare: (domain: DomainResult) => void;
  onOpenWhois: (domainName: string) => void;
  onOpenAppraise?: (domainName: string) => void;
}

export const DomainCard: React.FC<DomainCardProps> = ({
  domain,
  viewMode,
  currency,
  isInCart,
  isWishlisted,
  isCompared,
  onAddToCart,
  onToggleWishlist,
  onToggleCompare,
  onOpenWhois,
  onOpenAppraise,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(domain.domain);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `Domain Search: ${domain.domain}`,
        text: `Check out ${domain.domain} available on ApexDomain!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      handleCopy();
    }
  };

  // Render Table Row View
  if (viewMode === 'table') {
    return (
      <tr className="border-b border-slate-200 dark:border-slate-800 hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors">
        <td className="py-3 px-4">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-sm text-slate-900 dark:text-white">{domain.domain}</span>
            {domain.isPremium && (
              <span className="px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 rounded">
                Premium
              </span>
            )}
          </div>
        </td>
        <td className="py-3 px-4">
          {domain.isAvailable ? (
            <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-md">
              <CheckCircle2 className="w-3.5 h-3.5" /> Available
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-xs font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
              <XCircle className="w-3.5 h-3.5" /> Registered
            </span>
          )}
        </td>
        <td className="py-3 px-4">
          <div className="text-sm font-extrabold text-slate-900 dark:text-white">
            {formatPrice(domain.registrationPrice, currency)}
            <span className="text-[10px] text-slate-500 font-normal"> /1st yr</span>
          </div>
          <div className="text-[11px] text-slate-400 font-medium">
            Renews: {formatPrice(domain.renewalPrice, currency)}
          </div>
        </td>
        <td className="py-3 px-4 text-xs text-slate-500 font-medium hidden md:table-cell">
          {domain.timeEstimate}
        </td>
        <td className="py-3 px-4 text-right">
          <div className="flex items-center justify-end gap-1.5">
            <button
              onClick={() => onToggleWishlist(domain)}
              className={`p-1.5 rounded-lg border text-xs transition-colors ${
                isWishlisted 
                  ? 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-rose-900/30 dark:border-rose-800 dark:text-rose-400' 
                  : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-500'
              }`}
              title="Add to Wishlist"
            >
              <Heart className="w-3.5 h-3.5 fill-current" />
            </button>

            <button
              onClick={() => onOpenWhois(domain.domain)}
              className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-semibold text-slate-600 dark:text-slate-300 transition-colors"
            >
              Domain Info
            </button>

            {domain.isAvailable ? (
              <button
                onClick={() => onAddToCart(domain)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                  isInCart
                    ? 'bg-emerald-600 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm'
                }`}
              >
                {isInCart ? <Check className="w-3.5 h-3.5" /> : <ShoppingCart className="w-3.5 h-3.5" />}
                {isInCart ? 'In Cart' : 'Add to Cart'}
              </button>
            ) : (
              <button
                onClick={() => onOpenWhois(domain.domain)}
                className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
              >
                Backorder
              </button>
            )}
          </div>
        </td>
      </tr>
    );
  }

  // Render Compact Mode
  if (viewMode === 'compact') {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex items-center justify-between gap-3 hover:border-blue-500/50 transition-all shadow-sm">
        <div className="flex items-center gap-2.5 min-w-0">
          {domain.isAvailable ? (
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
          ) : (
            <span className="w-2 h-2 rounded-full bg-slate-400 shrink-0" />
          )}
          <div className="truncate">
            <span className="font-extrabold text-sm text-slate-900 dark:text-white truncate block">
              {domain.domain}
            </span>
            <span className="text-[10px] text-slate-400">
              Renews {formatPrice(domain.renewalPrice, currency)} • ICANN ${domain.icannFee}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="font-extrabold text-sm text-slate-900 dark:text-white">
            {formatPrice(domain.registrationPrice, currency)}
          </span>
          {domain.isAvailable ? (
            <button
              onClick={() => onAddToCart(domain)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                isInCart ? 'bg-emerald-600 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {isInCart ? 'Added' : 'Add'}
            </button>
          ) : (
            <button
              onClick={() => onOpenWhois(domain.domain)}
              className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
            >
              Taken
            </button>
          )}
        </div>
      </div>
    );
  }

  // Render List View
  if (viewMode === 'list') {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-blue-500/50 transition-all shadow-sm hover:shadow-md">
        
        {/* Main Information */}
        <div className="space-y-1.5 max-w-xl">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-black tracking-tight text-slate-900 dark:text-white">
              {domain.domain}
            </h3>

            {domain.isAvailable ? (
              <span className="px-2 py-0.5 text-xs font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Available
              </span>
            ) : (
              <span className="px-2 py-0.5 text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-full flex items-center gap-1">
                <XCircle className="w-3 h-3" /> Registered
              </span>
            )}

            {domain.isPremium && (
              <span className="px-2 py-0.5 text-[10px] font-black uppercase tracking-wider bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 rounded-full">
                ★ Premium Domain
              </span>
            )}

            <span className="px-2 py-0.5 text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-md">
              {domain.category}
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 font-normal">
            {domain.description} • Free Domain Privacy Included • Setup time: {domain.timeEstimate}
          </p>

          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-medium pt-1">
            <span>Renewal: <strong className="text-slate-700 dark:text-slate-200">{formatPrice(domain.renewalPrice, currency)}/yr</strong></span>
            <span>•</span>
            <span>Transfer: <strong className="text-slate-700 dark:text-slate-200">{formatPrice(domain.transferPrice, currency)}</strong></span>
            <span>•</span>
            <span>ICANN Fee: <strong className="text-slate-700 dark:text-slate-200">${domain.icannFee}</strong></span>
          </div>
        </div>

        {/* Price & Action Cluster */}
        <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 border-slate-100 dark:border-slate-800 pt-3 sm:pt-0">
          
          <div className="text-right">
            <div className="text-xl font-black text-slate-900 dark:text-white">
              {formatPrice(domain.registrationPrice, currency)}
            </div>
            <div className="text-[11px] font-medium text-slate-400">1st Year Registration</div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onToggleWishlist(domain)}
              className={`p-2 rounded-xl border text-slate-400 hover:text-rose-500 transition-colors ${
                isWishlisted ? 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-rose-900/30' : 'border-slate-200 dark:border-slate-700'
              }`}
              title="Wishlist"
            >
              <Heart className="w-4 h-4 fill-current" />
            </button>

            <button
              onClick={() => onToggleCompare(domain)}
              className={`p-2 rounded-xl border text-slate-400 hover:text-indigo-500 transition-colors ${
                isCompared ? 'bg-indigo-50 border-indigo-200 text-indigo-600 dark:bg-indigo-900/30' : 'border-slate-200 dark:border-slate-700'
              }`}
              title="Compare"
            >
              <ArrowRightLeft className="w-4 h-4" />
            </button>

            <button
              onClick={() => onOpenWhois(domain.domain)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
            >
              Domain Info
            </button>

            {domain.isAvailable ? (
              <button
                onClick={() => onAddToCart(domain)}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md ${
                  isInCart
                    ? 'bg-emerald-600 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-600/20'
                }`}
              >
                {isInCart ? <Check className="w-4 h-4" /> : <ShoppingCart className="w-4 h-4" />}
                {isInCart ? 'In Cart' : 'Add to Cart'}
              </button>
            ) : (
              <button
                onClick={() => onOpenWhois(domain.domain)}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
              >
                Backorder
              </button>
            )}
          </div>

        </div>

      </div>
    );
  }

  // Default Standard Card View
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between hover:border-blue-500/50 transition-all shadow-sm hover:shadow-xl relative group">
      
      {/* Top Card Bar */}
      <div>
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            {domain.isAvailable ? (
              <span className="px-2.5 py-1 text-[11px] font-extrabold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Available
              </span>
            ) : (
              <span className="px-2.5 py-1 text-[11px] font-extrabold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-full flex items-center gap-1">
                <XCircle className="w-3.5 h-3.5" /> Registered
              </span>
            )}

            {domain.isPremium && (
              <span className="px-2 py-0.5 text-[10px] font-black uppercase tracking-wider bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 rounded-full">
                ★ Premium
              </span>
            )}
          </div>

          {/* Top Quick Tools */}
          <div className="flex items-center gap-1">
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title={copied ? "Copied!" : "Copy Domain"}
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() => onToggleWishlist(domain)}
              className={`p-1.5 rounded-lg transition-colors ${
                isWishlisted 
                  ? 'text-rose-500 fill-current' 
                  : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Add to Wishlist"
            >
              <Heart className="w-3.5 h-3.5 fill-current" />
            </button>

            <button
              onClick={() => onToggleCompare(domain)}
              className={`p-1.5 rounded-lg transition-colors ${
                isCompared 
                  ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30' 
                  : 'text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Compare Side-by-Side"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Domain Name */}
        <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors truncate">
          {domain.domain}
        </h3>

        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 font-normal">
          {domain.description}
        </p>

        {/* Specs Pill List */}
        <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-2.5 space-y-1.5 text-xs text-slate-600 dark:text-slate-300 font-medium mb-4 border border-slate-100 dark:border-slate-800">
          <div className="flex justify-between">
            <span className="text-slate-400 font-normal">Renewal Cost:</span>
            <span className="font-semibold">{formatPrice(domain.renewalPrice, currency)} / yr</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400 font-normal">Transfer Fee:</span>
            <span className="font-semibold">{formatPrice(domain.transferPrice, currency)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400 font-normal">ID Protection:</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Included Free
            </span>
          </div>
        </div>
      </div>

      {/* Card Footer Price & Buy */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
        <div>
          <span className="text-2xl font-black text-slate-900 dark:text-white">
            {formatPrice(domain.registrationPrice, currency)}
          </span>
          <span className="text-[10px] text-slate-400 font-medium block -mt-1">
            +${domain.icannFee} ICANN Fee
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onOpenWhois(domain.domain)}
            className="px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
            title="View Domain Info"
          >
            Domain Info
          </button>

          {domain.isAvailable ? (
            <button
              onClick={() => onAddToCart(domain)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md ${
                isInCart
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-600/20'
              }`}
            >
              {isInCart ? <Check className="w-4 h-4" /> : <ShoppingCart className="w-4 h-4" />}
              {isInCart ? 'In Cart' : 'Add to Cart'}
            </button>
          ) : (
            <button
              onClick={() => onOpenWhois(domain.domain)}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
            >
              Backorder
            </button>
          )}
        </div>
      </div>

    </div>
  );
};
