import React from 'react';
import { 
  ShieldCheck, 
  Globe, 
  Server, 
  Receipt, 
  Wallet, 
  LifeBuoy, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowUpRight, 
  Clock, 
  Plus, 
  Lock, 
  TrendingUp, 
  CreditCard,
  Building,
  UserCheck
} from 'lucide-react';
import { Currency } from '../types';

interface ClientDashboardProps {
  user?: {
    fullName: string;
    email: string;
    role: string;
    accountStatus?: string;
    isEmailVerified?: boolean;
    twoFactorEnabled?: boolean;
    companyName?: string;
  };
  domainsCount: number;
  hostingCount: number;
  sslCount?: number;
  emailCount?: number;
  vpsCount?: number;
  walletBalanceGhs: number;
  walletBalanceUsd: number;
  unpaidInvoicesCount: number;
  unpaidTotalGhs: number;
  openTicketsCount: number;
  currency: Currency;
  onNavigateTab: (tab: string) => void;
  onOpenDomainHub?: () => void;
  onOpenCatalog?: () => void;
}

export const ClientDashboard: React.FC<ClientDashboardProps> = ({
  user = {
    fullName: 'Gideon Baffour',
    email: 'gideon@celoxaghana.online',
    role: 'client',
    accountStatus: 'active',
    isEmailVerified: true,
    twoFactorEnabled: true,
    companyName: 'Vikalink Enterprise'
  },
  domainsCount,
  hostingCount,
  sslCount = 1,
  emailCount = 2,
  vpsCount = 0,
  walletBalanceGhs,
  walletBalanceUsd,
  unpaidInvoicesCount,
  unpaidTotalGhs,
  openTicketsCount,
  currency,
  onNavigateTab,
  onOpenDomainHub,
  onOpenCatalog
}) => {
  const formatMoney = (amountGhs: number) => {
    if (currency === 'USD') {
      return `$${(amountGhs / 12.5).toFixed(2)}`;
    }
    return `GH₵${amountGhs.toLocaleString('en-GH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Banner: Welcome & Account Status */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 p-6 md:p-8 border border-slate-800 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-12 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5" /> Client Portal
              </span>
              {user.accountStatus === 'active' ? (
                <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Account Active
                </span>
              ) : (
                <span className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> Pending Verification
                </span>
              )}
              {user.twoFactorEnabled && (
                <span className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" /> 2FA Secured
                </span>
              )}
            </div>

            <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
              Welcome back, <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-cyan-400 to-teal-300">{user.fullName}</span>
            </h1>
            {user.companyName && (
              <p className="text-slate-400 text-sm flex items-center gap-2">
                <Building className="w-4 h-4 text-slate-500" /> {user.companyName} • {user.email}
              </p>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigateTab('wallet')}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition-all flex items-center gap-2"
            >
              <Wallet className="w-4 h-4" /> Deposit Funds
            </button>
            <button
              onClick={() => onNavigateTab('tickets')}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs rounded-xl transition-all flex items-center gap-2"
            >
              <LifeBuoy className="w-4 h-4 text-cyan-400" /> Get Support
            </button>
          </div>
        </div>
      </div>

      {/* Metric Tiles Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Registered Domains */}
        <div 
          onClick={() => onNavigateTab('services')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Domains</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-all">
              <Globe className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-white">{domainsCount}</span>
            <span className="text-xs text-cyan-400 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Manage <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Registered & Active Domains</p>
        </div>

        {/* Metric 2: Hosting & Infrastructure */}
        <div 
          onClick={() => onNavigateTab('services')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Hosting Services</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 group-hover:bg-indigo-500 group-hover:text-slate-950 transition-all">
              <Server className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-white">{hostingCount}</span>
            <span className="text-xs text-indigo-400 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Control Panel <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">WHM, CPanel & Cloud Instances</p>
        </div>

        {/* Metric 3: Wallet Balance */}
        <div 
          onClick={() => onNavigateTab('wallet')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Account Balance</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-slate-950 transition-all">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-emerald-400">{formatMoney(walletBalanceGhs)}</span>
            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Top Up <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Available prepaid credit balance</p>
        </div>

        {/* Metric 4: Invoices & Support */}
        <div 
          onClick={() => onNavigateTab('billing')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Unpaid Invoices</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-amber-400">{unpaidInvoicesCount}</span>
            <span className="text-xs text-amber-400 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Pay Now <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="text-[11px] text-amber-500/80 mt-2 font-medium">Due Total: {formatMoney(unpaidTotalGhs)}</p>
        </div>
      </div>

      {/* Core Quick Action Bar */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-white">Quick Infrastructure Deployment</h3>
          <p className="text-xs text-slate-400">Order new domain names, hosting packages, or submit technical assistance tickets</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <button 
            onClick={onOpenCatalog}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/20"
          >
            <Plus className="w-4 h-4" /> Order Hosting
          </button>
          <button 
            onClick={onOpenDomainHub}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-2"
          >
            <Globe className="w-4 h-4 text-cyan-400" /> Search Domain
          </button>
          <button 
            onClick={() => onNavigateTab('tickets')}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-2"
          >
            <LifeBuoy className="w-4 h-4 text-amber-400" /> Open Ticket ({openTicketsCount})
          </button>
        </div>
      </div>
    </div>
  );
};
