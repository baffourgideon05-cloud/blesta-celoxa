import React, { useState } from 'react';
import { FolderGit2, Search, ArrowRight, ShieldCheck, Check, Sparkles, HelpCircle } from 'lucide-react';
import { TLD_CATALOG } from '../data/tlds';
import { TLDDetail, Currency } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';

interface TldDirectoryViewProps {
  currency: Currency;
  onSearchTld: (tld: string) => void;
}

export const TldDirectoryView: React.FC<TldDirectoryViewProps> = ({ currency, onSearchTld }) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchFilter, setSearchFilter] = useState('');
  const [activeTldModal, setActiveTldModal] = useState<TLDDetail | null>(null);

  const categories = ['All', 'Popular', 'Tech & AI', 'Business', 'E-commerce', 'ccTLD', 'Creative'];

  const filteredTlds = TLD_CATALOG.filter((tld) => {
    const matchesCategory = selectedCategory === 'All' || tld.category === selectedCategory;
    const searchLow = (searchFilter || '').toLowerCase();
    const matchesSearch = (tld.tld || '').toLowerCase().includes(searchLow) ||
                          (tld.name || '').toLowerCase().includes(searchLow);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
          <FolderGit2 className="w-4 h-4" /> Global TLD Directory
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">Explore All Top-Level Extensions</h1>
        <p className="text-sm text-slate-500 max-w-2xl">
          Browse registration rules, renewal matrix, ICANN fees, and best use cases across 800+ gTLDs and country extensions.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Search TLD (e.g. .io, .ai)..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium focus:ring-2 focus:ring-blue-500"
          />
        </div>

      </div>

      {/* Directory Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredTlds.map((tld) => (
          <div
            key={tld.tld}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm hover:shadow-lg hover:border-blue-500/50 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-2xl font-black text-blue-600 dark:text-blue-400">{tld.tld}</span>
                <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-md">
                  {tld.category}
                </span>
              </div>

              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white mb-1">{tld.name}</h3>
              <p className="text-xs text-slate-500 line-clamp-2">{tld.description}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium">Registration:</span>
                <span className="font-black text-slate-900 dark:text-white">{formatPrice(tld.registrationPrice, currency)}</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setActiveTldModal(tld)}
                  className="py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors"
                >
                  TLD Details
                </button>

                <button
                  onClick={() => onSearchTld(tld.tld)}
                  className="py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1"
                >
                  Search <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* TLD Detail Modal */}
      {activeTldModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
            
            <div className="p-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
              <div>
                <span className="text-3xl font-black text-blue-600 dark:text-blue-400">{activeTldModal.tld}</span>
                <div className="text-xs font-bold text-slate-500">{activeTldModal.name} • {activeTldModal.category}</div>
              </div>
              <button
                onClick={() => setActiveTldModal(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700 dark:text-slate-300">
              <p className="text-sm font-medium text-slate-600 dark:text-slate-300">{activeTldModal.description}</p>

              {/* Pricing Matrix */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <div className="font-bold text-slate-400 text-[10px] uppercase">Registration</div>
                  <div className="font-extrabold text-slate-900 dark:text-white text-sm">{formatPrice(activeTldModal.registrationPrice, currency)}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <div className="font-bold text-slate-400 text-[10px] uppercase">Renewal</div>
                  <div className="font-extrabold text-slate-900 dark:text-white text-sm">{formatPrice(activeTldModal.renewalPrice, currency)}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <div className="font-bold text-slate-400 text-[10px] uppercase">Transfer</div>
                  <div className="font-extrabold text-slate-900 dark:text-white text-sm">{formatPrice(activeTldModal.transferPrice, currency)}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <div className="font-bold text-slate-400 text-[10px] uppercase">ICANN Fee</div>
                  <div className="font-extrabold text-slate-900 dark:text-white text-sm">${activeTldModal.icannFee}</div>
                </div>
              </div>

              {/* Best Use Cases */}
              <div className="space-y-2">
                <h4 className="font-extrabold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">Best Use Cases</h4>
                <div className="flex flex-wrap gap-2">
                  {activeTldModal.bestUseCases.map((uc, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-bold text-xs">
                      {uc}
                    </span>
                  ))}
                </div>
              </div>

              {/* Rules */}
              <div className="space-y-2">
                <h4 className="font-extrabold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">Registration Rules</h4>
                <ul className="list-disc pl-4 space-y-1 text-slate-500">
                  {activeTldModal.registrationRules.map((rule, i) => (
                    <li key={i}>{rule}</li>
                  ))}
                </ul>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
