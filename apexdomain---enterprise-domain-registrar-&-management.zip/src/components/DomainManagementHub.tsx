import React, { useState } from 'react';
import { 
  Building2, 
  Server, 
  Lock, 
  Unlock, 
  RefreshCw, 
  Mail, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Check, 
  Key, 
  AlertTriangle,
  FileText,
  Clock,
  Ticket
} from 'lucide-react';
import { 
  RegisteredDomain, 
  DNSRecord, 
  EmailForwardRule, 
  PaymentMethodSettings, 
  PaymentSubmission, 
  Currency 
} from '../types';
import { AdminPaymentSettings } from './AdminPaymentSettings';
import { DEFAULT_PAYMENT_SETTINGS } from '../data/paymentSettings';

interface DomainManagementHubProps {
  domains: RegisteredDomain[];
  setDomains: React.Dispatch<React.SetStateAction<RegisteredDomain[]>>;
  paymentSettings?: PaymentMethodSettings;
  onUpdatePaymentSettings?: (newSettings: PaymentMethodSettings) => void;
  paymentSubmissions?: PaymentSubmission[];
  onApproveSubmission?: (submissionId: string) => void;
  onRejectSubmission?: (submissionId: string) => void;
  currency?: Currency;
}

export const DomainManagementHub: React.FC<DomainManagementHubProps> = ({ 
  domains, 
  setDomains,
  paymentSettings = DEFAULT_PAYMENT_SETTINGS,
  onUpdatePaymentSettings = () => {},
  paymentSubmissions = [],
  onApproveSubmission = () => {},
  onRejectSubmission = () => {},
  currency = 'USD',
}) => {
  const [hubMode, setHubMode] = useState<'domains' | 'admin_payment'>('domains');
  const [selectedDomainId, setSelectedDomainId] = useState<string>(domains[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'dns' | 'nameservers' | 'email' | 'security'>('dns');

  // Selected domain object
  const selectedDomain = domains.find((d) => d.id === selectedDomainId) || domains[0];

  // DNS Form state
  const [newDnsType, setNewDnsType] = useState<'A' | 'AAAA' | 'CNAME' | 'MX' | 'TXT' | 'NS'>('A');
  const [newDnsName, setNewDnsName] = useState('@');
  const [newDnsValue, setNewDnsValue] = useState('');
  const [newDnsTtl, setNewDnsTtl] = useState(3600);

  // Email Forward Form State
  const [newForwardSource, setNewForwardSource] = useState('');
  const [newForwardDest, setNewForwardDest] = useState('');

  // Auth code reveal
  const [showAuthCode, setShowAuthCode] = useState(false);

  // Toggles
  const toggleAutoRenew = (id: string) => {
    setDomains((prev) =>
      prev.map((d) => (d.id === id ? { ...d, autoRenew: !d.autoRenew } : d))
    );
  };

  const toggleDomainLock = (id: string) => {
    setDomains((prev) =>
      prev.map((d) => (d.id === id ? { ...d, locked: !d.locked } : d))
    );
  };

  const handleAddDnsRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDnsValue.trim() || !selectedDomain) return;

    const newRecord: DNSRecord = {
      id: `dns-${Date.now()}`,
      type: newDnsType,
      name: newDnsName.trim() || '@',
      value: newDnsValue.trim(),
      ttl: newDnsTtl,
    };

    setDomains((prev) =>
      prev.map((d) =>
        d.id === selectedDomain.id
          ? { ...d, dnsRecords: [...d.dnsRecords, newRecord] }
          : d
      )
    );

    setNewDnsValue('');
  };

  const handleDeleteDnsRecord = (recordId: string) => {
    if (!selectedDomain) return;
    setDomains((prev) =>
      prev.map((d) =>
        d.id === selectedDomain.id
          ? { ...d, dnsRecords: d.dnsRecords.filter((r) => r.id !== recordId) }
          : d
      )
    );
  };

  const handleAddEmailForward = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newForwardSource || !newForwardDest || !selectedDomain) return;

    const newRule: EmailForwardRule = {
      id: `ef-${Date.now()}`,
      source: `${newForwardSource}@${selectedDomain.domain}`,
      destination: newForwardDest,
      active: true,
    };

    setDomains((prev) =>
      prev.map((d) =>
        d.id === selectedDomain.id
          ? { ...d, emailForwarding: [...d.emailForwarding, newRule] }
          : d
      )
    );

    setNewForwardSource('');
    setNewForwardDest('');
  };

  const handleDeleteEmailForward = (ruleId: string) => {
    if (!selectedDomain) return;
    setDomains((prev) =>
      prev.map((d) =>
        d.id === selectedDomain.id
          ? { ...d, emailForwarding: d.emailForwarding.filter((ef) => ef.id !== ruleId) }
          : d
      )
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Title & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 text-xs font-bold">
            <Building2 className="w-4 h-4" /> Domain Management Portal
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">Domain Management Hub</h1>
          <p className="text-sm text-slate-500 max-w-2xl">
            Manage DNS zone records, nameservers, domain transfer locks, and configure custom payment gateways.
          </p>
        </div>

        {/* Hub Mode Switcher */}
        <div className="flex items-center p-1 bg-slate-200 dark:bg-slate-800 rounded-xl self-start sm:self-auto">
          <button
            onClick={() => setHubMode('domains')}
            className={`px-4 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-2 ${
              hubMode === 'domains'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>My Domains ({domains.length})</span>
          </button>

          <button
            onClick={() => setHubMode('admin_payment')}
            className={`px-4 py-2 rounded-lg text-xs font-extrabold transition-all flex items-center gap-2 ${
              hubMode === 'admin_payment'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Key className="w-4 h-4 text-amber-400" />
            <span>Admin Payment Settings</span>
          </button>
        </div>
      </div>

      {hubMode === 'admin_payment' ? (
        <AdminPaymentSettings
          settings={paymentSettings}
          onUpdateSettings={onUpdatePaymentSettings}
          submissions={paymentSubmissions}
          onApproveSubmission={onApproveSubmission}
          onRejectSubmission={onRejectSubmission}
          currency={currency}
        />
      ) : (
        <>
          {/* Account Stats Widgets */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">Active Domains</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">{domains.length}</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">Expiring Soon</div>
          <div className="text-2xl font-black text-amber-500">
            {domains.filter((d) => d.status === 'expiring_soon').length}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase tracking-wider font-bold">Open Tickets</div>
          <div className="text-2xl font-black text-blue-500">0</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1">
          <div className="text-xs text-slate-400 font-bold uppercase tracking-wider font-bold">WHOIS Privacy</div>
          <div className="text-2xl font-black text-emerald-500">100% Protected</div>
        </div>
      </div>

      {/* Main Grid Layout */}
      {domains.length > 0 && selectedDomain && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Domain Selector List */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3 shadow-sm h-fit">
            <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-400 px-2">Your Domains</h3>
            <div className="space-y-1.5">
              {domains.map((dom) => (
                <button
                  key={dom.id}
                  onClick={() => {
                    setSelectedDomainId(dom.id);
                    setShowAuthCode(false);
                  }}
                  className={`w-full text-left p-3 rounded-xl transition-all border ${
                    selectedDomainId === dom.id
                      ? 'bg-blue-50/80 dark:bg-blue-950/60 border-blue-500 text-blue-600 dark:text-blue-400 font-extrabold'
                      : 'border-transparent text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="truncate text-sm">{dom.domain}</span>
                    {dom.status === 'expiring_soon' && (
                      <span className="w-2 h-2 rounded-full bg-amber-500" title="Expiring Soon" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400 font-normal">Expires: {dom.expiryDate}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Interactive Domain Manager */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
            
            {/* Active Selected Domain Summary Header */}
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-xl font-black text-slate-900 dark:text-white">{selectedDomain.domain}</h2>
                <div className="text-xs text-slate-400">Registered: {selectedDomain.registeredDate} • Expiry: {selectedDomain.expiryDate}</div>
              </div>

              {/* Toggles */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => toggleAutoRenew(selectedDomain.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                    selectedDomain.autoRenew
                      ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400'
                      : 'border-slate-300 dark:border-slate-700 text-slate-500'
                  }`}
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Auto-Renew: {selectedDomain.autoRenew ? 'ON' : 'OFF'}
                </button>

                <button
                  onClick={() => toggleDomainLock(selectedDomain.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                    selectedDomain.locked
                      ? 'bg-blue-50 dark:bg-blue-950/50 border-blue-300 dark:border-blue-800 text-blue-600 dark:text-blue-400'
                      : 'border-amber-300 text-amber-600'
                  }`}
                >
                  {selectedDomain.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  Domain Lock: {selectedDomain.locked ? 'LOCKED' : 'UNLOCKED'}
                </button>
              </div>
            </div>

            {/* Management Sub-tabs */}
            <div className="flex border-b border-slate-200 dark:border-slate-800 gap-6">
              <button
                onClick={() => setActiveTab('dns')}
                className={`pb-2.5 text-xs font-bold border-b-2 transition-all ${
                  activeTab === 'dns'
                    ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                DNS Zone Editor
              </button>
              <button
                onClick={() => setActiveTab('nameservers')}
                className={`pb-2.5 text-xs font-bold border-b-2 transition-all ${
                  activeTab === 'nameservers'
                    ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                Nameservers
              </button>
              <button
                onClick={() => setActiveTab('email')}
                className={`pb-2.5 text-xs font-bold border-b-2 transition-all ${
                  activeTab === 'email'
                    ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                Email Forwarding
              </button>
              <button
                onClick={() => setActiveTab('security')}
                className={`pb-2.5 text-xs font-bold border-b-2 transition-all ${
                  activeTab === 'security'
                    ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                Transfer Auth Code
              </button>
            </div>

            {/* SUB-TAB 1: DNS ZONE EDITOR */}
            {activeTab === 'dns' && (
              <div className="space-y-6">
                
                {/* Add DNS Record Form */}
                <form onSubmit={handleAddDnsRecord} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200">Add New DNS Record</div>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Type</label>
                      <select
                        value={newDnsType}
                        onChange={(e) => setNewDnsType(e.target.value as any)}
                        className="w-full mt-1 p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                      >
                        <option value="A">A Record</option>
                        <option value="AAAA">AAAA Record</option>
                        <option value="CNAME">CNAME Record</option>
                        <option value="MX">MX Record</option>
                        <option value="TXT">TXT Record</option>
                        <option value="NS">NS Record</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Host Name</label>
                      <input
                        type="text"
                        value={newDnsName}
                        onChange={(e) => setNewDnsName(e.target.value)}
                        placeholder="@ or www"
                        className="w-full mt-1 p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Value / Target</label>
                      <input
                        type="text"
                        required
                        value={newDnsValue}
                        onChange={(e) => setNewDnsValue(e.target.value)}
                        placeholder="192.0.2.1 or cname.target.com"
                        className="w-full mt-1 p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                      />
                    </div>

                    <div className="flex items-end">
                      <button
                        type="submit"
                        className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1"
                      >
                        <Plus className="w-4 h-4" /> Add Record
                      </button>
                    </div>
                  </div>
                </form>

                {/* DNS Table */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="p-3">Type</th>
                        <th className="p-3">Host Name</th>
                        <th className="p-3">Value</th>
                        <th className="p-3">TTL</th>
                        <th className="p-3 text-right">Delete</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {selectedDomain.dnsRecords.map((rec) => (
                        <tr key={rec.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 font-mono">
                          <td className="p-3 font-extrabold text-blue-600 dark:text-blue-400">{rec.type}</td>
                          <td className="p-3 font-bold text-slate-800 dark:text-slate-200">{rec.name}</td>
                          <td className="p-3 text-slate-600 dark:text-slate-300 truncate max-w-xs">{rec.value}</td>
                          <td className="p-3 text-slate-400">{rec.ttl}s</td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => handleDeleteDnsRecord(rec.id)}
                              className="text-slate-400 hover:text-red-500 p-1 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

              </div>
            )}

            {/* SUB-TAB 2: NAMESERVERS */}
            {activeTab === 'nameservers' && (
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Current Authoritative Nameservers</h4>
                <div className="bg-slate-900 text-slate-200 p-4 rounded-xl font-mono text-xs space-y-2">
                  {selectedDomain.nameservers.map((ns, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="text-blue-400 font-bold">NS{idx + 1}:</span> {ns}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SUB-TAB 3: EMAIL FORWARDING */}
            {activeTab === 'email' && (
              <div className="space-y-6">
                <form onSubmit={handleAddEmailForward} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200">Create Email Forwarding Rule</div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Forward From</label>
                      <div className="flex items-center gap-1 mt-1">
                        <input
                          type="text"
                          required
                          value={newForwardSource}
                          onChange={(e) => setNewForwardSource(e.target.value)}
                          placeholder="contact"
                          className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                        />
                        <span className="text-xs font-bold text-slate-400">@{selectedDomain.domain}</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Destination Inbox</label>
                      <input
                        type="email"
                        required
                        value={newForwardDest}
                        onChange={(e) => setNewForwardDest(e.target.value)}
                        placeholder="yourpersonal@gmail.com"
                        className="w-full mt-1 p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                      />
                    </div>

                    <div className="flex items-end">
                      <button
                        type="submit"
                        className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1"
                      >
                        <Plus className="w-4 h-4" /> Add Rule
                      </button>
                    </div>
                  </div>
                </form>

                {/* Email Forwarding Rules Table */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="p-3">Source Address</th>
                        <th className="p-3">Destination Email</th>
                        <th className="p-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {selectedDomain.emailForwarding.length === 0 ? (
                        <tr>
                          <td colSpan={3} className="p-4 text-center text-slate-400 text-xs">No email forwarding rules configured.</td>
                        </tr>
                      ) : (
                        selectedDomain.emailForwarding.map((rule) => (
                          <tr key={rule.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                            <td className="p-3 font-extrabold text-slate-900 dark:text-white font-mono">{rule.source}</td>
                            <td className="p-3 text-blue-600 dark:text-blue-400 font-mono">{rule.destination}</td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => handleDeleteEmailForward(rule.id)}
                                className="text-slate-400 hover:text-red-500 p-1 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* SUB-TAB 4: TRANSFER AUTH CODE */}
            {activeTab === 'security' && (
              <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-4">
                <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold text-sm">
                  <Key className="w-5 h-5 text-amber-500" /> Transfer Authorization Code (EPP Key)
                </div>
                <p className="text-xs text-slate-500">
                  You will need this secret authorization code if you decide to transfer {selectedDomain.domain} to another registrar.
                </p>

                {showAuthCode ? (
                  <div className="p-3 bg-slate-900 text-amber-400 font-mono text-sm rounded-xl font-bold flex items-center justify-between">
                    <span>{selectedDomain.authCode}</span>
                    <button
                      onClick={() => navigator.clipboard.writeText(selectedDomain.authCode)}
                      className="text-xs text-slate-400 hover:text-white"
                    >
                      Copy EPP Code
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowAuthCode(true)}
                    className="px-4 py-2 bg-slate-900 dark:bg-slate-700 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors"
                  >
                    Reveal Authorization Code
                  </button>
                )}
              </div>
            )}

          </div>

        </div>
      )}
        </>
      )}

    </div>
  );
};
