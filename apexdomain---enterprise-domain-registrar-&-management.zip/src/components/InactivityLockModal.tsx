import React, { useState } from 'react';
import { ShieldAlert, Lock, ArrowRight, LogOut, KeyRound, AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';
import { SystemUser, systemDatabase } from '../services/systemDatabase';

interface InactivityLockModalProps {
  isOpen: boolean;
  user: SystemUser | null;
  onUnlock: (password: string) => boolean;
  onUnlockWithGoogle: () => void;
  onLogout: () => void;
}

export const InactivityLockModal: React.FC<InactivityLockModalProps> = ({
  isOpen,
  user,
  onUnlock,
  onUnlockWithGoogle,
  onLogout,
}) => {
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [shake, setShake] = useState(false);

  if (!isOpen) return null;

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!password.trim()) {
      setErrorMsg('Please enter your account password.');
      triggerShake();
      return;
    }

    setIsAuthenticating(true);

    setTimeout(() => {
      const isValid = onUnlock(password);
      setIsAuthenticating(false);

      if (!isValid) {
        setErrorMsg('Authentication failed: Incorrect password provided. Security access rejected.');
        setPassword('');
        triggerShake();
      }
    }, 600);
  };

  const triggerShake = () => {
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  const handleGoogleUnlock = () => {
    setIsAuthenticating(true);
    setTimeout(() => {
      onUnlockWithGoogle();
      setIsAuthenticating(false);
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/90 backdrop-blur-2xl p-4 animate-in fade-in duration-300">
      
      {/* Background Glows */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className={`w-full max-w-md bg-slate-900 border border-slate-800/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden transition-all ${shake ? 'animate-bounce' : ''}`}>
        
        {/* Top Header Badge */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-[10px] font-black uppercase tracking-wider text-amber-400">
            <Lock className="w-3.5 h-3.5" />
            <span>Session Locked (Inactivity Security)</span>
          </div>
          <span className="text-[10px] font-mono text-slate-500 font-bold">HIGH SECURITY PROT-256</span>
        </div>

        {/* User Profile Summary */}
        <div className="text-center space-y-3 pt-2">
          <div className="relative inline-block">
            <img
              src={user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop'}
              alt="User Avatar"
              className="w-20 h-20 rounded-3xl object-cover mx-auto ring-4 ring-indigo-500/30 shadow-xl"
            />
            <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-xl bg-slate-950 border border-indigo-500/50 flex items-center justify-center text-amber-400">
              <Lock className="w-3.5 h-3.5" />
            </div>
          </div>

          <div>
            <h2 className="text-xl font-black text-white tracking-tight">{user?.fullName || 'Authenticated User'}</h2>
            <p className="text-xs font-mono text-slate-400 mt-0.5">{user?.email || 'user@celoxaghana.online'}</p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] font-black uppercase tracking-wider rounded-md border border-indigo-500/30">
                {user?.role || 'client'}
              </span>
              <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> System Verified
              </span>
            </div>
          </div>
        </div>

        {/* Informative Note */}
        <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl text-[11px] text-slate-400 flex items-start gap-2.5">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            Your session was automatically locked due to system idle inactivity. Please verify your identity to resume access to protected administration modules.
          </p>
        </div>

        {/* Error Notice */}
        {errorMsg && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-rose-400 text-xs flex items-center gap-2 font-semibold animate-in fade-in">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Unlock Form */}
        <form onSubmit={handlePasswordSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-indigo-400" />
              <span>Enter Password to Unlock</span>
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              disabled={isAuthenticating}
              className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-2xl text-white font-mono text-sm placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
              autoFocus
            />
          </div>

          <button
            type="submit"
            disabled={isAuthenticating}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs rounded-2xl shadow-lg shadow-blue-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {isAuthenticating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Verifying Password...</span>
              </>
            ) : (
              <>
                <span>Unlock System Access</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="relative flex items-center justify-center">
          <div className="border-t border-slate-800 w-full" />
          <span className="bg-slate-900 px-3 text-[10px] font-black uppercase tracking-wider text-slate-500 absolute">
            Alternative Options
          </span>
        </div>

        {/* Google Unlock Option */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={handleGoogleUnlock}
            disabled={isAuthenticating}
            className="w-full py-3 px-4 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white font-extrabold text-xs rounded-2xl transition-all flex items-center justify-center gap-2.5"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            <span>Unlock with Google SSO ({user?.email || 'Google Account'})</span>
          </button>

          <button
            type="button"
            onClick={onLogout}
            className="w-full py-2.5 text-xs text-rose-400 hover:text-rose-300 font-extrabold flex items-center justify-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out & Switch User Account</span>
          </button>
        </div>

      </div>
    </div>
  );
};
