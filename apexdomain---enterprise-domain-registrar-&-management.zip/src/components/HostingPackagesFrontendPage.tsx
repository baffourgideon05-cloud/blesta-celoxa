import React, { useState } from 'react';
import {
  Server,
  Zap,
  ShieldCheck,
  Check,
  Sparkles,
  ShoppingBag,
  Globe,
  HardDrive,
  Cpu,
  ArrowRight,
  HelpCircle,
  Clock,
  Database,
  Mail,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  RefreshCw,
  Lock,
  ChevronDown
} from 'lucide-react';
import { WhmcsHostingPackage, CartItem, Currency } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';

interface HostingPackagesFrontendPageProps {
  hostingPackages: WhmcsHostingPackage[];
  cartItems: CartItem[];
  onAddToCart: (item: CartItem) => void;
  onOpenCart: () => void;
  userDomains?: string[];
  currency?: Currency;
  onNavigateView?: (view: string) => void;
}

export const HostingPackagesFrontendPage: React.FC<HostingPackagesFrontendPageProps> = ({
  hostingPackages,
  cartItems,
  onAddToCart,
  onOpenCart,
  userDomains = ['nexustech.io', 'apexdomain.com'],
  currency = 'USD',
  onNavigateView
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually' | 'triennially'>('annually');
  const [targetDomain, setTargetDomain] = useState<string>(userDomains[0] || 'mysite.com');
  const [customDomainInput, setCustomDomainInput] = useState<string>('');
  const [useCustomDomain, setUseCustomDomain] = useState<boolean>(false);
  const [selectedServerRegion, setSelectedServerRegion] = useState<string>('US-East Equinix NY4');
  const [addedSuccessId, setAddedSuccessId] = useState<string | null>(null);

  // FAQ toggle state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const categories = [
    { id: 'all', name: 'All Hosting Plans' },
    { id: 'Shared Web Hosting', name: 'Shared NVMe Hosting' },
    { id: 'WordPress Cloud', name: 'Managed WordPress' },
    { id: 'KVM VPS', name: 'Cloud VPS' },
    { id: 'Reseller Hosting', name: 'Reseller Hosting' },
    { id: 'Dedicated Server', name: 'Dedicated Servers' },
  ];

  const filteredPackages = hostingPackages.filter(pkg => {
    if (selectedCategory === 'all') return true;
    return pkg.category === selectedCategory;
  });

  const getPrice = (pkg: WhmcsHostingPackage) => {
    if (billingCycle === 'monthly') return pkg.priceMonthly;
    if (billingCycle === 'annually') return pkg.priceAnnually / 12;
    if (billingCycle === 'triennially') return (pkg.priceAnnually * 0.85) / 12;
    return pkg.priceAnnually / 12;
  };

  const getBillingTotal = (pkg: WhmcsHostingPackage) => {
    if (billingCycle === 'monthly') return pkg.priceMonthly;
    if (billingCycle === 'annually') return pkg.priceAnnually;
    if (billingCycle === 'triennially') return pkg.priceAnnually * 2.5; // 3 years discount
    return pkg.priceAnnually;
  };

  const handleAddPackageToCart = (pkg: WhmcsHostingPackage) => {
    const boundDomain = useCustomDomain && customDomainInput.trim() ? customDomainInput.trim() : targetDomain;
    const priceForCycle = getBillingTotal(pkg);

    const newItem: CartItem = {
      id: `cart-hosting-${pkg.id}-${Date.now()}`,
      domain: boundDomain,
      tld: boundDomain.split('.').pop() || 'com',
      registrationPrice: priceForCycle,
      renewalPrice: priceForCycle,
      years: billingCycle === 'triennially' ? 3 : billingCycle === 'annually' ? 1 : 1,
      privacyProtection: true,
      emailForwarding: true,
      dnssecEnabled: true,
      hostingAddon: false,
      icannFee: 0,
      isPremium: false,
      itemType: 'hosting',
      packageName: pkg.name,
      planId: pkg.id,
      billingCycle: billingCycle,
      serverRegion: selectedServerRegion,
      diskLimitMb: pkg.diskLimitMb,
      bandwidthLimitGb: pkg.bandwidthLimitGb,
      module: pkg.module
    };

    onAddToCart(newItem);
    setAddedSuccessId(pkg.id);
    setTimeout(() => {
      setAddedSuccessId(null);
    }, 2500);
  };

  const handleOrderNowDirect = (pkg: WhmcsHostingPackage) => {
    handleAddPackageToCart(pkg);
    onOpenCart();
  };

  const isPackageInCart = (pkgId: string) => {
    return cartItems.some(item => item.itemType === 'hosting' && item.planId === pkgId);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20">
      {/* Hero Header */}
      <div className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-indigo-950/40 to-slate-950 border-b border-slate-800/80 pt-12 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto text-center space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <Zap className="w-4 h-4 text-indigo-400" />
            <span>High Performance NVMe Cloud Infrastructure</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight max-w-4xl mx-auto">
            Ultra-Fast Web Hosting & Cloud VPS
          </h1>

          <p className="text-slate-400 text-base sm:text-lg max-w-2xl mx-auto">
            Deploy lightning-fast cPanel, DirectAdmin, Plesk, or KVM VPS instances. Engineered for maximum uptime, SSD NVMe speeds, and automated instant WHMCS provisioning.
          </p>

          {/* Value Badges */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-300 font-medium">
            <div className="flex items-center gap-2 bg-slate-900/80 px-3.5 py-2 rounded-xl border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>99.99% Guaranteed Uptime SLA</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-900/80 px-3.5 py-2 rounded-xl border border-slate-800">
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              <span>Free Wildcard SSL Included</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-900/80 px-3.5 py-2 rounded-xl border border-slate-800">
              <Clock className="w-4 h-4 text-blue-400" />
              <span>Instant Auto-Provisioning</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-10">
        
        {/* Configuration Bar: Domain Binding, Region & Billing Cycle */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Domain Binding Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-400" />
                <span>Bind Domain Name to Hosting</span>
              </label>

              {!useCustomDomain ? (
                <div className="space-y-2">
                  <select
                    value={targetDomain}
                    onChange={(e) => setTargetDomain(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  >
                    {userDomains.map(d => (
                      <option key={d} value={d}>
                        {d} (Your Registered Domain)
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => setUseCustomDomain(true)}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold underline"
                  >
                    + Enter another domain name
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={customDomainInput}
                    onChange={(e) => setCustomDomainInput(e.target.value)}
                    placeholder="e.g. mynewcompany.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-sm focus:border-indigo-500"
                  />
                  <button
                    onClick={() => setUseCustomDomain(false)}
                    className="text-xs text-slate-400 hover:text-white font-semibold underline"
                  >
                    Select from my existing domains
                  </button>
                </div>
              )}
            </div>

            {/* Datacenter Region Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-400" />
                <span>Datacenter Node Region</span>
              </label>
              <select
                value={selectedServerRegion}
                onChange={(e) => setSelectedServerRegion(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-sm focus:border-emerald-500"
              >
                <option value="US-East Equinix NY4">US-East (New York NY4 - Equinix)</option>
                <option value="EU-Central Frankfurt Interxion">EU-Central (Frankfurt Interxion)</option>
                <option value="Asia-Pacific Singapore Singtel">Asia-Pacific (Singapore Singtel DC)</option>
                <option value="West Africa Ghana Accra Node">West Africa (Ghana Accra Equinix Node)</option>
              </select>
            </div>

            {/* Billing Term Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Select Billing Term</span>
              </label>
              <div className="grid grid-cols-3 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs font-bold">
                <button
                  onClick={() => setBillingCycle('monthly')}
                  className={`py-2 rounded-lg transition-all ${
                    billingCycle === 'monthly' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Monthly
                </button>
                <button
                  onClick={() => setBillingCycle('annually')}
                  className={`py-2 rounded-lg transition-all relative ${
                    billingCycle === 'annually' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Annual <span className="text-[9px] text-emerald-400 font-extrabold">-20%</span>
                </button>
                <button
                  onClick={() => setBillingCycle('triennially')}
                  className={`py-2 rounded-lg transition-all ${
                    billingCycle === 'triennially' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  3 Years <span className="text-[9px] text-amber-400 font-extrabold">-35%</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 ring-1 ring-indigo-400'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white hover:border-slate-700'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Hosting Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredPackages.map((pkg) => {
            const monthlyEquivalent = getPrice(pkg);
            const totalToPay = getBillingTotal(pkg);
            const inCart = isPackageInCart(pkg.id);

            return (
              <div
                key={pkg.id}
                className={`bg-slate-900 border rounded-3xl p-6 flex flex-col justify-between relative transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl ${
                  pkg.category === 'WordPress Cloud' || pkg.name.includes('Business')
                    ? 'border-indigo-500/80 shadow-indigo-500/10'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {pkg.freeDomainEligible && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black uppercase tracking-wider shadow">
                    Free Domain Eligible
                  </div>
                )}

                <div className="space-y-4">
                  {/* Category & Name */}
                  <div>
                    <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-widest">
                      {pkg.category} • {pkg.module.toUpperCase()}
                    </span>
                    <h3 className="text-xl font-black text-white mt-1">
                      {pkg.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 line-clamp-2">
                      {pkg.description}
                    </p>
                  </div>

                  {/* Pricing Box */}
                  <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800/80 space-y-1">
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-black text-white">
                        {formatPrice(monthlyEquivalent, currency)}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">/ mo</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Billed as {formatPrice(totalToPay, currency)} for {billingCycle === 'monthly' ? '1 month' : billingCycle === 'annually' ? '1 year' : '3 years'}
                    </div>
                  </div>

                  {/* Resource Specs */}
                  <div className="space-y-2 text-xs border-t border-slate-800 pt-4">
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-2 text-slate-400">
                        <HardDrive className="w-3.5 h-3.5 text-indigo-400" /> Storage
                      </span>
                      <span className="font-bold text-white">
                        {pkg.diskLimitMb === 0 ? 'Unlimited NVMe' : `${pkg.diskLimitMb / 1000} GB NVMe`}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-2 text-slate-400">
                        <Zap className="w-3.5 h-3.5 text-amber-400" /> Bandwidth
                      </span>
                      <span className="font-bold text-white">
                        {pkg.bandwidthLimitGb === 0 ? 'Unlimited' : `${pkg.bandwidthLimitGb} GB`}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-2 text-slate-400">
                        <Database className="w-3.5 h-3.5 text-blue-400" /> MySQL Databases
                      </span>
                      <span className="font-bold text-white">
                        {pkg.maxDatabases === 0 ? 'Unlimited' : pkg.maxDatabases}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-2 text-slate-400">
                        <Mail className="w-3.5 h-3.5 text-emerald-400" /> Mailboxes
                      </span>
                      <span className="font-bold text-white">
                        {pkg.maxMailboxes === 0 ? 'Unlimited' : pkg.maxMailboxes}
                      </span>
                    </div>
                  </div>

                  {/* Feature Bullets */}
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Included Features
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {pkg.features.map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Add to Cart / Order CTA */}
                <div className="pt-6 mt-6 border-t border-slate-800 space-y-2">
                  <button
                    onClick={() => handleOrderNowDirect(pkg)}
                    className="w-full py-3 px-4 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white rounded-2xl font-black text-xs shadow-lg shadow-indigo-600/30 hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>Order Now & Direct Checkout</span>
                  </button>

                  <button
                    onClick={() => handleAddPackageToCart(pkg)}
                    className={`w-full py-2.5 px-4 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${
                      addedSuccessId === pkg.id
                        ? 'bg-emerald-500 text-slate-950 shadow'
                        : inCart
                        ? 'bg-indigo-950/80 border border-indigo-500/50 text-indigo-300 hover:bg-indigo-900'
                        : 'bg-slate-950 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {addedSuccessId === pkg.id ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-slate-950" />
                        <span>Added to Cart</span>
                      </>
                    ) : inCart ? (
                      <>
                        <ShoppingBag className="w-4 h-4" />
                        <span>In Cart - Add Extra</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4" />
                        <span>Add to Cart</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Plan Comparison Matrix */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <span>Full Hosting Specifications Matrix</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Compare storage, security controls, SLA, and developer toolkits across all tiers.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3">Feature</th>
                  <th className="px-4 py-3">Starter</th>
                  <th className="px-4 py-3">Business Pro</th>
                  <th className="px-4 py-3">WP Enterprise</th>
                  <th className="px-4 py-3">KVM VPS Pro</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300 font-medium">
                <tr>
                  <td className="px-4 py-3 font-bold text-white">NVMe SSD Storage</td>
                  <td className="px-4 py-3">10 GB</td>
                  <td className="px-4 py-3 font-bold text-indigo-400">30 GB</td>
                  <td className="px-4 py-3">50 GB</td>
                  <td className="px-4 py-3 font-bold text-emerald-400">160 GB KVM</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-bold text-white">Monthly Bandwidth</td>
                  <td className="px-4 py-3">250 GB</td>
                  <td className="px-4 py-3">1,000 GB</td>
                  <td className="px-4 py-3">2,000 GB</td>
                  <td className="px-4 py-3">5,000 GB</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-bold text-white">Control Panel</td>
                  <td className="px-4 py-3">cPanel</td>
                  <td className="px-4 py-3">cPanel Direct SSO</td>
                  <td className="px-4 py-3">cPanel + WP-CLI</td>
                  <td className="px-4 py-3">SolusVM / Root SSH</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-bold text-white">SSL Security</td>
                  <td className="px-4 py-3">Free Let's Encrypt</td>
                  <td className="px-4 py-3 font-bold text-emerald-400">Wildcard SSL</td>
                  <td className="px-4 py-3 font-bold text-emerald-400">Wildcard + Cloudflare</td>
                  <td className="px-4 py-3">Custom Cert / Self-Signed</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-bold text-white">Daily Cloud Backups</td>
                  <td className="px-4 py-3">7-Day Retention</td>
                  <td className="px-4 py-3">30-Day Retention</td>
                  <td className="px-4 py-3">Real-time WP Snapshots</td>
                  <td className="px-4 py-3">Automated Node Snapshots</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-indigo-400" />
              <span>Hosting & Cloud VPS FAQ</span>
            </h2>
          </div>

          <div className="space-y-3">
            {[
              {
                q: "How fast is my hosting account provisioned after payment?",
                a: "All hosting accounts are instantly provisioned in under 4 seconds via our automated WHMCS module integration with cPanel, DirectAdmin, Plesk, and SolusVM."
              },
              {
                q: "Can I transfer my existing domain or website to Apex Domain?",
                a: "Yes! Our team offers free migration assistance. Simply provide your cPanel backup file or existing credentials and we'll migrate your site with zero downtime."
              },
              {
                q: "Is a free domain included with annual hosting plans?",
                a: "Yes! All annual and 3-year hosting subscriptions qualify for 1 year of free domain registration on .com, .net, .org, or .gh extensions."
              }
            ].map((faq, index) => (
              <div key={index} className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full p-4 text-left font-bold text-sm text-white flex items-center justify-between"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${openFaq === index ? 'rotate-180 text-indigo-400' : 'text-slate-500'}`} />
                </button>
                {openFaq === index && (
                  <div className="px-4 pb-4 text-xs text-slate-300 border-t border-slate-800/60 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
