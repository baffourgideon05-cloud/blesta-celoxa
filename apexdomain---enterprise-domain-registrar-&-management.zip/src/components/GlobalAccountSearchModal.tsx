import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Globe, Server, FileText, ShoppingBag, LifeBuoy, CreditCard, User, ArrowRight, CornerDownLeft } from 'lucide-react';
import { RegisteredDomain, HostingService, Invoice, SupportTicket, GlobalSearchResultItem } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  registeredDomains: RegisteredDomain[];
  hostingServices: HostingService[];
  invoices: Invoice[];
  tickets: SupportTicket[];
  isAdmin: boolean;
  onNavigateItem: (item: GlobalSearchResultItem) => void;
}

export const GlobalAccountSearchModal: React.FC<Props> = ({
  isOpen,
  onClose,
  registeredDomains,
  hostingServices,
  invoices,
  tickets,
  isAdmin,
  onNavigateItem,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setSearchQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Build searchable database
  const results: GlobalSearchResultItem[] = [];
  const q = searchQuery.trim().toLowerCase();

  if (q.length > 0) {
    // Domains
    registeredDomains.forEach((d) => {
      if (d.domain.toLowerCase().includes(q) || d.status.toLowerCase().includes(q)) {
        results.push({
          id: d.id,
          title: d.domain,
          subtitle: `Domain Name • Expires ${d.expiryDate}`,
          category: 'domain',
          status: d.status,
          linkAction: `domain:${d.domain}`,
        });
      }
    });

    // Hosting
    hostingServices.forEach((h) => {
      if (
        h.name.toLowerCase().includes(q) ||
        h.domain.toLowerCase().includes(q) ||
        h.ipAddress.includes(q) ||
        h.cpanelUser.toLowerCase().includes(q)
      ) {
        results.push({
          id: h.id,
          title: `${h.name} (${h.domain})`,
          subtitle: `Hosting • IP: ${h.ipAddress} • ${h.planName}`,
          category: 'hosting',
          status: h.status,
          linkAction: `hosting:${h.id}`,
        });
      }
    });

    // Invoices & Orders
    invoices.forEach((inv) => {
      if (
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.orderId.toLowerCase().includes(q) ||
        inv.customerName.toLowerCase().includes(q) ||
        inv.customerEmail.toLowerCase().includes(q)
      ) {
        results.push({
          id: inv.id,
          title: `${inv.invoiceNumber} (${inv.orderId})`,
          subtitle: `Invoice • ${inv.currency} ${inv.total.toFixed(2)} • Due ${inv.dueDate}`,
          category: 'invoice',
          status: inv.status,
          linkAction: `invoice:${inv.id}`,
        });
      }
    });

    // Support Tickets
    tickets.forEach((t) => {
      if (
        t.ticketNumber.toLowerCase().includes(q) ||
        t.subject.toLowerCase().includes(q) ||
        t.department.toLowerCase().includes(q)
      ) {
        results.push({
          id: t.id,
          title: `${t.ticketNumber}: ${t.subject}`,
          subtitle: `Ticket • Dept: ${t.department} • Priority: ${t.priority.toUpperCase()}`,
          category: 'ticket',
          status: t.status,
          linkAction: `ticket:${t.id}`,
        });
      }
    });

    // Admin Specific Search
    if (isAdmin) {
      if ('alex morgan'.includes(q) || 'nexustech.io'.includes(q) || 'baffour'.includes(q)) {
        results.push({
          id: 'cust-1',
          title: 'Alex Morgan (Nexus Tech LLC)',
          subtitle: 'Customer Profile • alex.morgan@nexustech.io • 3 Active Domains',
          category: 'customer',
          status: 'Active Customer',
          linkAction: 'customer:alex.morgan',
        });
      }
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'domain':
        return <Globe className="w-4 h-4 text-emerald-500" />;
      case 'hosting':
        return <Server className="w-4 h-4 text-sky-500" />;
      case 'invoice':
        return <FileText className="w-4 h-4 text-amber-500" />;
      case 'ticket':
        return <LifeBuoy className="w-4 h-4 text-indigo-500" />;
      case 'customer':
        return <User className="w-4 h-4 text-purple-500" />;
      default:
        return <CreditCard className="w-4 h-4 text-slate-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const s = status.toLowerCase();
    if (s === 'active' || s === 'paid') return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300';
    if (s === 'unpaid' || s === 'open' || s === 'expiring') return 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300';
    if (s === 'overdue' || s === 'failed') return 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300';
    return 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300';
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-start justify-center pt-16 md:pt-24 px-4 animate-in fade-in">
      <div
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header Bar */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3 bg-slate-50 dark:bg-slate-900">
          <Search className="w-5 h-5 text-emerald-600 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isAdmin
                ? "Search platform (e.g. 'example.com', 'INV-1025', 'John Doe', 'Ticket #582')..."
                : "Search your account (e.g. 'nexustech.io', 'Invoice', 'Hosting', 'SSL')..."
            }
            className="w-full bg-transparent text-slate-900 dark:text-white placeholder-slate-400 text-sm font-medium focus:outline-none"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded">
              <X className="w-4 h-4 text-slate-400" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2 py-1 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            ESC
          </button>
        </div>

        {/* Results Area */}
        <div className="p-2 overflow-y-auto flex-1 divide-y divide-slate-100 dark:divide-slate-800/60">
          {searchQuery.trim().length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              <p className="font-bold text-slate-600 dark:text-slate-300 text-sm mb-1">
                {isAdmin ? 'Universal Admin Search' : 'Global Account Search'}
              </p>
              <p className="max-w-xs mx-auto">
                Type any domain name, invoice number, order ID, support ticket subject, or customer name to locate records instantly.
              </p>
            </div>
          ) : results.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              <p className="font-bold text-slate-600 dark:text-slate-300 text-sm">No results found for "{searchQuery}"</p>
              <p className="mt-1">Try checking for typos or searching by invoice number or domain name.</p>
            </div>
          ) : (
            results.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onNavigateItem(item);
                  onClose();
                }}
                className="p-3 hover:bg-emerald-50/60 dark:hover:bg-emerald-950/30 rounded-xl transition-all cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900 shrink-0 transition-colors">
                    {getCategoryIcon(item.category)}
                  </div>
                  <div className="truncate">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-slate-900 dark:text-white text-sm truncate">
                        {item.title}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${getStatusBadge(item.status)}`}>
                        {item.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {item.subtitle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-slate-400 group-hover:text-emerald-600 shrink-0">
                  <span className="text-[10px] font-bold hidden sm:inline">Select</span>
                  <CornerDownLeft className="w-3.5 h-3.5" />
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Shortcut Helper */}
        <div className="p-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 flex items-center justify-between px-4 font-mono">
          <span>
            {isAdmin ? 'Mode: Admin Universal Search' : 'Mode: Customer Account Search'}
          </span>
          <span>{results.length} result(s)</span>
        </div>
      </div>
    </div>
  );
};
