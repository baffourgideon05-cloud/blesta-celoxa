import React, { useState, useRef } from 'react';
import { 
  User, 
  Lock, 
  Mail, 
  Building, 
  Phone, 
  ShieldCheck, 
  LogOut, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Wallet, 
  PlusCircle, 
  ArrowRight, 
  UserPlus, 
  KeyRound, 
  Camera, 
  Sparkles,
  Server,
  Globe,
  RefreshCw,
  Zap,
  Check,
  LayoutGrid
} from 'lucide-react';
import { systemDatabase, SystemUser } from '../services/systemDatabase';
import { Currency } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency?: Currency;
  onNavigateToView?: (view: any) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currency = 'USD',
  onNavigateToView,
}) => {
  const currentUser = systemDatabase.getCurrentUser();
  const allUsers = systemDatabase.getUsers();

  const [mode, setMode] = useState<'login' | 'register' | 'profile'>(currentUser ? 'profile' : 'login');
  
  // Login form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Register form
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regCompany, setRegCompany] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRole, setRegRole] = useState<'customer' | 'reseller'>('customer');
  const [regError, setRegError] = useState<string | null>(null);
  const [regSuccess, setRegSuccess] = useState<string | null>(null);

  // Wallet Top-up state
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [topUpAmountGhs, setTopUpAmountGhs] = useState(250);
  const [topUpSuccess, setTopUpSuccess] = useState(false);

  // Avatar upload reference
  const avatarInputRef = useRef<HTMLInputElement | null>(null);

  // Google SSO Handler
  const handleGoogleAuth = () => {
    setLoginError(null);
    setRegError(null);

    const userPromptEmail = prompt(
      'Google Sign In / Sign Up:\nEnter your Google Account email address (e.g., alex.morgan@gmail.com):',
      'baffourgideon05@gmail.com'
    );

    if (!userPromptEmail) return;

    const emailClean = userPromptEmail.trim().toLowerCase();
    const namePart = emailClean.split('@')[0].replace(/[._]/g, ' ');
    const formattedName = namePart.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

    const res = systemDatabase.loginOrRegisterWithGoogle({
      fullName: formattedName || 'Google User',
      email: emailClean,
      avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(formattedName || emailClean)}`,
    });

    if (res.success) {
      if (res.isNewUser) {
        setRegSuccess(`Welcome, ${res.user.fullName}! Your Google account was registered & credited with GH₵500 bonus.`);
      }
      if (onNavigateToView) onNavigateToView('client_portal');
      onClose();
    }
  };

  const GoogleIcon = () => (
    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
      />
    </svg>
  );

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const res = systemDatabase.loginUser(loginEmail, loginPassword);
    if (res.success) {
      if (onNavigateToView) onNavigateToView('client_portal');
      onClose();
    } else {
      setLoginError(res.error || 'Login failed.');
    }
  };

  const handleQuickLogin = (email: string) => {
    setLoginError(null);
    const res = systemDatabase.loginUser(email);
    if (res.success) {
      if (onNavigateToView) onNavigateToView('client_portal');
      onClose();
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    setRegSuccess(null);

    if (!regFullName || !regEmail || !regPassword) {
      setRegError('Please complete all required fields.');
      return;
    }

    const res = systemDatabase.registerUser({
      fullName: regFullName,
      email: regEmail,
      password: regPassword,
      companyName: regCompany || 'Individual Account',
      phone: regPhone || '+233 (0) 24 000 0000',
      role: regRole,
      avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(regFullName)}`,
      walletBalanceGhs: 500, // GH₵500 signup gift balance
      walletBalanceUsd: 35,
      twoFactorEnabled: false,
    });

    if (res.success) {
      setRegSuccess('Account created! GH₵500 welcome bonus credited to your wallet.');
      setTimeout(() => {
        if (onNavigateToView) onNavigateToView('client_portal');
        onClose();
        setRegSuccess(null);
      }, 1000);
    } else {
      setRegError(res.error || 'Registration failed.');
    }
  };

  const handleLogout = () => {
    systemDatabase.logoutUser();
    setMode('login');
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && currentUser) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const dataUrl = evt.target?.result as string;
        if (dataUrl) {
          systemDatabase.updateUserProfile(currentUser.id, { avatarUrl: dataUrl });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTopUpSubmit = () => {
    if (!currentUser) return;
    const ghs = Number(topUpAmountGhs);
    const usd = Number((ghs / 15).toFixed(2));
    systemDatabase.topUpUserWallet(currentUser.id, ghs, usd);
    setTopUpSuccess(true);
    setTimeout(() => {
      setTopUpSuccess(false);
      setIsTopUpOpen(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden relative flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/30 border border-blue-400/30 flex items-center justify-center text-cyan-400">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">
                {currentUser ? 'Client Account & Profile' : mode === 'login' ? 'Client Area Authentication' : 'Create Client Account'}
              </h2>
              <p className="text-xs text-slate-400">
                {currentUser ? `Signed in as ${currentUser.fullName}` : 'Access enterprise domain, cloud & server management'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs (if not signed in or switching) */}
        {!currentUser && (
          <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-1.5 shrink-0">
            <button
              onClick={() => { setMode('login'); setLoginError(null); }}
              className={`flex-1 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${
                mode === 'login'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm border border-slate-200 dark:border-slate-800'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
            <button
              onClick={() => { setMode('register'); setRegError(null); }}
              className={`flex-1 py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${
                mode === 'register'
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-200 dark:border-slate-800'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Register Account</span>
            </button>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-800 dark:text-slate-200">
          
          {/* ================= MODE: LOGIN ================= */}
          {!currentUser && mode === 'login' && (
            <div className="space-y-5">
              
              {/* Google Sign In Option */}
              <button
                type="button"
                onClick={handleGoogleAuth}
                className="w-full py-3 px-4 bg-white dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-extrabold text-xs rounded-2xl shadow-sm transition-all flex items-center justify-center gap-3 group"
              >
                <GoogleIcon />
                <span>Continue with Google</span>
              </button>

              <div className="relative flex items-center justify-center my-1">
                <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
                <span className="bg-white dark:bg-slate-900 px-3 text-[10px] font-black uppercase tracking-wider text-slate-400 absolute">
                  Or Sign In with Email
                </span>
              </div>
              
              {loginError && (
                <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="admin@celoxaghana.online"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Password</label>
                    <span className="text-[11px] text-blue-500 font-semibold cursor-pointer hover:underline">Forgot?</span>
                  </div>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>Authenticate & Sign In</span>
                </button>
              </form>

              {/* Quick Demo Sign In Shortcuts */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
                <span className="text-[11px] font-black uppercase tracking-wider text-slate-400 block">
                  ⚡ Quick Demo Accounts (1-Click Login)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={() => handleQuickLogin('admin@celoxaghana.online')}
                    className="p-3 bg-slate-100 dark:bg-slate-800/80 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-2xl border border-slate-200 dark:border-slate-700 text-left transition-all flex items-center gap-3 group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                      SA
                    </div>
                    <div>
                      <span className="font-extrabold text-xs text-slate-900 dark:text-white group-hover:text-blue-500 block">
                        Chief Admin
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 block">admin@celoxaghana.online</span>
                    </div>
                  </button>

                  <button
                    onClick={() => handleQuickLogin('kwame@enterpriseghana.com')}
                    className="p-3 bg-slate-100 dark:bg-slate-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-2xl border border-slate-200 dark:border-slate-700 text-left transition-all flex items-center gap-3 group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                      KM
                    </div>
                    <div>
                      <span className="font-extrabold text-xs text-slate-900 dark:text-white group-hover:text-indigo-500 block">
                        Kwame (Customer)
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 block">kwame@enterpriseghana.com</span>
                    </div>
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* ================= MODE: REGISTER ================= */}
          {!currentUser && mode === 'register' && (
            <div className="space-y-4">
              
              {/* Google Sign Up Button */}
              <button
                type="button"
                onClick={handleGoogleAuth}
                className="w-full py-3 px-4 bg-white dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-extrabold text-xs rounded-2xl shadow-sm transition-all flex items-center justify-center gap-3 group"
              >
                <GoogleIcon />
                <span>Fast Sign Up with Google</span>
              </button>

              <div className="relative flex items-center justify-center my-1">
                <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
                <span className="bg-white dark:bg-slate-900 px-3 text-[10px] font-black uppercase tracking-wider text-slate-400 absolute">
                  Or fill out registration form
                </span>
              </div>
              
              {regError && (
                <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{regError}</span>
                </div>
              )}

              {regSuccess && (
                <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{regSuccess}</span>
                </div>
              )}

              <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-xs">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-300">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      placeholder="e.g. Ama Osei"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-300">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="ama@company.com"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-300">Password *</label>
                    <input
                      type="password"
                      required
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-300">Phone Number</label>
                    <input
                      type="text"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+233 24 123 4567"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Company / Business Name</label>
                  <input
                    type="text"
                    value={regCompany}
                    onChange={(e) => setRegCompany(e.target.value)}
                    placeholder="e.g. Akwaaba Solutions Ltd"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Account Type</label>
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setRegRole('customer')}
                      className={`p-2.5 rounded-xl border text-left transition-all flex items-center gap-2 ${
                        regRole === 'customer'
                          ? 'bg-indigo-500/10 border-indigo-500 text-indigo-400 font-extrabold'
                          : 'border-slate-300 dark:border-slate-700 text-slate-500'
                      }`}
                    >
                      <User className="w-4 h-4" />
                      <div>
                        <span className="block text-xs">Standard Client</span>
                        <span className="block text-[10px] opacity-75">Domains & Hosting</span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRegRole('reseller')}
                      className={`p-2.5 rounded-xl border text-left transition-all flex items-center gap-2 ${
                        regRole === 'reseller'
                          ? 'bg-indigo-500/10 border-indigo-500 text-indigo-400 font-extrabold'
                          : 'border-slate-300 dark:border-slate-700 text-slate-500'
                      }`}
                    >
                      <Building className="w-4 h-4" />
                      <div>
                        <span className="block text-xs">Reseller Partner</span>
                        <span className="block text-[10px] opacity-75">Wholesale API Pricing</span>
                      </div>
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-[11px] text-emerald-400 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <span>New accounts automatically receive GH₵500 / $35 welcome wallet credit!</span>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center gap-2"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Create Account & Auto Sign In</span>
                </button>
              </form>

            </div>
          )}

          {/* ================= MODE: USER PROFILE & DASHBOARD ================= */}
          {currentUser && (
            <div className="space-y-6">
              
              {/* User Identity Card */}
              <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 relative overflow-hidden space-y-4">
                <div className="flex items-center gap-4">
                  <div className="relative group shrink-0">
                    <img
                      src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop'}
                      alt={currentUser.fullName}
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-500/40 shadow-md"
                    />
                    <button
                      onClick={() => avatarInputRef.current?.click()}
                      className="absolute inset-0 bg-slate-900/60 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity"
                    >
                      <Camera className="w-5 h-5" />
                    </button>
                    <input
                      type="file"
                      ref={avatarInputRef}
                      onChange={handleAvatarUpload}
                      accept="image/*"
                      className="hidden"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-black text-slate-900 dark:text-white">{currentUser.fullName}</h3>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        currentUser.role === 'admin'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : currentUser.role === 'reseller'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                      }`}>
                        {currentUser.role}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">{currentUser.email}</p>
                    <p className="text-[11px] text-slate-400">{currentUser.companyName || 'Individual'}</p>
                  </div>
                </div>

                {/* WALLET & FUNDS BOX */}
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-extrabold uppercase text-slate-400 flex items-center gap-1">
                      <Wallet className="w-3.5 h-3.5 text-emerald-500" />
                      Client Pre-paid Wallet Balance
                    </span>
                    <div className="text-xl font-black text-slate-900 dark:text-white">
                      {currency === 'GHS' ? `GH₵ ${currentUser.walletBalanceGhs.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : `$ ${currentUser.walletBalanceUsd.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
                    </div>
                  </div>

                  <button
                    onClick={() => setIsTopUpOpen(true)}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>Top Up Wallet</span>
                  </button>
                </div>
              </div>

              {/* TOP UP MODAL OVERLAY */}
              {isTopUpOpen && (
                <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-2xl space-y-3 text-xs animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-emerald-300 flex items-center gap-1.5">
                      <Wallet className="w-4 h-4" />
                      Simulate Wallet Deposit (Instant Credit)
                    </span>
                    <button onClick={() => setIsTopUpOpen(false)} className="text-slate-400 hover:text-white">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {topUpSuccess ? (
                    <div className="p-3 bg-emerald-500/20 text-emerald-300 rounded-xl font-bold text-center">
                      ✓ Deposit credited successfully! Balance updated.
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-2.5 font-bold text-slate-400 text-xs">GH₵</span>
                        <input
                          type="number"
                          value={topUpAmountGhs}
                          onChange={(e) => setTopUpAmountGhs(Number(e.target.value))}
                          className="w-full pl-12 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold text-xs"
                        />
                      </div>
                      <button
                        onClick={handleTopUpSubmit}
                        className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl shadow transition-all"
                      >
                        Confirm Deposit
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* PRIMARY LAUNCH CLIENT DASHBOARD BUTTON */}
              <button
                onClick={() => {
                  onClose();
                  if (onNavigateToView) onNavigateToView('client_portal');
                }}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-black text-xs rounded-2xl shadow-xl shadow-blue-600/30 transition-all flex items-center justify-center gap-2 transform hover:scale-[1.01]"
              >
                <LayoutGrid className="w-4 h-4" />
                <span>Go to Client Account Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* ACCOUNT ACTIONS & QUICK NAVIGATION */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                
                {currentUser.role === 'admin' && (
                  <button
                    onClick={() => { onClose(); onNavigateToView?.('settings'); }}
                    className="p-3 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-2xl border border-slate-200 dark:border-slate-700 text-left transition-all flex items-center gap-3"
                  >
                    <Server className="w-5 h-5 text-blue-500 shrink-0" />
                    <div>
                      <span className="font-black text-slate-900 dark:text-white block">System Settings & Logo</span>
                      <span className="text-[10px] text-slate-500">Configure global site branding</span>
                    </div>
                  </button>
                )}

                <button
                  onClick={() => { onClose(); onNavigateToView?.('hosting_provision'); }}
                  className="p-3 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-2xl border border-slate-200 dark:border-slate-700 text-left transition-all flex items-center gap-3"
                >
                  <Globe className="w-5 h-5 text-indigo-500 shrink-0" />
                  <div>
                    <span className="font-black text-slate-900 dark:text-white block">Provisioned Servers</span>
                    <span className="text-[10px] text-slate-500">View active cPanel / WHMCS accounts</span>
                  </div>
                </button>

              </div>

              {/* SWITCH DEMO USERS OR SIGN OUT */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-400 font-bold">Switch Account:</span>
                  {allUsers.map((u) => (
                    <button
                      key={u.id}
                      onClick={() => handleQuickLogin(u.email)}
                      className={`px-2 py-1 rounded text-[10px] font-bold ${
                        u.id === currentUser.id
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-300'
                      }`}
                    >
                      {u.fullName.split(' ')[0]}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleLogout}
                  className="px-4 py-2 bg-rose-600/10 hover:bg-rose-600/20 text-rose-500 font-extrabold text-xs rounded-xl border border-rose-500/20 transition-all flex items-center gap-1.5"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
};
