import React, { useState } from 'react';
import { 
  CreditCard, 
  Smartphone, 
  Landmark, 
  Save, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Sliders, 
  ShieldCheck, 
  FileText, 
  HelpCircle,
  Eye,
  Check,
  X,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { PaymentMethodSettings, PaymentSubmission, Currency } from '../types';
import { formatPrice } from '../utils/domainSearchEngine';

interface AdminPaymentSettingsProps {
  settings: PaymentMethodSettings;
  onUpdateSettings: (newSettings: PaymentMethodSettings) => void;
  submissions: PaymentSubmission[];
  onApproveSubmission: (submissionId: string) => void;
  onRejectSubmission: (submissionId: string) => void;
  currency: Currency;
}

export const AdminPaymentSettings: React.FC<AdminPaymentSettingsProps> = ({
  settings,
  onUpdateSettings,
  submissions,
  onApproveSubmission,
  onRejectSubmission,
  currency,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'custom' | 'paystack' | 'submissions'>('custom');

  // Local state for editable settings
  const [formSettings, setFormSettings] = useState<PaymentMethodSettings>(settings);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Paystack Connection Test state
  const [isTestingPaystack, setIsTestingPaystack] = useState(false);
  const [paystackTestStatus, setPaystackTestStatus] = useState<{ success: boolean; message: string } | null>(null);

  const handleTestPaystackKey = async () => {
    setIsTestingPaystack(true);
    setPaystackTestStatus(null);
    try {
      const res = await fetch('/api/paystack/test-credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ secretKey: formSettings.paystack.secretKey }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setPaystackTestStatus({
          success: true,
          message: data.message || 'Connected to Paystack API server successfully!',
        });
      } else {
        setPaystackTestStatus({
          success: false,
          message: data.message || 'Paystack test failed. Check your Secret Key.',
        });
      }
    } catch (err: any) {
      setPaystackTestStatus({
        success: false,
        message: err.message || 'Error connecting to Paystack API server.',
      });
    } finally {
      setIsTestingPaystack(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formSettings);
    setSaveSuccessMsg('Payment settings and instructions saved successfully!');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  const pendingCount = submissions.filter((s) => s.status === 'pending_approval').length;

  return (
    <div className="space-y-6">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-indigo-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/30 border border-indigo-400/30 text-indigo-200 text-xs font-extrabold uppercase tracking-wider">
              Admin Area
            </span>
            <span className="text-xs text-slate-300">Payment Gateway & Custom Instructions Control</span>
          </div>
          <h2 className="text-2xl font-black mt-1">Payment Systems & Submissions</h2>
          <p className="text-xs text-slate-300 max-w-xl mt-1">
            Configure custom manual payment instructions (Bank Transfer, Mobile Money), set up Paystack keys, and verify customer payment submissions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs shadow-lg shadow-blue-600/30 flex items-center gap-2 transition-all hover:scale-105"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </div>

      {saveSuccessMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 text-emerald-800 dark:text-emerald-200 font-bold text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* Sub Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveSubTab('custom')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeSubTab === 'custom'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          <Landmark className="w-4 h-4" />
          <span>Custom Payment & Instructions</span>
        </button>

        <button
          onClick={() => setActiveSubTab('paystack')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeSubTab === 'paystack'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          <span>Paystack Gateway (GHS / Africa)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('submissions')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 relative ${
            activeSubTab === 'submissions'
              ? 'bg-purple-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Payment Submissions & Approvals</span>
          {pendingCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white text-[10px] font-black animate-pulse">
              {pendingCount} Pending
            </span>
          )}
        </button>
      </div>

      {/* TAB 1: CUSTOM PAYMENT & INSTRUCTIONS CONFIGURATOR */}
      {activeSubTab === 'custom' && (
        <form onSubmit={handleSave} className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
            
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <Landmark className="w-5 h-5 text-blue-600" />
                  Custom Payment Method & Customer Instructions
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Allows customers to pay directly via Bank Transfer or Mobile Money and submit proof for admin approval.
                </p>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={formSettings.customPayment.enabled}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      customPayment: { ...formSettings.customPayment, enabled: e.target.checked },
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                <span className="ml-3 text-xs font-extrabold text-slate-700 dark:text-slate-300">
                  {formSettings.customPayment.enabled ? 'Enabled' : 'Disabled'}
                </span>
              </label>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Custom Payment Display Title
                </label>
                <input
                  type="text"
                  value={formSettings.customPayment.title}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      customPayment: { ...formSettings.customPayment, title: e.target.value },
                    })
                  }
                  placeholder="e.g., Direct Bank Transfer / Mobile Money"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Payment Subtitle / Short Description
                </label>
                <input
                  type="text"
                  value={formSettings.customPayment.description}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      customPayment: { ...formSettings.customPayment, description: e.target.value },
                    })
                  }
                  placeholder="e.g., Pay via GCB Bank or MTN MoMo / Telecel Cash"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium"
                />
              </div>
            </div>

            {/* Bank Details Config */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-4">
              <h4 className="font-extrabold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <Landmark className="w-4 h-4 text-indigo-600" />
                Bank Transfer Details (Shown to Customer)
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    Bank Name
                  </label>
                  <input
                    type="text"
                    value={formSettings.customPayment.bankName}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        customPayment: { ...formSettings.customPayment, bankName: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    Account Number
                  </label>
                  <input
                    type="text"
                    value={formSettings.customPayment.accountNumber}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        customPayment: { ...formSettings.customPayment, accountNumber: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    Account Name
                  </label>
                  <input
                    type="text"
                    value={formSettings.customPayment.accountName}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        customPayment: { ...formSettings.customPayment, accountName: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    SWIFT / BIC Code
                  </label>
                  <input
                    type="text"
                    value={formSettings.customPayment.swiftCode || ''}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        customPayment: { ...formSettings.customPayment, swiftCode: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Mobile Money Details Config */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-4">
              <h4 className="font-extrabold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-600" />
                Mobile Money Details (Ghana Networks)
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    Supported Network Providers
                  </label>
                  <input
                    type="text"
                    value={formSettings.customPayment.momoProvider}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        customPayment: { ...formSettings.customPayment, momoProvider: e.target.value },
                      })
                    }
                    placeholder="e.g. MTN Mobile Money / Telecel Cash"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    Mobile Money Number(s)
                  </label>
                  <input
                    type="text"
                    value={formSettings.customPayment.momoNumber}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        customPayment: { ...formSettings.customPayment, momoNumber: e.target.value },
                      })
                    }
                    placeholder="024 123 4567"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    Mobile Money Registered Name
                  </label>
                  <input
                    type="text"
                    value={formSettings.customPayment.momoName}
                    onChange={(e) =>
                      setFormSettings({
                        ...formSettings,
                        customPayment: { ...formSettings.customPayment, momoName: e.target.value },
                      })
                    }
                    placeholder="ApexDomain Ghana Ltd"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Step-by-Step Payment Instructions Textarea */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Custom Payment Instructions (Step-by-Step for Customer)
              </label>
              <textarea
                rows={4}
                value={formSettings.customPayment.instructions}
                onChange={(e) =>
                  setFormSettings({
                    ...formSettings,
                    customPayment: { ...formSettings.customPayment, instructions: e.target.value },
                  })
                }
                className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono leading-relaxed"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                This text will be displayed directly to the customer during checkout when they select Custom Payment.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center gap-2"
              >
                <Save className="w-4 h-4" /> Save Custom Instructions
              </button>
            </div>

          </div>
        </form>
      )}

      {/* TAB 2: PAYSTACK GATEWAY INTEGRATION CONFIGURATOR */}
      {activeSubTab === 'paystack' && (
        <form onSubmit={handleSave} className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
            
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-600" />
                  Paystack Payment Gateway Configuration
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Accept payments in Ghanaian Cedis (GHS), Mobile Money (MTN MoMo, Telecel Cash, AirtelTigo), Cards, and Bank Transfer across Africa.
                </p>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={formSettings.paystack.enabled}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      paystack: { ...formSettings.paystack, enabled: e.target.checked },
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                <span className="ml-3 text-xs font-extrabold text-slate-700 dark:text-slate-300">
                  {formSettings.paystack.enabled ? 'Enabled' : 'Disabled'}
                </span>
              </label>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Paystack Public Key
                </label>
                <input
                  type="text"
                  value={formSettings.paystack.publicKey}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      paystack: { ...formSettings.paystack, publicKey: e.target.value },
                    })
                  }
                  placeholder="pk_test_..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs font-bold text-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Paystack Secret Key
                </label>
                <input
                  type="password"
                  value={formSettings.paystack.secretKey}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      paystack: { ...formSettings.paystack, secretKey: e.target.value },
                    })
                  }
                  placeholder="sk_test_..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Merchant Display Name
                </label>
                <input
                  type="text"
                  value={formSettings.paystack.merchantName}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      paystack: { ...formSettings.paystack, merchantName: e.target.value },
                    })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Primary Settlement Currency
                </label>
                <select
                  value={formSettings.paystack.currencyPreference}
                  onChange={(e) =>
                    setFormSettings({
                      ...formSettings,
                      paystack: {
                        ...formSettings.paystack,
                        currencyPreference: e.target.value as 'GHS' | 'USD' | 'NGN',
                      },
                    })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                >
                  <option value="GHS">GHS - Ghanaian Cedi (GH₵)</option>
                  <option value="USD">USD - United States Dollar ($)</option>
                  <option value="NGN">NGN - Nigerian Naira (₦)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Environment Mode
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setFormSettings({
                      ...formSettings,
                      paystack: { ...formSettings.paystack, testMode: !formSettings.paystack.testMode },
                    })
                  }
                  className={`w-full py-2.5 rounded-xl text-xs font-black transition-colors ${
                    formSettings.paystack.testMode
                      ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-300'
                      : 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300'
                  }`}
                >
                  {formSettings.paystack.testMode ? 'Test Mode (Sandbox)' : 'Live Production Mode'}
                </button>
              </div>
            </div>

            {paystackTestStatus && (
              <div
                className={`p-4 rounded-xl border text-xs font-bold flex items-center justify-between gap-2 animate-in fade-in ${
                  paystackTestStatus.success
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 text-emerald-800 dark:text-emerald-200'
                    : 'bg-red-50 dark:bg-red-950/40 border-red-300 text-red-800 dark:text-red-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  {paystackTestStatus.success ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
                  )}
                  <span>{paystackTestStatus.message}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setPaystackTestStatus(null)}
                  className="p-1 hover:bg-black/10 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleTestPaystackKey}
                disabled={isTestingPaystack}
                className="px-4 py-2.5 rounded-xl border border-emerald-500/50 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 font-extrabold text-xs flex items-center gap-2 transition-colors"
              >
                <RefreshCw className={`w-4 h-4 ${isTestingPaystack ? 'animate-spin' : ''}`} />
                <span>{isTestingPaystack ? 'Testing Paystack Server...' : 'Test Connection to Paystack Server'}</span>
              </button>

              <button
                type="submit"
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center gap-2"
              >
                <Save className="w-4 h-4" /> Save Paystack Gateway Settings
              </button>
            </div>

          </div>
        </form>
      )}

      {/* TAB 3: CUSTOM PAYMENT SUBMISSIONS & APPROVALS MANAGER */}
      {activeSubTab === 'submissions' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-600" />
                Customer Payment Submissions & Manual Approvals
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Review payment receipts submitted by customers for manual bank transfer or Mobile Money orders.
              </p>
            </div>

            <span className="text-xs text-slate-400 font-bold">
              Total Submissions: {submissions.length}
            </span>
          </div>

          {submissions.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <FileText className="w-8 h-8 mx-auto" />
              <div className="font-bold text-xs">No Payment Submissions Found</div>
            </div>
          ) : (
            <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              {submissions.map((sub) => (
                <div key={sub.id} className="p-4 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-100/50 transition-colors space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-slate-900 dark:text-white">{sub.orderId}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          sub.paymentMethod === 'paystack'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                            : 'bg-purple-100 text-purple-800 dark:bg-purple-950/80 dark:text-purple-300'
                        }`}>
                          {sub.paymentMethod === 'paystack' ? 'Paystack' : 'Custom Payment'}
                        </span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          sub.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                            : sub.status === 'pending_approval'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
                            : 'bg-red-100 text-red-800 dark:bg-red-950/80 dark:text-red-300'
                        }`}>
                          {sub.status.replace('_', ' ')}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        Customer: <strong className="text-slate-800 dark:text-slate-200">{sub.customerName}</strong> ({sub.customerEmail})
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-base font-black text-blue-600 dark:text-blue-400">
                        {sub.currency === 'GHS' ? `GH₵ ${sub.amount.toFixed(2)}` : formatPrice(sub.amount, sub.currency)}
                      </div>
                      <div className="text-[10px] text-slate-400">{sub.createdAt}</div>
                    </div>
                  </div>

                  {/* Submission details */}
                  <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 text-xs space-y-1">
                    <div><span className="text-slate-400 font-bold">Domains:</span> {sub.domains.join(', ')}</div>
                    {sub.customProofText && (
                      <div><span className="text-slate-400 font-bold">Payment Proof / Ref:</span> <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">{sub.customProofText}</span></div>
                    )}
                    {sub.paystackReference && (
                      <div><span className="text-slate-400 font-bold">Paystack Reference:</span> <span className="font-mono text-purple-600 dark:text-purple-400">{sub.paystackReference}</span></div>
                    )}
                  </div>

                  {/* Approval Actions */}
                  {sub.status === 'pending_approval' && (
                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        onClick={() => onRejectSubmission(sub.id)}
                        className="px-3 py-1.5 rounded-lg border border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 text-xs font-bold flex items-center gap-1.5 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" /> Reject Payment
                      </button>

                      <button
                        onClick={() => onApproveSubmission(sub.id)}
                        className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" /> Approve Payment & Provision
                      </button>
                    </div>
                  )}

                </div>
              ))}
            </div>
          )}

        </div>
      )}

    </div>
  );
};
