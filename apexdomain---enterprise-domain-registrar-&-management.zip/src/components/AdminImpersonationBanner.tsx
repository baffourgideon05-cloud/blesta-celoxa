import React from 'react';
import { UserCheck, LogOut, Clock, ShieldAlert } from 'lucide-react';
import { ImpersonationState } from '../types';

interface Props {
  impersonation: ImpersonationState;
  onExitImpersonation: () => void;
}

export const AdminImpersonationBanner: React.FC<Props> = ({ impersonation, onExitImpersonation }) => {
  if (!impersonation.isActive) return null;

  return (
    <div className="bg-amber-500 text-slate-950 px-4 py-2 text-xs font-bold shadow-md flex items-center justify-between gap-3 z-50 sticky top-0 border-b border-amber-600">
      <div className="flex items-center gap-2 overflow-hidden">
        <span className="p-1 bg-slate-950 text-amber-400 rounded-md shrink-0">
          <ShieldAlert className="w-3.5 h-3.5" />
        </span>
        <div className="truncate">
          <span className="uppercase tracking-wider text-[10px] bg-slate-950/20 px-1.5 py-0.5 rounded mr-2 font-black">
            Staff Impersonation Active
          </span>
          <span>
            Logged in as <strong className="underline">{impersonation.targetCustomerName}</strong> ({impersonation.targetCustomerEmail}) by Admin <strong className="font-mono">{impersonation.adminName}</strong>
          </span>
          <span className="hidden md:inline text-slate-900/80 ml-2 italic">
            Reason: "{impersonation.reason}"
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3 shrink-0">
        <span className="hidden sm:flex items-center gap-1 text-[11px] opacity-90">
          <Clock className="w-3 h-3" />
          <span>Session Logged</span>
        </span>
        <button
          onClick={onExitImpersonation}
          className="px-3 py-1 bg-slate-950 hover:bg-slate-900 text-amber-400 font-extrabold text-[11px] rounded-lg shadow flex items-center gap-1.5 transition-all"
        >
          <LogOut className="w-3 h-3" />
          <span>Exit Impersonation</span>
        </button>
      </div>
    </div>
  );
};
