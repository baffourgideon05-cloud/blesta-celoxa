import { Router, Request, Response } from 'express';
import { iamStore, PlatformRole } from './iamStore.js';

export const authRouter = Router();

// Helper to parse cookie header
function parseCookies(cookieHeader?: string): Record<string, string> {
  const list: Record<string, string> = {};
  if (!cookieHeader) return list;

  cookieHeader.split(';').forEach(cookie => {
    const parts = cookie.split('=');
    if (parts.length >= 2) {
      list[parts[0].trim()] = decodeURIComponent(parts.slice(1).join('=').trim());
    }
  });

  return list;
}

// Cookie configuration
const SESSION_COOKIE_NAME = 'celoxa_session';

function setSessionCookie(res: Response, sessionId: string) {
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE_NAME}=${sessionId}; HttpOnly; Path=/; Max-Age=604800; SameSite=Lax`
  );
}

function clearSessionCookie(res: Response) {
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE_NAME}=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax`
  );
}

// 1. PUBLIC CLIENT REGISTRATION
authRouter.post('/register', (req: Request, res: Response) => {
  try {
    const { email, password, fullName, phone, country } = req.body;

    if (!email || !password || !fullName) {
      return res.status(400).json({ error: 'Full name, email address, and password are required.' });
    }

    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }

    const result = iamStore.registerClient({ email, password, fullName, phone, country });

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      success: true,
      message: 'Account created! Please check your email to verify your account.',
      userId: result.user?.id,
      verificationToken: result.verificationToken // Returned for testing & demo interface
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

// 2. EMAIL VERIFICATION (SINGLE-USE, TIME-LIMITED TOKEN)
authRouter.post('/verify-email', (req: Request, res: Response) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'Verification token is required.' });
    }

    const result = iamStore.verifyEmail(token);

    if (!result.success) {
      return res.status(400).json({ error: result.message });
    }

    res.json({
      success: true,
      message: result.message,
      user: {
        id: result.user?.id,
        email: result.user?.email,
        fullName: result.user?.fullName,
        isEmailVerified: result.user?.isEmailVerified,
        accountStatus: result.user?.accountStatus
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Verification failed' });
  }
});

// 3. RESEND VERIFICATION EMAIL
authRouter.post('/resend-verification', (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email address is required.' });
    }

    const result = iamStore.resendVerificationToken(email);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to resend verification email' });
  }
});

// 4. CLIENT / UNIFIED LOGIN
authRouter.post('/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
    const userAgent = req.headers['user-agent'] || 'Web Browser';

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const result = iamStore.login({
      email,
      password,
      ip,
      userAgent
    });

    if (!result.success || !result.sessionId || !result.user) {
      return res.status(401).json({ error: result.error || 'Invalid credentials' });
    }

    // Set Secure HTTP-Only Cookie
    setSessionCookie(res, result.sessionId);

    res.json({
      success: true,
      message: 'Login successful',
      user: {
        id: result.user.id,
        email: result.user.email,
        fullName: result.user.fullName,
        role: result.user.role,
        platformRole: result.user.platformRole,
        accountStatus: result.user.accountStatus,
        isEmailVerified: result.user.isEmailVerified,
        twoFactorEnabled: result.user.twoFactorEnabled,
        permissions: result.user.permissions
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Login failed' });
  }
});

// 4b. GOOGLE OAUTH SIGN-IN / SIGN-UP
authRouter.post('/google', (req: Request, res: Response) => {
  try {
    const { email, fullName } = req.body;
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
    const userAgent = req.headers['user-agent'] || 'Google SSO';

    if (!email) {
      return res.status(400).json({ error: 'Google email address is required.' });
    }

    const result = iamStore.googleAuth({
      email,
      fullName: fullName || email.split('@')[0],
      ip,
      userAgent
    });

    setSessionCookie(res, result.sessionId);

    res.json({
      success: true,
      isNewUser: result.isNewUser,
      message: result.isNewUser ? 'Google Sign Up successful' : 'Google Sign In successful',
      user: {
        id: result.user.id,
        email: result.user.email,
        fullName: result.user.fullName,
        role: result.user.role,
        platformRole: result.user.platformRole,
        accountStatus: result.user.accountStatus,
        isEmailVerified: result.user.isEmailVerified,
        twoFactorEnabled: result.user.twoFactorEnabled,
        permissions: result.user.permissions
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Google authentication failed' });
  }
});

// 5. DEDICATED STAFF / ADMIN PORTAL LOGIN
authRouter.post('/staff-login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
    const userAgent = req.headers['user-agent'] || 'Web Browser';

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const result = iamStore.login({
      email,
      password,
      ip,
      userAgent,
      requiredPortalRole: 'staff' // Requires Staff, Admin, or Super Admin
    });

    if (!result.success || !result.sessionId || !result.user) {
      return res.status(403).json({ error: result.error || 'Access denied for staff portal' });
    }

    // Set Secure HTTP-Only Cookie
    setSessionCookie(res, result.sessionId);

    res.json({
      success: true,
      message: `Welcome to Staff Portal, ${result.user.fullName}`,
      user: {
        id: result.user.id,
        email: result.user.email,
        fullName: result.user.fullName,
        role: result.user.role,
        platformRole: result.user.platformRole,
        department: result.user.department,
        staffTitle: result.user.staffTitle,
        accountStatus: result.user.accountStatus,
        permissions: result.user.permissions
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Staff login failed' });
  }
});

// 6. GET CURRENT AUTHENTICATED USER SESSION (/api/auth/me)
authRouter.get('/me', (req: Request, res: Response) => {
  try {
    const cookies = parseCookies(req.headers.cookie);
    const sessionId = cookies[SESSION_COOKIE_NAME];

    if (!sessionId) {
      return res.status(401).json({ authenticated: false, message: 'No active session cookie found.' });
    }

    const session = iamStore.validateSession(sessionId);
    if (!session) {
      clearSessionCookie(res);
      return res.status(401).json({ authenticated: false, message: 'Session expired or revoked.' });
    }

    const user = iamStore.findUserById(session.userId);
    if (!user) {
      clearSessionCookie(res);
      return res.status(401).json({ authenticated: false, message: 'User account not found.' });
    }

    res.json({
      authenticated: true,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        phone: user.phone,
        country: user.country,
        role: user.role,
        platformRole: user.platformRole,
        department: user.department,
        staffTitle: user.staffTitle,
        accountStatus: user.accountStatus,
        isEmailVerified: user.isEmailVerified,
        twoFactorEnabled: user.twoFactorEnabled,
        permissions: user.permissions,
        lastLoginAt: user.lastLoginAt
      },
      session: {
        sessionId: session.sessionId,
        createdAt: session.createdAt,
        expiresAt: session.expiresAt
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Session validation failed' });
  }
});

// 7. LOGOUT (REVOKE SESSION & CLEAR COOKIE)
authRouter.post('/logout', (req: Request, res: Response) => {
  try {
    const cookies = parseCookies(req.headers.cookie);
    const sessionId = cookies[SESSION_COOKIE_NAME];

    if (sessionId) {
      iamStore.revokeSession(sessionId);
    }

    clearSessionCookie(res);
    res.json({ success: true, message: 'Logged out successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Logout failed' });
  }
});

// 8. STAFF / ADMIN INVITATION (BY PRIVILEGED USER)
authRouter.post('/invite-staff', (req: Request, res: Response) => {
  try {
    const { email, fullName, role, department, staffTitle, permissions, createdByEmail } = req.body;

    if (!email || !fullName || !role) {
      return res.status(400).json({ error: 'Email, full name, and role are required for staff invitation.' });
    }

    const result = iamStore.createStaffInvitation({
      email,
      fullName,
      role: role as PlatformRole,
      department: department || 'Technical Support',
      staffTitle: staffTitle || 'Support Specialist',
      permissions,
      createdByEmail: createdByEmail || 'admin@celoxaghana.online'
    });

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      success: true,
      message: `Staff invitation token generated for ${email}`,
      invitationToken: result.invitation?.token,
      expiresAt: result.invitation?.expiresAt
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to create staff invitation' });
  }
});

// 9. ACCEPT STAFF INVITATION
authRouter.post('/accept-staff-invite', (req: Request, res: Response) => {
  try {
    const { token, password, phone } = req.body;

    if (!token || !password) {
      return res.status(400).json({ error: 'Invitation token and password are required.' });
    }

    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }

    const result = iamStore.acceptStaffInvitation({ token, password, phone });

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      success: true,
      message: 'Staff account successfully created and activated! You may now sign in to the Staff Portal.',
      user: {
        id: result.user?.id,
        email: result.user?.email,
        fullName: result.user?.fullName,
        role: result.user?.role
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to accept invitation' });
  }
});

// 10. LIST AUDIT LOGS
authRouter.get('/audit-logs', (req: Request, res: Response) => {
  try {
    res.json({ logs: iamStore.getAuditLogs() });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch audit logs' });
  }
});
