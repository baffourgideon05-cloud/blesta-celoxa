import crypto from 'crypto';

export type PlatformRole = 'super_admin' | 'administrator' | 'staff' | 'client';
export type UserAccountStatus = 'active' | 'pending_verification' | 'suspended' | 'locked' | 'deactivated';

export interface ModulePermissions {
  customers: { view: boolean; edit: boolean; suspend: boolean; delete: boolean };
  billing: { viewInvoices: boolean; createInvoice: boolean; processRefund: boolean; manageGateways: boolean };
  hosting: { view: boolean; provision: boolean; suspend: boolean; terminate: boolean };
  domains: { view: boolean; register: boolean; transfer: boolean; manageDns: boolean };
  tickets: { view: boolean; reply: boolean; assign: boolean; close: boolean };
  system: { viewSettings: boolean; editSettings: boolean; manageStaff: boolean; viewAuditLogs: boolean };
}

export interface UserRecord {
  id: string;
  email: string;
  passwordHash: string; // Hashed password
  fullName: string;
  phone?: string;
  country?: string;
  companyName?: string;
  role: PlatformRole;
  platformRole: PlatformRole;
  department?: string;
  staffTitle?: string;
  accountStatus: UserAccountStatus;
  isEmailVerified: boolean;
  twoFactorEnabled: boolean;
  mfaSecret?: string;
  mfaBackupCodes?: string[];
  createdAt: string;
  lastLoginAt?: string;
  permissions: ModulePermissions;
}

export interface VerificationToken {
  id: string;
  token: string;
  userId: string;
  email: string;
  createdAt: string;
  expiresAt: string; // ISO String, 24 hours from creation
  used: boolean;
}

export interface StaffInvitationToken {
  id: string;
  token: string;
  email: string;
  fullName: string;
  role: PlatformRole;
  department: string;
  staffTitle: string;
  permissions: ModulePermissions;
  createdByEmail: string;
  createdAt: string;
  expiresAt: string;
  used: boolean;
}

export interface UserSession {
  sessionId: string;
  userId: string;
  role: PlatformRole;
  createdAt: string;
  expiresAt: string;
  ip: string;
  userAgent: string;
  isRevoked: boolean;
}

export interface AuditLogRecord {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  details: string;
  ipAddress: string;
}

// Default Permissions Presets
export const DEFAULT_CLIENT_PERMISSIONS: ModulePermissions = {
  customers: { view: false, edit: false, suspend: false, delete: false },
  billing: { viewInvoices: true, createInvoice: false, processRefund: false, manageGateways: false },
  hosting: { view: true, provision: false, suspend: false, terminate: false },
  domains: { view: true, register: true, transfer: true, manageDns: true },
  tickets: { view: true, reply: true, assign: false, close: true },
  system: { viewSettings: false, editSettings: false, manageStaff: false, viewAuditLogs: false }
};

export const DEFAULT_SUPPORT_STAFF_PERMISSIONS: ModulePermissions = {
  customers: { view: true, edit: true, suspend: false, delete: false },
  billing: { viewInvoices: true, createInvoice: false, processRefund: false, manageGateways: false },
  hosting: { view: true, provision: true, suspend: true, terminate: false },
  domains: { view: true, register: true, transfer: true, manageDns: true },
  tickets: { view: true, reply: true, assign: true, close: true },
  system: { viewSettings: true, editSettings: false, manageStaff: false, viewAuditLogs: true }
};

export const DEFAULT_ADMIN_PERMISSIONS: ModulePermissions = {
  customers: { view: true, edit: true, suspend: true, delete: false },
  billing: { viewInvoices: true, createInvoice: true, processRefund: true, manageGateways: true },
  hosting: { view: true, provision: true, suspend: true, terminate: true },
  domains: { view: true, register: true, transfer: true, manageDns: true },
  tickets: { view: true, reply: true, assign: true, close: true },
  system: { viewSettings: true, editSettings: true, manageStaff: true, viewAuditLogs: true }
};

export const DEFAULT_SUPER_ADMIN_PERMISSIONS: ModulePermissions = {
  customers: { view: true, edit: true, suspend: true, delete: true },
  billing: { viewInvoices: true, createInvoice: true, processRefund: true, manageGateways: true },
  hosting: { view: true, provision: true, suspend: true, terminate: true },
  domains: { view: true, register: true, transfer: true, manageDns: true },
  tickets: { view: true, reply: true, assign: true, close: true },
  system: { viewSettings: true, editSettings: true, manageStaff: true, viewAuditLogs: true }
};

// Simple Password Hashing Helper (SHA-256 with salt)
export function hashPassword(password: string): string {
  const salt = "celoxa_secure_iam_salt_2026";
  return crypto.createHash('sha256').update(password + salt).digest('hex');
}

class IamStoreEngine {
  private users: UserRecord[] = [
    {
      id: 'usr-admin-1',
      email: 'admin@celoxaghana.online',
      passwordHash: hashPassword('AdminPass2026!'),
      fullName: 'Chief Super Admin',
      phone: '+233 20 123 4567',
      country: 'Ghana',
      companyName: 'Celoxa Technology Group Ltd',
      role: 'super_admin',
      platformRole: 'super_admin',
      department: 'Executive Leadership',
      staffTitle: 'Head of Infrastructure & IAM',
      accountStatus: 'active',
      isEmailVerified: true,
      twoFactorEnabled: true,
      mfaSecret: 'JBSWY3DPEHPK3PXP',
      mfaBackupCodes: ['8942-1029', '3910-8271', '4019-2819'],
      createdAt: '2026-01-01T00:00:00.000Z',
      lastLoginAt: new Date().toISOString(),
      permissions: DEFAULT_SUPER_ADMIN_PERMISSIONS
    },
    {
      id: 'staff-demo-1',
      email: 'support@celoxaghana.online',
      passwordHash: hashPassword('SupportPass2026!'),
      fullName: 'Kofi Mensah',
      phone: '+233 24 555 0199',
      country: 'Ghana',
      companyName: 'Celoxa Tech Support',
      role: 'staff',
      platformRole: 'staff',
      department: 'Technical Support',
      staffTitle: 'Senior Cloud Engineer',
      accountStatus: 'active',
      isEmailVerified: true,
      twoFactorEnabled: false,
      createdAt: '2026-01-15T10:30:00.000Z',
      lastLoginAt: new Date().toISOString(),
      permissions: DEFAULT_SUPPORT_STAFF_PERMISSIONS
    },
    {
      id: 'usr-client-1',
      email: 'gideon@celoxaghana.online',
      passwordHash: hashPassword('ClientPass2026!'),
      fullName: 'Gideon Baffour',
      phone: '+233 50 987 6543',
      country: 'Ghana',
      companyName: 'Vikalink Enterprise',
      role: 'client',
      platformRole: 'client',
      accountStatus: 'active',
      isEmailVerified: true,
      twoFactorEnabled: true,
      mfaSecret: 'KRSXG5CTMVRXEZLU',
      mfaBackupCodes: ['1234-5678', '9876-5432'],
      createdAt: '2026-02-01T09:00:00.000Z',
      lastLoginAt: new Date().toISOString(),
      permissions: DEFAULT_CLIENT_PERMISSIONS
    }
  ];

  private verificationTokens: VerificationToken[] = [];
  private staffInvitations: StaffInvitationToken[] = [];
  private sessions: UserSession[] = [];
  private auditLogs: AuditLogRecord[] = [
    {
      id: 'log-1',
      timestamp: new Date().toISOString(),
      actor: 'System Initialization',
      action: 'IAM_ENGINE_BOOT',
      target: 'IAM Core',
      details: 'Identity & Access Management engine online with RBAC engine',
      ipAddress: '127.0.0.1'
    }
  ];

  public recordAuditLog(actor: string, action: string, target: string, details: string, ipAddress: string = '127.0.0.1') {
    const log: AuditLogRecord = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actor,
      action,
      target,
      details,
      ipAddress
    };
    this.auditLogs.unshift(log);
    if (this.auditLogs.length > 200) this.auditLogs.pop();
  }

  public getUsers(): UserRecord[] {
    return this.users;
  }

  public findUserByEmail(email: string): UserRecord | undefined {
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): UserRecord | undefined {
    return this.users.find(u => u.id === id);
  }

  // Google OAuth Login or Register
  public googleAuth(data: {
    email: string;
    fullName: string;
    ip?: string;
    userAgent?: string;
  }): { success: boolean; user: UserRecord; sessionId: string; isNewUser: boolean } {
    const cleanEmail = data.email.toLowerCase().trim();
    let user = this.findUserByEmail(cleanEmail);
    let isNewUser = false;

    if (!user) {
      isNewUser = true;
      const userId = `usr-cli-${Date.now()}`;
      user = {
        id: userId,
        email: cleanEmail,
        passwordHash: hashPassword(crypto.randomBytes(16).toString('hex')),
        fullName: data.fullName || cleanEmail.split('@')[0],
        phone: '+233240000000',
        country: 'Ghana',
        role: 'client',
        platformRole: 'client',
        accountStatus: 'active',
        isEmailVerified: true,
        twoFactorEnabled: false,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
        permissions: DEFAULT_CLIENT_PERMISSIONS
      };
      this.users.push(user);

      this.recordAuditLog(
        cleanEmail,
        'GOOGLE_SIGN_UP',
        userId,
        'Created new account via Google SSO',
        data.ip || '127.0.0.1'
      );
    } else {
      user.isEmailVerified = true;
      user.lastLoginAt = new Date().toISOString();
      if (user.accountStatus === 'pending_verification') {
        user.accountStatus = 'active';
      }

      this.recordAuditLog(
        cleanEmail,
        'GOOGLE_SIGN_IN',
        user.id,
        'Signed in via Google SSO',
        data.ip || '127.0.0.1'
      );
    }

    const sessionId = `sess-${Date.now()}-${crypto.randomBytes(8).toString('hex')}`;
    const session: UserSession = {
      sessionId,
      userId: user.id,
      role: user.role,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      ip: data.ip || '127.0.0.1',
      userAgent: data.userAgent || 'Google Auth',
      isRevoked: false
    };

    this.sessions.push(session);

    return {
      success: true,
      user,
      sessionId,
      isNewUser
    };
  }

  // Register New Client Account
  public registerClient(data: {
    email: string;
    password: string;
    fullName: string;
    phone?: string;
    country?: string;
  }): { success: boolean; user?: UserRecord; verificationToken?: string; error?: string } {
    const existing = this.findUserByEmail(data.email);
    if (existing) {
      return { success: false, error: 'An account with this email address already exists.' };
    }

    const userId = `usr-cli-${Date.now()}`;
    const newUser: UserRecord = {
      id: userId,
      email: data.email.toLowerCase().trim(),
      passwordHash: hashPassword(data.password),
      fullName: data.fullName.trim(),
      phone: data.phone || '',
      country: data.country || 'Ghana',
      role: 'client',
      platformRole: 'client',
      accountStatus: 'pending_verification',
      isEmailVerified: false,
      twoFactorEnabled: false,
      createdAt: new Date().toISOString(),
      permissions: DEFAULT_CLIENT_PERMISSIONS
    };

    this.users.push(newUser);

    // Generate Single-Use, Time-Limited Verification Token (24 hours)
    const tokenString = crypto.randomBytes(24).toString('hex');
    const tokenRecord: VerificationToken = {
      id: `tok-${Date.now()}`,
      token: tokenString,
      userId,
      email: newUser.email,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
      used: false
    };

    this.verificationTokens.push(tokenRecord);

    this.recordAuditLog(
      newUser.email,
      'CLIENT_REGISTRATION',
      userId,
      `Registered new client account. Single-use verification token generated (Expires in 24h).`
    );

    return {
      success: true,
      user: newUser,
      verificationToken: tokenString
    };
  }

  // Verify Email with Token
  public verifyEmail(tokenString: string): { success: boolean; message: string; user?: UserRecord } {
    const tok = this.verificationTokens.find(t => t.token === tokenString);

    if (!tok) {
      return { success: false, message: 'Invalid or non-existent email verification token.' };
    }

    if (tok.used) {
      return { success: false, message: 'This verification token has already been used. Please request a new link.' };
    }

    const now = new Date();
    const expiry = new Date(tok.expiresAt);
    if (now > expiry) {
      return { success: false, message: 'Verification link expired. Please request a new verification email.' };
    }

    // Mark token as used
    tok.used = true;

    // Update user status
    const user = this.findUserById(tok.userId);
    if (user) {
      user.isEmailVerified = true;
      if (user.accountStatus === 'pending_verification') {
        user.accountStatus = 'active';
      }
      this.recordAuditLog(
        user.email,
        'EMAIL_VERIFIED',
        user.id,
        'Single-use verification token validated. Account status set to ACTIVE.'
      );
      return { success: true, message: 'Email verified successfully! Your account is active.', user };
    }

    return { success: false, message: 'User account associated with this token was not found.' };
  }

  // Resend Email Verification Token
  public resendVerificationToken(email: string): { success: boolean; verificationToken?: string; message: string } {
    const user = this.findUserByEmail(email);
    if (!user) {
      // Don't leak user existence
      return { success: true, message: 'If an unverified account exists for this email, a new verification link has been sent.' };
    }

    if (user.isEmailVerified) {
      return { success: false, message: 'This email address is already verified.' };
    }

    // Invalidate old tokens for this user
    this.verificationTokens.forEach(t => {
      if (t.userId === user.id) t.used = true;
    });

    // Create fresh single-use 24-hour token
    const tokenString = crypto.randomBytes(24).toString('hex');
    const tokenRecord: VerificationToken = {
      id: `tok-${Date.now()}`,
      token: tokenString,
      userId: user.id,
      email: user.email,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      used: false
    };

    this.verificationTokens.push(tokenRecord);

    this.recordAuditLog(
      user.email,
      'VERIFICATION_TOKEN_RESENT',
      user.id,
      'Generated new 24-hour single-use email verification token.'
    );

    return {
      success: true,
      verificationToken: tokenString,
      message: 'New verification link sent successfully!'
    };
  }

  // Authenticate User & Create Session
  public login(data: {
    email: string;
    password: string;
    ip?: string;
    userAgent?: string;
    requiredPortalRole?: 'client' | 'staff' | 'admin';
  }): { success: boolean; user?: UserRecord; sessionId?: string; error?: string } {
    const user = this.findUserByEmail(data.email);

    if (!user) {
      this.recordAuditLog('Anonymous', 'LOGIN_FAILED', data.email, 'User not found', data.ip || '127.0.0.1');
      return { success: false, error: 'Invalid email address or password.' };
    }

    const hash = hashPassword(data.password);
    if (user.passwordHash !== hash) {
      this.recordAuditLog(user.email, 'LOGIN_FAILED', user.id, 'Incorrect password attempt', data.ip || '127.0.0.1');
      return { success: false, error: 'Invalid email address or password.' };
    }

    // Status checks
    if (user.accountStatus === 'suspended') {
      return { success: false, error: 'Account is suspended. Please contact system support.' };
    }
    if (user.accountStatus === 'locked') {
      return { success: false, error: 'Account is locked for security reasons.' };
    }
    if (user.accountStatus === 'deactivated') {
      return { success: false, error: 'Account has been deactivated.' };
    }

    // Portal Separation Role Checks
    if (data.requiredPortalRole === 'staff' || data.requiredPortalRole === 'admin') {
      if (user.role === 'client') {
        this.recordAuditLog(user.email, 'UNAUTHORIZED_PORTAL_ACCESS', user.id, `Client attempted access to ${data.requiredPortalRole} portal`, data.ip || '127.0.0.1');
        return { success: false, error: 'Access Denied: This portal is reserved for authorized Staff and Administrators.' };
      }
    }

    // Update last login
    user.lastLoginAt = new Date().toISOString();

    // Create Session
    const sessionId = `sess_${crypto.randomBytes(32).toString('hex')}`;
    const session: UserSession = {
      sessionId,
      userId: user.id,
      role: user.role,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
      ip: data.ip || '127.0.0.1',
      userAgent: data.userAgent || 'Web Browser',
      isRevoked: false
    };

    this.sessions.push(session);

    this.recordAuditLog(user.email, 'LOGIN_SUCCESS', user.id, `Authenticated successfully into ${user.role.toUpperCase()} session`, data.ip || '127.0.0.1');

    return {
      success: true,
      user,
      sessionId
    };
  }

  // Validate Session by SessionId
  public validateSession(sessionId: string): UserSession | null {
    const session = this.sessions.find(s => s.sessionId === sessionId);
    if (!session || session.isRevoked) return null;

    if (new Date() > new Date(session.expiresAt)) {
      session.isRevoked = true;
      return null;
    }

    return session;
  }

  // Revoke Session
  public revokeSession(sessionId: string): boolean {
    const session = this.sessions.find(s => s.sessionId === sessionId);
    if (session) {
      session.isRevoked = true;
      this.recordAuditLog('User', 'SESSION_REVOKED', session.userId, `Session ${sessionId.slice(0, 10)}... revoked`);
      return true;
    }
    return false;
  }

  public revokeAllOtherSessions(userId: string, currentSessionId?: string): number {
    let count = 0;
    this.sessions.forEach(s => {
      if (s.userId === userId && s.sessionId !== currentSessionId && !s.isRevoked) {
        s.isRevoked = true;
        count++;
      }
    });
    this.recordAuditLog('User', 'ALL_SESSIONS_REVOKED', userId, `Revoked ${count} other sessions`);
    return count;
  }

  // Staff Invitation Management (Admin creating Staff/Admin)
  public createStaffInvitation(data: {
    email: string;
    fullName: string;
    role: PlatformRole;
    department: string;
    staffTitle: string;
    permissions?: ModulePermissions;
    createdByEmail: string;
  }): { success: boolean; invitation?: StaffInvitationToken; error?: string } {
    if (this.findUserByEmail(data.email)) {
      return { success: false, error: 'A user with this email address already exists in the system.' };
    }

    const tokenString = `inv_${crypto.randomBytes(24).toString('hex')}`;
    const invitation: StaffInvitationToken = {
      id: `inv-${Date.now()}`,
      token: tokenString,
      email: data.email.toLowerCase().trim(),
      fullName: data.fullName.trim(),
      role: data.role,
      department: data.department || 'Operations',
      staffTitle: data.staffTitle || 'Staff Member',
      permissions: data.permissions || (data.role === 'super_admin' ? DEFAULT_SUPER_ADMIN_PERMISSIONS : data.role === 'administrator' ? DEFAULT_ADMIN_PERMISSIONS : DEFAULT_SUPPORT_STAFF_PERMISSIONS),
      createdByEmail: data.createdByEmail,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(), // 48h invitation expiry
      used: false
    };

    this.staffInvitations.push(invitation);

    this.recordAuditLog(
      data.createdByEmail,
      'STAFF_INVITATION_CREATED',
      invitation.email,
      `Generated single-use staff invitation token for role ${data.role.toUpperCase()}`
    );

    return { success: true, invitation };
  }

  public acceptStaffInvitation(data: {
    token: string;
    password: string;
    phone?: string;
  }): { success: boolean; user?: UserRecord; error?: string } {
    const inv = this.staffInvitations.find(i => i.token === data.token);

    if (!inv) {
      return { success: false, error: 'Invalid or non-existent staff invitation token.' };
    }

    if (inv.used) {
      return { success: false, error: 'This invitation token has already been used.' };
    }

    if (new Date() > new Date(inv.expiresAt)) {
      return { success: false, error: 'This staff invitation has expired. Please request a new invitation from an Administrator.' };
    }

    inv.used = true;

    const newStaffUser: UserRecord = {
      id: `usr-stf-${Date.now()}`,
      email: inv.email,
      passwordHash: hashPassword(data.password),
      fullName: inv.fullName,
      phone: data.phone || '',
      country: 'Ghana',
      role: inv.role,
      platformRole: inv.role,
      department: inv.department,
      staffTitle: inv.staffTitle,
      accountStatus: 'active',
      isEmailVerified: true, // Auto-verified via invitation
      twoFactorEnabled: false,
      createdAt: new Date().toISOString(),
      permissions: inv.permissions
    };

    this.users.push(newStaffUser);

    this.recordAuditLog(
      newStaffUser.email,
      'STAFF_INVITATION_ACCEPTED',
      newStaffUser.id,
      `Staff account activated for role ${newStaffUser.role.toUpperCase()}`
    );

    return { success: true, user: newStaffUser };
  }

  public getStaffInvitations(): StaffInvitationToken[] {
    return this.staffInvitations.filter(i => !i.used);
  }

  public getAuditLogs(): AuditLogRecord[] {
    return this.auditLogs;
  }
}

export const iamStore = new IamStoreEngine();
