import { DomainResult } from '../types';
import { TLD_CATALOG } from '../data/tlds';

// Currency exchange rates relative to USD
export const CURRENCY_RATES: Record<string, { symbol: string; rate: number; name: string }> = {
  USD: { symbol: '$', rate: 1.0, name: 'USD - United States Dollar' },
  GHS: { symbol: 'GH₵', rate: 15.5, name: 'GHS - Ghanaian Cedi' },
  EUR: { symbol: '€', rate: 0.92, name: 'EUR - Euro' },
  GBP: { symbol: '£', rate: 0.79, name: 'GBP - British Pound' },
  JPY: { symbol: '¥', rate: 154.5, name: 'JPY - Japanese Yen' },
  INR: { symbol: '₹', rate: 83.2, name: 'INR - Indian Rupee' },
};

export function formatPrice(priceInUsd: number, currency: string = 'USD'): string {
  const curr = CURRENCY_RATES[currency] || CURRENCY_RATES.USD;
  const converted = priceInUsd * curr.rate;
  if (currency === 'JPY') {
    return `${curr.symbol}${Math.round(converted).toLocaleString()}`;
  }
  if (currency === 'GHS') {
    return `${curr.symbol} ${converted.toFixed(2)}`;
  }
  return `${curr.symbol}${converted.toFixed(2)}`;
}

export function generateDomainResults(searchTerm: string): DomainResult[] {
  if (!searchTerm || typeof searchTerm !== 'string' || !searchTerm.trim()) return [];

  const rawClean = (searchTerm || '').toLowerCase().trim().replace(/https?:\/\//, '').replace(/^www\./, '');
  
  // Extract name and explicit TLD if typed e.g. "nexus.io" -> name: "nexus", explicitTld: ".io"
  let name = rawClean;
  let explicitTld = '';
  
  const dotIndex = rawClean.indexOf('.');
  if (dotIndex > 0) {
    name = rawClean.slice(0, dotIndex).replace(/[^a-z0-9-]/g, '');
    explicitTld = rawClean.slice(dotIndex);
  } else {
    name = rawClean.replace(/[^a-z0-9-]/g, '');
  }

  if (!name) return [];

  const results: DomainResult[] = [];

  // Registered short names list or reserved keywords
  const reservedTaken = ['google', 'apple', 'amazon', 'microsoft', 'meta', 'twitter', 'facebook', 'openai', 'stripe', 'github', 'tesla', 'uber', 'airbnb', 'netflix', 'spotify', 'zoom'];
  const premiumKeywords = ['ai', 'cloud', 'nexus', 'app', 'dev', 'meta', 'pay', 'coin', 'trade', 'shop', 'tech', 'smart', 'data', 'block', 'hub', 'bot', 'flow'];

  const prefixes = ['', 'get', 'try', 'the', 'use', 'my', 'go'];
  const suffixes = ['', 'hq', 'labs', 'app', 'hub', 'stack', 'flow', 'io', 'ai', 'cloud', 'craft', 'pro', 'zone', 'box'];

  let idCounter = 1;

  // 1. Direct TLD variations for exact clean name
  TLD_CATALOG.forEach((tldInfo) => {
    const fullDomain = `${name}${tldInfo.tld}`;
    const isExplicit = explicitTld && explicitTld === tldInfo.tld;
    
    // Deterministic availability logic
    const isTaken = reservedTaken.includes(name) || (name.length <= 3 && tldInfo.tld === '.com');
    const isPremium = premiumKeywords.includes(name) && (tldInfo.tld === '.com' || tldInfo.tld === '.ai' || tldInfo.tld === '.io');

    let regPrice = tldInfo.registrationPrice;
    if (isPremium) {
      regPrice = regPrice * 25 + 499;
    }

    results.push({
      id: `dom-${idCounter++}`,
      domain: fullDomain,
      name: name,
      tld: tldInfo.tld,
      isAvailable: !isTaken,
      isPremium: isPremium,
      registrationPrice: Number(regPrice.toFixed(2)),
      renewalPrice: tldInfo.renewalPrice,
      transferPrice: tldInfo.transferPrice,
      restorePrice: tldInfo.restorePrice,
      icannFee: tldInfo.icannFee,
      category: tldInfo.category,
      description: tldInfo.description,
      timeEstimate: tldInfo.tld === '.com' || tldInfo.tld === '.net' ? 'Instant' : '1-3 minutes',
      popularityScore: isExplicit ? 99 : (tldInfo.tld === '.com' ? 98 : tldInfo.tld === '.ai' ? 95 : 85),
      characterLength: fullDomain.length,
      brandScore: Math.min(99, Math.max(65, 100 - name.length * 2 + (tldInfo.tld === '.com' ? 10 : 5))),
      hasPrivacyIncluded: true,
    });
  });

  // 2. Add high-value variations if primary is taken or to enrich choices
  const featuredTlds = ['.com', '.io', '.ai', '.app', '.tech', '.co', '.store', '.cloud'];

  prefixes.forEach((pre) => {
    if (!pre) return;
    const varName = `${pre}${name}`;
    featuredTlds.slice(0, 3).forEach((tld) => {
      const full = `${varName}${tld}`;
      const tldInfo = TLD_CATALOG.find((t) => t.tld === tld) || TLD_CATALOG[0];
      results.push({
        id: `dom-${idCounter++}`,
        domain: full,
        name: varName,
        tld: tld,
        isAvailable: true,
        isPremium: false,
        registrationPrice: tldInfo.registrationPrice,
        renewalPrice: tldInfo.renewalPrice,
        transferPrice: tldInfo.transferPrice,
        restorePrice: tldInfo.restorePrice,
        icannFee: tldInfo.icannFee,
        category: tldInfo.category,
        description: `Brandable prefix variation: ${pre.toUpperCase()} + ${name}`,
        timeEstimate: 'Instant',
        popularityScore: 82,
        characterLength: full.length,
        brandScore: 88,
        hasPrivacyIncluded: true,
      });
    });
  });

  suffixes.forEach((suf) => {
    if (!suf) return;
    const varName = `${name}${suf}`;
    featuredTlds.slice(0, 3).forEach((tld) => {
      const full = `${varName}${tld}`;
      const tldInfo = TLD_CATALOG.find((t) => t.tld === tld) || TLD_CATALOG[0];
      results.push({
        id: `dom-${idCounter++}`,
        domain: full,
        name: varName,
        tld: tld,
        isAvailable: true,
        isPremium: false,
        registrationPrice: tldInfo.registrationPrice,
        renewalPrice: tldInfo.renewalPrice,
        transferPrice: tldInfo.transferPrice,
        restorePrice: tldInfo.restorePrice,
        icannFee: tldInfo.icannFee,
        category: tldInfo.category,
        description: `Memorable modifier suffix: ${name} + ${suf.toUpperCase()}`,
        timeEstimate: 'Instant',
        popularityScore: 80,
        characterLength: full.length,
        brandScore: 86,
        hasPrivacyIncluded: true,
      });
    });
  });

  return results;
}

export function getLiveSearchSuggestions(query: string): DomainResult[] {
  if (!query || query.length < 2) return [];
  const all = generateDomainResults(query);
  return all.slice(0, 5);
}

export interface FilterOptions {
  category?: string;
  tld?: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy?: 'price_asc' | 'price_desc' | 'popular' | 'alpha' | 'score';
  availabilityOnly?: boolean;
}

export function filterAndSortResults(
  results: DomainResult[],
  filters: FilterOptions
): DomainResult[] {
  let filtered = [...results];

  if (filters.availabilityOnly) {
    filtered = filtered.filter((r) => r.isAvailable);
  }

  if (filters.category && filters.category !== 'All') {
    filtered = filtered.filter((r) => r.category === filters.category);
  }

  if (filters.tld && filters.tld !== 'All') {
    filtered = filtered.filter((r) => (r.tld || '').toLowerCase() === (filters.tld || '').toLowerCase());
  }

  if (filters.minPrice !== undefined && filters.maxPrice !== undefined) {
    filtered = filtered.filter(
      (r) => r.registrationPrice >= filters.minPrice! && r.registrationPrice <= filters.maxPrice!
    );
  }

  if (filters.sortBy) {
    switch (filters.sortBy) {
      case 'price_asc':
        filtered.sort((a, b) => a.registrationPrice - b.registrationPrice);
        break;
      case 'price_desc':
        filtered.sort((a, b) => b.registrationPrice - a.registrationPrice);
        break;
      case 'alpha':
        filtered.sort((a, b) => a.domain.localeCompare(b.domain));
        break;
      case 'score':
        filtered.sort((a, b) => b.brandScore - a.brandScore);
        break;
      case 'popular':
      default:
        filtered.sort((a, b) => b.popularityScore - a.popularityScore);
        break;
    }
  }

  return filtered;
}

