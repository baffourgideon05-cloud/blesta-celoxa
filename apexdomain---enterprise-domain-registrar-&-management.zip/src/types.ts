export type ViewMode = 'card' | 'list' | 'compact' | 'table';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'INR' | 'GHS';

export type Language = 'en' | 'es' | 'fr' | 'de' | 'ja';

export interface CustomPaymentConfig {
  enabled: boolean;
  title: string;
  description: string;
  instructions: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  swiftCode?: string;
  momoProvider: string;
  momoNumber: string;
  momoName: string;
  requireProofOfPayment: boolean;
}

export interface PaystackConfig {
  enabled: boolean;
  testMode: boolean;
  publicKey: string;
  secretKey: string;
  merchantName: string;
  allowedChannels: ('card' | 'mobile_money' | 'bank_transfer' | 'ussd')[];
  currencyPreference: 'GHS' | 'USD' | 'NGN';
}

export interface PaymentMethodSettings {
  creditCardEnabled: boolean;
  customPayment: CustomPaymentConfig;
  paystack: PaystackConfig;
}

export interface PaymentSubmission {
  id: string;
  orderId: string;
  domains: string[];
  amount: number;
  currency: string;
  paymentMethod: 'paystack' | 'custom_manual' | 'card';
  paystackReference?: string;
  customProofText?: string;
  momoNumberUsed?: string;
  status: 'completed' | 'pending_approval' | 'failed' | 'refunded';
  createdAt: string;
  customerName: string;
  customerEmail: string;
}

export interface DomainResult {
  id: string;
  domain: string;
  name: string;
  tld: string;
  isAvailable: boolean;
  isPremium: boolean;
  registrationPrice: number;
  renewalPrice: number;
  transferPrice: number;
  restorePrice: number;
  icannFee: number;
  category: string;
  description: string;
  timeEstimate: string;
  popularityScore: number;
  characterLength: number;
  brandScore: number;
  hasPrivacyIncluded: boolean;
}

export interface TLDDetail {
  tld: string;
  name: string;
  category: string;
  registrationPrice: number;
  renewalPrice: number;
  transferPrice: number;
  restorePrice: number;
  icannFee: number;
  description: string;
  bestUseCases: string[];
  registrationRules: string[];
  supportedYears: number[];
  popularIn: string;
  faq: { question: string; answer: string }[];
}

export interface CartItem {
  id: string;
  domain: string;
  tld: string;
  registrationPrice: number;
  renewalPrice: number;
  years: number;
  privacyProtection: boolean;
  emailForwarding: boolean;
  dnssecEnabled: boolean;
  hostingAddon: boolean;
  icannFee: number;
  isPremium: boolean;
  itemType?: 'domain' | 'hosting' | 'ssl' | 'email' | 'vps';
  packageName?: string;
  planId?: string;
  billingCycle?: 'monthly' | 'annually' | 'triennially';
  serverRegion?: string;
  diskLimitMb?: number;
  bandwidthLimitGb?: number;
  module?: WhmcsModuleType;
}

export interface DNSRecord {
  id: string;
  type: 'A' | 'AAAA' | 'CNAME' | 'MX' | 'TXT' | 'NS';
  name: string;
  value: string;
  ttl: number;
  priority?: number;
}

export interface EmailForwardRule {
  id: string;
  source: string;
  destination: string;
  active: boolean;
}

export interface RegisteredDomain {
  id: string;
  domain: string;
  registeredDate: string;
  expiryDate: string;
  autoRenew: boolean;
  locked: boolean;
  whoisPrivacy: boolean;
  authCode: string;
  dnsRecords: DNSRecord[];
  nameservers: string[];
  emailForwarding: EmailForwardRule[];
  status: 'active' | 'expiring_soon' | 'pending_transfer' | 'expired';
}

export interface Coupon {
  code: string;
  discountPercent: number;
  description: string;
}

export interface SearchFilter {
  availability: 'all' | 'available' | 'registered' | 'premium';
  maxPrice: number;
  minPrice: number;
  category: string;
  maxChars: number;
  tldType: string;
}

export type SortOption = 'price-asc' | 'price-desc' | 'alphabetical' | 'popular' | 'bestselling' | 'recent';

export interface EducationalArticle {
  id: string;
  title: string;
  category: string;
  readTime: string;
  description: string;
  icon: string;
  sections: { title: string; content: string }[];
}

export interface PriceAlertSub {
  id: string;
  domain: string;
  email: string;
  alertType: 'availability' | 'price_drop' | 'backorder';
  createdAt: string;
}

export interface WhoisData {
  domainName: string;
  status: string;
  registrar: string;
  creationDate: string;
  updatedDate: string;
  expirationDate: string;
  registrantOrganization: string;
  registrantCountry: string;
  nameServers: string[];
  dnssec: string;
  rawWhoisText: string;
}

export interface AiDomainSuggestion {
  domain: string;
  tld: string;
  brandScore: number;
  rationale: string;
  estimatedValue: number;
  available: boolean;
  price: number;
  category: string;
}

export interface AiAppraisalResult {
  domain: string;
  estimatedValue: number;
  brandabilityScore: number;
  seoScore: number;
  lengthScore: number;
  summary: string;
  pros: string[];
  cons: string[];
  comparableSales: { domain: string; price: number; year: number }[];
}

// Service Types (Hosting, SSL, Email, VPS)
export type ServiceType = 'domain' | 'hosting' | 'ssl' | 'email' | 'vps';
export type ServiceStatus = 'active' | 'pending' | 'provisioning' | 'suspended' | 'expiring' | 'expired' | 'cancelled' | 'failed';

export interface HostingService {
  id: string;
  name: string;
  domain: string;
  planName: string;
  diskUsageMb: number;
  diskLimitMb: number;
  bandwidthUsageGb: number;
  bandwidthLimitGb: number;
  ipAddress: string;
  phpVersion: string;
  cpanelUser: string;
  price: number;
  billingCycle: 'monthly' | 'annually' | 'triennially';
  startDate: string;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  timeline: ServiceTimelineEvent[];
}

export interface SslService {
  id: string;
  domain: string;
  type: 'PositiveSSL' | 'Wildcard SSL' | 'EV SSL' | 'Let\'s Encrypt Free';
  issuer: string;
  issuedDate: string;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  sanDomains: string[];
  timeline: ServiceTimelineEvent[];
}

export interface EmailService {
  id: string;
  domain: string;
  provider: 'Google Workspace' | 'Titan Business Email' | 'Custom cPanel Mail';
  mailboxesCount: number;
  maxMailboxes: number;
  storagePerMailboxGb: number;
  price: number;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  timeline: ServiceTimelineEvent[];
}

export interface VpsService {
  id: string;
  hostname: string;
  os: string;
  vCpus: number;
  ramGb: number;
  ssdGb: number;
  ipAddress: string;
  datacenterRegion: string;
  price: number;
  expiryDate: string;
  autoRenew: boolean;
  status: ServiceStatus;
  timeline: ServiceTimelineEvent[];
}

export interface ServiceTimelineEvent {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  type: 'created' | 'provisioned' | 'ssl_installed' | 'upgraded' | 'renewed' | 'suspended' | 'dns_changed';
}

// Customer Account Timeline
export interface CustomerTimelineEvent {
  id: string;
  category: 'service' | 'billing' | 'support' | 'security' | 'domain';
  title: string;
  description: string;
  timestamp: string;
  actor: string;
  statusBadge?: string;
}

// Invoices & Billing
export interface InvoiceItem {
  description: string;
  serviceType: ServiceType;
  amount: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  orderId: string;
  customerName: string;
  customerEmail: string;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  total: number;
  currency: Currency;
  status: 'paid' | 'unpaid' | 'overdue' | 'cancelled';
  issueDate: string;
  dueDate: string;
  paidDate?: string;
  paymentMethod?: string;
}

// Wallet & Credit System
export interface WalletTransaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  currency: Currency;
  description: string;
  reference: string;
  date: string;
  balanceAfter: number;
}

export interface CustomerWallet {
  balance: number;
  currency: Currency;
  transactions: WalletTransaction[];
}

// Team Accounts & Permissions
export type TeamRole = 'Owner' | 'Billing Contact' | 'Technical Contact' | 'Administrative Contact' | 'Support Agent';

export interface TeamMemberPermission {
  viewInvoices: boolean;
  payInvoices: boolean;
  downloadReceipts: boolean;
  manageDomains: boolean;
  manageHosting: boolean;
  cancelHosting: boolean;
  openTickets: boolean;
  manageTeam: boolean;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: TeamRole;
  isPrimaryOwner: boolean;
  status: 'active' | 'invited' | 'disabled';
  addedDate: string;
  permissions: TeamMemberPermission;
}

// Support Tickets & Internal Notes
export type TicketPriority = 'low' | 'normal' | 'high' | 'urgent' | 'critical';
export type TicketStatus = 'open' | 'in_progress' | 'waiting_customer' | 'resolved' | 'closed';

export interface TicketAttachment {
  name: string;
  sizeKb: number;
  url: string;
}

export interface TicketMessage {
  id: string;
  senderName: string;
  senderEmail: string;
  isStaff: boolean;
  isInternalNote: boolean; // Staff only internal notes
  content: string;
  timestamp: string;
  attachments?: TicketAttachment[];
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  subject: string;
  department: 'Domains' | 'Hosting' | 'Billing' | 'Technical' | 'SSL & Security';
  serviceRelated?: string;
  priority: TicketPriority;
  status: TicketStatus;
  assignedAgent?: string;
  createdAt: string;
  updatedAt: string;
  slaTargetHours: number;
  messages: TicketMessage[];
}

export interface CannedResponseTemplate {
  id: string;
  title: string;
  category: string;
  content: string;
}

// Renewal Reminder Rules Configurator
export interface RenewalReminderRule {
  id: string;
  days: number;
  timing: 'before_expiry' | 'after_expiry' | 'before_termination';
  enabled: boolean;
  channel: 'email' | 'sms' | 'dashboard_banner';
  subjectTemplate: string;
}

// Global Account Search Result
export interface GlobalSearchResultItem {
  id: string;
  title: string;
  subtitle: string;
  category: 'domain' | 'hosting' | 'invoice' | 'order' | 'ticket' | 'payment' | 'customer';
  status: string;
  linkAction: string;
}

// Impersonation State
export interface ImpersonationState {
  isActive: boolean;
  adminName: string;
  targetCustomerName: string;
  targetCustomerEmail: string;
  reason: string;
  startedAt: string;
}

// ==========================================
// WHMCS HOSTMING SYSTEM EXTENSION TYPES
// ==========================================

export type WhmcsModuleType = 'cpanel' | 'directadmin' | 'plesk' | 'solusvm' | 'custom_api';

export interface WhmcsServerNode {
  id: string;
  name: string;
  hostname: string;
  ipAddress: string;
  module: WhmcsModuleType;
  serverGroup: string;
  datacenter: string;
  maxAccounts: number;
  activeAccounts: number;
  status: 'online' | 'degraded' | 'maintenance' | 'offline';
  cpuLoadPercentage: number;
  ramUsagePercentage: number;
  diskUsagePercentage: number;
  activeIpPool: string[];
  accessHashConfigured: boolean;
}

export interface WhmcsHostingPackage {
  id: string;
  name: string;
  category: 'Shared Web Hosting' | 'WordPress Cloud' | 'Reseller Hosting' | 'KVM VPS' | 'Dedicated Server';
  module: WhmcsModuleType;
  description: string;
  diskLimitMb: number; // 0 = unlimited
  bandwidthLimitGb: number; // 0 = unlimited
  maxDatabases: number;
  maxSubdomains: number;
  maxMailboxes: number;
  priceMonthly: number;
  priceAnnually: number;
  freeDomainEligible: boolean;
  features: string[];
}

export interface WhmcsProvisioningQueueItem {
  id: string;
  serviceId: string;
  domain: string;
  packageName: string;
  action: 'Create Account' | 'Suspend Account' | 'Unsuspend Account' | 'Terminate Account' | 'Change Package' | 'Reset Password';
  serverId: string;
  serverName: string;
  status: 'queued' | 'processing' | 'success' | 'failed';
  errorMessage?: string;
  queuedAt: string;
  completedAt?: string;
}

export interface WhmcsAutomationCronLog {
  id: string;
  jobName: string;
  category: 'Billing & Invoicing' | 'Domain Sync' | 'Provisioning Queue' | 'Auto-Suspension' | 'SSL Issuance';
  executedAt: string;
  status: 'success' | 'warning' | 'error';
  recordsProcessed: number;
  details: string;
}

export interface WhmcsCpanelEmailAccount {
  id: string;
  email: string;
  usageMb: number;
  quotaMb: number;
  forwardTo?: string;
}

export interface WhmcsCpanelDatabase {
  id: string;
  dbName: string;
  dbUser: string;
  sizeMb: number;
}

export interface WhmcsSoftaculousApp {
  id: string;
  name: string;
  category: 'CMS' | 'E-Commerce' | 'Framework' | 'Forum' | 'Wiki';
  version: string;
  installedUrl: string;
  installedPath: string;
  dbName: string;
  installedDate: string;
  autoUpdate: boolean;
}

export interface SystemSettingsConfig {
  general: {
    siteName: string;
    companyName: string;
    contactEmail: string;
    supportPhone: string;
    logoUrl: string;
    defaultCurrency: Currency;
    defaultLanguage: Language;
    timezone: string;
    maintenanceMode: boolean;
  };
  hostingProvisioning: {
    autoProvisionOnPayment: boolean;
    defaultServerManager: 'whmcs' | 'cpanel' | 'directadmin' | 'plesk';
    defaultNameservers: [string, string, string, string];
    serverNodePool: string;
    autoSslEnabled: boolean;
    cpanelTheme: string;
    phpVersion: string;
  };
  domains: {
    defaultPricingMarkupPercent: number;
    autoRenewGraceDays: number;
    defaultWhoisPrivacy: boolean;
    requireEppForTransfers: boolean;
  };
  securityAntiSpam: {
    captchaProvider: 'recaptcha_v3' | 'recaptcha_v2' | 'turnstile' | 'hcaptcha' | 'none';
    ipRateLimitRequestsPerMin: number;
    stopForumSpamEnabled: boolean;
    disposableEmailFilter: boolean;
    staffIpWhitelist: string[];
    centralSecurityAlerts: boolean;
  };
  billing: {
    autoExchangeRateSync: boolean;
    rateSyncProvider: 'ExchangeRate-API' | 'CurrencyDataAPI' | 'currencylayer';
    invoicePrefix: string;
    invoiceDueDays: number;
    defaultTaxRate: number;
  };
  notifications: {
    smtpHost: string;
    smtpPort: number;
    smtpUser: string;
    smtpFromEmail: string;
    sendLowDiskAlerts: boolean;
    sendSslExpiryAlerts: boolean;
  };
}

// ==========================================
// IDENTITY & ACCESS MANAGEMENT (IAM) TYPES
// ==========================================

export type PlatformRole = 'super_admin' | 'administrator' | 'staff' | 'client';

export type UserAccountStatus = 'active' | 'pending_verification' | 'suspended' | 'locked' | 'deactivated';

export interface ModulePermissions {
  customers: { view: boolean; create: boolean; edit: boolean; suspend: boolean; delete: boolean };
  domains: { view: boolean; register: boolean; transfer: boolean; editDns: boolean; delete: boolean };
  hosting: { view: boolean; provision: boolean; suspend: boolean; unsuspend: boolean; terminate: boolean };
  billing: { viewInvoices: boolean; createInvoice: boolean; refundPayment: boolean; managePaymentSettings: boolean };
  servers: { view: boolean; manage: boolean; restart: boolean };
  staff: { view: boolean; create: boolean; edit: boolean; suspend: boolean; manageRoles: boolean };
  systemSettings: { view: boolean; edit: boolean };
  auditLogs: { view: boolean; export: boolean };
}

export interface UserSession {
  id: string;
  userId: string;
  device: string;
  ip: string;
  location: string;
  createdAt: string;
  lastActiveAt: string;
  isCurrent: boolean;
}

export interface LoginActivityRecord {
  id: string;
  userId: string;
  userEmail: string;
  timestamp: string;
  device: string;
  ip: string;
  status: 'success' | 'failed';
  failureReason?: string;
}

export interface StaffInvitation {
  id: string;
  email: string;
  fullName: string;
  role: PlatformRole;
  department?: string;
  staffTitle?: string;
  permissions: ModulePermissions;
  token: string;
  expiresAt: string;
  status: 'pending' | 'accepted' | 'expired';
  createdByEmail: string;
  createdAt: string;
}

export interface ClientApiKey {
  id: string;
  userId: string;
  keyName: string;
  keySecret: string;
  scopes: ('domain:read' | 'domain:write' | 'hosting:read' | 'hosting:write' | 'billing:read' | 'tickets:write')[];
  createdAt: string;
  lastUsedAt?: string;
  active: boolean;
}



