import { SystemSettingsConfig } from '../types';

export const DEFAULT_SYSTEM_SETTINGS: SystemSettingsConfig = {
  general: {
    siteName: 'Celoxa Ghana Cloud Systems',
    companyName: 'Celoxa Technologies Ltd',
    contactEmail: 'admin@celoxaghana.online',
    supportPhone: '+233 (0) 30 291 8840',
    logoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop',
    defaultCurrency: 'USD',
    defaultLanguage: 'en',
    timezone: 'UTC+00:00 (Accra / Greenwich)',
    maintenanceMode: false,
  },
  hostingProvisioning: {
    autoProvisionOnPayment: true,
    defaultServerManager: 'whmcs',
    defaultNameservers: [
      'ns1.apexdomain.com',
      'ns2.apexdomain.com',
      'ns3.apexdomain.com',
      'ns4.apexdomain.com',
    ],
    serverNodePool: 'US-EAST-GH1 WHMCS Cluster',
    autoSslEnabled: true,
    cpanelTheme: 'jupiter',
    phpVersion: '8.2',
  },
  domains: {
    defaultPricingMarkupPercent: 12.5,
    autoRenewGraceDays: 30,
    defaultWhoisPrivacy: true,
    requireEppForTransfers: true,
  },
  securityAntiSpam: {
    captchaProvider: 'turnstile',
    ipRateLimitRequestsPerMin: 120,
    stopForumSpamEnabled: true,
    disposableEmailFilter: true,
    staffIpWhitelist: ['198.51.100.42', '102.176.32.14'],
    centralSecurityAlerts: true,
  },
  billing: {
    autoExchangeRateSync: true,
    rateSyncProvider: 'ExchangeRate-API',
    invoicePrefix: 'INV-2026-',
    invoiceDueDays: 14,
    defaultTaxRate: 15,
  },
  notifications: {
    smtpHost: 'mail.celoxaghana.online',
    smtpPort: 587,
    smtpUser: 'notifications@celoxaghana.online',
    smtpFromEmail: 'noreply@celoxaghana.online',
    sendLowDiskAlerts: true,
    sendSslExpiryAlerts: true,
  },
};
