import { Coupon } from '../types';

export const VALID_COUPONS: Coupon[] = [
  { code: 'WELCOME20', discountPercent: 20, description: '20% off your entire order for new accounts' },
  { code: 'DOMAINS50', discountPercent: 50, description: '50% off select .tech, .store, and .online extensions' },
  { code: 'ENTERPRISE15', discountPercent: 15, description: '15% instant savings on orders over $100' },
  { code: 'SAVEMORE', discountPercent: 10, description: '10% sitewide discount on registration and renewal' }
];
