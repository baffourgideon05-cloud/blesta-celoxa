import { PaymentMethodSettings, PaymentSubmission } from '../types';

export const DEFAULT_PAYMENT_SETTINGS: PaymentMethodSettings = {
  creditCardEnabled: true,
  customPayment: {
    enabled: true,
    title: 'Custom Bank Transfer & Mobile Money',
    description: 'Direct payment via Ghanaian Bank Account or Mobile Money (MTN MoMo, Telecel Cash, AirtelTigo Money).',
    instructions: `1. Send the exact total payment amount to the bank or Mobile Money account specified below.
2. Please use your Order Reference (e.g., APX-109283) as the transaction remark or reference note.
3. Once completed, enter your Transaction ID or Mobile Money reference code in the field below to submit for instant verification.`,
    bankName: 'GCB Bank Ghana PLC',
    accountNumber: '1011182736450',
    accountName: 'ApexDomain Digital Services Ghana Ltd',
    swiftCode: 'GCBGHAC',
    momoProvider: 'MTN Mobile Money / Telecel Cash',
    momoNumber: '024 123 4567 / 020 987 6543',
    momoName: 'ApexDomain Ghana Ltd',
    requireProofOfPayment: true,
  },
  paystack: {
    enabled: true,
    testMode: true,
    publicKey: 'pk_test_apexdomain_ghana_paystack_8839201',
    secretKey: 'sk_test_apexdomain_ghana_paystack_secret_key',
    merchantName: 'ApexDomain Ghana (Paystack Direct Gateway)',
    allowedChannels: ['card', 'mobile_money', 'bank_transfer', 'ussd'],
    currencyPreference: 'GHS',
  },
};

export const INITIAL_PAYMENT_SUBMISSIONS: PaymentSubmission[] = [
  {
    id: 'sub-1001',
    orderId: 'APX-882190',
    domains: ['ghana-techhub.ai'],
    amount: 542.50,
    currency: 'GHS',
    paymentMethod: 'paystack',
    paystackReference: 'PSTK_GHS_99182371928',
    status: 'completed',
    createdAt: '2026-08-07 14:22',
    customerName: 'Kwame Mensah',
    customerEmail: 'kwame@ghana-techhub.ai',
  },
  {
    id: 'sub-1002',
    orderId: 'APX-882191',
    domains: ['accraventures.co'],
    amount: 217.00,
    currency: 'GHS',
    paymentMethod: 'custom_manual',
    customProofText: 'MTN MoMo Trans ID: 19827364512 - Transferred GH₵ 217.00 from 0244112233',
    momoNumberUsed: '0244112233',
    status: 'pending_approval',
    createdAt: '2026-08-08 09:15',
    customerName: 'Abena Osei',
    customerEmail: 'abena.osei@gmail.com',
  },
];
