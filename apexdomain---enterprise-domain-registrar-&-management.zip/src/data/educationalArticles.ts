import { EducationalArticle } from '../types';

export const EDUCATIONAL_ARTICLES: EducationalArticle[] = [
  {
    id: 'domain-buying-guide',
    title: 'The Ultimate Domain Buying Guide for 2026',
    category: 'Getting Started',
    readTime: '6 min read',
    description: 'Learn how to choose, evaluate, and secure the perfect domain name for your business or brand.',
    icon: 'Compass',
    sections: [
      {
        title: '1. Keep It Short and Memorable',
        content: 'Aim for 1 to 3 words or under 15 characters. Short domain names are easier to type on mobile keyboards, recall from memory, and print on physical marketing materials.'
      },
      {
        title: '2. Pick the Right TLD Extension',
        content: '.com remains the gold standard for global trust, but tech startups thrive on .io and .ai, while e-commerce platforms stand out with .store or .shop.'
      },
      {
        title: '3. Avoid Hyphens and Numbers',
        content: 'Hyphens and numbers create verbal confusion when sharing your web address aloud (e.g., "Is that the digit 4 or four?"). Stick to letters.'
      },
      {
        title: '4. Check Trademark Availability',
        content: 'Before completing your purchase, perform a trademark query in your target jurisdiction to avoid legal dispute or forced domain forfeiture.'
      }
    ]
  },
  {
    id: 'dns-basics-explained',
    title: 'DNS Demystified: A, CNAME, MX, and TXT Records',
    category: 'Technical',
    readTime: '8 min read',
    description: 'A beginner-friendly breakdown of how Domain Name System records route traffic, mail, and domain ownership verification.',
    icon: 'Network',
    sections: [
      {
        title: 'A & AAAA Records',
        content: 'A records map your hostname directly to an IPv4 address (e.g., 192.0.2.1). AAAA records do the same for modern IPv6 addresses.'
      },
      {
        title: 'CNAME Records',
        content: 'Canonical Name records point an alias domain to another canonical domain name (e.g., www.example.com -> example.com).'
      },
      {
        title: 'MX Records',
        content: 'Mail Exchanger records direct incoming emails to specified mail servers (e.g., Google Workspace or Outlook mail servers).'
      },
      {
        title: 'TXT Records & Security',
        content: 'TXT records hold arbitrary text payload, commonly used for SPF, DKIM, and DMARC email authentication to prevent phishing.'
      }
    ]
  },
  {
    id: 'domain-security-dnssec',
    title: 'Domain Security & Essential DNSSEC Tips',
    category: 'Security',
    readTime: '5 min read',
    description: 'Protect your valuable digital assets against domain hijacking, DNS spoofing, and WHOIS spam.',
    icon: 'ShieldCheck',
    sections: [
      {
        title: 'Enable Registry Lock',
        content: 'Domain Lock prevents unauthorized transfer attempts or accidental changes to nameservers by locking status in the registry.'
      },
      {
        title: 'Activate Free WHOIS Privacy',
        content: 'WHOIS privacy replaces your personal address, email, and phone number with proxy contact details to eliminate spam and harassment.'
      },
      {
        title: 'Implement DNSSEC',
        content: 'DNSSEC signs DNS records cryptographically to protect users from cache poisoning and man-in-the-middle spoofing attacks.'
      }
    ]
  },
  {
    id: 'domain-transfer-guide',
    title: 'How to Seamlessly Transfer Domains with Zero Downtime',
    category: 'Transfers',
    readTime: '7 min read',
    description: 'Step-by-step checklist to transfer existing domains to ApexDomain safely without service interruption.',
    icon: 'ArrowRightLeft',
    sections: [
      {
        title: '1. Unlock Domain at Current Registrar',
        content: 'Disable the Transfer Lock setting at your current registrar account.'
      },
      {
        title: '2. Request Authorization (EPP) Code',
        content: 'Generate and copy the secret EPP transfer code from your current domain manager.'
      },
      {
        title: '3. Verify Registrant Email',
        content: 'Ensure your admin contact email is active to receive the ICANN transfer approval confirmation email.'
      },
      {
        title: '4. Initiate Transfer on ApexDomain',
        content: 'Enter your domain and EPP code on our Bulk Transfer wizard. Most transfers complete in 1 to 5 days.'
      }
    ]
  }
];
