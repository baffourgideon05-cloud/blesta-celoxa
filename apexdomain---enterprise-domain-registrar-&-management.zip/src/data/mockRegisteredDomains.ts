import { RegisteredDomain } from '../types';

export const INITIAL_REGISTERED_DOMAINS: RegisteredDomain[] = [
  {
    id: 'reg-celoxa',
    domain: 'celoxaghana.online',
    registeredDate: '2025-01-01',
    expiryDate: '2028-01-01',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-CELOXA-772910-GH',
    status: 'active',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
    dnsRecords: [
      { id: 'dns-celoxa-1', type: 'A', name: '@', value: '198.51.100.42', ttl: 3600 },
      { id: 'dns-celoxa-2', type: 'CNAME', name: 'www', value: 'celoxaghana.online', ttl: 3600 },
      { id: 'dns-celoxa-3', type: 'MX', name: '@', value: 'mail.celoxaghana.online', ttl: 3600, priority: 10 },
      { id: 'dns-celoxa-4', type: 'TXT', name: '@', value: 'v=spf1 include:_spf.apexdomain.com ~all', ttl: 3600 },
      { id: 'dns-celoxa-5', type: 'TXT', name: '_ghana-verification', value: 'celoxa-ghana-verified-active-2026', ttl: 3600 }
    ],
    emailForwarding: [
      { id: 'ef-celoxa-1', source: 'info@celoxaghana.online', destination: 'admin@celoxaghana.online', active: true },
      { id: 'ef-celoxa-2', source: 'support@celoxaghana.online', destination: 'help@celoxaghana.online', active: true }
    ]
  },
  {
    id: 'reg-1',
    domain: 'apexcloud.io',
    registeredDate: '2025-01-15',
    expiryDate: '2027-01-15',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-APEX-992384-IO',
    status: 'active',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com', 'ns3.apexdomain.com'],
    dnsRecords: [
      { id: 'dns-1', type: 'A', name: '@', value: '76.76.21.21', ttl: 3600 },
      { id: 'dns-2', type: 'CNAME', name: 'www', value: 'cname.vercel-dns.com', ttl: 3600 },
      { id: 'dns-3', type: 'MX', name: '@', value: 'ASPMX.L.GOOGLE.COM', ttl: 3600, priority: 1 },
      { id: 'dns-4', type: 'TXT', name: '@', value: 'v=spf1 include:_spf.google.com ~all', ttl: 3600 }
    ],
    emailForwarding: [
      { id: 'ef-1', source: 'contact@apexcloud.io', destination: 'admin@mycompany.com', active: true },
      { id: 'ef-2', source: 'support@apexcloud.io', destination: 'support-team@mycompany.com', active: true }
    ]
  },
  {
    id: 'reg-2',
    domain: 'nexusapp.com',
    registeredDate: '2024-09-10',
    expiryDate: '2026-09-10',
    autoRenew: true,
    locked: true,
    whoisPrivacy: true,
    authCode: 'EPP-NEXUS-881923-COM',
    status: 'expiring_soon',
    nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
    dnsRecords: [
      { id: 'dns-5', type: 'A', name: '@', value: '185.199.108.153', ttl: 300 },
      { id: 'dns-6', type: 'A', name: '@', value: '185.199.109.153', ttl: 300 },
      { id: 'dns-7', type: 'TXT', name: '_github-pages-challenge-nexus', value: '9a8b7c6d5e', ttl: 3600 }
    ],
    emailForwarding: [
      { id: 'ef-3', source: 'hello@nexusapp.com', destination: 'founder@gmail.com', active: true }
    ]
  },
  {
    id: 'reg-3',
    domain: 'venturelabs.ai',
    registeredDate: '2025-05-20',
    expiryDate: '2027-05-20',
    autoRenew: false,
    locked: false,
    whoisPrivacy: true,
    authCode: 'EPP-VENTURE-331002-AI',
    status: 'active',
    nameservers: ['ns1.cloudflare.com', 'ns2.cloudflare.com'],
    dnsRecords: [
      { id: 'dns-8', type: 'NS', name: '@', value: 'ns1.cloudflare.com', ttl: 86400 },
      { id: 'dns-9', type: 'NS', name: '@', value: 'ns2.cloudflare.com', ttl: 86400 }
    ],
    emailForwarding: []
  }
];
