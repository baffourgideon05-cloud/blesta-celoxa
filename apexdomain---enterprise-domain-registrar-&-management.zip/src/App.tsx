import React, { useState, useEffect } from 'react';
import { X, Sparkles, ShoppingCart } from 'lucide-react';
import { 
  Navbar, 
  HeroSearch, 
  SearchFiltersBar, 
  DomainCard, 
  DomainComparisonModal, 
  WhoisModal, 
  RegistrationWizardModal, 
  FloatingCartDrawer, 
  AiDomainBrainModal, 
  BulkDomainTools, 
  DomainManagementHub, 
  TldDirectoryView, 
  LearningHubView, 
  Footer,
  CustomerCommandCenter,
  GlobalAccountSearchModal,
  AdminImpersonationBanner,
  SystemSettingsView,
  HostingProvisionSystem,
  AuthModal,
  VikalinkHomepage,
  StaffPortalView,
  AdminIamManagement,
  InactivityLockModal,
  ClientDashboard,
  VisitorAnalyticsDashboard,
  HostingPackagesFrontendPage,
  AdminHostingPackagesManager,
  AccessDeniedModal
} from './components';

import { 
  DomainResult, 
  CartItem, 
  Currency, 
  ViewMode, 
  RegisteredDomain,
  PaymentMethodSettings,
  PaymentSubmission,
  ImpersonationState,
  GlobalSearchResultItem,
  WhmcsHostingPackage
} from './types';

import { 
  generateDomainResults, 
  filterAndSortResults, 
  getLiveSearchSuggestions 
} from './utils/domainSearchEngine';

import { INITIAL_REGISTERED_DOMAINS } from './data/mockRegisteredDomains';
import { DEFAULT_PAYMENT_SETTINGS, INITIAL_PAYMENT_SUBMISSIONS } from './data/paymentSettings';
import { MOCK_HOSTING_SERVICES, MOCK_INVOICES, MOCK_SUPPORT_TICKETS } from './data/mockCustomerServices';
import { MOCK_WHMCS_PACKAGES } from './data/mockWhmcsData';
import { systemDatabase } from './services/systemDatabase';
import { AccessControlEngine } from './services/accessControlEngine';

export default function App() {
  // Navigation & View Mode
  const [currentView, setCurrentView] = useState<string>('search');
  const [viewMode, setViewMode] = useState<ViewMode>('card');

  // RBAC Access Denied State
  const [accessDeniedState, setAccessDeniedState] = useState<{
    isOpen: boolean;
    reason: string;
    attemptedView: string;
    redirectView: string;
  }>({
    isOpen: false,
    reason: '',
    attemptedView: '',
    redirectView: 'client_portal',
  });

  // Central Router Handler with RBAC Guard
  const handleNavigateView = (targetViewKey: string) => {
    const currentUser = systemDatabase.getCurrentUser();
    const result = AccessControlEngine.canAccessView(currentUser, targetViewKey);

    if (!result.allowed) {
      setAccessDeniedState({
        isOpen: true,
        reason: result.reason || 'Access to this portal view is restricted.',
        attemptedView: targetViewKey,
        redirectView: result.redirectView,
      });
      return;
    }

    setCurrentView(targetViewKey);
  };

  // System Database State & Settings Sync
  const [systemSettings, setSystemSettings] = useState(systemDatabase.getSettings());

  useEffect(() => {
    const unsubscribe = systemDatabase.subscribe((db) => {
      setSystemSettings(db.settings);
    });
    return () => unsubscribe();
  }, []);

  // Universal Search Modal State & Impersonation State
  const [isGlobalSearchOpen, setIsGlobalSearchOpen] = useState(false);
  const [isLocked, setIsLocked] = useState(false);

  // Inactivity Security Auto-Lock Timer (3 Minutes)
  useEffect(() => {
    let idleTimer: any;

    const handleUserActivity = () => {
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        setIsLocked(true);
      }, 3 * 60 * 1000); // 3 minutes of inactivity
    };

    const activityEvents = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];
    activityEvents.forEach((event) => window.addEventListener(event, handleUserActivity));
    handleUserActivity();

    return () => {
      if (idleTimer) clearTimeout(idleTimer);
      activityEvents.forEach((event) => window.removeEventListener(event, handleUserActivity));
    };
  }, []);
  const [impersonation, setImpersonation] = useState<ImpersonationState>({
    isActive: false,
    adminName: '',
    targetCustomerName: '',
    targetCustomerEmail: '',
    reason: '',
    startedAt: '',
  });

  // Global Ctrl+K Shortcut Listener for Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsGlobalSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleTriggerImpersonation = (custName: string, custEmail: string) => {
    setImpersonation({
      isActive: true,
      adminName: 'Chief Administrator',
      targetCustomerName: custName,
      targetCustomerEmail: custEmail,
      reason: 'Staff Diagnostic Session',
      startedAt: new Date().toLocaleTimeString(),
    });
    setCurrentView('command_center');
  };

  const handleExitImpersonation = () => {
    setImpersonation({
      isActive: false,
      adminName: '',
      targetCustomerName: '',
      targetCustomerEmail: '',
      reason: '',
      startedAt: '',
    });
  };

  const handleNavigateFromSearch = (item: GlobalSearchResultItem) => {
    if (item.category === 'domain') {
      setCurrentView('management');
    } else if (item.category === 'hosting' || item.category === 'invoice' || item.category === 'ticket' || item.category === 'customer') {
      setCurrentView('command_center');
    }
  };

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [activeQuery, setActiveQuery] = useState('');
  const [searchHistory, setSearchHistory] = useState<string[]>(['celoxaghana.online', 'nexusapp.com', 'venturelabs.ai', 'cloudstack.io']);
  const [suggestions, setSuggestions] = useState<DomainResult[]>([]);
  const [domainResults, setDomainResults] = useState<DomainResult[]>([]);

  // Filter & Sorting State
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [tldFilter, setTldFilter] = useState('All');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 200]);
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'popular' | 'alpha' | 'score'>('popular');
  const [availabilityOnly, setAvailabilityOnly] = useState(false);

  // Currency & Theme State
  const [currency, setCurrency] = useState<Currency>('GHS');
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Global Cart State with System Database Persistence
  const [cart, setCart] = useState<CartItem[]>(() => systemDatabase.getPersistentCart());
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Sync cart changes to persistent database storage
  useEffect(() => {
    systemDatabase.savePersistentCart(cart);
  }, [cart]);

  // Keep system database state changes (including users, settings, hosting packages, and cart) synced
  useEffect(() => {
    const unsubscribe = systemDatabase.subscribe((db) => {
      setSystemSettings(db.settings);
      if (db.hostingPackages && db.hostingPackages.length > 0) {
        setHostingPackages(systemDatabase.getHostingPackages());
      }
    });
    return () => unsubscribe();
  }, []);

  // Wishlist & Compare State
  const [wishlist, setWishlist] = useState<DomainResult[]>([]);
  const [compareList, setCompareList] = useState<DomainResult[]>([]);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);

  // Modals
  const [whoisDomain, setWhoisDomain] = useState<string | null>(null);
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [isAiBrainOpen, setIsAiBrainOpen] = useState(false);

  // User Registered Domains state (for Management Hub)
  const [userDomains, setUserDomains] = useState<RegisteredDomain[]>(INITIAL_REGISTERED_DOMAINS);

  // Hosting Packages Catalog State
  const [hostingPackages, setHostingPackages] = useState<WhmcsHostingPackage[]>(() => {
    const stored = systemDatabase.getHostingPackages();
    return stored && stored.length > 0 ? stored : MOCK_WHMCS_PACKAGES;
  });

  const handleAddHostingPackage = (newPkg: WhmcsHostingPackage) => {
    setHostingPackages((prev) => [newPkg, ...prev]);
    systemDatabase.saveHostingPackage(newPkg);
  };

  const handleUpdateHostingPackage = (updatedPkg: WhmcsHostingPackage) => {
    setHostingPackages((prev) => prev.map((p) => (p.id === updatedPkg.id ? updatedPkg : p)));
    systemDatabase.saveHostingPackage(updatedPkg);
  };

  const handleDeleteHostingPackage = (id: string) => {
    setHostingPackages((prev) => prev.filter((p) => p.id !== id));
    systemDatabase.deleteHostingPackage(id);
  };

  // Payment Settings & Submissions State
  const [paymentSettings, setPaymentSettings] = useState<PaymentMethodSettings>(DEFAULT_PAYMENT_SETTINGS);
  const [paymentSubmissions, setPaymentSubmissions] = useState<PaymentSubmission[]>(INITIAL_PAYMENT_SUBMISSIONS);

  const handleAddSubmission = (submission: PaymentSubmission) => {
    setPaymentSubmissions((prev) => [submission, ...prev]);

    // If completed immediately (e.g. Paystack / Card), auto-register domains
    if (submission.status === 'completed') {
      submission.domains.forEach((domName) => {
        const newDom: RegisteredDomain = {
          id: `dom-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          domain: domName,
          registeredDate: new Date().toISOString().split('T')[0],
          expiryDate: new Date(Date.now() + 365 * 24 * 3600 * 1000).toISOString().split('T')[0],
          autoRenew: true,
          status: 'active',
          nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
          whoisPrivacy: true,
          locked: true,
          authCode: `EPP-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
          dnsRecords: [
            { id: '1', type: 'A', name: '@', value: '192.0.2.1', ttl: 3600 },
            { id: '2', type: 'CNAME', name: 'www', value: domName, ttl: 3600 },
          ],
          emailForwarding: [],
        };

        setUserDomains((prevD) => {
          if (prevD.some((d) => d.domain === domName)) return prevD;
          return [newDom, ...prevD];
        });
      });
    }
  };

  const handleApproveSubmission = (submissionId: string) => {
    setPaymentSubmissions((prev) =>
      prev.map((sub) => {
        if (sub.id === submissionId) {
          // Provision domains
          sub.domains.forEach((domName) => {
            const newDom: RegisteredDomain = {
              id: `dom-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
              domain: domName,
              registeredDate: new Date().toISOString().split('T')[0],
              expiryDate: new Date(Date.now() + 365 * 24 * 3600 * 1000).toISOString().split('T')[0],
              autoRenew: true,
              status: 'active',
              nameservers: ['ns1.apexdomain.com', 'ns2.apexdomain.com'],
              whoisPrivacy: true,
              locked: true,
              authCode: `EPP-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
              dnsRecords: [
                { id: '1', type: 'A', name: '@', value: '192.0.2.1', ttl: 3600 },
                { id: '2', type: 'CNAME', name: 'www', value: domName, ttl: 3600 },
              ],
              emailForwarding: [],
            };

            setUserDomains((prevD) => {
              if (prevD.some((d) => d.domain === domName)) return prevD;
              return [newDom, ...prevD];
            });
          });

          return { ...sub, status: 'completed' };
        }
        return sub;
      })
    );
  };

  const handleRejectSubmission = (submissionId: string) => {
    setPaymentSubmissions((prev) =>
      prev.map((sub) => (sub.id === submissionId ? { ...sub, status: 'failed' } : sub))
    );
  };

  // Initialize Dark Mode Class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Initial default domain results
  useEffect(() => {
    const initial = generateDomainResults('apexdomain');
    setDomainResults(initial);
  }, []);

  // Handle Search Input Change & Live Suggestions
  const handleQueryChange = (text: string) => {
    setSearchQuery(text);
    if (text.trim().length >= 2) {
      const liveSugg = getLiveSearchSuggestions(text);
      setSuggestions(liveSugg);
    } else {
      setSuggestions([]);
    }
  };

  // Perform Search
  const handleExecuteSearch = (queryToSearch?: string) => {
    const q = queryToSearch || searchQuery;
    if (!q.trim()) return;

    setActiveQuery(q);
    const results = generateDomainResults(q);
    setDomainResults(results);
    setSuggestions([]);

    // Update history
    setSearchHistory((prev) => Array.from(new Set([q.trim(), ...prev])).slice(0, 8));
    setCurrentView('search');
  };

  const handleClearHistory = () => {
    setSearchHistory([]);
  };

  // Cart Operations
  const handleAddToCart = (domain: DomainResult) => {
    const exists = cart.find((item) => item.id === domain.id);
    if (exists) return;

    const newItem: CartItem = {
      ...domain,
      years: 1,
      privacyProtection: true,
      emailForwarding: true,
      dnssecEnabled: false,
      hostingAddon: false,
    };
    setCart((prev) => [...prev, newItem]);
  };

  const handleHostingAddToCart = (
    pkgOrItem: WhmcsHostingPackage | CartItem,
    boundDomain?: string,
    billingCycle: 'monthly' | 'annually' | 'triennially' = 'annually',
    serverRegion: string = 'US-East Equinix NY4'
  ) => {
    let newItem: CartItem;

    if ('itemType' in pkgOrItem && pkgOrItem.itemType === 'hosting') {
      newItem = pkgOrItem as CartItem;
    } else {
      const pkg = pkgOrItem as WhmcsHostingPackage;
      const targetDom = boundDomain || userDomains[0]?.domain || 'mysite.com';
      let price = pkg.priceAnnually;
      let years = 1;

      if (billingCycle === 'monthly') {
        price = pkg.priceMonthly;
        years = 1;
      } else if (billingCycle === 'annually') {
        price = pkg.priceAnnually;
        years = 1;
      } else if (billingCycle === 'triennially') {
        price = pkg.priceAnnually * 2.5;
        years = 3;
      }

      newItem = {
        id: `cart-hosting-${pkg.id}-${Date.now()}`,
        domain: targetDom,
        tld: targetDom.split('.').pop() || 'com',
        registrationPrice: price,
        renewalPrice: price,
        years,
        privacyProtection: true,
        emailForwarding: true,
        dnssecEnabled: true,
        hostingAddon: false,
        icannFee: 0,
        isPremium: false,
        itemType: 'hosting',
        packageName: pkg.name,
        planId: pkg.id,
        billingCycle,
        serverRegion,
        diskLimitMb: pkg.diskLimitMb,
        bandwidthLimitGb: pkg.bandwidthLimitGb,
        module: pkg.module,
      };
    }

    setCart((prev) => {
      const exists = prev.some((item) => item.id === newItem.id);
      if (exists) return prev;
      return [...prev, newItem];
    });

    setIsCartOpen(true);
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const handleUpdateCartYears = (id: string, years: number) => {
    setCart((prev) =>
      prev.map((item) => (item.id === id ? { ...item, years } : item))
    );
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Wishlist Toggle
  const handleToggleWishlist = (domain: DomainResult) => {
    setWishlist((prev) => {
      const exists = prev.some((d) => d.id === domain.id);
      if (exists) {
        return prev.filter((d) => d.id !== domain.id);
      } else {
        return [...prev, domain];
      }
    });
  };

  // Compare Toggle
  const handleToggleCompare = (domain: DomainResult) => {
    setCompareList((prev) => {
      const exists = prev.some((d) => d.id === domain.id);
      if (exists) {
        return prev.filter((d) => d.id !== domain.id);
      } else {
        if (prev.length >= 10) return prev; // max 10
        return [...prev, domain];
      }
    });
  };

  const handleRemoveFromCompare = (id: string) => {
    setCompareList((prev) => prev.filter((d) => d.id !== id));
  };

  // Reset Filters
  const handleResetFilters = () => {
    setCategoryFilter('All');
    setTldFilter('All');
    setPriceRange([0, 200]);
    setSortBy('popular');
    setAvailabilityOnly(false);
  };

  // Apply filters and sorting to search results
  const filteredResults = filterAndSortResults(domainResults, {
    category: categoryFilter,
    tld: tldFilter,
    minPrice: priceRange[0],
    maxPrice: priceRange[1],
    sortBy,
    availabilityOnly,
  });

  const cartItemIds = cart.map((i) => i.id);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      
      {/* Staff Impersonation Sticky Warning Banner */}
      <AdminImpersonationBanner
        impersonation={impersonation}
        onExitImpersonation={handleExitImpersonation}
      />

      {/* Navigation Header */}
      <Navbar
        currentView={currentView}
        setCurrentView={handleNavigateView}
        setActiveTab={handleNavigateView}
        siteName={systemSettings.general.siteName}
        logoUrl={systemSettings.general.logoUrl}
        cartCount={cart.length}
        compareCount={compareList.length}
        wishlistCount={wishlist.length}
        userDomainsCount={userDomains.length}
        currency={currency}
        setCurrency={setCurrency}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAiBrain={() => setIsAiBrainOpen(true)}
        onOpenSearch={() => setIsGlobalSearchOpen(true)}
        onOpenCommandCenter={() => setCurrentView('command_center')}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onLockSession={() => setIsLocked(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* VIEW 0: UNIVERSAL CLIENT PORTAL & DASHBOARD */}
        {['client_portal', 'dashboard', 'command_center', 'services', 'billing', 'wallet', 'renewals', 'calendar', 'team', 'tickets', 'timeline', 'security'].includes(currentView) && (
          <CustomerCommandCenter
            registeredDomains={userDomains}
            onOpenDomainHub={(domainName) => setCurrentView('management')}
            isAdmin={systemDatabase.getCurrentUser()?.platformRole === 'super_admin' || systemDatabase.getCurrentUser()?.role === 'super_admin' || systemDatabase.getCurrentUser()?.role === 'admin'}
            onTriggerImpersonation={handleTriggerImpersonation}
            currency={currency}
            onOpenSearch={() => setIsGlobalSearchOpen(true)}
            initialTab={
              currentView === 'services' ? 'services' :
              currentView === 'billing' ? 'billing' :
              currentView === 'wallet' ? 'wallet' :
              currentView === 'renewals' ? 'renewals' :
              currentView === 'calendar' ? 'calendar' :
              currentView === 'team' ? 'team' :
              currentView === 'tickets' ? 'tickets' :
              currentView === 'timeline' ? 'timeline' :
              currentView === 'security' ? 'security' : 'overview'
            }
          />
        )}

        {/* VIEW 1: DOMAIN SEARCH ENGINE & VIKALINK HOMEPAGE */}
        {currentView === 'search' && (
          <div className="space-y-8 pb-12">
            
            {/* Hero Search Section */}
            <HeroSearch
              query={searchQuery}
              onQueryChange={handleQueryChange}
              onSearch={handleExecuteSearch}
              suggestions={suggestions}
              onSelectSuggestion={(sugg) => {
                setSearchQuery(sugg.domain);
                handleExecuteSearch(sugg.domain);
              }}
              searchHistory={searchHistory}
              onClearHistory={handleClearHistory}
              onOpenAiBrain={() => setIsAiBrainOpen(true)}
            />

            {/* ONLY display TLD results and filter controls when domain search is actively being used */}
            {searchQuery.trim().length > 0 || activeQuery.trim().length > 0 ? (
              <div className="space-y-6 animate-in fade-in">
                
                {/* TLD Results Top Dismiss & Overview Header */}
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 rounded-2xl p-4 sm:p-5 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-blue-600/30 border border-blue-400/30 text-cyan-400">
                        <Sparkles className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs text-blue-300 font-extrabold uppercase tracking-wider">Active Search Query</div>
                        <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                          <span>"{searchQuery || activeQuery}"</span>
                          <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-bold border border-cyan-500/30">
                            {filteredResults.length} TLDs Found
                          </span>
                        </h3>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                      {cart.length > 0 && (
                        <button
                          onClick={() => setIsWizardOpen(true)}
                          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all hover:scale-105"
                        >
                          <ShoppingCart className="w-4 h-4" />
                          <span>Checkout ({cart.length})</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setSearchQuery('');
                          setActiveQuery('');
                        }}
                        className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-extrabold text-xs rounded-xl border border-slate-700 hover:border-slate-500 transition-all flex items-center gap-2"
                      >
                        <X className="w-4 h-4 text-rose-400" />
                        <span>Hide TLD Results & Show Homepage</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Results Filter Bar */}
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <SearchFiltersBar
                    resultsCount={filteredResults.length}
                    viewMode={viewMode}
                    onViewModeChange={setViewMode}
                    selectedCategory={categoryFilter}
                    onCategoryChange={setCategoryFilter}
                    tldFilter={tldFilter}
                    onTldFilterChange={setTldFilter}
                    priceRange={priceRange}
                    onPriceRangeChange={setPriceRange}
                    sortBy={sortBy}
                    onSortByChange={setSortBy}
                    availabilityOnly={availabilityOnly}
                    onAvailabilityOnlyChange={setAvailabilityOnly}
                    onResetFilters={handleResetFilters}
                  />
                </div>

                {/* Results Grid Container */}
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  {filteredResults.length === 0 ? (
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center space-y-4 shadow-sm">
                      <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
                        🔍
                      </div>
                      <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200">No Domains Match Your Filters</h3>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto">
                        Try adjusting your price range, resetting TLD extensions, or unchecking availability-only filter.
                      </p>
                      <button
                        onClick={handleResetFilters}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  ) : viewMode === 'table' ? (
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
                      <table className="w-full text-left">
                        <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase text-[10px] border-b border-slate-200 dark:border-slate-700">
                          <tr>
                            <th className="py-3 px-4">Domain</th>
                            <th className="py-3 px-4">Status</th>
                            <th className="py-3 px-4">Price</th>
                            <th className="py-3 px-4 hidden md:table-cell">Setup</th>
                            <th className="py-3 px-4 text-right">Quick Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredResults.map((domain) => (
                            <DomainCard
                              key={domain.id}
                              domain={domain}
                              viewMode={viewMode}
                              currency={currency}
                              isInCart={cartItemIds.includes(domain.id)}
                              isWishlisted={wishlist.some((w) => w.id === domain.id)}
                              isCompared={compareList.some((c) => c.id === domain.id)}
                              onAddToCart={handleAddToCart}
                              onToggleWishlist={handleToggleWishlist}
                              onToggleCompare={handleToggleCompare}
                              onOpenWhois={(dName) => setWhoisDomain(dName)}
                            />
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className={
                      viewMode === 'card' 
                        ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6'
                        : viewMode === 'compact'
                        ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3'
                        : 'space-y-4' // list view
                    }>
                      {filteredResults.map((domain) => (
                        <DomainCard
                          key={domain.id}
                          domain={domain}
                          viewMode={viewMode}
                          currency={currency}
                          isInCart={cartItemIds.includes(domain.id)}
                          isWishlisted={wishlist.some((w) => w.id === domain.id)}
                          isCompared={compareList.some((c) => c.id === domain.id)}
                          onAddToCart={handleAddToCart}
                          onToggleWishlist={handleToggleWishlist}
                          onToggleCompare={handleToggleCompare}
                          onOpenWhois={(dName) => setWhoisDomain(dName)}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* When domain search is NOT active, display the Vikalink Homepage showcase */
              <VikalinkHomepage
                onExecuteSearch={(term) => {
                  setSearchQuery(term);
                  handleExecuteSearch(term);
                }}
                currency={currency}
                onOpenAuthModal={() => setIsAuthModalOpen(true)}
                onOpenHostingModal={() => setCurrentView('hosting_provision')}
                onAddToCart={handleAddToCart}
                onOpenCart={() => setIsWizardOpen(true)}
                hostingPackages={hostingPackages}
                cartItems={cart}
              />
            )}

          </div>
        )}

        {/* VIEW 2: BULK DOMAIN TOOLS */}
        {currentView === 'bulk' && (
          <BulkDomainTools
            currency={currency}
            onAddToCart={handleAddToCart}
            cartItemIds={cartItemIds}
          />
        )}

        {/* VIEW 3: DOMAIN MANAGEMENT HUB */}
        {currentView === 'management' && (
          <DomainManagementHub
            domains={userDomains}
            setDomains={setUserDomains}
            paymentSettings={paymentSettings}
            onUpdatePaymentSettings={setPaymentSettings}
            paymentSubmissions={paymentSubmissions}
            onApproveSubmission={handleApproveSubmission}
            onRejectSubmission={handleRejectSubmission}
            currency={currency}
          />
        )}

        {/* VIEW 4: TLD DIRECTORY */}
        {currentView === 'tlds' && (
          <TldDirectoryView
            currency={currency}
            onSearchTld={(tld) => {
              setSearchQuery(tld);
              handleExecuteSearch(tld);
            }}
          />
        )}

        {/* VIEW 5: ACADEMY & LEARNING HUB */}
        {currentView === 'academy' && <LearningHubView />}

        {/* VIEW 6: VISITOR ANALYTICS DASHBOARD */}
        {currentView === 'visitor_analytics' && (
          <VisitorAnalyticsDashboard
            currency={currency}
            onNavigate={(view) => setCurrentView(view)}
          />
        )}

        {/* VIEW 7: SYSTEM SETTINGS CONTROL PANEL */}
        {currentView === 'settings' && (
          <SystemSettingsView
            currency={currency}
            settings={systemSettings}
            onSaveSettings={(newSettings) => systemDatabase.updateSettings(newSettings)}
          />
        )}

        {/* VIEW 8: HOSTING PROVISION SYSTEM */}
        {currentView === 'hosting_provision' && (
          <HostingProvisionSystem
            currency={currency}
            onNavigateToSettings={() => setCurrentView('settings')}
          />
        )}

        {/* VIEW 9: STAFF INTERNAL OPERATIONS PORTAL */}
        {currentView === 'staff_portal' && (
          <StaffPortalView
            currentUser={systemDatabase.getCurrentUser() || {
              id: 'staff-demo-1',
              email: 'support@celoxaghana.online',
              fullName: 'Kofi Mensah',
              role: 'staff',
              platformRole: 'staff',
              department: 'Technical Support',
              staffTitle: 'Senior Infrastructure Engineer',
              permissions: systemDatabase.getUserPermissions('staff-demo-1')
            }}
            onTriggerImpersonation={(custName, custEmail) => {
              handleTriggerImpersonation(custName, custEmail);
              setCurrentView('command_center');
            }}
          />
        )}

        {/* VIEW 10: ADMIN IDENTITY & ACCESS MANAGEMENT (IAM) */}
        {currentView === 'admin_iam' && (
          <AdminIamManagement
            currentUser={systemDatabase.getCurrentUser() || {
              id: 'usr-admin-1',
              email: 'admin@celoxaghana.online',
              fullName: 'Chief Super Admin',
              role: 'super_admin',
              platformRole: 'super_admin',
              department: 'Executive Leadership',
              staffTitle: 'Head of Infrastructure & Security',
              permissions: systemDatabase.getUserPermissions('usr-admin-1')
            }}
          />
        )}

        {/* VIEW 11: FRONTEND HOSTING PACKAGES STOREFRONT */}
        {currentView === 'hosting_packages' && (
          <HostingPackagesFrontendPage
            hostingPackages={hostingPackages}
            cartItems={cart}
            onAddToCart={handleHostingAddToCart}
            onOpenCart={() => setIsCartOpen(true)}
            userDomains={userDomains.map((d) => d.domain)}
            currency={currency}
            onNavigateView={(v) => setCurrentView(v)}
          />
        )}

        {/* VIEW 12: ADMIN HOSTING PACKAGES & SERVER CLUSTER MANAGER */}
        {currentView === 'admin_hosting_packages' && (
          <AdminHostingPackagesManager
            hostingPackages={hostingPackages}
            onAddPackage={handleAddHostingPackage}
            onUpdatePackage={handleUpdateHostingPackage}
            onDeletePackage={handleDeleteHostingPackage}
            currency={currency}
          />
        )}

      </main>

      {/* Footer */}
      <Footer 
        onNavigate={setCurrentView} 
        siteName={systemSettings.general.siteName}
        companyName={systemSettings.general.companyName}
        logoUrl={systemSettings.general.logoUrl}
      />

      {/* Floating Compare Button Bar */}
      {compareList.length > 0 && (
        <div className="fixed bottom-6 right-6 z-40 bg-slate-900 text-white rounded-2xl p-4 shadow-2xl border border-indigo-500/40 flex items-center gap-4 animate-in slide-in-from-bottom-5">
          <div className="text-xs">
            <span className="font-extrabold text-indigo-400">{compareList.length} Domains</span> selected to compare
          </div>
          <button
            onClick={() => setIsCompareModalOpen(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all"
          >
            Compare Side-by-Side
          </button>
        </div>
      )}

      {/* Side-by-Side Comparison Modal */}
      {isCompareModalOpen && (
        <DomainComparisonModal
          compareList={compareList}
          currency={currency}
          onClose={() => setIsCompareModalOpen(false)}
          onRemoveFromCompare={handleRemoveFromCompare}
          onAddToCart={handleAddToCart}
          cartItemIds={cartItemIds}
        />
      )}

      {/* WHOIS Modal */}
      {whoisDomain && (
        <WhoisModal
          domainName={whoisDomain}
          onClose={() => setWhoisDomain(null)}
        />
      )}

      {/* Slide-over Cart Drawer */}
      <FloatingCartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onRemoveItem={handleRemoveFromCart}
        onUpdateYears={handleUpdateCartYears}
        onStartWizard={() => setIsWizardOpen(true)}
        currency={currency}
      />

      {/* Registration Checkout Wizard */}
      {isWizardOpen && (
        <RegistrationWizardModal
          cartItems={cart}
          currency={currency}
          paymentSettings={paymentSettings}
          userDomains={userDomains}
          onClose={() => setIsWizardOpen(false)}
          onClearCart={handleClearCart}
          onOrderComplete={() => {
            setCurrentView('management');
          }}
          onAddSubmission={handleAddSubmission}
        />
      )}

      {/* AI Domain Brain Modal */}
      <AiDomainBrainModal
        isOpen={isAiBrainOpen}
        onClose={() => setIsAiBrainOpen(false)}
        currency={currency}
        onAddToCart={handleAddToCart}
        cartItemIds={cartItemIds}
      />

      {/* Global Account Search Modal */}
      <GlobalAccountSearchModal
        isOpen={isGlobalSearchOpen}
        onClose={() => setIsGlobalSearchOpen(false)}
        registeredDomains={userDomains}
        hostingServices={MOCK_HOSTING_SERVICES}
        invoices={MOCK_INVOICES}
        tickets={MOCK_SUPPORT_TICKETS}
        isAdmin={true}
        onNavigateItem={handleNavigateFromSearch}
      />

      {/* Account System & Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currency={currency}
        onNavigateToView={setCurrentView}
      />

      {/* Security Session Lock Screen Modal */}
      <InactivityLockModal
        isOpen={isLocked}
        user={systemDatabase.getCurrentUser() || {
          id: 'usr-admin-default',
          email: 'baffourgideon05@gmail.com',
          fullName: 'Gideon Baffour (Admin)',
          role: 'super_admin',
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop',
          status: 'active',
          mfaEnabled: true,
          createdAt: new Date().toISOString()
        }}
        onUnlock={(pwd) => {
          const userEmail = systemDatabase.getCurrentUser()?.email || 'baffourgideon05@gmail.com';
          const valid = systemDatabase.verifyUserPassword(userEmail, pwd);
          if (valid) {
            setIsLocked(false);
            return true;
          }
          return false;
        }}
        onUnlockWithGoogle={() => {
          systemDatabase.loginOrRegisterWithGoogle({
            fullName: 'Gideon Baffour',
            email: 'baffourgideon05@gmail.com',
            avatarUrl: 'https://lh3.googleusercontent.com/a/default-user=s96-c'
          });
          setIsLocked(false);
        }}
        onLogout={() => {
          systemDatabase.logoutUser();
          setIsLocked(false);
        }}
      />

    </div>
  );
}
